// Angular modules
import { NgModule } from '@angular/core';
import { MultiSelectModule } from 'primeng/primeng';
import { SharedModule } from '../shared/shared.module';
import { AprovacaoSolicitacaoModule } from './aprovacao-manutencao-preventiva/aprovacao-solicitacao.module';

@NgModule({
    imports: [
        SharedModule,
        AprovacaoSolicitacaoModule,
        MultiSelectModule,
    ],
    providers: [
    ]
})
export class AprovacaoModule {}
