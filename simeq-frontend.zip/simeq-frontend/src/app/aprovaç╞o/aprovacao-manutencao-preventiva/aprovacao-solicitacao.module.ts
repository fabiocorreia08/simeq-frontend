import { NgModule } from '@angular/core';
import { InputMaskModule, DataTableModule, DropdownModule, InputTextareaModule, CheckboxModule, CalendarModule } from 'primeng/primeng';
import { FormsModule } from '@angular/forms';
import { CoreModule } from '../../core/core.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ButtonModule } from 'primeng/components/button/button';
import { TextMaskModule } from "angular2-text-mask";
import { AprovacaoSolicitacaoRoutingModule } from './aprovacao-solicitacao-routing.module';
import { AprovarSolicitacaoComponent } from './components/aprovar-solicitacao/aprovar-solicitacao.component';
import { AprovacaoSolicitacaoService } from './services/aprovacao-solicitacao.service';
import { SharedModule } from '../../shared/shared.module';

@NgModule({
    declarations: [
        AprovarSolicitacaoComponent
    ],
    imports: [
        AprovacaoSolicitacaoRoutingModule,
        FormsModule,
        BrowserAnimationsModule,
        ButtonModule,
        CoreModule,
        InputMaskModule,
        InputTextareaModule,
        DataTableModule,
        DropdownModule,
        CalendarModule,
        CheckboxModule,
        TextMaskModule,
        SharedModule
    ],

    providers: [
        AprovacaoSolicitacaoService
    ]
})
export class AprovacaoSolicitacaoModule {}
