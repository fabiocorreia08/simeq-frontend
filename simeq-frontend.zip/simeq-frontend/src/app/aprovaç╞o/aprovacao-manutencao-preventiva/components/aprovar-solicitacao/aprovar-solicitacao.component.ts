import { CalendarLocaleService } from '../../../../core/calendar.locale.service';
import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { BreadcrumbService } from '../../../../core/breadcrumb/breadcrumb.service';
import { Location } from '@angular/common';
import { MessagesService } from '../../../../core/messages/messages.service';
import { ActivatedRoute } from '@angular/router';
import { AprovacaoGenericComponent } from '../../../aprovacao-generic.component';
import { AuthenticationService } from '../../../../core/security/auth.service';
import { Pagina } from '../../../../core/models/pagina.model';

import { LazyLoadEvent } from 'primeng/components/common/api';

import { isNullOrUndefined } from 'util';
import { PerfisConstants } from '../../../../core/security/perfis.constants';
import { LabelValue } from '../../../../core/models/label-value';
import { ArrayUtil } from '../../../../shared/Utils/ArrayUtil';
import { AprovacaoManutencaoPreventivaFiltro } from '../../models/aprovacao-manutencao-preventiva-filtro.model';
import { EquipamentoService } from '../../../../administracao/equipamento/services/equipamento.service';
import { AprovacaoPreventivaConsultaTabela } from '../../models/aprovacao-preventiva-consulta-tabela.model';
import { CentroCustoService } from '../../../../shared/services/centro-custo.service';
import { ManutencaoPreventivaService } from '../../../../manutencao/services/manutencao-preventiva.service';
import { AprovacaoReprovacaoManutencaoPreventivaDTO } from '../../models/aprovacao-reprovacao-manutencao-preventiva.dto';
import { AprovacaoSolicitacaoService } from '../../services/aprovacao-solicitacao.service';
import { ManutencaoCorretivaService } from '../../../../manutencao/services/manutencao-corretiva.service';
import { ModalConfirmacaoComponent } from '../../../../core/modal-confirmacao/modal-confirmacao.component';
import { PreventivaCadastro } from '../../../../manutencao/models/preventiva-cadastro.model';
import { Dialog } from 'primeng/primeng';
import * as moment from 'moment';

declare var $: any;

@Component({
  selector: 'simeq-aprovar-solicitacao',
  templateUrl: './aprovar-solicitacao.component.html',
  styleUrls: ['./aprovar-solicitacao.component.scss']
})
export class AprovarSolicitacaoComponent extends AprovacaoGenericComponent implements OnInit {

  @ViewChild('modalConfirmaAprovacao')
  modalConfirmaAprovacao: ModalConfirmacaoComponent;  
  
  public filtro: AprovacaoManutencaoPreventivaFiltro = new AprovacaoManutencaoPreventivaFiltro;
  public listaCentrosCusto: LabelValue[] = [];
  public listaAnos: LabelValue[] = [];
  public listaEquipamento: LabelValue[] = [];
  public pagina: Pagina<AprovacaoPreventivaConsultaTabela> = new Pagina<AprovacaoPreventivaConsultaTabela>();
  public solicitacoesSelecionadas: AprovacaoPreventivaConsultaTabela[] = [];
  public aprovacaoReprovacaoManutencaoPreventiva: AprovacaoReprovacaoManutencaoPreventivaDTO = new AprovacaoReprovacaoManutencaoPreventivaDTO();  
  private divModalMotivoReprovacao: any;
  private divModalReprogramacao: any;
  private divModalSugestao: any;
  public btPesquisar: boolean = false;
  public listaMes: LabelValue[] = [];
  public numeroSolicitacao;
  public preventivaCadastro: PreventivaCadastro = new PreventivaCadastro();

  public sugestao: any;

  constructor(breadcrumbService: BreadcrumbService,
    protected messagesService: MessagesService,
    private route: ActivatedRoute,
    private location: Location,
    public calendarLocaleService: CalendarLocaleService,
    public authenticationService: AuthenticationService,
    private equipamentoService: EquipamentoService,
    public auth: AuthenticationService,
    private centroCustoService: CentroCustoService,    
    private manutencaoPreventivaService: ManutencaoPreventivaService,
    public aprovacaoSolicitacaoService: AprovacaoSolicitacaoService,
  ) {
    super(messagesService);
    breadcrumbService.addRoute('/app/manutencao/preventiva/consultar', 'Preventivas', true);
    breadcrumbService.addRoute('/app/aprovacao/aprovar-solicitacao', 'Aprovar Calendários', false);
    breadcrumbService.addRoute('/app/aprovacao/aprovar-solicitacao', 'Consultar', false);
  }

  ngOnInit() {
    this.carregarEquipamentos();
    this.carregarCentroCusto();
    this.carregarMeses();
    this.carregarAno();
    this.btPesquisar = false; 
  }

  public carregarEquipamentos(): void {
    this.equipamentoService.buscarTodosLabelValue().subscribe(e => {
      this.listaEquipamento = e;
      this.listaEquipamento = ArrayUtil.adicionarPrimeiroValor(this.listaEquipamento, 'Selecione', null);
    });
  }

  public carregarCentroCusto(): void {
    let idPerfil = this.auth.getIdPerfil(this.auth.authInfo.details.perfis);
    if (isNullOrUndefined(idPerfil)) {
      idPerfil = 0;
    }
    this.centroCustoService.buscarCentroCustoHierarquiaUsuarioLogadoPerfil(idPerfil, this.auth.authInfo.username)
      .subscribe(c => {
        this.listaCentrosCusto = c;
        this.listaCentrosCusto = ArrayUtil.adicionarPrimeiroValor(this.listaCentrosCusto, 'Selecione', null);
      });
  }

  public carregarMeses(): void {
    this.aprovacaoSolicitacaoService.buscarTodosMeses()
      .subscribe(m => {
        this.listaMes = m;        
        this.listaMes = ArrayUtil.adicionarPrimeiroValor(this.listaMes, 'Selecione', null);
      });      
  }

  public carregarAno(): void {
    let dataAtual = new Date();
    this.listaAnos.push(new LabelValue((dataAtual.getFullYear() - 1).toString(), (dataAtual.getFullYear() - 1)));
    this.listaAnos.push(new LabelValue(dataAtual.getFullYear().toString(), dataAtual.getFullYear()));
    this.listaAnos.push(new LabelValue((dataAtual.getFullYear() + 1).toString(), (dataAtual.getFullYear() + 1)));
    this.listaAnos = ArrayUtil.adicionarPrimeiroValor(this.listaAnos, 'Selecione', null);
  }

  public pesquisar(): void {    
    this.solicitacoesSelecionadas = [];
    this.filtro.matricula = this.auth.authInfo.username;
    this.filtro.perfil = this.auth.getIdPerfil(this.auth.authInfo.details.perfis);
    this.pagina = new Pagina();
    this.btPesquisar = true;
    this.filtrar();
  }

  public filtrar(): void {
    if (this.camposObrigatoriosPreenchidos()) {
      this.manutencaoPreventivaService.filtrarManutencaoAprovacao(this.filtro, this.pagina)
        .subscribe((pagina) => {
          this.pagina = pagina;
        },
          (error) => {
            this.messagesService.addErrorMessage(error);
          });
    }
  }

  public paginar(event: LazyLoadEvent): void {
    this.pagina = new Pagina<AprovacaoPreventivaConsultaTabela>(event.first, event.rows);
    if (this.btPesquisar) {
      this.filtrar();
    }
  }

  public reprogramar() {
    this.beforeAprovarReprovar();
    if (this.validarCamposObrigatoriosReprogramar()) {
      this.aprovacaoSolicitacaoService.reprogramar(this.aprovacaoReprovacaoManutencaoPreventiva).subscribe(codigo => {
        this.messagesService.addSuccessMessage("Avaliação de solicitação reprogramada com sucesso.");
        this.divModalMotivoReprovacao = $('#id-modal-reprogramacao').modal('hide');
        this.resetar();
        this.aprovacaoSolicitacaoService.enviarEmailReprovacao(this.aprovacaoReprovacaoManutencaoPreventiva).subscribe(() => {
        }, error => {
          //this.messagesService.addErrorMessage(error);
        });
      }, error => {
        this.messagesService.addErrorMessage(error);
      });
    }
  }

  public reprovar() {
    this.beforeAprovarReprovar();
    if (this.validarCamposObrigatoriosReprovar()) {
      this.aprovacaoSolicitacaoService.reprovar(this.aprovacaoReprovacaoManutencaoPreventiva).subscribe(codigo => {
        this.messagesService.addSuccessMessage("Avaliação de solicitação reprovada com sucesso.");
        this.divModalMotivoReprovacao = $('#id-modal-motivo-reprovacao').modal('hide');
        this.resetar();
        this.aprovacaoSolicitacaoService.enviarEmailReprovacao(this.aprovacaoReprovacaoManutencaoPreventiva).subscribe(() => {
        }, error => {
          //this.messagesService.addErrorMessage(error);
        });
      }, error => {
        this.messagesService.addErrorMessage(error);
      });
    }
  }

  private resetar() {
    this.aprovacaoReprovacaoManutencaoPreventiva.motivo = null;
    this.aprovacaoReprovacaoManutencaoPreventiva.diaInicio = null;
    this.aprovacaoReprovacaoManutencaoPreventiva.diaFim = null;
    this.solicitacoesSelecionadas = [];
    this.filtrar();
  }

  public cancelarReprovar() {
    this.aprovacaoReprovacaoManutencaoPreventiva.motivo = null;
    this.divModalMotivoReprovacao = $('#id-modal-motivo-reprovacao').modal('hide');
  }

  public cancelarReprogramar() {
    this.aprovacaoReprovacaoManutencaoPreventiva.diaInicio = null;
    this.aprovacaoReprovacaoManutencaoPreventiva.diaFim = null;
    this.divModalReprogramacao = $('#id-modal-reprogramacao').modal('hide');
  }

  public abrirModalMotivoReprovacao() {
    this.divModalReprogramacao = $('#id-modal-motivo-reprovacao').modal('show');
  }

  public abrirModalReprogramacao() {
    this.beforeReprogramar();
    this.manutencaoPreventivaService.buscarPorId(this.aprovacaoReprovacaoManutencaoPreventiva.ids[0]).subscribe(m => {         
        
    let dataAtual = moment(); // Data de hoje
          
    let dia = m.diaInicio;
    let mes = m.mes;
    let ano = m.ano;    
                  
    let dataSolicitacao = moment(ano+'-'+ mes+'-'+dia); // Data solicitacao   

    if(dataAtual.isAfter(dataSolicitacao, 'month')) {
      this.messagesService.addErrorMessage('Não é possível reprogramar após mês da solicitação.');           
    } else{
      this.divModalReprogramacao = $('#id-modal-reprogramacao').modal('show');
    } 
    });    
  }

  exibirSugestao(numeroSolicitacao): void{        
    this.manutencaoPreventivaService.buscarPreventivaPorNumeroSolicitacao(numeroSolicitacao).subscribe(m => {         
      this.filtro.sugestao = m.justificativa;   
    });    
  }

  fecharModalSugestao(){        
    this.filtro.sugestao = null;   
  }

  private validarCamposObrigatoriosReprovar(): boolean {
    if (isNullOrUndefined(this.aprovacaoReprovacaoManutencaoPreventiva.motivo) || this.aprovacaoReprovacaoManutencaoPreventiva.motivo.length == 0) {
      this.mostrarMensagemCamposObrigatorios(['Motivo da Reprovação']);
      return false;
    }
    return true;
  }

  private validarCamposObrigatoriosReprogramar(): boolean {
    if (isNullOrUndefined(this.aprovacaoReprovacaoManutencaoPreventiva.motivo) || this.aprovacaoReprovacaoManutencaoPreventiva.motivo.length == 0) {
      this.mostrarMensagemCamposObrigatorios(['Motivo da Reprogramação']);
      return false;
    }
    return true;
  }

  private beforeAprovarReprovar() {
    this.aprovacaoReprovacaoManutencaoPreventiva.ids = [];
    this.aprovacaoReprovacaoManutencaoPreventiva.matriculaUsuarioLogado = this.authenticationService.authInfo.username;
    this.solicitacoesSelecionadas.forEach(solicitacao => {
      this.aprovacaoReprovacaoManutencaoPreventiva.ids.push(solicitacao.idManutencao);
    });
  }

  private beforeReprogramar() {
    this.aprovacaoReprovacaoManutencaoPreventiva.ids = [];    
    this.solicitacoesSelecionadas.forEach(solicitacao => {
      this.aprovacaoReprovacaoManutencaoPreventiva.ids.push(solicitacao.idManutencao);
    });
  }

  public aprovar() {
    this.beforeAprovarReprovar();
    this.manutencaoPreventivaService.buscarPorId(this.aprovacaoReprovacaoManutencaoPreventiva.ids[0]).subscribe(m => {    
      
      let dataAtual = moment(); // Data de hoje
          
      let dia = m.diaInicio;
      let mes = m.mes;
      let ano = m.ano;
                  
      let dataSolicitacao = moment(ano+'-'+ mes+'-'+dia); // Data solicitacao   
                  
      if(dataAtual.isAfter(dataSolicitacao, 'day')) {      
        this.messagesService.addErrorMessage('Não é possível aprovar após dia da solicitação.');             
      } else{
        this.modalConfirmaAprovacao.showDialog().subscribe(success => {
          if (success) {
            this.aprovacaoSolicitacaoService.aprovar(this.aprovacaoReprovacaoManutencaoPreventiva).subscribe(codigo => {
              this.messagesService.addSuccessMessage("Avaliação de solicitação aprovada com sucesso.");
              this.divModalMotivoReprovacao = $('#id-modal-motivo-reprovacao').modal('hide');
              this.resetar();
              this.aprovacaoSolicitacaoService.enviarEmailAprovacao(this.aprovacaoReprovacaoManutencaoPreventiva).subscribe(() => {
              }, error => {
                //this.messagesService.addErrorMessage(error);
              });
            }, error => {
              this.messagesService.addErrorMessage(error);
            });        
          }
        });
      }
      });   
  }

  private camposObrigatoriosPreenchidos(): boolean {
    let campos: string[] = [];
    if (isNullOrUndefined(this.filtro.centroCusto)) {
      campos.push("Centro de Custo");
    }
    if (isNullOrUndefined(this.filtro.mes)) {
      campos.push("Mês");
    }
    if (isNullOrUndefined(this.filtro.ano)) {
      campos.push("Ano");
    }    

    if (campos.length > 0) {
      this.mostrarMensagemCamposObrigatorios(campos);
      return false;
    }
    return true;
  }

  public isUsuarioLogadoVisitante(): boolean {
    return this.authenticationService.getPerfil(PerfisConstants.VISITANTE);
  }

  exibirInformacao(numeroSolicitacao): void{        
    this.manutencaoPreventivaService.buscarPreventivaPorNumeroSolicitacao(numeroSolicitacao).subscribe(m => {         
      this.sugestao = m.sugestao;     
      this.numeroSolicitacao = m.numeroSolicitacao;
    }); 
    
  } 

  atualizar(){    
    this.manutencaoPreventivaService.buscarPreventivaPorNumeroSolicitacao(this.numeroSolicitacao).subscribe(m => { 
      this.preventivaCadastro = m;  
      this.preventivaCadastro.sugestao = this.sugestao;      
      this.manutencaoPreventivaService.atualizar(this.preventivaCadastro)
        .subscribe(mp => {          
          this.messagesService.addSuccessMessage('Operação realizado com sucesso.');
        }, error => {
          this.messagesService.addErrorMessage(error);
        });
    });      
    }

    public desabilitarBotaoAprovar() {
      let dataAtual: Date = new Date();
      if ((this.preventivaCadastro.mes < dataAtual.getMonth() && this.preventivaCadastro.ano === dataAtual.getFullYear())) {
        return true;       
      }
      return false;
    }   

  }


 


