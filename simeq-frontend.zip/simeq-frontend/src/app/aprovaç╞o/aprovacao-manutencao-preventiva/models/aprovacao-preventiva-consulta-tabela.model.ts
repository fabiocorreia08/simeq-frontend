export class AprovacaoPreventivaConsultaTabela {
  public idManutencao: number;
  public numeroSolicitacao: string;
  public codigoManutencao: string;
  public centroCusto: string;
  public mes: number;
  public dataInicio: number;
  public dataFim: number; 
  public qtdHoras: string;
}
