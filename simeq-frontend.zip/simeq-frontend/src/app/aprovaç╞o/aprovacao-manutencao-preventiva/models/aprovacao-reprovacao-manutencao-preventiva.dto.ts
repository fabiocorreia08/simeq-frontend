export class AprovacaoReprovacaoManutencaoPreventivaDTO {
    ids: number[];
    motivo: string;
    matriculaUsuarioLogado: string;
    diaInicio: number;
    diaFim: number;
}