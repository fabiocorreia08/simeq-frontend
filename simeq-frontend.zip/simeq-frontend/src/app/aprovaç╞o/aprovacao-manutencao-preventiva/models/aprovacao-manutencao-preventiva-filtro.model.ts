
export class AprovacaoManutencaoPreventivaFiltro {    
  public centroCusto: string;
  public mes: number; 
  public ano: number;  
  public matricula: string;
  public perfil: number;
  public sugestao: string;
}
