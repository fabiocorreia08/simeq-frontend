import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MainComponent } from '../../main/main.component';

import { AuthGuard } from '../../core/security/auth.guard';
import { AuthenticationService } from '../../core/security/auth.service';
import { PerfisConstants } from '../../core/security/perfis.constants';
import { AprovarSolicitacaoComponent } from './components/aprovar-solicitacao/aprovar-solicitacao.component';

const routes: Routes = [
    { path: 'app', component: MainComponent,
        children: [
            { 
                path: 'aprovacao/aprovar-solicitacao', 
                component: AprovarSolicitacaoComponent,
                canActivate: [AuthGuard],
                data: {funcionalidade: PerfisConstants.APROVAR_SOLICITACOES_PREVENTIVAS_PERMISSOES},
                resolve: {
                }
            }
        ]
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class AprovacaoSolicitacaoRoutingModule { }