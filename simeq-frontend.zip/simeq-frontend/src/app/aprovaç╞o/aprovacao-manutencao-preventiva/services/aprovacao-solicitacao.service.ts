import { Observable } from 'rxjs/Observable';
import { Http } from '@angular/http';
import { Injectable } from '@angular/core';
import { AbstractResource } from '../../../core/http/abstract.resource';
import { Pagina } from '../../../core/models/pagina.model';
import { AprovacaoReprovacaoManutencaoPreventivaDTO } from '../models/aprovacao-reprovacao-manutencao-preventiva.dto';
import { LabelValue } from "../../../core/models/label-value";

@Injectable()
export class AprovacaoSolicitacaoService extends AbstractResource<any>{

  private baseEndPoint: string = "/aprovacao-solicitacao-preventiva";

  constructor(http: Http) {
    super(http, '');
  }

  public reprogramar(aprovacaoReprovacaoManutencaoPreventivaDTO: AprovacaoReprovacaoManutencaoPreventivaDTO) {
    return super.post(this.baseEndPoint + '/reprogramar', aprovacaoReprovacaoManutencaoPreventivaDTO);
  }

  public aprovar(aprovacaoReprovacaoManutencaoPreventivaDTO: AprovacaoReprovacaoManutencaoPreventivaDTO) {
    return super.post(this.baseEndPoint + '/aprovar', aprovacaoReprovacaoManutencaoPreventivaDTO);
  }

  public reprovar(aprovacaoReprovacaoManutencaoPreventivaDTO: AprovacaoReprovacaoManutencaoPreventivaDTO) {
    return super.post(this.baseEndPoint + '/reprovar', aprovacaoReprovacaoManutencaoPreventivaDTO);
  }

  public enviarEmailAprovacao(aprovacaoReprovacaoManutencaoPreventivaDTO: AprovacaoReprovacaoManutencaoPreventivaDTO) {
    return super.post(this.baseEndPoint + '/enviar-email-aprovacao', aprovacaoReprovacaoManutencaoPreventivaDTO);
  }

  public enviarEmailReprovacao(aprovacaoReprovacaoManutencaoPreventivaDTO: AprovacaoReprovacaoManutencaoPreventivaDTO) {
    return super.post(this.baseEndPoint + '/enviar-email-reprovacao', aprovacaoReprovacaoManutencaoPreventivaDTO);
  }

  public buscarTodosMeses(): Observable<LabelValue[]> {
    return super.getList(this.baseEndPoint + '/meses');
}

}
