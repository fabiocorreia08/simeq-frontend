// import { UserDetails } from './../../core/security/User';
// import { AuthenticationService } from './../../core/security/auth.service';
// import { ManutencaoCorretivaService } from './../../manutencao/services/manutencao-corretiva.service';
// import { CanActivate, Router, ActivatedRouteSnapshot } from '@angular/router';
// import { Injectable } from '@angular/core';

// @Injectable()
// export class EditarManutencaoCorretivaGuard implements CanActivate {

//   public readonly VISITANTE: number = 6;

//   constructor(private auth: AuthenticationService,
//     private router: Router,
//     private manutencaoService: ManutencaoCorretivaService) { }

//   canActivate(route: ActivatedRouteSnapshot) {
//     const userDetails: UserDetails = this.auth.authInfo.details;
//     const matricula: string = this.auth.authInfo.username;
//     const idManutencao: number = route.params['idManutencao'];
//     if (this.auth.getIdPerfil(this.auth.authInfo.details.perfis) === this.VISITANTE) {
//       return false;
//     }
//     return this.manutencaoService.permitirEditar(this.auth.getIdPerfil(userDetails.perfis), matricula, idManutencao);
//   }

// }
