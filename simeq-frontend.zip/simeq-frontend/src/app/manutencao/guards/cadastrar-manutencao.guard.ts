import { AuthenticationService } from './../../core/security/auth.service';
import { CanActivate, Router, ActivatedRouteSnapshot } from '@angular/router';
import { Injectable } from '@angular/core';

@Injectable()
export class CadastrarManutencaoCorretivaGuard implements CanActivate {

  public readonly VISITANTE: number = 6;

  constructor(private auth: AuthenticationService,
    private router: Router,) { }

  canActivate(route: ActivatedRouteSnapshot) {
    if (this.auth.getIdPerfil(this.auth.authInfo.details.perfis) === this.VISITANTE) {
      return false;
    }
    return true;
  }

}
