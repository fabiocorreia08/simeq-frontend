// import { UserDetails } from './../../core/security/User';
// import { ManutencaoPreventivaService } from './../services/manutencao-preventiva.service';
// import { AuthenticationService } from './../../core/security/auth.service';
// import { CanActivate, Router, ActivatedRouteSnapshot } from '@angular/router';
// import { Injectable } from '@angular/core';

// @Injectable()
// export class EditarManutencaoPreventivaGuard implements CanActivate {

//   public readonly VISITANTE: number = 6;

//   constructor(private auth: AuthenticationService,
//     private router: Router,
//     private manutencaoService: ManutencaoPreventivaService) { }

//   canActivate(route: ActivatedRouteSnapshot) {
//     const userDetails: UserDetails = this.auth.authInfo.details;
//     const matricula: string = this.auth.authInfo.username;
//     const numeroSolicitacao: string = route.params['numeroSolicitacao'];
//     if (this.auth.getIdPerfil(this.auth.authInfo.details.perfis) === this.VISITANTE) {
//       return false;
//     }
//     return this.manutencaoService.permitirEditar(matricula, numeroSolicitacao, this.auth.getIdPerfil(userDetails.perfis));
//   }

// }
