import { AtividadeService } from './../services/atividade.service';
import { AuthenticationService } from './../../core/security/auth.service';
import { CanActivate, Router, ActivatedRouteSnapshot } from '@angular/router';
import { Injectable } from '@angular/core';

@Injectable()
export class EditarAtividadeGuard implements CanActivate {

  constructor(private auth: AuthenticationService,
    private router: Router,
    private atividadeService: AtividadeService) { }

  canActivate(route: ActivatedRouteSnapshot) {
    const idPerfil = this.auth.getIdPerfil(this.auth.authInfo.details.perfis);
    const idAtividade: number = route.params['idAtividade'];
    const numeroSolicitacao: string = route.params['numeroSolicitacao'];
    return  this.atividadeService.permitirEditar(numeroSolicitacao, this.auth.authInfo.username, idAtividade, idPerfil);
  }

}
