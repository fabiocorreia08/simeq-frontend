
export class StatusManutencaoCorretivaEnum {
  public static readonly ABERTA: number = 1;
  public static readonly RECURSO_ALOCADO: number = 2;
  public static readonly AG_ACEITE: number = 3;
  public static readonly AG_APROPRIACAO: number = 4;
  public static readonly AG_FORNECEDOR: number = 5;
  public static readonly CANCELADA: number = 6;
  public static readonly CONCLUIDA: number = 7;
  public static readonly MANUTENCAO: number = 8;
  //public static readonly REPROVADA: number = 9;
  //public static readonly IMPROCEDENTE: number = 10;
  public static readonly AG_MATERIAL: number = 10;
  //public static readonly VERIFICANDO_REPROVACAO: number = 11;
  //ublic static readonly REABERTA: number = 12;
}