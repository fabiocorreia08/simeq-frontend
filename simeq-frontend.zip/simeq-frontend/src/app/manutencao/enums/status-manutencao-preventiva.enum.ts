
export class StatusManutencaoPreventivaEnum {
  public static readonly ABERTA: number = 1;
  public static readonly RECURSO_ALOCADO: number = 2;
  public static readonly APROVADA_GESTOR: number = 3;
  public static readonly REPROVADA_GESTOR: number = 4;
  public static readonly AG_FORNECEDOR: number = 5;
  public static readonly CANCELADA: number = 6;
  public static readonly CONCLUIDA: number = 7;
  public static readonly MANUTENCAO: number = 8;
  public static readonly REPROGRAMADA: number = 9;
  public static readonly EXPIRADA: number = 10;
  public static readonly REABERTA: number = 11;
  public static readonly IMPROCEDENTE: number = 12;
  public static readonly AG_MATERIAL: number = 13;
}
