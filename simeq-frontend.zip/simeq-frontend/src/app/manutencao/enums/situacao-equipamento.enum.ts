
export class SituacaoEquipamento {
  public static readonly VERDE: number = 1;
  public static readonly VERMELHO: number = 2;
  public static readonly AMARELO: number = 3;
}
