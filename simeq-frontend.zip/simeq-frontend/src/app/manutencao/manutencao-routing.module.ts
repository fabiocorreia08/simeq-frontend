import { DetalharManutencaoAtividadeComponent } from './components/detalhar-manutencao-atividade/detalhar-manutencao-atividade.component';
import { DetalharAtividadeComponent } from './components/atividade/detalhar-atividade/detalhar-atividade.component';
import { AtividadeResolve } from './resolves/atividade.resolve';
import { ConsultarAtividadeComponent } from './components/atividade/consultar-atividade/consultar-atividade.component';
import { DetalharAlocacaoComponent } from './components/detalhar-alocacao/detalhar-alocacao.component';
import { CadastrarManutencaoCorretivaComponent } from './components/cadastrar-manutencao-corretiva/cadastrar-manutencao-corretiva.component';
import { PerfisConstants } from './../core/security/perfis.constants';
import { AuthenticationService } from './../core/security/auth.service';
import { AuthGuard } from './../core/security/auth.guard';
import { ConsultarManutencaoCorretivaComponent } from './components/consultar-manutencao-corretiva/consultar-manutencao-corretiva.component';
import { MainComponent } from './../main/main.component';
import { Routes, RouterModule, Resolve } from '@angular/router';
import { NgModule } from '@angular/core';
import { ManutencaoCorretivaResolve } from './resolves/manutencao-corretiva.resolve';
import { DetalharManutencaoCorretivaComponent } from './components/detalhar-manutencao-corretiva/detalhar-manutencao-corretiva.component';
import { DetalharManutencaoCorretivaStatusComponent } from './components/detalhar-manutencao-corretiva-status/detalhar-manutencao-corretiva-status.component';
import { CadastrarManutencaoCorretivaGuard } from './guards/cadastrar-manutencao.guard';
import { CadastrarAtividadeComponent } from './components/atividade/cadastrar-atividade/cadastrar-atividade.component';
import { ConsultarInformacaoComponent } from './components/consultar-informacao/consultar-informacao.component';
import { CadastrarInformacaoComponent } from './components/cadastrar-informacao/cadastrar-informacao.component';
import { CadastrarPreventivaComponent } from './components/preventiva/cadastrar-preventiva/cadastrar-preventiva.component';
import { EditarAtividadeGuard } from './guards/editar-atividade.guard';
import { AtividadeDetalheResolve } from './resolves/atividade-detalhe.resolve';
import { ManutencaoResolve } from './resolves/manutencao.resolve';
import { StatusCorretivaResolve } from './resolves/status-corretiva.resolve';
import { EditarAtividadeComponent } from './components/atividade/editar-atividade/editar-atividade.component';
import { AtividadeEditeResolve } from './resolves/atividade-edite.resolve';

const routes: Routes = [
  {
    path: 'app', component: MainComponent,
    children: [
      {
        path: 'manutencao/consultar-manutencao-corretiva',
        component: ConsultarManutencaoCorretivaComponent,
        canActivate: [AuthGuard],
        data: { funcionalidade: PerfisConstants.CONSULTAR_MANUTENCAO_CORRETIVA_PERMISSOES },
        resolve: {
          statusCorretivaResolve: StatusCorretivaResolve
        }
      },            
      {
        path: 'manutencao/consultar-manutencao-corretiva/:idStatus',
        component: ConsultarManutencaoCorretivaComponent,
        canActivate: [AuthGuard],
        data: {
          funcionalidade:
            PerfisConstants.CONSULTAR_MANUTENCAO_CORRETIVA_PERMISSOES,
          isDashboard: true
        },
        resolve: {
          statusCorretivaResolve: StatusCorretivaResolve
        }
      },                       
      {
        path: 'manutencao/cadastrar-manutencao-corretiva',
        component: CadastrarManutencaoCorretivaComponent,
        canActivate: [AuthGuard, CadastrarManutencaoCorretivaGuard],
        data: { funcionalidade: PerfisConstants.CADASTRAR_MANUTENCAO_CORRETIVA_PERMISSOES },
      },
      {
        path: 'manutencao/editar-manutencao-corretiva/:idManutencao',
        component: CadastrarManutencaoCorretivaComponent,
        canActivate: [AuthGuard],
        resolve: {
          manutencaoCorretivaResolve: ManutencaoCorretivaResolve
        },
        data: {
          funcionalidade: PerfisConstants.EDITAR_MANUTENCAO_CORRETIVA_PERMISSOES,
          isTelaAltera: true
        }
      },
      {
        path: 'manutencao/detalhar-manutencao-corretiva/:idManutencao',
        component: DetalharManutencaoCorretivaComponent,
        canActivate: [AuthGuard],
        resolve: {
          manutencaoCorretivaResolve: ManutencaoCorretivaResolve
        },
        data: { funcionalidade: PerfisConstants.DETALHAR_MANUTENCAO_CORRETIVA_PERMISSOES },
      },
      {
        path: 'manutencao/detalhar-manutencao-corretiva-status/:idManutencao/:numeroSolicitacao',
        component: DetalharManutencaoCorretivaStatusComponent,
        canActivate: [AuthGuard],
        data: { funcionalidade: PerfisConstants.DETALHAR_MANUTENCAO_CORRETIVA_PERMISSOES },
      },
      {
        path: 'manutencao/preventiva/detalhar-alocacao/:idManutencao',
        component: DetalharAlocacaoComponent,
        canActivate: [AuthGuard],
        data: {
          funcionalidade: PerfisConstants.DETALHAR_MANUTENCAO_PREVENTIVA_PERMISSOES,
          isCorretiva: false
        },
      },
      {
        path: 'manutencao/corretiva/detalhar-alocacao/:idManutencao',
        component: DetalharAlocacaoComponent,
        canActivate: [AuthGuard],
        data: {
          funcionalidade: PerfisConstants.DETALHAR_MANUTENCAO_CORRETIVA_PERMISSOES,
          isCorretiva: true
        },
      },
      {
        path: 'manutencao/atividade/cadastrar-atividade/:idManutencao/:numeroSolicitacao',
        component: CadastrarAtividadeComponent,
        canActivate: [AuthGuard],
        data: { funcionalidade: [PerfisConstants.CADASTRAR_ATIVIDADES] },
      },
      {
        path: 'manutencao/atividade/consultar-atividade',
        component: ConsultarAtividadeComponent,
        canActivate: [AuthGuard],
        data: { funcionalidade: [PerfisConstants.CONSULTAR_ATIVIDADES] },
      },
      {
        path: 'manutencao/atividade/cadastrar-atividade',
        component: CadastrarAtividadeComponent,
        canActivate: [AuthGuard],
        data: { funcionalidade: [PerfisConstants.CADASTRAR_ATIVIDADES] },
      },
      {
        path: 'manutencao/atividade/editar-atividade',
        component: EditarAtividadeComponent,
        canActivate: [AuthGuard],
        data: { funcionalidade: [PerfisConstants.CADASTRAR_ATIVIDADES] },
      },
      {
        path: 'manutencao/atividade/cadastrar-atividade/:idManutencao/:numeroSolicitacao',
        component: CadastrarAtividadeComponent,
        canActivate: [AuthGuard],
        data: { funcionalidade: [PerfisConstants.CADASTRAR_ATIVIDADES] },
      },
      {
        path: 'manutencao/atividade/editar/:idAtividade/:numeroSolicitacao',
        component: CadastrarAtividadeComponent,
        canActivate: [AuthGuard, EditarAtividadeGuard],
        resolve: {
          atividadeResolve: AtividadeResolve
        },
        data: { 
          funcionalidade: [PerfisConstants.CADASTRAR_ATIVIDADES], 
          isEditar: true },
      },      
      {
        path: 'manutencao/atividade/detalhar/:idManutencao/:numeroSolicitacao',
        component: DetalharManutencaoAtividadeComponent,
        canActivate: [AuthGuard],
        resolve: {
          manutencaoResolve: ManutencaoResolve
        },
        data: { funcionalidade: [PerfisConstants.CONSULTAR_ATIVIDADES] },
      },
      {
        path: 'atividade/detalhar/:idAtividade/:numeroSolicitacao',
        component: DetalharAtividadeComponent,
        canActivate: [AuthGuard],
        resolve: {
          atividadeResolve: AtividadeDetalheResolve
        },
        data: { funcionalidade: [PerfisConstants.CONSULTAR_ATIVIDADES] },
      },
      {
        path: 'atividade/editar/:idAtividade/:numeroSolicitacao',
        component: EditarAtividadeComponent,
        canActivate: [AuthGuard],
        resolve: {
          atividadeResolve: AtividadeEditeResolve
        },
        data: { funcionalidade: [PerfisConstants.CONSULTAR_ATIVIDADES] },
      },
      {
        path: 'manutencao/informacao/consultar-informacao',
        component: ConsultarInformacaoComponent,
        canActivate: [AuthGuard],
        data: { funcionalidade: [PerfisConstants.CONSULTAR_INFORMACOES_PERMISSOES] },
      },
      {
        path: 'manutencao/informacao/consultar-informacao/:codigo',
        component: ConsultarInformacaoComponent,
        canActivate: [AuthGuard],
        data: { funcionalidade: [PerfisConstants.CONSULTAR_INFORMACOES_PERMISSOES] },
      },
      {
        path: 'manutencao/informacao/consultar-informacao/:acao/:codigo',
        component: ConsultarInformacaoComponent,
        canActivate: [AuthGuard],
        data: { funcionalidade: [PerfisConstants.CONSULTAR_INFORMACOES_PERMISSOES] },
      },
      {
        path: 'manutencao/informacao/cadastrar-informacao',
        component: CadastrarInformacaoComponent,
        canActivate: [AuthGuard],
        data: { funcionalidade: [PerfisConstants.CADASTRAR_INFORMACOES_PERMISSOES] },
      },
      {
        path: 'manutencao/informacao/cadastrar-informacao/:codigo',
        component: CadastrarInformacaoComponent,
        canActivate: [AuthGuard],
        data: { funcionalidade: [PerfisConstants.CADASTRAR_INFORMACOES_PERMISSOES] },
      }      
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ManutencaoRoutingModule { }
