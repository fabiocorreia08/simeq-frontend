export class AtividadeTecnicoFiltro {
  matricula: string;
  nome: string;
  numeroSolicitacao: string;
  idPerfil: number;
  matriculaUsuarioLogado: string;
}
