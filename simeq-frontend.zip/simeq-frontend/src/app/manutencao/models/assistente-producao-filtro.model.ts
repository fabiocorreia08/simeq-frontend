export class AssistenteProducaoFiltro {
  public matricula: string = '';
  public nome: string;
}
