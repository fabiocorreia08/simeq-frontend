import { LabelValue } from '../../core/models/label-value';

export class PlanoPreventivaCadastro {
  public id: number;
  public idManutencao: number;
  public idEquipamento: number;
  public dataCriacao: string;
  public horaCriacao: string;
  public codigoCentroCusto: string;
  public numeroSolicitacao: string;
  public hierarquiaCentroCusto: string = "";
  public ano: number;
  public mes: number;
  public diaInicio: string;
  public diaFim: string;
  public qtdHoras: string;
  public matriculaSolicitante: string;
  public mesAno: string;
  public matriculaUsuarioLogado: string;
  public classeManutencao: LabelValue = new LabelValue('Preventiva', 'P');
  public idStatus: number;
  public anoAntigo: number;
  public mesAntigo: number;
  public diaInicioAntigo: number;
  public diaFimAntigo: number;
  public idStatusAntigo: number;
  public idSetor: number;
  public nomeSetor: string;
  public qtdHorasExecutadas: string;
  public justificativa: string;  
  public dataUltimaConcluida: string;
  public sugestao: string;
  public planoPreventiva: boolean;
  public acaoUltimaPreventiva: boolean;
  
}
