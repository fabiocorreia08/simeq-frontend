
export class AlocacaoDetalharFiltro {
  public idManutencao: number;  
}
