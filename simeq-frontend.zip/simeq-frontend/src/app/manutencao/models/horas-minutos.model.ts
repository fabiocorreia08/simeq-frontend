
export class HorasMinutos {
    public horas: number;
    public minutos: number;
  }
  