export class ManutencaoCorretivaConsulta {
  public idManutencao: number;
  public numeroSolicitacao: string;
  public tipo: string;
  public status: string;
  public dataCadastro: Date;  
  public horaCadastro: string;  
  public dataAlteracao: Date;
  public codigoManutencaoEquipamento: string;
  public centroCusto: string;
  public paralisacao: boolean;
  public idStatus: number;
}





