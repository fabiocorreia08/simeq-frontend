export class Material {
  public sequencial: number;
  public codigo: string;
  public nome: string;
  public descricao: string;
  public quantidade: number;
}
