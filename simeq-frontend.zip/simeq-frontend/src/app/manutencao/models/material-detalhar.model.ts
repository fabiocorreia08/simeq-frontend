export class MaterialDetalhar {
  public id: number;
  public codigo: string;
  public nome: string;
  public qtd: number;
  public unidade: string;
}
