export class PreventivaConsultaTabela {
  public idManutencao: number;
  public codigoEquipamento: string;
  public descricaoEquipamento: string;
  public dataManutencao: Date;
  public dataInicial: Date;
  public status: string;
  public idStatus: number;
  public numeroSolicitacao: string;
  public centroCusto: string;
}
