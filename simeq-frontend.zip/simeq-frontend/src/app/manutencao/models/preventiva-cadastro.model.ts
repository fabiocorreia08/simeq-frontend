import { LabelValue } from "../../core/models/label-value";

export class PreventivaCadastro {
  public id: number;
  public idManutencao: number;
  public idEquipamento: number;
  public dataCriacao: string;
  public horaCriacao: string;
  public codigoCentroCusto: string;
  public numeroSolicitacao: string;
  public hierarquiaCentroCusto: string = "";
  public ano: number;
  public mes: number;
  public diaInicio: number;
  public diaFim: number;
  public qtdHoras: string;
  public matriculaSolicitante: string;
  public mesAno: string;
  public matriculaUsuarioLogado: string;
  public classeManutencao: LabelValue = new LabelValue('Preventiva', 'P');
  public idStatus: number;
  public anoAntigo: number;
  public mesAntigo: number;
  public diaInicioAntigo: number;
  public diaFimAntigo: number;
  public idStatusAntigo: number;
  public idSetor: number;
  public nomeSetor: string;
  public qtdHorasExecutadas: string;
  public justificativa: string;  
  public sugestao: string;
  public dataUltimaConcluida: string;
  
}
