
export class AtividadeConsulta {
  public id: number;
  public grupoSubGrupo: string;
  public acao: string;
  public componente: string;
  public hht: string;
  public matriculaExecutante: string;
  public dataCriacao: Date;
  public horasApropriadas: string;
}
