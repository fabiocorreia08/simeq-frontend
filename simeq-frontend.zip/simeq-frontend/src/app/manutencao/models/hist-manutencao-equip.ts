export class HistoricoManutencaoEquipamento {
  public idManutencao: string;
  public numeroSolicitacao: string;
  public equipamento: string;
  public dtAlteracao: Date;
  public codManutencao: string;
  public centroCusto: string;
  public dtSolicitacao: Date; 
  
}
