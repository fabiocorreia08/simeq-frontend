import { AtividadeMaterial } from './atividade-material.model';

export class Atividade {
  public id: number;
  public idManutencao: number;
  public classeManutencao: string;
  public dataCadastroManutencao: string;
  public matriculaExecutante: string;
  public nomeExecutante: string;
  public hierarquiaCentroCustoEquipamento: string;
  public idSubGrupo: number;
  public idGrupo: number;
  public decricaoAcao: string;
  public codigoAcao: string;
  public codigoComponente: string;
  public nomeComponente: string;
  public mesReferencia: number;
  public horasAtividade: string;
  public observacao: string;
  public materiais: AtividadeMaterial[] = [];
  public numeroSolicitacao: string;
  public matriculaUsuarioLogado: string;
  public nomeUsuarioLogado: string;
  public tipoManutencao: string;
  public salario: number;  
  public horasApropriadas: string;  
  public horasTotal: string;
  
}
