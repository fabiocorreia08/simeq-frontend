export class Manutencao {
    public idManutencao: number;
    public nomeEquipamento: string;
    public numeroSolicitacao: string;
    public idEquipamento: number;
    public dataCriacao: string;
    public horaCriacao: string;
    public centroCustoEquipamento: string;
    public classeManutencao: string;
    public tipoManutencao: string;
    public idStatus: number;
    public siglaCentroCusto: string;
    public paralisacao: Boolean;
    public matriculaAssistenteProducao: string;
    public nomeAssistenteProducao: string;
    public hierarquiaCentroCusto: string;
    public horasTotal: string;
}
