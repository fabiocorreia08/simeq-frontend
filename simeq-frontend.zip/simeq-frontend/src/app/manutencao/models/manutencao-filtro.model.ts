export class ManutencaoCorretivaFiltro {
  public numeroSolicitacao: string;
  public idsStatus: number[] = null;
  public centroCustos: number[] = null;
  public periodoInicio: Date;
  public periodoFim: Date;
  public solicitante: string;
  public idEquipamento: number;
  public idGrupo: number;
  public idsSubGrupo: number[] = null;
  public perfil: number;
  public matricula: string;
  public avaria: string;
  public classeManutencao: string;
  public paralisacao: boolean = null;
  public siglaCentroCusto: string;
  public setor: string = null;
}
