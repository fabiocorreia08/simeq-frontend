import { LabelValue } from './../../core/models/label-value';

export class ManutencaoCorretiva {
  public idManutencao: number;
  public dataCriacao: string;
  public horaCriacao: string;
  public numeroSolicitacao: string;
  public idEquipamento: number;
  public codigoCentroCusto: string;
  public matriculaAssistenteProducao: string;
  public nomeAssistenteProducao: string;
  public classeManutencao: LabelValue = new LabelValue('Corretiva', 'C');
  public paralisacao: boolean;
  public avaria: string;
  public matriculaSolicitante: string;
  public nomeSolicitante: string;
  public numeroRamal: string;
  public numeroPredio: string;
  public idStatus: number;
  public codigoManutencao: string;
  public nomeEquipamento: string;
  public siglaCentroCusto: string;
  public nomeStatus: string;
  public matriculaUsuarioLogado: string;
  public hierarquiaCentroCusto: string;
  public centroCustoEquipamento: string;
  public idFamilia:  number = 0; 
  public idSetor: number;
  public nomeSetor: number;
  public horasComParalisacao: string;
  public horasSemParalisacao: string;  
  public horasTotal: string; 
  public justificativa: string;   
}
