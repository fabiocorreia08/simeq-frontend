export class AtividadeMaterialFiltro {
  public codigoMaterial: string = '';
  public nomePradronizado: string;
}
