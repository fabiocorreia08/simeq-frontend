import { MaterialDetalhar } from './material-detalhar.model';
export class AtividadeDetalhar {
  public numeroSolicitacao: string;
  public classeManutencao: string;
  public dataCadastroManutencao: string;
  public matriculaExecutante: string;
  public nomeExecutante: string;
  public hierarquiaCentroCustoEquipamento: string;
  public equipamento: string;
  public grupo: string;
  public subgrupo: string;
  public acao: string;
  public componente: string;
  public horasAtividade: string;
  public mesReferencia: string;
  public observacao: string;
  public materiais: MaterialDetalhar[];
  public tipoManutencao: string;
  public salario: number;
  public horasComParalisacao: string;
  public horasSemParalisacao: string;
}
