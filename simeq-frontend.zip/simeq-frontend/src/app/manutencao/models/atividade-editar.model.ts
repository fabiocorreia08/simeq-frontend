import { MaterialDetalhar } from './material-detalhar.model';
export class AtividadeEditar {
  public numeroSolicitacao: string;
  public classeManutencao: string;
  public dataCadastroManutencao: string;
  public matriculaExecutante: string;
  public nomeExecutante: string;
  public hierarquiaCentroCustoEquipamento: string;
  public idEquipamento: number;
  public equipamento: string;
  public nomeEquipamento: string;
  public idGrupo: number;  
  public grupo: string;
  public idSubGrupo: number;
  public subgrupo: string;
  public codigoAcao: string;
  public acao: string;
  public codigoComponente: string;
  public componente: string;
  public horasAtividade: string;
  public mesReferencia: string;
  public observacao: string;
  public materiais: MaterialDetalhar[];
  public tipoManutencao: string;
  public salario: number;
  public horasComParalisacao: string;
  public horasSemParalisacao: string;
}
