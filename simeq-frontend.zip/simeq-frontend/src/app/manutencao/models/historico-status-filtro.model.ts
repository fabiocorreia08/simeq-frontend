
export class HistoricoStatusManutencaoFiltro {
  public idManutencao: number;
  public numeroSolicitacao: string;
  public idsStatus: number[];
  public dtUltimaManutencao: Date;
  public idEquipamento: number;
}
