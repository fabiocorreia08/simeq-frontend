
export class AtividadeFiltro {
  public numeroSolicitacao: string;
  public periodoInicio: Date;
  public periodoFim: Date;
  public matriculaExecutante: string;
  public matricula: string;
  public perfil: number;
}
