
export class PlanoPreventivaConsultaFiltro {
  idEquipamento: number;
  dataInicialFiltro: Date;
  dataFinalFiltro: Date; 
}
