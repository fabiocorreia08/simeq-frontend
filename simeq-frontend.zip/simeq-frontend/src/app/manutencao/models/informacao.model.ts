export class Informacao{
    public idManutencao: number;
    public idEquipamento: number;
    public numeroSolicitacao: string;
    public idStatus: number;
    public classeManutencao: string = null;
    public matriculaUsuarioLogado: string = "";
    public nomeUsuarioLogado: string = "";
    public descricaoInformacao: string;
    public perfil: number;
    public descricaoStatus: string;
    public dataCadastro: Date;
}