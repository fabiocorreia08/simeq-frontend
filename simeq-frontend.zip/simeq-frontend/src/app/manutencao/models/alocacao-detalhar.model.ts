
export class AlocacaoDetalhar {
  public matriculaTecnico: string;
  public nomeTecnico: string;
  public cargo: string;
  public turno: string;
  public dataAlocacao: string;
  public nomeResponsavelPelaAlocacao: string;
  
}
