
export class HistoricoStatusPreventivaFiltro {
  public numeroSolicitacao: string;
}
