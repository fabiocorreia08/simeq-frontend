export class InformacaoFiltro{
    idManutencao: number;
    //idEquipamento: number;
    numeroSolicitacao: string;
    dataCadastro: Date;
}