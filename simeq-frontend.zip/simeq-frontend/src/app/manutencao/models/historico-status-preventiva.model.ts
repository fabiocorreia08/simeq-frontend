
export class HistoricoStatusPreventiva {
  public sequencial: number;
  public dataHoraAlteracao: string;
  public status: string;
  public matriculaUsuarioAlteracao: string;
  public nomeUsuarioAlteracao: string;  
}
