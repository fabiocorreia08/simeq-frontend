export class PlanoPreventivaConsultaTabela {  
  public id: number;
  public grupoSubGrupo: string;
  public grupo: string;
  public subGrupo: string;
  public frequencia: number;
  public idsManutencao: number[];
  public acaoUltimaPreventiva: boolean = true;
}
