export class AtividadeMaterial {
  public id: number;
  public idAtividade: number;
  public codigoMaterial: string = '';
  public descricaoMaterialOutros: string = '';
  public nomeMaterialOutros: string = '';
  public quantidadeMaterial: number;
  public descricaoUnidadeMedida: string;
  public sequencialMaterial: number;
  public nomeMaterial: string;
  public codificado: boolean = true;
}
