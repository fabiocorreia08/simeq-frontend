export class PlanoPreventivaVO{
    
    diaInicio: string;
    diaFim: string;    
    
}

