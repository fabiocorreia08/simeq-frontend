import { Pagina } from './../../core/models/pagina.model';
import { LabelValue } from './../../core/models/label-value';
import { Observable } from 'rxjs/Observable';
import { Http } from '@angular/http';
import { Injectable } from '@angular/core';
import { AbstractResource } from '../../core/http/abstract.resource';
import { HistoricoStatusPreventivaFiltro } from '../models/historico-status-preventiva-filtro.model';
import { HistoricoStatusPreventiva } from '../models/historico-status-preventiva.model';
import { DashboardVO } from '../../shared/models/dashboardVO.model';
import { DashboardDTO } from '../../shared/models/dashboardDTO.model';
import { HorasMinutos } from '../models/horas-minutos.model';

@Injectable()
export class StatusPreventivaService extends AbstractResource<any> {

    private baseEndPoint: string = '/status-preventiva';

    constructor(http: Http) {
      super(http, '');
    }

    public buscarTodosLabelValue(): Observable<LabelValue[]> {
      return super.getList(this.baseEndPoint);
    }

    public buscarComboEditarPreventiva(idManutencao: number): Observable<LabelValue[]> {            
      return super.getList(this.baseEndPoint + '/manutencao', idManutencao);
    }

    public buscarComboEditarPreventivaPerfil(numeroSolicitacao: string, idPerfil: number): Observable<LabelValue[]> {            
      return super.getList(this.baseEndPoint + '/numero-manutencao/' + numeroSolicitacao + '/' + idPerfil);
    }

    public filtrar(filtro: HistoricoStatusPreventivaFiltro, params?: any): Observable<Pagina<HistoricoStatusPreventiva>> {
      return super.filter(this.baseEndPoint + '/pagina', filtro, params);
    }

    public buscarDashboardPreventiva(dashboardVO: DashboardVO): Observable<DashboardDTO[]>{    
      return super.post(`${this.baseEndPoint}/dashboard-preventiva`, dashboardVO);
    }
    /*
    public buscarHorasStatusPreventiva(idManutencao: number): Observable<HorasMinutos> {
      return super.getOne(`${this.baseEndPoint}/historico-preventiva/${idManutencao}`);
    }*/

}
