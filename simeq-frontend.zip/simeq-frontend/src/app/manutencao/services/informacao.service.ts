import { InformacaoFiltro } from './../models/informacao-filtro.model';
import { Informacao } from './../models/informacao.model';
import { Injectable } from '@angular/core';
import { AbstractResource } from '../../core/http/abstract.resource';
import { Http } from '@angular/http';
import { Observable } from 'rxjs';
import { Pagina } from '../../core/models/pagina.model';

@Injectable()
export class InformacaoService extends AbstractResource<any>{

    constructor(http: Http) {
        super(http, '/informacoes');
    }

    public salvar(manutencao: Informacao): Observable<Informacao> {
        return super.post('', manutencao);
    }

    public filtrar(filtro: InformacaoFiltro, params?: any): Observable<Pagina<Informacao>> {
        return super.filter('/pagina', filtro, params);
    }
}