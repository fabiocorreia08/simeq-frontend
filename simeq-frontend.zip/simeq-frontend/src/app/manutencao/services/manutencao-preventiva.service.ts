import { PreventivaCadastro } from './../models/preventiva-cadastro.model';
import { LabelValue } from './../../core/models/label-value';
import { Observable } from 'rxjs/Observable';
import { Http } from '@angular/http';
import { Injectable } from '@angular/core';
import { AbstractResource } from '../../core/http/abstract.resource';
import { PreventivaConsultaFiltro } from '../models/preventiva-consulta-filtro.model';
import { PreventivaConsultaTabela } from '../models/preventiva-consulta-tabela.model';
import { Pagina } from '../../core/models/pagina.model';
import { AprovacaoManutencaoPreventivaFiltro } from '../../aprova\u00E7\u00E3o/aprovacao-manutencao-preventiva/models/aprovacao-manutencao-preventiva-filtro.model';
import { AprovacaoPreventivaConsultaTabela } from '../../aprova\u00E7\u00E3o/aprovacao-manutencao-preventiva/models/aprovacao-preventiva-consulta-tabela.model';
import { HistoricoStatusManutencaoFiltro } from '../models/historico-status-filtro.model';
import { HistoricoManutencaoEquipamento } from '../models/hist-manutencao-equip';
import { HistoricoStatusPreventiva } from '../models/historico-status-preventiva.model';

@Injectable()
export class ManutencaoPreventivaService extends AbstractResource<any> {

  private baseEndPoint: string = '/manutencoes-preventivas';

  constructor(http: Http) {
    super(http, '');
  }

  public buscarTodosMeses(): Observable<LabelValue[]> {
    return super.getList(this.baseEndPoint + '/meses');
  }

  public buscarPreventivasPorEquipamentoCentroCusto(idEquipamento: number, centroCusto: string) {
    return super.getList(this.baseEndPoint + '/equipamento/' + idEquipamento + '/centro-custo/' + centroCusto);
  }

  public buscarPorPerfil(idPerfil: number, matricula: string, numeroSolicitacao: string): Observable<PreventivaCadastro> {
    return super.getOne(this.baseEndPoint + '/solicitacao-por-perfil/' + matricula + '/' + numeroSolicitacao + '/' + idPerfil);
  }

  public buscarPorId(id: number): Observable<PreventivaCadastro> {
    return super.getOne(this.baseEndPoint, id);
  }

  public salvar(preventivasCadastro: PreventivaCadastro[]): Observable<any> {
    return super.post(this.baseEndPoint, preventivasCadastro);
  }

  public atualizar(preventivasCadastro: PreventivaCadastro): Observable<any> {
    return super.put(this.baseEndPoint, preventivasCadastro);
  }

  public buscarPreventivaPorNumeroSolicitacao(numeroSolicitacao: string): Observable<PreventivaCadastro> {
    return super.getOne(this.baseEndPoint + '/numero-solicitacao', numeroSolicitacao);
  }

  public buscarUltimaPreventivaPorEquipamento(idEquipamento: number): Observable<PreventivaCadastro> {
    return super.getOne(this.baseEndPoint + '/ultima-manutencao-equipamento/' +idEquipamento);
  }  

  public filtrar(filtro: PreventivaConsultaFiltro, params?: any): Observable<Pagina<PreventivaConsultaTabela>> {
    return super.filter(this.baseEndPoint + '/pagina', filtro, params);
  }

  public filtrarManutencaoAprovacao(filtro: AprovacaoManutencaoPreventivaFiltro, params?: any): Observable<Pagina<AprovacaoPreventivaConsultaTabela>> {
    return super.filter(this.baseEndPoint + '/aprovacao/pagina', filtro, params);
  }

  public buscarRelatorioPreventiva(idPreventiva: number) {
    return super.getBlob(`${this.baseEndPoint}/download-relatorio-preventiva/${idPreventiva}`);
  }

  public filtrarHistoricoPorEquipamento(filtro: HistoricoStatusManutencaoFiltro, params?: any): Observable<Pagina<HistoricoManutencaoEquipamento>> {
    return super.filter(this.baseEndPoint + '/equipamento', filtro, params);
  }  
  
}
