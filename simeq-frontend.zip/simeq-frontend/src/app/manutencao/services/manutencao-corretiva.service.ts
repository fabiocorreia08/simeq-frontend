import { ManutencaoCorretiva } from './../models/manutencao-corretiva.model';
import { Pagina } from './../../core/models/pagina.model';
import { Observable } from 'rxjs/Observable';
import { ManutencaoCorretivaFiltro } from './../models/manutencao-filtro.model';
import { Http } from '@angular/http';
import { Injectable } from '@angular/core';
import { AbstractResource } from '../../core/http/abstract.resource';
import { ManutencaoCorretivaConsulta } from '../models/manutencao-consulta.model';
import { LabelValue } from '../../core/models/label-value';
import { Manutencao } from '../models/manutencao.model';
import { HistoricoManutencaoEquipamento } from '../models/hist-manutencao-equip';
import { HistoricoStatusManutencaoFiltro } from '../models/historico-status-filtro.model';
import { RankEquipamentoFiltro } from '../../relatorios/models/relatorio-rank-equipamento-filtro';

@Injectable()
export class ManutencaoCorretivaService extends AbstractResource<any> {

  private baseEndPoint: string = '/manutencoes-corretivas';

    constructor(http: Http) {
      super(http, '');
    }

    public filtrar(filtro: ManutencaoCorretivaFiltro, params?: any): Observable<Pagina<ManutencaoCorretivaConsulta>> {
      return super.filter(this.baseEndPoint + '/pagina', filtro, params);
    } 
    
    public buscarPaginadaAbertaReaberta(matricula: string, params?: any): Observable<Pagina<ManutencaoCorretivaConsulta>> {
      return super.filter(this.baseEndPoint + '/pagina/aberta-reaberta', matricula, params);
    }

    public buscarClassesManutencao(): Observable<LabelValue[]> {
      return super.getList(this.baseEndPoint + '/classes-manutencao');
    } 
    
    public salvar(manutencao: ManutencaoCorretiva): Observable<ManutencaoCorretiva> {
      return super.post(this.baseEndPoint, manutencao);
    }

    public enviarEmailCriacao(manutencao: ManutencaoCorretiva): Observable<ManutencaoCorretiva> {
      return super.post(this.baseEndPoint + '/enviar-email-criacao', manutencao);
    }

    public atualizar(manutencao: ManutencaoCorretiva): Observable<ManutencaoCorretiva> {
      return super.put(this.baseEndPoint, manutencao);
    }

    public buscarUltimaPreventiva(numeroSolicitacao: string): any {
      return super.getOne(this.baseEndPoint, numeroSolicitacao);
    }

    public buscarPorId(id: number): Observable<ManutencaoCorretiva> {
      return super.getOne(this.baseEndPoint, id);
    }

    public buscarPorIdManutencao(id: number, numeroSolicitacao: string): Observable<Manutencao> {
      return super.getOne(this.baseEndPoint, id + '/' + numeroSolicitacao);
    }

    public buscarPorNumeroSolicitacao(numeroSolicitacao: string): Observable<ManutencaoCorretiva> {
      return super.getOne(this.baseEndPoint + '/numero-solicitacao', numeroSolicitacao);
    }
    
    public buscarComAvariaPorIdManutencao(idManutencao: number): Observable<ManutencaoCorretiva> {
      return super.getOne(this.baseEndPoint + '/id-solicitacao', idManutencao);
    }

    public buscarPorEquipamento(idEquipamento: number) {
      return super.getList(this.baseEndPoint + '/equipamento/' + idEquipamento);
    }
    
    public buscarAvariaPorNumeroSolicitacao(numeroSolicitacao: string): Observable<ManutencaoCorretiva> {
      return super.getOne(this.baseEndPoint + '/avaria', numeroSolicitacao);
    }

    public buscarPorNumeroSolicitacaoPorHierarquia(numeroSolicitacao: string, idPerfil: number, matricula: string): Observable<Manutencao> {
      return super.getOne(this.baseEndPoint + '/numero-solicitacao/hierarquia/' + numeroSolicitacao + '/' + idPerfil, matricula);
    }

    public buscarPorPerfil(idPerfil: number, matricula: string, numeroSolicitacao: string): Observable<Manutencao> {
      return super.getOne(this.baseEndPoint + '/solicitacao-por-perfil/' + matricula + '/' + numeroSolicitacao + '/' + idPerfil);
    }

    public filtrarHistoricoPorEquipamento(filtro: HistoricoStatusManutencaoFiltro, params?: any): Observable<Pagina<HistoricoManutencaoEquipamento>> {
      return super.filter(this.baseEndPoint + '/equipamento', filtro, params);
    }

    public buscarRelatorioCorretiva(idCorretiva: number) {
      return super.getBlob(`${this.baseEndPoint}/download-relatorio-corretiva/${idCorretiva}`);
    }

    public buscarTempoRefreshParametrizado(): Observable<number> {
      return super.getOne(this.baseEndPoint + '/tempo-refresh');
    }

    public buscarRelatorioRankEquipamento(filtro: RankEquipamentoFiltro): Observable<any> {
      return super.downloadPost(this.baseEndPoint + '/relatorio-rank-equipamento', filtro);
    }

    buscarSituacoesEquipamentos(){
      return [
        { label: 'Com Paralisação', value: true},
        { label: 'Sem Paralisação', value: false}
      ];
    }    
    
}