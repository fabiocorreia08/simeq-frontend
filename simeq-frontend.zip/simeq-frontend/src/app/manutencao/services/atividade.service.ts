import { AtividadeDetalhar } from './../models/atividade-detalhar.model';
import { AtividadeMaterialFiltro } from './../models/atividade-material-filtro.model';
import { Material } from './../models/material.model';
import { AtividadeConsulta } from './../models/atividade-consulta.model';
import { Pagina } from './../../core/models/pagina.model';
import { Observable } from 'rxjs/Observable';
import { AtividadeFiltro } from './../models/atividade-filtro.model';
import { Http } from '@angular/http';
import { Injectable } from '@angular/core';
import { AbstractResource } from '../../core/http/abstract.resource';
import { LabelValue } from '../../core/models/label-value';
import { Atividade } from '../models/atividade.model';
import { Manutencao } from '../models/manutencao.model';
import { AtividadeEditar } from '../models/atividade-editar.model';

@Injectable()
export class AtividadeService extends AbstractResource<any> {

  private baseEndPoint: string = '/atividades';

  constructor(http: Http) {
    super(http, '');
  }

  public buscarPorId(id: number, numeroSolicitacao: string): Observable<Atividade> {
    return super.getOne(this.baseEndPoint, id + '/' + numeroSolicitacao);
  }

  public filtrar(filtro: AtividadeFiltro, params?: any): Observable<Pagina<AtividadeConsulta>> {
    return super.filter(this.baseEndPoint + '/pagina', filtro, params);
  }

  public filtrarMaterial(filtro: AtividadeMaterialFiltro, params?: any): Observable<Pagina<Material>> {
    return super.filter(this.baseEndPoint + '/pagina-material', filtro, params);
  }

  public buscarAcoesPorCodigo(codigoAcao: string): Observable<LabelValue[]> {
    return super.getList(this.baseEndPoint + `/acao/${codigoAcao}`);
  }

  public buscarTodasAcoes(): Observable<LabelValue[]> {
    return super.getList(this.baseEndPoint + '/acao');
  }

  public buscarComponentesPorCodigo(codigoComponente: string): Observable<LabelValue[]> {
    return super.getList(this.baseEndPoint + `/componente/${codigoComponente}`);
  }

  public buscarTodosComponentes(): Observable<LabelValue[]> {
    return super.getList(this.baseEndPoint + '/componente');
  }

  public buscarMeses(): Observable<LabelValue[]> {
    return super.getList(this.baseEndPoint + '/meses');
  }

  public buscarUnidades(): Observable<LabelValue[]> {
    return super.getList(this.baseEndPoint + '/unidades');
  }

  public buscarMesesSolicitacao(numeroSolicitacao: string): Observable<LabelValue[]> {
    return super.getList(this.baseEndPoint + '/meses-solicitacao', numeroSolicitacao);
  }

  public salvar(atividade: Atividade): Observable<Atividade> {    
    return super.post(this.baseEndPoint, atividade);
  }

  public atualizar(atividade: Atividade): Observable<Atividade> {
    return super.put(this.baseEndPoint, atividade);
  }

  public atualizarAtividade(atividade: AtividadeEditar): Observable<AtividadeEditar> {
    return super.put(this.baseEndPoint, atividade);
  }

  public buscarMaterialPorId(codigo: string): Observable<Material> {
    return super.getOne(this.baseEndPoint + '/material', codigo);
  }

  public removerAtividade(idAtividade: number, numeroSolicitacao: string): Observable<any> {
    return super.delete(this.baseEndPoint, idAtividade + '/' +  numeroSolicitacao);
  }

  public permitirEditar(numeroSolicitacao: string, matricula: string, idAtividade: number, idPerfil: number): Observable<boolean> {
    return super.getOne(this.baseEndPoint + '/autorizacao-usuario-edicao/' + numeroSolicitacao + '/' + matricula + '/' + idAtividade, idPerfil);
  }

  public buscarSolicitacaoTecnicoAlocado(numeroSolicitacao: string, matriculaTecnico: string): Observable<Manutencao> {
    return super.getOne(this.baseEndPoint + '/tecnico-alocado/' + numeroSolicitacao, matriculaTecnico);
  }

  public buscarAtividadeDetalhe(idAtividade: number, numeroSolicitacao: string): Observable<AtividadeDetalhar> {
    return super.getOne(this.baseEndPoint + '/detalhe', idAtividade + '/' +  numeroSolicitacao);
  }

  public buscarAtividadeEdite(idAtividade: number, numeroSolicitacao: string): Observable<AtividadeEditar> {
    return super.getOne(this.baseEndPoint + '/edite', idAtividade + '/' +  numeroSolicitacao);
  }

  public buscarAtividadesPorManutencao(idManutencao: number, numeroSolicitacao: string): Observable<AtividadeConsulta[]> {
    return super.getList(this.baseEndPoint + '/manutencao-corretiva', idManutencao + '/' +  numeroSolicitacao);
  }

  public buscarAtividadesPorManutencaoPreventiva(idManutencao: number): Observable<AtividadeConsulta[]> {    
    return super.getList(this.baseEndPoint + '/manutencao-preventiva/' +idManutencao);
  }

  public buscarAtividadesPorExecutante(idManutencao: number, matriculaTecnico: string, numeroSolicitacao: string): Observable<AtividadeConsulta[]> {
    return super.getList(this.baseEndPoint + '/executante/' + idManutencao + '/' +  matriculaTecnico, numeroSolicitacao);
  }

  public buscarHorasApropriadas(idManutencao: number, matriculaTecnico: string): Observable<Atividade> {
    return super.getOne(this.baseEndPoint + '/horas-apropriadas', idManutencao + '/' +  matriculaTecnico);
  }

  public buscarTempoDisponivel(idManutencao: number, matriculaTecnico: string): Observable<Atividade> {
    return super.getOne(this.baseEndPoint + '/tempo-disponivel', idManutencao + '/' +  matriculaTecnico);
  }

  public remover(id: number): Observable<Atividade>{    
    return super.delete(this.baseEndPoint, id);
  }

}
