import { Pagina } from './../../core/models/pagina.model';
import { Observable } from 'rxjs/Observable';
import { LabelValue } from './../../core/models/label-value';
import { Http } from '@angular/http';
import { Injectable } from '@angular/core';
import { AbstractResource } from '../../core/http/abstract.resource';
import { HistoricoStatusManutencaoFiltro } from '../models/historico-status-filtro.model';
import { HistoricoStatusManutencao } from '../models/historico-status-manutencao.model';
import { DashboardVO } from '../../shared/models/dashboardVO.model';
import { DashboardDTO } from '../../shared/models/dashboardDTO.model';
import { HorasMinutos } from '../models/horas-minutos.model';

@Injectable()
export class StatusManutencaoCorretivaService extends AbstractResource<any> {

  private baseEndPoint: string = '/status-manutencao';

  constructor(http: Http) {
    super(http, '');
  }

  public buscarTodosLabelValue(): Observable<LabelValue[]> {
    return super.getList(this.baseEndPoint);
  }

  public buscarComboEditarManutencao(idManutencao: number, idPerfil: number, matricula: string): Observable<LabelValue[]> {
    return super.getList(this.baseEndPoint + '/manutencao/' + idManutencao + '/' + idPerfil, matricula);
  }

  public filtrar(filtro: HistoricoStatusManutencaoFiltro, params?: any): Observable<Pagina<HistoricoStatusManutencao>> {
    return super.filter(this.baseEndPoint + '/pagina', filtro, params);
  }

  public buscarDashboard(dashboardVO: DashboardVO): Observable<DashboardDTO[]>{    
    return super.post(`${this.baseEndPoint}/dashboard`, dashboardVO);
  }

  public buscarHorasStatus(idManutencao: number): Observable<HorasMinutos> {
    return super.getOne(`${this.baseEndPoint}/historico/${idManutencao}`);
  }
  
}
