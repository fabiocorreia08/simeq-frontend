import { PreventivaCadastro } from '../models/preventiva-cadastro.model';
import { LabelValue } from '../../core/models/label-value';
import { Observable } from 'rxjs/Observable';
import { Http } from '@angular/http';
import { Injectable } from '@angular/core';
import { AbstractResource } from '../../core/http/abstract.resource';
import { PreventivaConsultaFiltro } from '../models/preventiva-consulta-filtro.model';
import { PreventivaConsultaTabela } from '../models/preventiva-consulta-tabela.model';
import { Pagina } from '../../core/models/pagina.model';
import { AprovacaoManutencaoPreventivaFiltro } from '../../aprova\u00E7\u00E3o/aprovacao-manutencao-preventiva/models/aprovacao-manutencao-preventiva-filtro.model';
import { AprovacaoPreventivaConsultaTabela } from '../../aprova\u00E7\u00E3o/aprovacao-manutencao-preventiva/models/aprovacao-preventiva-consulta-tabela.model';
import { HistoricoStatusManutencaoFiltro } from '../models/historico-status-filtro.model';
import { HistoricoManutencaoEquipamento } from '../models/hist-manutencao-equip';
import { PlanoPreventivaCadastro } from '../models/plano-preventiva-cadastro.model';
import { PlanoPreventivaConsultaFiltro } from '../models/plano-preventiva-consulta-filtro.model';
import { PlanoPreventivaConsultaTabela } from '../models/plano-preventiva-consulta-tabela.model';

@Injectable()
export class PlanoPreventivaService extends AbstractResource<any> {

  private baseEndPoint: string = '/planos-manutencoes-preventivas';

  constructor(http: Http) {
    super(http, '');
  }

  public buscarTodosMeses(): Observable<LabelValue[]> {
    return super.getList(this.baseEndPoint + '/meses');
  }

  public buscarPorId(id: number): Observable<PreventivaCadastro> {
    return super.getOne(this.baseEndPoint, id);
  }

  public buscarPreventivaPorNumeroSolicitacao(numeroSolicitacao: string): Observable<PlanoPreventivaCadastro> {
    return super.getOne(this.baseEndPoint + '/numero-solicitacao', numeroSolicitacao);
  }

  public filtrar(filtro: PlanoPreventivaConsultaFiltro, params?: any): Observable<Pagina<PlanoPreventivaConsultaTabela>> {
    return super.filter(this.baseEndPoint + '/pagina', filtro, params);
  }

  public buscarAtividadesCorretivaPorEquipamento(idEquipamento: number, dataInicialFiltro: Date, dataFinalFiltro: Date ) {
    return super.getList(this.baseEndPoint + '/atividades-corretiva/equipamento/'+idEquipamento+'/'+dataInicialFiltro+'/'+dataFinalFiltro);
  }

}
