import { StatusPreventivaComponent } from './components/preventiva/status-preventiva/status-preventiva.component';
import { ManutencaoPreventivaService } from './services/manutencao-preventiva.service';
import { ManutencaoPreventivaRoutingModule } from './components/preventiva/manutencao-preventiva-routing.module';
import { InformacaoService } from './services/informacao.service';
import { CadastrarInformacaoComponent } from './components/cadastrar-informacao/cadastrar-informacao.component';
import { CadastrarManutencaoCorretivaGuard } from './guards/cadastrar-manutencao.guard';
import { AlocacaoModule } from './../alocacao/alocacao.module';
import { ManutencaoCorretivaResolve } from './resolves/manutencao-corretiva.resolve';
import { StatusManutencaoCorretivaService } from './services/status-manutencao.service';
import { TextMaskModule } from 'angular2-text-mask';
import { ButtonModule, InputMaskModule, InputTextareaModule, DataTableModule, DropdownModule, CalendarModule } from 'primeng/primeng';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule } from '@angular/forms';
import { TecnicoModule } from './../administracao/tecnico/tecnico.module';
import { GrupoSubgrupoModule } from './../administracao/grupo-subgrupo/grupo-subgrupo.module';
import { EquipamentoModule } from './../administracao/equipamento/equipamento.module';
import { NgModule } from '@angular/core';
import { CoreModule } from '../core/core.module';
import { SharedModule } from '../shared/shared.module';
import { ConsultarManutencaoCorretivaComponent } from './components/consultar-manutencao-corretiva/consultar-manutencao-corretiva.component';
import { ManutencaoRoutingModule } from './manutencao-routing.module';
import { MultiSelectModule } from 'primeng/components/multiselect/multiselect';
import { ManutencaoCorretivaService } from './services/manutencao-corretiva.service';
import { CadastrarManutencaoCorretivaComponent } from './components/cadastrar-manutencao-corretiva/cadastrar-manutencao-corretiva.component';
import { DetalharManutencaoCorretivaComponent } from './components/detalhar-manutencao-corretiva/detalhar-manutencao-corretiva.component';
import { DetalharManutencaoCorretivaStatusComponent } from './components/detalhar-manutencao-corretiva-status/detalhar-manutencao-corretiva-status.component';
import { DetalharAlocacaoComponent } from './components/detalhar-alocacao/detalhar-alocacao.component';
import { ConsultarAtividadeComponent } from './components/atividade/consultar-atividade/consultar-atividade.component';
import { CadastrarAtividadeComponent } from './components/atividade/cadastrar-atividade/cadastrar-atividade.component';
import { AtividadeService } from './services/atividade.service';
import { ConsultarInformacaoComponent } from './components/consultar-informacao/consultar-informacao.component';
import { ModalMaterialComponent } from './components/atividade/cadastrar-atividade/modal-material/modal-material.component';
import { EditarAtividadeGuard } from './guards/editar-atividade.guard';
import { DetalharAtividadeComponent } from './components/atividade/detalhar-atividade/detalhar-atividade.component';
import { AtividadeDetalheResolve } from './resolves/atividade-detalhe.resolve';
import { DetalharManutencaoAtividadeComponent } from './components/detalhar-manutencao-atividade/detalhar-manutencao-atividade.component';
import { AtividadeResolve } from './resolves/atividade.resolve';
import { CadastrarPreventivaComponent } from './components/preventiva/cadastrar-preventiva/cadastrar-preventiva.component';
import { ManutencaoPreventivaResolve } from './resolves/manutencao-preventiva.resolve';
import { StatusPreventivaService } from './services/status-preventiva.service';
import { ConsultarPreventivaComponent } from './components/preventiva/consultar-preventiva/consultar-preventiva.component';
import { DetalharPreventivaComponent } from './components/preventiva/detalhar-preventiva/detalhar-preventiva.component';
import { ManutencaoResolve } from './resolves/manutencao.resolve';
import { SomenteNumerosDirective } from '../shared/directives/somente-numeros.directive';
import { SomenteNumerosPrefixo } from '../shared/directives/somente-numeros-prefixo';
import { CurrencyMaskModule } from 'ng2-currency-mask';
import {AccordionModule} from 'primeng/accordion';
import { ModalAssistenteProducaoComponent } from './components/cadastrar-manutencao-corretiva/modal-assistente-producao/modal-assistente-producao.component';
import { ModalTecnicoComponent } from './components/atividade/cadastrar-atividade/modal-tecnico/modal-tecnico.component';
import { StatusCorretivaResolve } from './resolves/status-corretiva.resolve';
import { PlanoPreventivaService } from './services/plano-preventiva.service';
import { ConsultarPlanoPreventivaComponent } from './components/preventiva/plano/consultar-plano-preventiva/consultar-plano-preventiva.component';
import { PlanoPreventivaRoutingModule } from './components/preventiva/plano/plano-preventiva-routing.module';
import { EditarAtividadeComponent } from './components/atividade/editar-atividade/editar-atividade.component';
import { AtividadeEditeResolve } from './resolves/atividade-edite.resolve';
import { StatusPreventivaResolve } from './resolves/status-preventiva.resolve';

@NgModule({
    imports: [
        SharedModule,
        EquipamentoModule,
        GrupoSubgrupoModule,
        TecnicoModule,
        AlocacaoModule,
        ManutencaoRoutingModule,
        ManutencaoPreventivaRoutingModule,
        PlanoPreventivaRoutingModule,
        FormsModule,
        BrowserAnimationsModule,
        ButtonModule,
        CoreModule,
        InputMaskModule,
        InputTextareaModule,
        MultiSelectModule,
        DataTableModule,
        DropdownModule,
        CalendarModule,
        TextMaskModule,
        CurrencyMaskModule,
        AccordionModule
    ],
    providers: [
      AtividadeResolve,
      AtividadeDetalheResolve,
      AtividadeEditeResolve,
      AtividadeService,
      StatusManutencaoCorretivaService,
      StatusPreventivaService,
      ManutencaoCorretivaService,
      ManutencaoCorretivaResolve,
      ManutencaoPreventivaService,
      ManutencaoPreventivaResolve,
      PlanoPreventivaService,
      InformacaoService,
      EditarAtividadeGuard,
      CadastrarManutencaoCorretivaGuard,
      ManutencaoResolve,
      StatusCorretivaResolve,
      StatusPreventivaResolve
    ],
    declarations: [
      ConsultarManutencaoCorretivaComponent,
      CadastrarManutencaoCorretivaComponent,
      DetalharManutencaoCorretivaComponent,
      DetalharManutencaoCorretivaStatusComponent,
      DetalharAlocacaoComponent,
      ConsultarAtividadeComponent,
      CadastrarAtividadeComponent,
      ConsultarInformacaoComponent,
      CadastrarInformacaoComponent,
      ModalMaterialComponent,
      DetalharAtividadeComponent,
      EditarAtividadeComponent,
      DetalharManutencaoAtividadeComponent,
      CadastrarPreventivaComponent,
      ConsultarPreventivaComponent,
      DetalharPreventivaComponent,
      StatusPreventivaComponent,      
      SomenteNumerosDirective,
      SomenteNumerosPrefixo,
      ModalAssistenteProducaoComponent,
      ModalTecnicoComponent,
      ConsultarPlanoPreventivaComponent
      ],
    exports: [
      ModalMaterialComponent,
      SomenteNumerosDirective,
      SomenteNumerosPrefixo,
      ModalAssistenteProducaoComponent,
      ModalTecnicoComponent
    ]
})
export class ManutecaoModule {}
