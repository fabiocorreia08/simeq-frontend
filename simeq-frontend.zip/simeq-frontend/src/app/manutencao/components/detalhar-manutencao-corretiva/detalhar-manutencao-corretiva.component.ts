import { PerfisConstants } from './../../../core/security/perfis.constants';
import { AuthenticationService } from './../../../core/security/auth.service';
import { BreadcrumbService } from './../../../core/breadcrumb/breadcrumb.service';
import { ManutencaoCorretivaService } from './../../services/manutencao-corretiva.service';
import { LabelValue } from './../../../core/models/label-value';
import { ActivatedRoute, Router } from '@angular/router';
import { ManutencaoCorretiva } from './../../models/manutencao-corretiva.model';
import { StatusManutencaoCorretivaEnum } from '../../enums/status-manutencao-corretiva.enum';
import { Component, OnInit } from '@angular/core';
import { isNullOrUndefined } from 'util';
import { Location } from '@angular/common';
import * as moment from 'moment';

@Component({
  selector: 'simeq-detalhar-manutencao-corretiva',
  templateUrl: './detalhar-manutencao-corretiva.component.html',
  styleUrls: ['./detalhar-manutencao-corretiva.component.scss']
})
export class DetalharManutencaoCorretivaComponent implements OnInit {

  public manutencaoCorretiva: ManutencaoCorretiva = new ManutencaoCorretiva();
  public classesManutencao: LabelValue[];
  public readonly TECNICO: number = 2;
  public readonly SOLICITANTE: number = 3;
  public readonly VISITANTE: number = 6;
  public isPerfilSolicitante: boolean;
  public isCancelada = false;
  public isExibir = false;

  constructor(private manutencaoCorretivaService: ManutencaoCorretivaService,
    private route: ActivatedRoute,
    private breadcrumbService: BreadcrumbService,
    private router: Router,
    private location: Location,
    public auth: AuthenticationService,) {
      breadcrumbService.addRoute('/app/manutencao/consultar-manutencao-corretiva', 'Corretivas', true);
      this.breadcrumbService.addRoute('/app/manutencao/detalhar-manutencao-corretiva', 'Detalhar', false);
  }

  ngOnInit() {
    this.buscarClassesManutencao();
    this.manutencaoCorretiva = this.route.snapshot.data['manutencaoCorretivaResolve'];
    this.isPerfilSolicitante = this.auth.getPerfil(this.SOLICITANTE);
    this.verificarStatusJustificativa();
    
    if(this.manutencaoCorretiva.paralisacao){      
      if(this.manutencaoCorretiva.idStatus === StatusManutencaoCorretivaEnum.ABERTA ||
        this.manutencaoCorretiva.idStatus === StatusManutencaoCorretivaEnum.RECURSO_ALOCADO ||
        this.manutencaoCorretiva.idStatus === StatusManutencaoCorretivaEnum.MANUTENCAO ||
        this.manutencaoCorretiva.idStatus === StatusManutencaoCorretivaEnum.AG_MATERIAL ||
        this.manutencaoCorretiva.idStatus === StatusManutencaoCorretivaEnum.AG_FORNECEDOR){
          this.atualizarHorasComParalizacao();
        }    
    }else{
      if(this.manutencaoCorretiva.idStatus === StatusManutencaoCorretivaEnum.ABERTA ||
        this.manutencaoCorretiva.idStatus === StatusManutencaoCorretivaEnum.RECURSO_ALOCADO ||
        this.manutencaoCorretiva.idStatus === StatusManutencaoCorretivaEnum.MANUTENCAO ||
        this.manutencaoCorretiva.idStatus === StatusManutencaoCorretivaEnum.AG_MATERIAL ||
        this.manutencaoCorretiva.idStatus === StatusManutencaoCorretivaEnum.AG_FORNECEDOR){
          this.atualizarHorasSemParalizacao();
        }
    }
    
  } 
  
  public atualizarHorasSemParalizacao(){    
      
    const now = new Date(); // Data de hoje
        
    const dia = this.manutencaoCorretiva.dataCriacao.substring(0,2);
    const mes = this.manutencaoCorretiva.dataCriacao.substring(3,5);
    const ano = this.manutencaoCorretiva.dataCriacao.substring(6,10);
    const hora = this.manutencaoCorretiva.horaCriacao;
          
    const past = new Date(ano+'-'+ mes+'-'+dia+' '+hora); // Data abertura
    const diff1 = Math.abs(now.getTime() - past.getTime()); // Subtrai uma data pela outra

    const horas = Math.floor(diff1/(1000*60*60));    
    const segundos = Math.ceil(diff1/1000);        
    const minutos = Math.floor(segundos/60)%60;

    //this.manutencaoCorretiva.horasComParalisacao  = '0000:00';
    this.manutencaoCorretiva.horasSemParalisacao  = this.formatarHoras(horas, minutos); 
    this.manutencaoCorretiva.horasTotal  = this.formatarHoras(horas, minutos); 
      
  
}

public atualizarHorasComParalizacao(){      

  let hoje = new Date();

  let diaCad = this.manutencaoCorretiva.dataCriacao.substring(0,2);
  let mesCad = this.manutencaoCorretiva.dataCriacao.substring(3,5);
  let anoCad = this.manutencaoCorretiva.dataCriacao.substring(6,10);
  let horaCad = this.manutencaoCorretiva.horaCriacao;

  let abertura = new Date(anoCad+'-'+ mesCad+'-'+diaCad+' '+horaCad);
  let df = Math.abs(hoje.getTime() - abertura.getTime());

  let horasTotal = Math.floor(df/(1000*60*60));    
  let segundosTotal = Math.ceil(df/1000);        
  let minutosTotal = Math.floor(segundosTotal/60)%60;

  //horas total    
  this.manutencaoCorretiva.horasTotal = this.formatarHoras(horasTotal, minutosTotal);
  //horas com
  let hc = this.manutencaoCorretiva.horasComParalisacao.replace(':', '');
  
  let horasCom = parseInt(hc.substring(0,4));
  let minutosCom = parseInt(hc.substring(4,6));
 
  this.manutencaoCorretiva.horasComParalisacao = this.formatarHoras(horasCom, minutosCom);

  let somaMinutosTotal = (horasTotal)*60 + minutosTotal;
  let somaMinutosCom = (horasCom)*60 + minutosCom;   

  let dfSem = somaMinutosTotal - somaMinutosCom;    
   
  let horasSem = Math.floor(dfSem/60);
  let minutosSem = dfSem%60;
 
   //horas sem
   this.manutencaoCorretiva.horasSemParalisacao = this.formatarHoras(horasSem, minutosSem);     

}

private formatarHoras(hora: number, minuto: number): string {
  if (!isNullOrUndefined(hora)) {
    if (!isNullOrUndefined(minuto)) {
      if (hora > 999) {
        return minuto > 9 ? `${hora}${minuto}` : `${hora}0${minuto}`;
      }
      if (hora > 99) {
        return minuto > 9 ? `0${hora}${minuto}` : `0${hora}0${minuto}`;
      }
      if (hora < 10) {
        return minuto > 9 ? `000${hora}${minuto}` : `000${hora}0${minuto}`;
      }
      return minuto > 9 ? `00${hora}${minuto}` : `00${hora}0${minuto}`;
    } else {               
      return hora > 99 ? `0${hora}00` : hora < 10 ? `000${hora}00` : `00${hora}00`;
    }
  } else {
    if (!isNullOrUndefined(minuto)) {
      return minuto > 9 ? `${minuto}` : `0${minuto}`;
    } else {
      return '000000';
    }
  }
}

  public buscarClassesManutencao(): void {
    this.manutencaoCorretivaService.buscarClassesManutencao().subscribe(c => {
      this.classesManutencao = c;
    });
  }

  public cancelar(): void {
    this.location.back();
  }

  public detalharStatus(): void {
    this.router.navigate(['app/manutencao/detalhar-manutencao-corretiva-status/' + this.manutencaoCorretiva.idManutencao + '/' + this.manutencaoCorretiva.numeroSolicitacao]);
  }

  public getPerfil(perfil: number): boolean {
    this.auth.authInfo.details.perfis.forEach(p => {
      if (p.id_perfil === perfil) {
        return true;
      }
    });
    return false;
  }

  public verificarStatusJustificativa():void{         
    if(this.manutencaoCorretiva.idStatus === 6 || this.manutencaoCorretiva.idStatus === 9 || this.manutencaoCorretiva.justificativa !== null){
      this.isExibir = true;
    }else{
      this.isExibir = false;
    }
  }

}
