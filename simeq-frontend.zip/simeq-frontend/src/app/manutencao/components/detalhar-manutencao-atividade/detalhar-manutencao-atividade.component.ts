import { BreadcrumbService } from './../../../core/breadcrumb/breadcrumb.service';
import { AtividadeService } from './../../services/atividade.service';
import { ActivatedRoute } from '@angular/router';
import { AtividadeConsulta } from './../../models/atividade-consulta.model';
import { ManutencaoCorretiva } from './../../models/manutencao-corretiva.model';
import { Component, OnInit, ViewChild } from '@angular/core';
import { Location } from '@angular/common';
import { Manutencao } from '../../models/manutencao.model';
import { ModalConfirmacaoComponent } from '../../../core/modal-confirmacao/modal-confirmacao.component';
import { MessagesService } from '../../../core/messages/messages.service';
import { AdministracaoGenericComponent } from '../../../administracao/administracao-generic.component';
import { Atividade } from '../../models/atividade.model';
import { Pagina } from '../../../core/models/pagina.model';
import { AtividadeFiltro } from '../../models/atividade-filtro.model';

@Component({
  selector: 'simeq-detalhar-manutencao-atividade',
  templateUrl: './detalhar-manutencao-atividade.component.html',
  styleUrls: ['./detalhar-manutencao-atividade.component.scss']
})
export class DetalharManutencaoAtividadeComponent extends AdministracaoGenericComponent implements OnInit {

  @ViewChild('modalConfirmaExclusao')
  modalConfirmaExclusao: ModalConfirmacaoComponent;

  public filtro: AtividadeFiltro = new AtividadeFiltro;
  public pagina: Pagina<AtividadeConsulta> = new Pagina<AtividadeConsulta>();

  public manutencao: Manutencao = new Manutencao();
  public atividades: AtividadeConsulta[] = [];

  constructor(private route: ActivatedRoute,
    private atividadeService: AtividadeService,
    private breadcrumbService: BreadcrumbService,
    protected messagesService: MessagesService,
    private location: Location,) {
      super(messagesService);
      breadcrumbService.addRoute('/app/manutencao/atividade/consultar-atividade', 'Atividades', true);
    }

    ngOnInit() {
      this.manutencao = this.route.snapshot.data['manutencaoResolve'];
      this.atividadeService.buscarAtividadesPorManutencao(this.manutencao.idManutencao, this.manutencao.numeroSolicitacao)
      .subscribe(a => {
        this.atividades = a;
      });
      this.breadcrumbService.addRoute('/app/manutencao/atividade/detalhar/' + this.manutencao.idManutencao,
        'Detalhar', false);
  }

  public filtrar(): void {
    this.atividadeService.filtrar(this.filtro, this.pagina)
      .subscribe((pagina) => {
        this.pagina = pagina;
      },
      (error) => {
        this.messagesService.addErrorMessage(error);
      });
  }

  public remover(idParametro:number): void {    
    this.modalConfirmaExclusao.showDialog().subscribe(success => {
      if (success) {
        this.atividadeService.remover(idParametro).subscribe(() => {          
          this.messagesService.addSuccessMessage("Exclusão realizada com sucesso");
          this.filtrar();
        }
        , error => {
          this.messagesService.addErrorMessage(error);
        })        
      }
    });
  }

  public voltar(): void {
    this.location.back();
  }

}
