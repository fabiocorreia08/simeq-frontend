import { isNullOrUndefined } from 'util';
import { AuthenticationService } from './../../../core/security/auth.service';
import { InformacaoService } from './../../services/informacao.service';
import { Router, ActivatedRoute } from '@angular/router';
import { ManutencaoCorretivaService } from './../../services/manutencao-corretiva.service';
import { Informacao } from './../../models/informacao.model';
import { Component, OnInit } from '@angular/core';
import { AdministracaoGenericComponent } from '../../../administracao/administracao-generic.component';
import { MessagesService } from '../../../core/messages/messages.service';
import { BreadcrumbService } from '../../../core/breadcrumb/breadcrumb.service';
import { Pagina } from '../../../core/models/pagina.model';
import { LazyLoadEvent } from 'primeng/primeng';
import { InformacaoFiltro } from '../../models/informacao-filtro.model';
import { Location } from '@angular/common';
import { Manutencao } from '../../models/manutencao.model';
import { CalendarLocaleService } from './../../../core/calendar.locale.service';
import { LabelValue } from './../../../core/models/label-value';
import { EquipamentoService } from '../../../administracao/equipamento/services/equipamento.service';
import { ArrayUtil } from './../../../shared/Utils/ArrayUtil';
import { PerfisConstants } from '../../../core/security/perfis.constants';

@Component({
    selector: 'simeq-consultar-informacao',
    templateUrl: 'consultar-informacao.component.html',
    styleUrls: ['consultar-informacao.component.scss']
})

export class ConsultarInformacaoComponent extends AdministracaoGenericComponent implements OnInit {

    public informacao: Informacao = new Informacao();
    public manutencao: Manutencao;
    public informacaoFiltro: InformacaoFiltro = new InformacaoFiltro();
    public codigoManutencaoURL: string = null;
    public isDetalhar: boolean = false;
    public desabilitarBotoesVisitante: boolean = false;
    public desabilitarBotoesSolicitante = false;
    public readonly VISITANTE: number = 6;
    public readonly SOLICITANTE: number = 3;
    public isCorretiva: boolean = false;
    public listaEquipamento: LabelValue[] = [];

    public isPerfilTecnico = false;
    public isPerfilVisitante = false;

    public pagina: Pagina<Informacao> = new Pagina<Informacao>();

    constructor(messagesService: MessagesService,
        private equipamentoService: EquipamentoService,
        public calendarLocaleService: CalendarLocaleService,
        private breadcrumbService: BreadcrumbService,
        private manutencaoCorretivaService: ManutencaoCorretivaService,
        private router: Router,
        private location: Location,
        private route: ActivatedRoute,
        private informacaoService: InformacaoService,
        public auth: AuthenticationService) {
        super(messagesService);
    }

    ngOnInit() {
        let verificaCaminho;
        this.route.queryParams.subscribe(params => {
            verificaCaminho = (params['isCorretiva'] === "true");
            this.isCorretiva = (this.route.snapshot.data['isCorretiva']) ?
                this.route.snapshot.data['isCorretiva'] : verificaCaminho;
        })

        if (this.breadcrumbService.routes.length === 0) {
            if (this.isCorretiva) {
                this.breadcrumbService.addRoute('/app/manutencao/consultar-manutencao-corretiva', 'Corretivas', true);
                this.breadcrumbService.addRoute('/app/manutencao/atividade/consultar-atividade', 'Informações', false);
                this.breadcrumbService.addRoute('/app/manutencao/atividade/consultar-atividade', 'Consultar', false);
            } else {
                this.breadcrumbService.addRoute('/app/manutencao/preventiva/consultar', 'Preventivas', true);
                this.breadcrumbService.addRoute('/app/manutencao/atividade/consultar-atividade', 'Informações', false);
                this.breadcrumbService.addRoute('/app/manutencao/atividade/consultar-atividade', 'Consultar', false);
            }
        }
        this.recuperarUsuarioLogado();
        this.recuperarNumeroSolicitacaoURL();
        this.carregarEquipamentos();

        this.desabilitarBotoesVisitante = this.getPerfil(this.VISITANTE);
        this.desabilitarBotoesSolicitante = this.getPerfil(this.SOLICITANTE);
    }

    public carregarEquipamentos(): void {
        this.equipamentoService.buscarTodosLabelValue().subscribe(e => {
          this.listaEquipamento = e;
          this.listaEquipamento = ArrayUtil.adicionarPrimeiroValor(this.listaEquipamento, 'Selecione', null);
        });
      }

    private recuperarUsuarioLogado() {        
        this.informacao.matriculaUsuarioLogado = this.auth.authInfo.username;        
        this.informacao.nomeUsuarioLogado = this.auth.authInfo.details['nome'];
        this.informacao.perfil = this.auth.getIdPerfil(this.auth.authInfo.details.perfis);
    }

    private numeroSolicitacaoPreenchido() {
        if (isNullOrUndefined(this.informacao.numeroSolicitacao) ||
            this.informacao.numeroSolicitacao.trim() == "") {
            this.messagesService.addErrorMessage("Informe o número da solicitação.");
            return false;
        }
        return true;
    }

    public recuperarManutencao() {                
        if (this.numeroSolicitacaoPreenchido()) {
            this.informacao.numeroSolicitacao = this.informacao.numeroSolicitacao.toLocaleUpperCase();
            this.manutencaoCorretivaService.buscarPorPerfil(this.informacao.perfil, this.informacao.matriculaUsuarioLogado, this.informacao.numeroSolicitacao)
                .subscribe(manutencao => {
                    if (manutencao) {
                        this.manutencao = manutencao;
                        this.informacao.classeManutencao = manutencao.classeManutencao;
                        this.informacaoFiltro.idManutencao = this.manutencao.idManutencao;
                        this.informacaoFiltro.numeroSolicitacao = this.manutencao.numeroSolicitacao;                        
                        this.informacaoFiltro.dataCadastro = this.informacao.dataCadastro;                        
                        this.pesquisar();
                    } else {
                        this.limparClasse();
                        this.messagesService.addErrorMessage("Este Nº de Solicitação não existe.");
                    }
                },
                    error => {
                        this.limparClasse();
                        this.messagesService.addErrorMessage(error);
                    });
        }
    }

    public redirecionarTelaCadastro() {
        let numeroSolicitacao = !isNullOrUndefined(this.manutencao) ? this.manutencao.numeroSolicitacao : "";
        this.router.navigate(['app/manutencao/informacao/cadastrar-informacao', numeroSolicitacao]);
    }

    public filtrar(): void {
        if (!isNullOrUndefined(this.manutencao)) {
            this.informacao.idManutencao = this.manutencao.idManutencao;
            this.informacaoService.filtrar(this.informacaoFiltro, this.pagina)
                .subscribe((pagina) => {
                    this.pagina = pagina;
                },
                    (error) => {
                        this.messagesService.addErrorMessage(error);
                    });
        }
    }

    public limparFiltros(): void {
        this.pagina = new Pagina();
        this.informacao.classeManutencao = null;
        this.informacao.numeroSolicitacao = null;
        this.informacaoFiltro = new InformacaoFiltro();
        this.manutencao = null;
    }

    public limparClasse(): void {
        this.pagina = new Pagina();
        this.informacao.classeManutencao = null;
        this.manutencao = null;
    }

    public pesquisar(): void {
        this.pagina = new Pagina();
        this.filtrar();
    }

    public paginar(event: LazyLoadEvent): void {
        this.pagina = new Pagina<Informacao>(event.first, event.rows);
        this.filtrar();
    }

    private recuperarNumeroSolicitacaoURL() {
        this.codigoManutencaoURL = this.route.snapshot.paramMap.get('codigo');
        if (!isNullOrUndefined(this.codigoManutencaoURL) && this.codigoManutencaoURL !== '') {
            this.informacao.numeroSolicitacao = this.codigoManutencaoURL;
            this.recuperarManutencao();
        }
        let acao = this.route.snapshot.paramMap.get('acao');
        this.isDetalhar = !isNullOrUndefined(acao) && acao != '' ? true : false;
    }

    public voltar() {
        this.location.back();
    }

    public getPerfil(perfil: number): boolean {
        let isPerfil = false;
        this.auth.authInfo.details.perfis.forEach(p => {
            if (p.id_perfil === perfil) {
                isPerfil = true;
            }
        });
        return isPerfil;
    }
    
}