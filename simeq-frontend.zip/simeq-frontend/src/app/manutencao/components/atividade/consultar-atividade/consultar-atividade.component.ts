import { ActivatedRoute } from '@angular/router';
import { ModalConfirmacaoComponent } from './../../../../core/modal-confirmacao/modal-confirmacao.component';
import { PerfisConstants } from './../../../../core/security/perfis.constants';
import { AuthenticationService } from './../../../../core/security/auth.service';
import { LazyLoadEvent } from 'primeng/components/common/api';
import { BreadcrumbService } from './../../../../core/breadcrumb/breadcrumb.service';
import { CalendarLocaleService } from './../../../../core/calendar.locale.service';
import { MessagesService } from './../../../../core/messages/messages.service';
import { AdministracaoGenericComponent } from './../../../../administracao/administracao-generic.component';
import { isNullOrUndefined } from 'util';
import { Pagina } from './../../../../core/models/pagina.model';
import { Component, OnInit, ViewChild } from '@angular/core';
import { AtividadeConsulta } from '../../../models/atividade-consulta.model';
import { AtividadeFiltro } from '../../../models/atividade-filtro.model';
import { EquipamentoDTO } from '../../../../administracao/equipamento/resources/dtos/equipamento-dto.class';
import { HistoricoSituacaoEquipamentoService } from '../../../../administracao/equipamento/services/historico-situacao-equipamento.service';
import { ManutencaoCorretivaService } from '../../../services/manutencao-corretiva.service';
import { PessoaService } from '../../../../shared/services/pessoa.service';
import { HistoricoSituacaoEquipamentoDTO } from '../../../../administracao/equipamento/resources/dtos/historico-situacao-equipamento-dto.class';
import { AtividadeService } from '../../../services/atividade.service';
import { AssistenteProducao } from '../../../../shared/models/assistente-producao.model';
import { Manutencao } from '../../../models/manutencao.model';

@Component({
  selector: 'simeq-consultar-atividade',
  templateUrl: './consultar-atividade.component.html',
  styleUrls: ['./consultar-atividade.component.scss']
})
export class ConsultarAtividadeComponent extends AdministracaoGenericComponent implements OnInit {

  public pagina: Pagina<AtividadeConsulta> = new Pagina<AtividadeConsulta>();
  public filtro: AtividadeFiltro = new AtividadeFiltro();
  public assitenteProducao: AssistenteProducao = new AssistenteProducao();
  public manutencaoSelecionada: Manutencao = new Manutencao();
  public centroCustoEquipamento: string;
  public desabilitarBotoesVisitante = false;
  @ViewChild('modalConfirmaExclusaoAtividade')
  public modalConfirmaExclusaoAtividade: ModalConfirmacaoComponent;
  public idPerfil;
  public buscaHabilitada: boolean = false;
  public isDesabilitarCamposEditar: boolean = false;
  public isCorretiva: boolean = false;

  constructor(public calendarLocaleService: CalendarLocaleService,
    public historicoSituacaoEquipamentoService: HistoricoSituacaoEquipamentoService,
    public manutencaoCorretivaService: ManutencaoCorretivaService,
    public pessoaService: PessoaService,
    messagesService: MessagesService,
    private breadcrumbService: BreadcrumbService,
    public atividadeService: AtividadeService,
    private route: ActivatedRoute,
    public auth: AuthenticationService, ) {
    super(messagesService);

  }

  ngOnInit() {
    if (this.breadcrumbService.routes.length === 0) {
      let verificaCaminho;
      this.route.queryParams.subscribe(params => {
        verificaCaminho = (params['isCorretiva'] === "true") ? true : false;
      })
      this.isCorretiva = (verificaCaminho || this.route.snapshot.data['isCorretiva']) ? true : false;

      if (this.isCorretiva === true) {
          this.breadcrumbService.addRoute('/app/manutencao/consultar-manutencao-corretiva', 'Corretivas', true);
          this.breadcrumbService.addRoute('/app/manutencao/atividade/consultar-atividade', 'Atividades', false);
          this.breadcrumbService.addRoute('/app/manutencao/atividade/consultar-atividade', 'Consultar', false);
      } else if (this.isCorretiva === false) {
          this.breadcrumbService.addRoute('/app/manutencao/preventiva/consultar', 'Preventivas', true);
          this.breadcrumbService.addRoute('/app/manutencao/atividade/consultar-atividade', 'Atividades', false);
          this.breadcrumbService.addRoute('/app/manutencao/atividade/consultar-atividade', 'Consultar', false);
      }
    }
      this.idPerfil = this.auth.getIdPerfil(this.auth.authInfo.details.perfis);
      this.desabilitarBotoesVisitante = this.auth.getPerfil(PerfisConstants.VISITANTE);
  }

  public buscarAssistenteProducao(): void {
    if (this.isMatriculaPreenchida()) {
      this.pessoaService.buscarSolicitantesManutencao(this.filtro.matriculaExecutante)
        .subscribe((a: AssistenteProducao) => {
          if (isNullOrUndefined(a)) {
            this.assitenteProducao = new AssistenteProducao();
            this.messagesService.addErrorMessage('Matrícula não encontrada.');
            return;
          }
          if (a.situacao.length !== 0) {
            this.assitenteProducao = new AssistenteProducao();
            this.messagesService.addErrorMessage('Usuário inativo, informe um usuário ativo.');
            return;
          }
          this.assitenteProducao = a;
        });
    }
  }

  private isMatriculaPreenchida(): boolean {
    if (isNullOrUndefined(this.filtro.matriculaExecutante) ||
      this.filtro.matriculaExecutante.trim().length === 0) {
      this.messagesService.addErrorMessage('Falta informação obrigatória. Por favor, informe a Matrícula.');
      return false;
    }
    return true;
  }

  public buscarManutencao(): void {
    if (this.isNumeroSolicitacaoPreenchido()) {
      this.buscarManutencaoTodosPerfis();
    }
  }

  private buscarManutencaoTodosPerfis() {
    this.filtro.numeroSolicitacao = this.filtro.numeroSolicitacao.toLocaleUpperCase();
    this.manutencaoCorretivaService.buscarPorNumeroSolicitacaoPorHierarquia(this.filtro.numeroSolicitacao, this.idPerfil,
      this.auth.authInfo.username)
      .subscribe((m: Manutencao) => {
        if (isNullOrUndefined(m)) {
          this.manutencaoSelecionada = new Manutencao();
          this.centroCustoEquipamento = null;
          this.messagesService.addErrorMessage('Solicitação não encontrada.');
          return;
        }
        this.manutencaoSelecionada = m;
        this.historicoSituacaoEquipamentoService.buscarCentroCustoInstalacaoPorIdEquipamento(this.manutencaoSelecionada.idEquipamento)
          .subscribe((h: HistoricoSituacaoEquipamentoDTO) => {
            this.centroCustoEquipamento = h.hierarquiaCentroCusto;
          });
      },
        (error) => {
          this.messagesService.addErrorMessage(error);
        });
  }

  private isNumeroSolicitacaoPreenchido(): boolean {
    if (isNullOrUndefined(this.filtro.numeroSolicitacao) ||
      this.filtro.numeroSolicitacao.trim().length === 0) {
      this.centroCustoEquipamento = null;
      this.manutencaoSelecionada = new Manutencao();
      this.messagesService.addErrorMessage('Falta informação obrigatória. Por favor, informe o Nº Solicitação.');
      return false;
    }
    return true;
  }

  public limparFiltros(): void {
    this.buscaHabilitada = false;
    this.assitenteProducao = new AssistenteProducao();
    this.manutencaoSelecionada = new Manutencao();
    this.centroCustoEquipamento = '';
    this.pagina = new Pagina();
    this.filtro = new AtividadeFiltro();
  }

  public pesquisar(): void {
    if (this.isNumeroSolicitacaoPreenchido()) {
      this.buscaHabilitada = true;
      this.pagina = new Pagina();
      this.filtrar();
    }
  }

  public paginar(event: LazyLoadEvent): void {
    if (this.buscaHabilitada) {
      this.pagina = new Pagina<AtividadeConsulta>(event.first, event.rows);
      this.filtrar();
    }
  }

  public filtrar(): void {
    this.filtro.matricula = this.auth.authInfo.username;
    this.filtro.perfil = this.auth.getIdPerfil(this.auth.authInfo.details.perfis);
    if (this.isDatasFiltroValida()) {
      this.atividadeService.filtrar(this.filtro, this.pagina)
        .subscribe((pagina) => {
          this.pagina = pagina;
        },
          (error) => {
            this.messagesService.addErrorMessage(error);
          });
    }
  }

  private isDatasFiltroValida(): boolean {
    if (!isNullOrUndefined(this.filtro.periodoInicio) && !isNullOrUndefined(this.filtro.periodoFim)) {
      if (this.filtro.periodoFim < this.filtro.periodoInicio) {
        this.messagesService.addErrorMessage('Data inválida. A data final deve ser maior que a data inicial.');
        return false;
      }
    }
    return true;
  }

  public removerAtividade(idAtividade: number): void {
    this.modalConfirmaExclusaoAtividade.showDialog().subscribe(success => {
      if (success) {
        this.atividadeService.removerAtividade(idAtividade, this.filtro.numeroSolicitacao)
          .subscribe(a => {
            this.messagesService.addSuccessMessage('Atividade excluída com sucesso.');
            this.pesquisar();
          }, (error) => {
            this.messagesService.addErrorMessage(error);
          });
      }
    }, (error) => {
      this.messagesService.addErrorMessage(error);
    });
  }

}
