import { BreadcrumbService } from './../../../../core/breadcrumb/breadcrumb.service';
import { ActivatedRoute } from '@angular/router';
import { AtividadeService } from './../../../services/atividade.service';
import { Component, OnInit } from '@angular/core';
import { AtividadeDetalhar } from '../../../models/atividade-detalhar.model';
import { Location } from '@angular/common';

@Component({
  selector: 'simeq-detalhar-atividade',
  templateUrl: './detalhar-atividade.component.html',
  styleUrls: ['./detalhar-atividade.component.scss']
})
export class DetalharAtividadeComponent implements OnInit {

  public atividadeDatalhar: AtividadeDetalhar = new AtividadeDetalhar();

  constructor(public atividadeService: AtividadeService,
    private route: ActivatedRoute,
    public breadcrumbService: BreadcrumbService,
    private location: Location,) {
      breadcrumbService.addRoute('/app/manutencao/atividade/consultar-atividade', 'Atividades', true);
      breadcrumbService.addRoute('/app/manutencao/atividade/consultar-atividade', 'Detalhar', false);
  }

  ngOnInit() {
    this.atividadeDatalhar = this.route.snapshot.data['atividadeResolve'];
  }

  public voltar() {
    this.location.back();
  }
}
