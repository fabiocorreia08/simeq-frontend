import { BreadcrumbService } from './../../../../core/breadcrumb/breadcrumb.service';
import { ActivatedRoute, Router } from '@angular/router';
import { ModalConfirmacaoComponent } from './../../../../core/modal-confirmacao/modal-confirmacao.component';
import { ModalMaterialComponent } from './modal-material/modal-material.component';
import { AuthenticationService } from './../../../../core/security/auth.service';
import { TecnicoDTO } from './../../../../administracao/tecnico/resources/dtos/tecnico-dto.class';
import { GrupoDTO } from './../../../../administracao/grupo-subgrupo/resources/dtos/grupo-dto.class';
import { GrupoService } from './../../../../administracao/grupo-subgrupo/services/grupo.service';
import { ManutencaoCorretivaService } from './../../../services/manutencao-corretiva.service';
import { isNullOrUndefined, error } from 'util';
import { ArrayUtil } from './../../../../shared/Utils/ArrayUtil';
import { AtividadeService } from './../../../services/atividade.service';
import { MessagesService } from './../../../../core/messages/messages.service';
import { AdministracaoGenericComponent } from './../../../../administracao/administracao-generic.component';
import { LabelValue } from './../../../../core/models/label-value';
import { Component, OnInit, ViewChild } from '@angular/core';
import { Atividade } from '../../../models/atividade.model';
import { PessoaService } from '../../../../shared/services/pessoa.service';
import { TecnicoService } from '../../../../administracao/tecnico/services/tecnico.service';
import { PerfisConstants } from '../../../../core/security/perfis.constants';
import { AtividadeMaterial } from '../../../models/atividade-material.model';
import { Manutencao } from '../../../models/manutencao.model';
import { AtividadeTecnicoFiltro } from '../../../models/atividade-tecnico-filtro.model';
import { ModalTecnicoComponent } from './modal-tecnico/modal-tecnico.component';
import { StatusManutencaoCorretivaService } from '../../../services/status-manutencao.service';
import { Location } from '@angular/common';

@Component({
  selector: 'simeq-cadastrar-atividade',
  templateUrl: './cadastrar-atividade.component.html',
  styleUrls: ['./cadastrar-atividade.component.scss']
})
export class CadastrarAtividadeComponent extends AdministracaoGenericComponent implements OnInit {

  @ViewChild('modalMaterial')
  modalMaterial: ModalMaterialComponent;

  @ViewChild('modalMaterialEdicao')
  modalMaterialEdicao: ModalMaterialComponent;

  @ViewChild('modalConfirmaExclusaoMaterial')
  modalConfirmaExclusaoMaterial: ModalConfirmacaoComponent;

  @ViewChild('modalTecnico')
  modalTecnico: ModalTecnicoComponent;

  public mesReferencia: LabelValue[] = [];
  public listaComponente: LabelValue[] = [];
  public listaAcao: LabelValue[] = [];
  public listaSubGrupo: LabelValue[] = [];
  public listaGrupo: LabelValue[] = [];  
  public desabilitarSubGrupo = true;
  public atividade: Atividade = new Atividade();
  public atividadeTempoDisponivel: Atividade = new Atividade();
  public manutencaoSelecionada: Manutencao = new Manutencao();
  public tituloTela: string = 'Cadastrar';
  public isTecnicoLogado = false;
  public desabilitarMatricula = true;
  public idPerfil;
  public atividadeMaterialEdicao: AtividadeMaterial = new AtividadeMaterial();
  public listaCampoObrigatoriosNaoPreenchidos: string[] = [];
  public desabilitarBotoesVisitante = false;
  public isEditar: boolean = false;
  public desabilitarMes = false;
  public isDesabilitarHorasComParalisacao = true;
  public filtrotTecnico: AtividadeTecnicoFiltro = new AtividadeTecnicoFiltro();
  public isDesabilitarBotaoSalvar = true;
  registrarMaisAtividades = false;

  constructor(
    public messagesService: MessagesService,
    private atividadeService: AtividadeService,
    public statusService: StatusManutencaoCorretivaService,
    public pessoaService: PessoaService,
    public manutencaoCorretivaService: ManutencaoCorretivaService,
    public grupoService: GrupoService,
    public tecnicoService: TecnicoService,
    public auth: AuthenticationService,
    private route: ActivatedRoute,
    private router: Router,
    public breadcrumbService: BreadcrumbService,
    private location: Location
  ) {
    super(messagesService);
    this.breadcrumbService.addRoute('/app/manutencao/atividade/cadastrar-atividade', 'Atividades', true);
  }

  ngOnInit() {    
    this.idPerfil = this.auth.getIdPerfil(this.auth.authInfo.details.perfis);
    this.isEditar = this.route.snapshot.data['isEditar'];
    this.desabilitarBotoesVisitante = this.auth.getPerfil(PerfisConstants.VISITANTE);

    if (this.isEditar) {
      this.breadcrumbService.addRoute('/app/manutencao/atividade/editar' + this.atividade.id, 'Editar', false);
      this.tituloTela = 'Editar';
      this.atividade = this.route.snapshot.data['atividadeResolve'];
    } else {
      this.breadcrumbService.addRoute('/app/manutencao/atividade/cadastrar-atividade', 'Cadastrar', false);
      this.atividade.numeroSolicitacao = this.route.snapshot.params['numeroSolicitacao'];            
      this.preencherCamposObrigatorios();
      this.carregarExecutanteCadastro();      
    }

    if (this.auth.getPerfil(PerfisConstants.TECNICO)) {
      this.isTecnicoLogado = true;
    }

    this.carregarTodasAcoes();
    this.carregarTodosComponentes();
    this.carregarMeses();
    
    if (!isNullOrUndefined(this.atividade.numeroSolicitacao)) {
      this.buscarManutencao();
    }

    //this.buscarAtividadeMateriais();

  }  

  buscarAtividadeMateriais(){
    this.atividade.materiais.length = 1;
  }

  abrirModalTecnico() {    
    this.filtrotTecnico.idPerfil = this.idPerfil;
    this.filtrotTecnico.numeroSolicitacao = this.atividade.numeroSolicitacao;
    this.filtrotTecnico.matriculaUsuarioLogado = this.auth.authInfo.username;
    this.modalTecnico.showDialog().then((retorno) => {
      if (!retorno.error) {
        this.atividade.matriculaExecutante = retorno.tecnico.matricula;
        this.atividade.nomeExecutante = retorno.tecnico.nomeEmpregado;
        this.atividade.salario = retorno.tecnico.salario;
        this.carregarHorasApropriadas();
      }
    }).catch(erro => {

    });

    this.modalTecnico.pesquisar();
  }

  public carregarHorasApropriadas(){    
    this.atividadeService.buscarAtividadesPorExecutante(this.manutencaoSelecionada.idManutencao, this.atividade.matriculaExecutante, this.atividade.numeroSolicitacao)
    .subscribe(a => { 
      if(a.length===0){        
        this.atividade.horasApropriadas  = '0000:00'; 
      }else{        
      let hs = a[0][0];
      let ms = a[0][1];        
      let soma = (hs*60) + ms;

      const horasAprop = Math.floor(soma/60); 
      const minutosAprop = soma % 60;

      this.atividade.horasApropriadas  = this.formatarHoras(horasAprop, minutosAprop);  
      }
        
    });    
  }

  private carregarExecutanteCadastro(): void {    
    if (this.auth.getPerfil(PerfisConstants.TECNICO)) {
      this.tecnicoService.buscarPorMatricula(this.auth.authInfo.username)
        .subscribe((t: TecnicoDTO) => {
          this.atividade.matriculaExecutante = t.matricula;
          this.atividade.nomeExecutante = t.nomeEmpregado;
          this.atividade.salario = t.salario;
          
        },
          (error) => {
            this.atividade.matriculaExecutante = null;
            this.atividade.nomeExecutante = null;
            this.messagesService.addErrorMessage('Matrícula não encontrada.');
          });
    }
  }

  private isMatriculaPreenchida(): boolean {
    if ((isNullOrUndefined(this.atividade.matriculaExecutante) ||
      this.atividade.matriculaExecutante.trim().length === 0) && !this.isTecnicoLogado) {
      this.messagesService.addErrorMessage('Falta informação obrigatória. Por favor, informe a Matrícula.');
      return false;
    }
    return true;
  }

  public numeroSolicitacaoPreenchido(): void {
    this.blurCamposObrigatorios(this.atividade.numeroSolicitacao, 'Nº Solicitação');
    if ((isNullOrUndefined(this.atividade.numeroSolicitacao) ||
      this.atividade.numeroSolicitacao.trim().length === 0) &&
      (this.atividade.matriculaExecutante !== this.auth.authInfo.username)) {
      this.desabilitarMatricula = true;
      this.atividade.matriculaExecutante = null;
      this.atividade.nomeExecutante = null;
      this.limparDadosSolicitacao();
    }
  }

  public buscarManutencao(): void {  
    
    this.registrarMaisAtividades = false;
    if (this.isNumeroSolicitacaoPreenchido()) {
      this.atividade.numeroSolicitacao = this.atividade.numeroSolicitacao.toLocaleUpperCase();      
      //if (this.auth.getPerfil(PerfisConstants.TECNICO)) {
      //  this.buscarManutencaoTecnicoAlocado();
      //  return;
      //}
      this.buscarManutencaoTodosPerfis();
    }
  }

  public buscarHorasComParalizacao() {
    this.statusService.buscarHorasStatus(this.verificarIdManutencao())
      .subscribe(resposta => {
        let horas: string = this.formatarHoras(resposta.horas, resposta.minutos);
        //this.atividade.horasSemParalisacao = this.formatarHoras(null, null);
        //this.atividade.horasComParalisacao = horas;
        //this.atividade.horasAtividade = horas;
      });
    this.validarCamposObrigatoriosAtividadeCorretiva();
  }

  private verificarIdManutencao(): number {
    let routeId = parseInt(this.route.snapshot.params['idManutencao']);
    return this.manutencaoSelecionada.idManutencao === routeId ? routeId : this.manutencaoSelecionada.idManutencao;
  }

  private formatarHoras(hora: number, minuto: number): string {
    if (!isNullOrUndefined(hora)) {
      if (!isNullOrUndefined(minuto)) {
        if (hora > 999) {
          return minuto > 9 ? `${hora}${minuto}` : `${hora}0${minuto}`;
        }
        if (hora > 99) {
          return minuto > 9 ? `0${hora}${minuto}` : `0${hora}0${minuto}`;
        }
        if (hora < 10) {
          return minuto > 9 ? `000${hora}${minuto}` : `000${hora}0${minuto}`;
        }
        return minuto > 9 ? `00${hora}${minuto}` : `00${hora}0${minuto}`;
      } else {               
        return hora > 99 ? `0${hora}00` : hora < 10 ? `000${hora}00` : `00${hora}00`;
      }
    } else {
      if (!isNullOrUndefined(minuto)) {
        return minuto > 9 ? `${minuto}` : `0${minuto}`;
      } else {
        return '000000';
      }
    }
  }

  /*
  private formatarHoras(hora: number, minuto: number): string {
    if (!isNullOrUndefined(hora)) {
      if (!isNullOrUndefined(minuto)) {
        if (hora > 99) {
          return minuto > 9 ? `${hora}${minuto}` : `${hora}0${minuto}`;
        }
        if (hora < 10) {
          return minuto > 9 ? `00${hora}${minuto}` : `00${hora}0${minuto}`;
        }
        return minuto > 9 ? `0${hora}${minuto}` : `0${hora}0${minuto}`;
      } else {
        return hora > 99 ? `${hora}00` :
          hora < 10 ? `00${hora}00` :
            `0${hora}00`;
      }
    } else {
      if (!isNullOrUndefined(minuto)) {
        return minuto > 9 ? `000${minuto}` : `0000${minuto}`;
      } else {
        return '00000';
      }
    }
  }
   
  public validarMaskHorasEPrencherCamposAutomaticamente() {
    if (!isNullOrUndefined(this.atividade.horasAtividade)) {
      if (!isNullOrUndefined(this.atividade.horasComParalisacao)
        && !isNullOrUndefined(this.atividade.horasSemParalisacao)) {
        let horasS;
        let horasP;
        let horasHHT;
        let minutosS = parseInt(this.atividade.horasSemParalisacao.substr(3, 5)) + (60 * parseInt(this.atividade.horasSemParalisacao.substr(0, 3)));
        let minutosP = parseInt(this.atividade.horasComParalisacao.substr(3, 5)) + (60 * parseInt(this.atividade.horasComParalisacao.substr(0, 3)));
        let minutosHHT = parseInt(this.atividade.horasAtividade.substr(3, 5)) + (60 * parseInt(this.atividade.horasAtividade.substr(0, 3)));
        if (minutosP <= minutosHHT) {
          minutosS = minutosHHT - minutosP;
        }

        if (minutosS > 59) {
          horasS = Math.floor(minutosS / 60);
          minutosS = minutosS % 60;
        }

        if (minutosP > 59) {
          horasP = Math.floor(minutosP / 60);
          minutosP = minutosP % 60;
        }

        if (minutosHHT > 59) {
          horasHHT = Math.floor(minutosHHT / 60);
          minutosHHT = minutosHHT % 60;
        }
        this.atividade.horasSemParalisacao = this.formatarHoras(horasS, minutosS);
        this.atividade.horasComParalisacao = this.formatarHoras(horasP, minutosP);
        this.atividade.horasAtividade = this.formatarHoras(horasHHT, minutosHHT);
      }
    }
  }
*/
  private buscarManutencaoTodosPerfis() {    
    this.manutencaoCorretivaService.buscarPorNumeroSolicitacaoPorHierarquia(this.atividade.numeroSolicitacao, this.idPerfil,
      this.auth.authInfo.username)
      .subscribe((m: Manutencao) => {
        
        if (isNullOrUndefined(m)) {
          this.limparDadosSolicitacao();
          this.desabilitarMatricula = true;
          this.messagesService.addErrorMessage('Este Nº de Solicitação não existe.');
          return;
        }

        this.manutencaoSelecionada = m;                
        this.atividade.classeManutencao = this.manutencaoSelecionada.classeManutencao;
        this.desabilitarMatricula = false;
        this.atividade.tipoManutencao = this.manutencaoSelecionada.tipoManutencao;
        this.atividade.horasTotal = this.manutencaoSelecionada.horasTotal; 
                
        this.carregarGrupo();
        this.carregarMesesSolicitacao();
        this.validarCamposObrigatoriosAtividadePreventiva();
        
        if (!this.isEditar) {
          this.atividade.matriculaExecutante = '';
          this.atividade.nomeExecutante = '';
         
          if (m.tipoManutencao === 'C') {
            this.buscarHorasComParalizacao();
          }
        }
      },
        (error) => {
          this.limparDadosSolicitacao();
          this.messagesService.addErrorMessage(error);
        });
  } 

  private validarCamposObrigatoriosAtividadePreventiva(): void {
    if (this.atividade.tipoManutencao === 'P') {
      this.blurCamposObrigatorios(0, 'Mês Referência');
      this.blurCamposObrigatorios(0, 'Horas sem Paralisação');
      this.blurCamposObrigatorios(0, 'Horas com Paralisação');
    }
  }

  private validarCamposObrigatoriosAtividadeCorretiva(): void {
    if (this.atividade.tipoManutencao === 'C') {
      this.blurCamposObrigatorios(0, 'Horas sem Paralisação');
      this.blurCamposObrigatorios(0, 'Horas com Paralisação');
      this.blurCamposObrigatorios(0, 'H.H.T.');
    }
  }

  private buscarManutencaoTecnicoAlocado() {   
    
    this.atividadeService.buscarSolicitacaoTecnicoAlocado(this.atividade.numeroSolicitacao, this.auth.authInfo.username)
      .subscribe((m: Manutencao) => {

        if (isNullOrUndefined(m)) {
          this.limparDadosSolicitacao();
          this.messagesService.addErrorMessage('Executante não se encontra alocado na solicitação.');
          return;
        }
        
        this.manutencaoSelecionada = m;

        this.atividade.classeManutencao = this.manutencaoSelecionada.classeManutencao;
        this.desabilitarMatricula = false;
        this.atividade.tipoManutencao = this.manutencaoSelecionada.tipoManutencao;        
        this.isDesabilitarHorasComParalisacao = this.manutencaoSelecionada.paralisacao ? true : undefined;
        this.atividade.horasTotal = this.manutencaoSelecionada.horasTotal; 
        this.carregarHorasApropriadas();
        this.carregarGrupo();
        this.validarCamposObrigatoriosAtividadePreventiva();
        
        if (m.tipoManutencao === 'C') {
          this.carregarMesesSolicitacao();
          if (!this.isEditar) {
            this.buscarHorasComParalizacao();
          }
        }
      },
        (error) => {
          if (this.isEditar) {
            this.router.navigate(['app/manutencao/atividade/consultar-atividade']);
          }
          this.limparDadosSolicitacao();
          this.messagesService.addErrorMessage(error);
        }
      );
  }

  private limparDadosSolicitacao(): void {
    this.manutencaoSelecionada = new Manutencao();
    this.listaGrupo = ArrayUtil.adicionarPrimeiroValor([], 'Selecione', null);
    this.atividade.classeManutencao = null;
    this.atividade.numeroSolicitacao = null;
    this.listaSubGrupo = [];
    this.desabilitarSubGrupo = true;
    this.blurCamposObrigatorios(null, 'Nº Solicitação');
    this.blurCamposObrigatorios(null, 'Grupo');
    this.blurCamposObrigatorios(null, 'Subgrupo');
  }

  private isNumeroSolicitacaoPreenchido(): boolean {
    if (isNullOrUndefined(this.atividade.numeroSolicitacao) ||
      this.atividade.numeroSolicitacao.trim().length === 0) {
      this.manutencaoSelecionada = new Manutencao();
      this.atividade.classeManutencao = null;
      this.messagesService.addErrorMessage('Falta informação obrigatória. Por favor, informe o Nº Solicitação.');
      return false;
    }
    return true;
  }

  public carregarTodasAcoes() {
    this.atividadeService.buscarTodasAcoes()
      .subscribe(a => {
        this.listaAcao = a;
        this.listaAcao = ArrayUtil.adicionarPrimeiroValor(this.listaAcao, 'Selecione', null);
      },
        (error) => {
          this.messagesService.addErrorMessage(error);
        });
  }

  public carregarTodosComponentes() {
    this.atividadeService.buscarTodosComponentes()
      .subscribe(c => {
        this.listaComponente = c;
        this.listaComponente = ArrayUtil.adicionarPrimeiroValor(this.listaComponente, 'Selecione', null);
      },
        (error) => {
          this.messagesService.addErrorMessage(error);
        });
  }

  public carregarMeses() {
    this.atividadeService.buscarMeses()
      .subscribe(m => {
        this.mesReferencia = m;
        this.mesReferencia = ArrayUtil.adicionarPrimeiroValor(this.mesReferencia, 'Selecione', null);
      },
        (error) => {
          this.messagesService.addErrorMessage(error);
        });
  }

  public carregarMesesSolicitacao() {
    this.mesReferencia = [];
    this.atividadeService.buscarMesesSolicitacao(this.atividade.numeroSolicitacao)
      .subscribe(m => {
        this.mesReferencia = m;
        this.mesReferencia = ArrayUtil.adicionarPrimeiroValor(this.mesReferencia, 'Selecione', null);
        if (this.isEditar && this.mesReferencia.length >= 2) {
          this.desabilitarMes = true;
        }
      },
        (error) => {
          this.messagesService.addErrorMessage(error);
        });
  }

  public carregarGrupo(): void {
    this.grupoService.buscarGruposPorEquipamento(this.manutencaoSelecionada.idEquipamento).subscribe(g => {
      this.listaGrupo = g;
      this.listaGrupo = ArrayUtil.adicionarPrimeiroValor(this.listaGrupo, 'Selecione', null);
      if (this.isEditar) {
        this.onChangeGrupo();
      }
    });
  }

  public onChangeGrupo(): void {
    this.blurCamposObrigatorios(this.atividade.idGrupo, 'Grupo');
    if (this.atividade.idGrupo != null) {
      this.desabilitarSubGrupo = false;
      this.grupoService.buscarGruposFilho(this.atividade.idGrupo).subscribe(g => {
        this.listaSubGrupo = this.montarItensSelecaoGruposFilho(g);
        this.listaSubGrupo = ArrayUtil.adicionarPrimeiroValor(this.listaSubGrupo, 'Selecione', null);
      });
      return;
    }
    this.listaSubGrupo = [];
    this.desabilitarSubGrupo = true;
    this.atividade.idSubGrupo = null;
    this.blurCamposObrigatorios(this.atividade.idSubGrupo, 'Subgrupo');
  }

  private montarItensSelecaoGruposFilho(grupo: GrupoDTO[]): LabelValue[] {
    const itens: LabelValue[] = [];
    grupo.forEach((g) => {
      itens.push(new LabelValue(g.descricaoGrupo, g.idGrupo));
    });
    return itens;
  }

  abrirModalMaterial() {
    this.modalMaterial.showDialog().then((retorno) => {
      if (!retorno.error) {
        let material: AtividadeMaterial = retorno.atividadeMaterial;
        material.idAtividade = this.atividade.id;
        this.atividade.materiais.push(material);        
      }
    }).catch(erro => {

    });
  }

  public removerMaterial(material: AtividadeMaterial): void {
    this.modalConfirmaExclusaoMaterial.showDialog().subscribe(success => {
      if (success) {
        var index = this.atividade.materiais.indexOf(material);
        if (index > -1) {
          this.atividade.materiais.splice(index, 1);
          this.messagesService.addSuccessMessage('Exclusão realizada com sucesso.');
        }
      }
    }, error => {
      this.messagesService.addErrorMessage(error);
    });
  }

  changeCheckbox() {
    this.registrarMaisAtividades = !this.registrarMaisAtividades;
  }

  public salvar(): void {     
    
    if (this.isMatriculaPreenchida() && this.isCamposvalidos()) {            
      this.atividade.idManutencao = this.manutencaoSelecionada.idManutencao;
      this.atividade.matriculaUsuarioLogado = this.auth.authInfo.username;
      this.atividade.observacao = !isNullOrUndefined(this.atividade.observacao) ? this.atividade.observacao.toLocaleUpperCase() : undefined;
      this.atividade.nomeUsuarioLogado = this.auth.authInfo.details.nome;      
      if (!this.isEditar) {
        this.atividade.materiais.forEach(m => {
          if (m.codificado === false) {
            m.codigoMaterial = '';
          }
        }); 

        let hht = (60*parseInt(this.atividade.horasAtividade.substr(0, 4))) + (parseInt(this.atividade.horasAtividade.substr(4, 2)));        
        let apropriadas = (60*parseInt(this.atividade.horasApropriadas.substr(0, 4))) + (parseInt(this.atividade.horasApropriadas.substr(4, 2)));        
        
        let hT = this.atividade.horasTotal.substr(0, 4);
        let mT = this.atividade.horasTotal.substr(5, 2);
        let disponiveis = (60*parseInt(hT)) + (parseInt(mT));        

        let somaHhtApropriadas = hht+apropriadas;

        if(somaHhtApropriadas>disponiveis){
          this.messagesService.addErrorMessage('Tempo informado é maior do que o disponível.');        
          return;
        }
            
        this.atividadeService.salvar(this.atividade)
          .subscribe(a => {
            this.preencherCamposObrigatorios();
            if (!this.registrarMaisAtividades) {              
              this.limparRegistrosParaMaisAtividades();
              this.router.navigate(['app/manutencao/atividade/cadastrar-atividade/'+this.atividade.idManutencao+'/'+this.atividade.numeroSolicitacao]); 
            }                
            this.carregarHorasApropriadas();                
            this.messagesService.addSuccessMessage('Cadastro realizado com sucesso.');                      
          },
            (error) => {
              this.messagesService.addErrorMessage(error);
            });
      } else {
        this.atividadeService.atualizar(this.atividade)
          .subscribe(a => {
            this.messagesService.addSuccessMessage('Alterações realizadas com sucesso.');
            this.location.back();
          }, (error) => {
            this.messagesService.addErrorMessage(error);
          });
      }
    }
  }  

  voltar(){
    this.location.back();
  }

  public limpar(): void {
    this.listaCampoObrigatoriosNaoPreenchidos = [];
    const matricula = this.atividade.matriculaExecutante;
    const nomeEmpregado = this.atividade.nomeExecutante;
    const numeroSolicitacao = this.atividade.numeroSolicitacao;
    const mesReferencia = this.atividade.mesReferencia;
    this.atividade = new Atividade();
    this.registrarMaisAtividades = false;
    if (this.auth.getPerfil(PerfisConstants.TECNICO)) {
      this.atividade.matriculaExecutante = matricula;
      this.atividade.nomeExecutante = nomeEmpregado;
    }
    if (this.isEditar) {
      this.atividade.numeroSolicitacao = numeroSolicitacao;
      this.buscarManutencao();
      if (this.desabilitarMes) {
        this.atividade.mesReferencia = mesReferencia;
      }
    } else {
      this.listaGrupo = [];
      this.listaSubGrupo = [];
      this.desabilitarSubGrupo = true;
      this.mesReferencia = [];
    }
    this.manutencaoSelecionada = new Manutencao();
    this.desabilitarMatricula = true;
    this.preencherCamposObrigatorios();
  }

  public editarMaterial(material: AtividadeMaterial): void {
    this.atividadeMaterialEdicao = material;
    this.modalMaterialEdicao.showDialog().then((retorno) => {
      if (!retorno.error) {
        const index = this.atividade.materiais.indexOf(material);
        this.atividade.materiais.splice(index, 1);
        this.atividade.materiais.push(retorno.atividadeMaterial);
      }
    }).catch(erro => {
    });
  }

  public blurCamposObrigatorios(valorCampo: any, nomeCampo: string) {
    const index = this.listaCampoObrigatoriosNaoPreenchidos.indexOf(nomeCampo);
    if (index > -1) {
      this.listaCampoObrigatoriosNaoPreenchidos.splice(index, 1);
    }
    if (isNullOrUndefined(valorCampo) || valorCampo.toString().trim().length === 0) {
      if (index > -1) {
        this.listaCampoObrigatoriosNaoPreenchidos[this.listaCampoObrigatoriosNaoPreenchidos.length] = nomeCampo;
        return;
      }
      this.listaCampoObrigatoriosNaoPreenchidos.push(nomeCampo);
    }
  }

  private preencherCamposObrigatorios(): void {      
    if (isNullOrUndefined(this.atividade.numeroSolicitacao)) {
      this.listaCampoObrigatoriosNaoPreenchidos.push('Nº Solicitação');
    }
    if(this.atividade.tipoManutencao === 'P'){
      this.desabilitarMes = true;
    }
    if (!this.desabilitarMes) {
      this.listaCampoObrigatoriosNaoPreenchidos.push('Mês Referência');
    }    
    this.listaCampoObrigatoriosNaoPreenchidos.push('Grupo');
    this.listaCampoObrigatoriosNaoPreenchidos.push('Subgrupo');
    this.listaCampoObrigatoriosNaoPreenchidos.push('Ação');
    this.listaCampoObrigatoriosNaoPreenchidos.push('Componente');
    this.listaCampoObrigatoriosNaoPreenchidos.push('H.H.T.');
    //this.listaCampoObrigatoriosNaoPreenchidos.push('Horas sem Paralisação');
    
    if (this.manutencaoSelecionada && this.manutencaoSelecionada.paralisacao) {
      //this.listaCampoObrigatoriosNaoPreenchidos.push('Horas com Paralisação');
    }
  }

  private isCamposvalidos(): boolean {    
    if (!isNullOrUndefined(this.listaCampoObrigatoriosNaoPreenchidos) && this.listaCampoObrigatoriosNaoPreenchidos.length > 0) {
      this.messagesService.addErrorMessage('Falta informação obrigatória. Por favor, informe o/a ' +
        this.listaCampoObrigatoriosNaoPreenchidos[0] + '.');        
      return false;
    }    
    return true;
  }

  private limparRegistrosParaMaisAtividades() {    
    this.atividade.codigoAcao = null;
    this.atividade.horasAtividade = null;    
    this.atividade.codigoComponente = null;
    this.atividade.observacao = null;
    this.atividade.materiais = [];
    if (this.atividade.tipoManutencao === "P") {
      //this.validarCamposObrigatoriosAtividadePreventiva();      
      this.blurCamposObrigatorios(this.atividade.idGrupo, "Grupo");
      this.blurCamposObrigatorios(this.atividade.idSubGrupo, "Subgrupo");
      this.blurCamposObrigatorios(this.atividade.codigoAcao, "Ação");
      this.blurCamposObrigatorios(this.atividade.codigoComponente, "Componente");
    } else {      
      this.blurCamposObrigatorios(this.atividade.mesReferencia, "Mês Referência");
      this.blurCamposObrigatorios(this.atividade.idGrupo, "Grupo");
      this.blurCamposObrigatorios(this.atividade.idSubGrupo, "Subgrupo");
      this.blurCamposObrigatorios(this.atividade.codigoAcao, "Ação");
      this.blurCamposObrigatorios(this.atividade.codigoComponente, "Componente");
    }
  }
 /*
  public carregarTempoDisponivel() { 

    if (this.atividade.matriculaExecutante.trim().length === 0) {
      this.messagesService.addErrorMessage('Falta informação obrigatória. Por favor, informe a Matrícula.');
      return;
    }  
    
    this.atividadeService.buscarTempoDisponivel(this.manutencaoSelecionada.idManutencao, this.atividade.matriculaExecutante)
      .subscribe(a => {
        if (isNullOrUndefined(a)){
          this.messagesService.addErrorMessage('Executante não possui atividade cadastrada para essa solicitação.');          
          //this.atividade.horasDisponiveis = this.manutencaoSelecionada.horasTempoSolicitacao;
          return;
        }else{
          //this.atividade.horasDisponiveis = a.horasDisponiveis; 
          return;         
        }
        
      },
        (error) => {
          this.messagesService.addErrorMessage(error);
          return;
        });    
  }

 
  private verificaDesabilitarBotaoSalvar(): boolean {
    if (this.atividade.horasDisponiveis==='000:00') {
      return false;
    }
    return true;
  }
 
  public atualizarHorasDisponiveis(){

    if(isNullOrUndefined(this.atividade.horasDisponiveis)){
      this.messagesService.addErrorMessage('Falta informação obrigatória. Por favor, verificar tempo disponível.');
      this.atividade.horasAtividade = null;
      return;
    }else{

      if(this.atividade.horasDisponiveis==='000:00'){
        this.messagesService.addErrorMessage('Não existe hora disponível para mais atividades.');
        this.atividade.horasAtividade = null;        
        return;
      }

      let horasDisponiveis;
      let minutosDisponiveis = parseInt(this.atividade.horasDisponiveis.substr(4, 5)) + (60*parseInt(this.atividade.horasDisponiveis.substr(0, 3)));

      let horasAtividade;
      let minutosAtividade = parseInt(this.atividade.horasAtividade.substr(3, 5)) + (60*parseInt(this.atividade.horasAtividade.substr(0, 3)));
      
      if(minutosAtividade>horasDisponiveis){
        this.messagesService.addErrorMessage('Tempo informado é maior do que o disponível.');        
        return;
      }

      let diffMinutos = minutosDisponiveis - minutosAtividade; 

      if (diffMinutos > 59) {
        horasDisponiveis = Math.floor(diffMinutos/60);
        minutosDisponiveis = diffMinutos % 60;
        this.atividade.horasDisponiveis = this.formatarHoras(horasDisponiveis, minutosDisponiveis);
      }else{
        this.atividade.horasDisponiveis = this.formatarHoras(null, diffMinutos);      
      }     
    }    
      
  }
  */ 
}
