import { Atividade } from './../../../../models/atividade.model';
import { AdministracaoGenericComponent } from './../../../../../administracao/administracao-generic.component';
import { isNullOrUndefined } from 'util';
import { ArrayUtil } from './../../../../../shared/Utils/ArrayUtil';
import { Material } from './../../../../models/material.model';
import { AtividadeMaterialFiltro } from './../../../../models/atividade-material-filtro.model';
import { LabelValue } from './../../../../../core/models/label-value';
import { LazyLoadEvent } from 'primeng/components/common/api';
import { Pagina } from './../../../../../core/models/pagina.model';
import { AtividadeConsulta } from './../../../../models/atividade-consulta.model';
import { Subject } from 'rxjs/Subject';
import { Component, OnInit, Input } from '@angular/core';
import { NgForm } from '@angular/forms';
import { AtividadeMaterial } from '../../../../models/atividade-material.model';
import { AtividadeService } from '../../../../services/atividade.service';
import { MessagesService } from '../../../../../core/messages/messages.service';
import { AtividadeFiltro } from '../../../../models/atividade-filtro.model';
//import createNumberMask from 'text-mask-addons/dist/createNumberMask';


declare var $:any;

@Component({
  selector: 'simeq-modal-material',
  templateUrl: './modal-material.component.html',
  styleUrls: ['./modal-material.component.scss']
})
export class ModalMaterialComponent extends AdministracaoGenericComponent implements OnInit {

  @Input('id') modalId: string;

  @Input('tituloMaterial') tituloMaterial: string;

  @Input('isEdicao') isEdicao: boolean;

  @Input('atividadeMaterialEdicao') atividadeMaterialEdicao: AtividadeMaterial;

  @Input('materiaisInseridos') materiaisInseridos: AtividadeMaterial [];

  public paginaMaterial: Pagina<Material> = new Pagina<Material>();
  public listaUnidades: LabelValue[] = [];
  public materialSelecionado: Material = new Material();
  public atividadeMaterial: AtividadeMaterial = new AtividadeMaterial();
  public atividadeMaterialFiltro: AtividadeMaterialFiltro = new AtividadeMaterialFiltro();
  public materialNaoCodificado: boolean = false;
  public buscaHabilitada: boolean = false;
  private _eventBus: Subject<ModalMaterialEvent> = new Subject<ModalMaterialEvent>();
  private atividadeMaterialEdicaoAntiga: AtividadeMaterial;

  modal: any;

  constructor(messagesService: MessagesService,
    public atividadeService: AtividadeService) {
      super(messagesService);
  }

  ngOnInit() {
  }

  showDialog(): Promise<ModalMaterialEvent> {
    this.modal = $('#id-' + this.modalId).modal('show');
    this.atividadeService.buscarUnidades().subscribe(u => {
      this.listaUnidades = u;
      this.listaUnidades = ArrayUtil.adicionarPrimeiroValor(this.listaUnidades, 'Selecione', null);
      this.carregarMaterialEdicao();
    });

    return new Promise<ModalMaterialEvent> ((resolve, reject) => {
       return this._eventBus.asObservable().subscribe(message => {
         if (message.success) {
           resolve(message);
         } else {
           reject(message);
         }
      });
    });
  }

  private carregarMaterialEdicao(): void {
    if (this.isEdicao) {
      this.atividadeMaterial = Object.assign({}, this.atividadeMaterialEdicao);
      this.atividadeMaterialEdicaoAntiga = Object.assign({}, this.atividadeMaterialEdicao);
      if (isNullOrUndefined(this.atividadeMaterialEdicao.descricaoMaterialOutros) ||
        this.atividadeMaterialEdicao.descricaoMaterialOutros.length == 0) {
        this.atividadeService.buscarMaterialPorId(this.atividadeMaterialEdicao.codigoMaterial)
        .subscribe(m => {
          this.materialSelecionado = m;
          this.paginaMaterial.primeiroRegistro = 0;
          this.paginaMaterial.tamanho = 1;
          this.paginaMaterial.totalDeRegistros = 1;
          let materialPaginaRegistros: Material[] = [];
          materialPaginaRegistros.push(this.materialSelecionado);
          this.paginaMaterial.registros = materialPaginaRegistros;
        });
        return;
      }
      this.materialNaoCodificado = true;
    }
  }

  cancelClick() {
    this.materialSelecionado = new Material();
    this.atividadeMaterial = new AtividadeMaterial();
    this.atividadeMaterialFiltro = new AtividadeMaterialFiltro();
    if (this.isEdicao) {
      this.atividadeMaterialEdicao = this.atividadeMaterialEdicaoAntiga;
    }
    this.materialNaoCodificado = false;
    this.paginaMaterial = new Pagina();
    this._eventBus.next({ error: true });
    this.modal.modal('hide');
  }

  adicionar() {
    if (this.isAdicionar()) {
      this.preencherAtividadeMaterial();
      this._eventBus.next({ success: true, atividadeMaterial: this.atividadeMaterial, material: this.materialSelecionado });
      this.limparTudo();
      this.modal.modal('hide');
    }
  }

  private preencherAtividadeMaterial(): void {
    if (isNullOrUndefined(this.atividadeMaterialEdicao)) {
      const ultimoInserido = this.materiaisInseridos[this.materiaisInseridos.length - 1];
      this.atividadeMaterial.sequencialMaterial = isNullOrUndefined(ultimoInserido) ?  1 : ultimoInserido.sequencialMaterial + 1;
    }
    if (this.materialNaoCodificado) {
      if(!this.isEdicao){
        this.atividadeMaterial.codigoMaterial = this.atividadeMaterialFiltro.codigoMaterial.replace(/_/g, '');
        this.atividadeMaterial.nomeMaterial = this.atividadeMaterialFiltro.nomePradronizado;
      } else {
        this.atividadeMaterial.codigoMaterial = this.atividadeMaterial.codigoMaterial.replace(/_/g, '');
      }
      this.atividadeMaterial.descricaoMaterialOutros = this.atividadeMaterial.codigoMaterial;
      this.atividadeMaterial.nomeMaterialOutros = this.atividadeMaterial.nomeMaterial;
      this.atividadeMaterial.codificado = false;
    } else {
      this.atividadeMaterial.codificado = true;
      this.atividadeMaterial.codigoMaterial = this.materialSelecionado.codigo;
      this.atividadeMaterial.nomeMaterial = this.materialSelecionado.nome;
    }
  }

  private isAdicionar(): boolean {
    if(this.isEdicao){
      if ((!this.materialNaoCodificado && isNullOrUndefined(this.materialSelecionado.codigo)) ||
        (this.materialNaoCodificado && (!isNullOrUndefined(this.atividadeMaterial.codigoMaterial) &&
          (this.atividadeMaterial.codigoMaterial.trim().length === 0 || this.removerNCMaterialNaoCodificadoEdicao() === 'NC-')))) {
          this.messagesService.addErrorMessage('Falta informação obrigatória. Por favor, informe o Material.');
        return false;
      }
    } else {
        if ((!this.materialNaoCodificado && isNullOrUndefined(this.materialSelecionado.codigo)) ||
        (this.materialNaoCodificado && (!isNullOrUndefined(this.atividadeMaterialFiltro.codigoMaterial) &&
          (this.atividadeMaterialFiltro.codigoMaterial.trim().length === 0 || this.removerNCMaterialNaoCodificado() === 'NC-')))) {
          this.messagesService.addErrorMessage('Falta informação obrigatória. Por favor, informe o Material.');
        return false;
      }
    }
    
    if (isNullOrUndefined(this.atividadeMaterial.quantidadeMaterial) ||
       this.atividadeMaterial.quantidadeMaterial === 0 ) {
        this.messagesService.addErrorMessage('Falta informação obrigatória. Por favor, informe a quantidade.');
        return false;
    }
    if (isNullOrUndefined(this.atividadeMaterial.descricaoUnidadeMedida)) {
      this.messagesService.addErrorMessage('Falta informação obrigatória. Por favor, informe a Unidade de Medida.');
      return false;
    }
    return true;
  }

  private removerNCMaterialNaoCodificado(): string {
    return this.atividadeMaterialFiltro.codigoMaterial.substr(0, this.atividadeMaterialFiltro.codigoMaterial.length);
  }

  private removerNCMaterialNaoCodificadoEdicao(): string {
    return this.atividadeMaterial.codigoMaterial.substr(0, this.atividadeMaterial.codigoMaterial.length);
  }

  public pesquisar(): void {
    this.buscaHabilitada = true;
    this.paginaMaterial = new Pagina();
    this.filtrar();
  }

  public paginarMaterial(event: LazyLoadEvent): void {
    if (this.buscaHabilitada) {
      this.paginaMaterial = new Pagina<Material>(event.first, event.rows);
      this.filtrar();
    }
  }

  public filtrar(): void {
    this.atividadeService.filtrarMaterial(this.atividadeMaterialFiltro, this.paginaMaterial)
      .subscribe((pagina) => {
        this.paginaMaterial = pagina;
      },
      (error) => {

      });
    }

  public checkMaterialNaoCodificado(): void {
    if (this.materialNaoCodificado) {
      this.paginaMaterial = new Pagina();
      this.atividadeMaterialFiltro = new AtividadeMaterialFiltro();
      this.materialSelecionado = new Material();
      this.maskCodigo();
      return;
    } else {
      this.atividadeMaterialFiltro = new AtividadeMaterialFiltro();
    }
  }

  public limparFiltro() {
    this.buscaHabilitada = false;
    this.materialSelecionado = new Material();
    this.atividadeMaterial = new AtividadeMaterial();
    this.paginaMaterial = new Pagina();
  }

  public limparTudo(): void {
    this.materialSelecionado = new Material();
    this.atividadeMaterial = new AtividadeMaterial();
    this.atividadeMaterialFiltro = new AtividadeMaterialFiltro();
    this.materialNaoCodificado = false;
    this.paginaMaterial = new Pagina();
  }

  public limparMaterial(): void {
    this.materialSelecionado = new Material();
    this.atividadeMaterialFiltro = new AtividadeMaterialFiltro();
    this.materialNaoCodificado = false;
    this.atividadeMaterial.descricaoMaterialOutros = '';
    this.paginaMaterial = new Pagina();
  }

  public mask() {
    let prefix = 'NC-';
    if (this.atividadeMaterial.descricaoMaterialOutros.length === 1) {
      this.atividadeMaterial.descricaoMaterialOutros = prefix.concat(this.atividadeMaterial.descricaoMaterialOutros);
    } else {
      this.atividadeMaterial.descricaoMaterialOutros = this.atividadeMaterial.descricaoMaterialOutros.substr(3,
      this.atividadeMaterial.descricaoMaterialOutros.length - 3);
      this.atividadeMaterial.descricaoMaterialOutros =  prefix.concat(this.atividadeMaterial.descricaoMaterialOutros);
    }
  }

  public maskCodigo() {
    if(this.materialNaoCodificado){
      let prefix = 'NC-';
      if(!this.isEdicao){
        if (this.atividadeMaterialFiltro.codigoMaterial.length === 1) {
          this.atividadeMaterialFiltro.codigoMaterial = prefix.concat(this.atividadeMaterialFiltro.codigoMaterial);
        } else {
          this.atividadeMaterialFiltro.codigoMaterial = this.atividadeMaterialFiltro.codigoMaterial.substr(3,
                                                                this.atividadeMaterialFiltro.codigoMaterial.length - 3);
          this.atividadeMaterialFiltro.codigoMaterial =  prefix.concat(this.atividadeMaterialFiltro.codigoMaterial);
        }
      } else {
        if (this.atividadeMaterial.codigoMaterial.length === 1) {
          this.atividadeMaterial.codigoMaterial = prefix.concat(this.atividadeMaterial.codigoMaterial);
        } else {
          this.atividadeMaterial.codigoMaterial = this.atividadeMaterial.codigoMaterial.substr(3,
                                                                this.atividadeMaterial.codigoMaterial.length - 3);
          this.atividadeMaterial.codigoMaterial =  prefix.concat(this.atividadeMaterial.codigoMaterial);
        }
      }
    }
  }
}


export class ModalMaterialEvent {
  error?: boolean;
  success?: boolean;
  atividadeMaterial?: any;
  material?: any;
}
