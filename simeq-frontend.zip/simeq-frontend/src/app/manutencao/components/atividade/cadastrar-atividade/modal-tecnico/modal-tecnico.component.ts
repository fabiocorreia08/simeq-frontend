import { TecnicoService } from './../../../../../administracao/tecnico/services/tecnico.service';
import { MessagesService } from './../../../../../core/messages/messages.service';
import { AtividadeTecnicoFiltro } from './../../../../models/atividade-tecnico-filtro.model';
import { Pagina } from './../../../../../core/models/pagina.model';
import { TecnicoDTO } from './../../../../../administracao/tecnico/resources/dtos/tecnico-dto.class';
import { AdministracaoGenericComponent } from './../../../../../administracao/administracao-generic.component';
import { isNullOrUndefined } from 'util';

import { Subject } from 'rxjs/Subject';
import { Component, OnInit, Input } from '@angular/core';
import { NgForm } from '@angular/forms';
import { LazyLoadEvent } from 'primeng/primeng';


declare var $:any;

@Component({
  selector: 'simeq-modal-tecnico',
  templateUrl: './modal-tecnico.component.html',
  styleUrls: ['./modal-tecnico.component.scss']
})
export class ModalTecnicoComponent extends AdministracaoGenericComponent implements OnInit {

  @Input('id') modalId: string;

  @Input('tituloTecnico') tituloTecnico: string;

  @Input('isEdicao') isEdicao: boolean;

  @Input('filtrotTecnico')
  public filtrotTecnico: AtividadeTecnicoFiltro = new AtividadeTecnicoFiltro();

  public paginaTecnico: Pagina<TecnicoDTO> = new Pagina<TecnicoDTO>();
  public tecnicoSelecionado: TecnicoDTO = new TecnicoDTO();
  private _eventBus: Subject<ModalTecnicoEvent> = new Subject<ModalTecnicoEvent>();
  public buscaHabilitada: boolean = false;

  modal: any;

  constructor(messagesService: MessagesService,
    public tecnicoService: TecnicoService, ) {
      super(messagesService);
  }

  ngOnInit() { 
         
  }

  showDialog(): Promise<ModalTecnicoEvent> {
    this.modal = $('#id-' + this.modalId).modal('show');
       return new Promise<ModalTecnicoEvent> ((resolve, reject) => {
       return this._eventBus.asObservable().subscribe(message => {
         if (message.success) {
           resolve(message);
         } else {
           reject(message);
         }
      });
    });  
  }

  public pesquisar(): void {    
    this.buscaHabilitada = true;
    this.paginaTecnico = new Pagina();
    if (!isNullOrUndefined(this.filtrotTecnico.matricula) &&
          this.filtrotTecnico.matricula.trim().length !== 0) {
      this.filtrotTecnico.nome = '';
    }
    this.filtrar();
  }

  public filtrar(): void {
    this.tecnicoService.buscarPorMatriculaAlocado(this.filtrotTecnico, this.paginaTecnico)
      .subscribe((pagina) => {
        this.paginaTecnico = pagina;
      },
      (error) => {
        this.messagesService.addErrorMessage(error);
      });
    }

  cancelClick() {
    this.tecnicoSelecionado = new TecnicoDTO();
    this.filtrotTecnico.matricula = '';
    this.filtrotTecnico.matricula = '';
    this.paginaTecnico = new Pagina();
    this._eventBus.next({ error: true });
    this.modal.modal('hide');
  }

  public paginarTecnico(event: LazyLoadEvent): void {
    if (this.buscaHabilitada) {
      this.paginaTecnico = new Pagina<TecnicoDTO>(event.first, event.rows);
      this.filtrar();
    }
  }

  public limpar(): void {
    this.buscaHabilitada = false;
    this.tecnicoSelecionado = new TecnicoDTO();
    this.paginaTecnico = new Pagina();
    this.filtrotTecnico.nome = '';
    this.filtrotTecnico.matricula = '';
  }

  adicionar() {
    if (isNullOrUndefined(this.tecnicoSelecionado.matricula)){
      this.messagesService.addErrorMessage('Falta informação obrigatória. Por favor, informe o Técnico.');
    } else {
      this._eventBus.next({ success: true, tecnico: this.tecnicoSelecionado });
      this.limpar();
      this.modal.modal('hide');      
    }
  }  

 }

export class ModalTecnicoEvent {
  error?: boolean;
  success?: boolean;
  tecnico?: any;
}
