import { BreadcrumbService } from './../../../../core/breadcrumb/breadcrumb.service';
import { ActivatedRoute } from '@angular/router';
import { AtividadeService } from './../../../services/atividade.service';
import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';
import { AtividadeEditar } from '../../../models/atividade-editar.model';
import { LabelValue } from '../../../../core/models/label-value';
import { GrupoService } from '../../../../administracao/grupo-subgrupo/services/grupo.service';
import { ArrayUtil } from '../../../../shared/Utils/ArrayUtil';
import { isNullOrUndefined, error } from 'util';
import { GrupoDTO } from '../../../../administracao/grupo-subgrupo/resources/dtos/grupo-dto.class';
import { AuthenticationService } from '../../../../core/security/auth.service';
import { MessagesService } from '../../../../core/messages/messages.service';
import { Atividade } from '../../../models/atividade.model';

@Component({
  selector: 'simeq-editar-atividade',
  templateUrl: './editar-atividade.component.html',
  styleUrls: ['./editar-atividade.component.scss']
})
export class EditarAtividadeComponent implements OnInit {

  public listaAcao: LabelValue[] = [];
  public listaComponente: LabelValue[] = [];
  public listaGrupo: LabelValue[] = [];
  public listaSubGrupo: LabelValue[] = [];
  public listaCampoObrigatoriosNaoPreenchidos: string[] = [];
  public desabilitarSubGrupo = true;
  public idPerfil;

  public atividade: Atividade = new Atividade();

  public atividadeEditar: AtividadeEditar = new AtividadeEditar();
  public isEditar: boolean = false;

  constructor(
    public messagesService: MessagesService,
    public atividadeService: AtividadeService,
    public grupoService: GrupoService,
    public auth: AuthenticationService,
    private route: ActivatedRoute,
    public breadcrumbService: BreadcrumbService,
    private location: Location,) {
      breadcrumbService.addRoute('/app/manutencao/atividade/editar-atividade', 'Atividades', true);
      breadcrumbService.addRoute('/app/manutencao/atividade/editar-atividade', 'Editar', false);
  }

  ngOnInit() {
    this.idPerfil = this.auth.getIdPerfil(this.auth.authInfo.details.perfis);
    this.isEditar = this.route.snapshot.data['isEditar'];
    this.atividadeEditar = this.route.snapshot.data['atividadeResolve'];   
    
    this.carregarGrupo(); 
    this.carregarSubGrupo();
    this.carregarAcoes();
    this.carregarComponentes();    

  }

  public carregarAcoes() {
    this.atividadeService.buscarAcoesPorCodigo(this.atividadeEditar.codigoAcao)
      .subscribe(a => {
        this.listaAcao = a;
        this.listaAcao = ArrayUtil.adicionarPrimeiroValor(this.listaAcao, 'Selecione', null);
      },
        (error) => {
          this.messagesService.addErrorMessage(error);
        });
  }

  public carregarComponentes() {
    this.atividadeService.buscarComponentesPorCodigo(this.atividadeEditar.codigoComponente)
      .subscribe(c => {
        this.listaComponente = c;
        this.listaComponente = ArrayUtil.adicionarPrimeiroValor(this.listaComponente, 'Selecione', null);
      },
        (error) => {
          this.messagesService.addErrorMessage(error);
        });
  }

  public carregarGrupo(): void {
    this.grupoService.buscarGruposPorEquipamento(this.atividadeEditar.idEquipamento).subscribe(g => {
      this.listaGrupo = g;
      this.listaGrupo = ArrayUtil.adicionarPrimeiroValor(this.listaGrupo, 'Selecione', null);      
    });
  }

  public carregarSubGrupo(): void {
    this.grupoService.buscarGruposFilho(this.atividadeEditar.idGrupo).subscribe(g => {
      this.listaSubGrupo = this.montarItensSelecaoGruposFilho(g);
      this.listaSubGrupo = ArrayUtil.adicionarPrimeiroValor(this.listaSubGrupo, 'Selecione', null);
    });
  }

  public onChangeGrupo(): void {
    this.blurCamposObrigatorios(this.atividadeEditar.idGrupo, 'Grupo');
    if (this.atividadeEditar.idGrupo != null) {
      this.desabilitarSubGrupo = false;
      this.grupoService.buscarGruposFilho(this.atividadeEditar.idGrupo).subscribe(g => {
        this.listaSubGrupo = this.montarItensSelecaoGruposFilho(g);
        this.listaSubGrupo = ArrayUtil.adicionarPrimeiroValor(this.listaSubGrupo, 'Selecione', null);
      });
      return;
    }
    this.listaSubGrupo = [];
    this.desabilitarSubGrupo = true;
    this.atividadeEditar.idSubGrupo = null;
    this.blurCamposObrigatorios(this.atividadeEditar.idSubGrupo, 'Subgrupo');
  }

  public blurCamposObrigatorios(valorCampo: any, nomeCampo: string) {
    const index = this.listaCampoObrigatoriosNaoPreenchidos.indexOf(nomeCampo);
    if (index > -1) {
      this.listaCampoObrigatoriosNaoPreenchidos.splice(index, 1);
    }
    if (isNullOrUndefined(valorCampo) || valorCampo.toString().trim().length === 0) {
      if (index > -1) {
        this.listaCampoObrigatoriosNaoPreenchidos[this.listaCampoObrigatoriosNaoPreenchidos.length] = nomeCampo;
        return;
      }
      this.listaCampoObrigatoriosNaoPreenchidos.push(nomeCampo);
    }
  }

  private montarItensSelecaoGruposFilho(grupo: GrupoDTO[]): LabelValue[] {
    const itens: LabelValue[] = [];
    grupo.forEach((g) => {
      itens.push(new LabelValue(g.descricaoGrupo, g.idGrupo));
    });
    return itens;
  }

  private preencherCamposObrigatorios(): void {      
    
    this.listaCampoObrigatoriosNaoPreenchidos.push('Grupo');
    this.listaCampoObrigatoriosNaoPreenchidos.push('Subgrupo');
    this.listaCampoObrigatoriosNaoPreenchidos.push('Ação');
    this.listaCampoObrigatoriosNaoPreenchidos.push('Componente');
    this.listaCampoObrigatoriosNaoPreenchidos.push('H.H.T.');
    
  }

  public salvar(): void {  
        
  }
  

  public voltar() {
    this.location.back();
  }
}
