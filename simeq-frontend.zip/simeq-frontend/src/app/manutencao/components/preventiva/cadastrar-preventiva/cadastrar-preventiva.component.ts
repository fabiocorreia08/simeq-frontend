import { Location } from '@angular/common';
import { StatusPreventivaService } from './../../../services/status-preventiva.service';
import { StatusManutencaoPreventivaEnum } from './../../../enums/status-manutencao-preventiva.enum';
import { ActivatedRoute, Router } from '@angular/router';
import { BreadcrumbService } from './../../../../core/breadcrumb/breadcrumb.service';
import { AdministracaoGenericComponent } from './../../../../administracao/administracao-generic.component';
import { ManutencaoPreventivaService } from './../../../services/manutencao-preventiva.service';
import { Component, OnInit, ɵConsole } from '@angular/core';

import { AuthenticationService } from './../../../../core/security/auth.service';
import { isNullOrUndefined, error } from 'util';
import { CentroCustoService } from './../../../../shared/services/centro-custo.service';
import { EquipamentoService } from './../../../../administracao/equipamento/services/equipamento.service';
import { LabelValue } from './../../../../core/models/label-value';
import { ArrayUtil } from './../../../../shared/Utils/ArrayUtil';
import { PreventivaCadastro } from '../../../models/preventiva-cadastro.model';
import { MessagesService } from '../../../../core/messages/messages.service';
import * as moment from 'moment';
import { HistoricoSituacaoEquipamentoService } from '../../../../administracao/equipamento/services/historico-situacao-equipamento.service';
import { HistoricoSituacaoEquipamentoDTO } from '../../../../administracao/equipamento/resources/dtos/historico-situacao-equipamento-dto.class';
import { AssistenteProducao } from '../../../../shared/models/assistente-producao.model';
import { PessoaService } from '../../../../shared/services/pessoa.service';
import { FamiliaService } from '../../../../administracao/familia/service/familia.service';
import { SetorManutencaoService } from '../../../../shared/services/setor-manutencao.service';
import { StatusManutencaoCorretivaEnum } from '../../../enums/status-manutencao-corretiva.enum';
import { PerfisConstants } from '../../../../core/security/perfis.constants';

@Component({
  selector: 'simeq-cadastrar-preventiva',
  templateUrl: './cadastrar-preventiva.component.html',
  styleUrls: ['./cadastrar-preventiva.component.scss']
})
export class CadastrarPreventivaComponent extends AdministracaoGenericComponent implements OnInit {

  public preventivaCadastro: PreventivaCadastro = new PreventivaCadastro();
  public manutencaoPreventivaSelecionada: PreventivaCadastro;
  public listaPreventivaCadastro: PreventivaCadastro[] = [];
  public listaEquipamentos: LabelValue[] = [];
  public listaStatus: LabelValue[] = [];
  public listaAno: LabelValue[] = [];
  public listaMes: LabelValue[] = [];
  public tituloTela = 'Cadastrar';
  public listaCampoObrigatoriosNaoPreenchidos: string[] = [];
  public isEditar = false;  
  public isEditarInformacao = false;  
  public isDetalhar = false;  
  public isDesabilitarCamposEditar = false;  
  public isDesabilitarBotaoSalvar = false;  
  public mesesSelecionados: number[] = null;
  public usuarioLogado: AssistenteProducao = new AssistenteProducao();
  public familiaOpcoes: LabelValue[] = [];
  public setorOpcoes: LabelValue[] = [];
  public idFamilia: number = 0;
  public isDataInicioInvalida = false;
  public isDataFimInvalida = false;
  public isMesAnterior = false;
  public isCancelada = false;  
  public isConcluida = false;  
  public isReprovada = false;
  public isReprogramada = false;
  
  public isDesabilitarQuantidadeHorasExecutadas = true;
  public quantidadeHorasExecutadasManutençao = false;

  public isPerfilAdministrador = false;
  public isPerfilMaster = false;
  public isPerfilTecnico = false;
  public isPerfilGestor = false;
  public isPerfilSolicitante = false;
  
  public readonly TECNICO: number = 2;
  public readonly SOLICITANTE: number = 3
  public readonly MASTER: number = 4;
  public readonly GESTOR: number = 5;

  constructor(messagesService: MessagesService,
    private equipamentoService: EquipamentoService,
    private centroCustoService: CentroCustoService,
    public auth: AuthenticationService,
    private manutencaoPreventivaService: ManutencaoPreventivaService,
    private breadcrumbService: BreadcrumbService,
    private route: ActivatedRoute,
    private router: Router,
    public historicoSituacaoEquipamentoService: HistoricoSituacaoEquipamentoService,
    private statusPreventivaService: StatusPreventivaService,
    private pessoaService: PessoaService,
    private familiaService: FamiliaService,
    private location: Location,
    private setorService: SetorManutencaoService) {
    super(messagesService);
    breadcrumbService.addRoute('/app/manutencao/preventiva/consultar', 'Preventivas', true);
  }

  ngOnInit() {    
    this.isEditar = this.route.snapshot.data['isEditar'];    
    this.isEditarInformacao = this.route.snapshot.data['isEditarInformacao']; 
    this.isDetalhar = this.route.snapshot.data['isDetalhar']; 
    this.isPerfilAdministrador = this.getPerfil(PerfisConstants.ADMINISTRADOR);
    this.isPerfilMaster = this.getPerfil(PerfisConstants.MASTER);
    this.isPerfilTecnico = this.getPerfil(PerfisConstants.TECNICO);
    this.isPerfilGestor = this.getPerfil(PerfisConstants.GESTOR);
    this.isPerfilSolicitante = this.getPerfil(PerfisConstants.SOLICITANTE);

    if (!this.isEditar) {
      this.breadcrumbService.addRoute('/app/manutencao/preventiva/cadastrar', 'Cadastrar', false);
      this.buscarUsuarioLogado();
    } else {
      this.breadcrumbService.addRoute('/app/manutencao/preventiva/cadastrar', 'Editar', false);
      this.preventivaCadastro = this.route.snapshot.data['preventivaResolve'];      
      if (this.preventivaCadastro.idStatus.toString() === StatusManutencaoPreventivaEnum.CONCLUIDA.toString() ||
        this.preventivaCadastro.idStatus.toString() === StatusManutencaoPreventivaEnum.MANUTENCAO.toString()) {
        this.isDesabilitarQuantidadeHorasExecutadas = false;
      }
      this.tituloTela = 'Editar';
      this.mesesSelecionados = [];
      this.mesesSelecionados.push(this.preventivaCadastro.mes);
      this.carregarStatus();
      this.desabilitarCamposEditar();
    }
    this.carregarEquipamento();
    this.carregarMeses();
    this.carregarAno();
    this.preencherCamposObrigatorios();
    this.verificarStatusJustificativa();
  }  

  public getPerfil(perfil: number): boolean {
    let isPerfil = false;
    this.auth.authInfo.details.perfis.forEach(p => {
      if (p.id_perfil === perfil) {
        isPerfil = true;
      }
    });
    return isPerfil;
  }

  public carregarStatus(): void {   
    let idPerfil = this.auth.getIdPerfil(this.auth.authInfo.details.perfis);
    if (isNullOrUndefined(idPerfil)) {
      idPerfil = 0;
    }  
    this.statusPreventivaService.buscarComboEditarPreventivaPerfil(this.preventivaCadastro.numeroSolicitacao, idPerfil).subscribe(s => {
      this.listaStatus = s;
      this.listaStatus = ArrayUtil.adicionarPrimeiroValor(this.listaStatus, 'Selecione', null);
    });
  }  

  public buscarPorNumeroSolicitacao(): void {
    this.manutencaoPreventivaService.buscarPreventivaPorNumeroSolicitacao(this.preventivaCadastro.numeroSolicitacao).subscribe(m => {
      this.manutencaoPreventivaSelecionada = m;
    });
  }

  public buscarUsuarioLogado(): void {
    this.pessoaService.buscarSolicitantesManutencao(this.auth.authInfo.username)
      .subscribe((a: AssistenteProducao) => {
        if (!isNullOrUndefined(a)) {
          this.usuarioLogado = a;
          this.buscarFamilias();
        }
      });
  }

  private buscarFamilias(): void {
    this.familiaService.buscarFamilias().subscribe(f => {
      this.familiaOpcoes = f;      
      this.familiaOpcoes = ArrayUtil.adicionarPrimeiroValor(this.familiaOpcoes, 'Selecione', null);      
    });
  }

  /* private buscarFamiliasAssistenteProducao(): void {
    this.familiaService.buscarPorCentroCustoAssistenteProducao(this.usuarioLogado.centroCusto).subscribe(f => {
      this.familiaOpcoes = f;
      if (this.familiaOpcoes.length == 1) {
        this.idFamilia = this.familiaOpcoes[0].value;
        this.buscarSetoresPorFamilia();
      } else {
        this.familiaOpcoes = ArrayUtil.adicionarPrimeiroValor(this.familiaOpcoes, 'Selecione', null);
      }
    });
  } */

  private buscarSetoresPorFamilia(): void {
    this.setorService.buscarPorIdFamilia(this.idFamilia).subscribe(s => {
      this.setorOpcoes = s;
      this.setorOpcoes = ArrayUtil.adicionarPrimeiroValor(this.setorOpcoes, 'Selecione', null);
    });
  }

  private desabilitarCamposEditar(): void {    
    let dataAtual: Date = new Date();

    if ((this.isPerfilAdministrador)&&(this.preventivaCadastro.idStatus !== StatusManutencaoPreventivaEnum.CONCLUIDA) && 
        (this.isPerfilAdministrador)&&(this.preventivaCadastro.idStatus !== StatusManutencaoPreventivaEnum.CANCELADA) && 
        (this.isPerfilAdministrador)&&(this.preventivaCadastro.idStatus !== StatusManutencaoPreventivaEnum.REPROVADA_GESTOR)) {
      this.isDesabilitarCamposEditar = false;
    return;
    } 

    if (this.preventivaCadastro.idStatus === StatusManutencaoPreventivaEnum.CONCLUIDA ||
        this.preventivaCadastro.idStatus === StatusManutencaoPreventivaEnum.CANCELADA ||
        this.preventivaCadastro.idStatus === StatusManutencaoPreventivaEnum.REPROVADA_GESTOR || 
        (this.preventivaCadastro.mes === dataAtual.getMonth() && this.preventivaCadastro.ano === dataAtual.getFullYear())      
      ) {
      this.isDesabilitarCamposEditar = true;
      return;
    }    
  }

  public isExibirHorasExecutadas(): boolean {
    if (this.preventivaCadastro.idStatus === StatusManutencaoPreventivaEnum.ABERTA) {
      return false;
    }
    return true;
  }

  public carregarEquipamento(): void {
    let idPerfil = this.auth.getIdPerfil(this.auth.authInfo.details.perfis);
    if (isNullOrUndefined(idPerfil)) {
      idPerfil = 0;
    }
    this.equipamentoService.buscarPorHierarquiaCCUsuarioLogado(idPerfil ,this.auth.authInfo.username).subscribe(e => {
 
      this.listaEquipamentos = e;
      this.listaEquipamentos = ArrayUtil.adicionarPrimeiroValor(this.listaEquipamentos, 'Selecione', null);
    });
  }  

  public carregarMeses(): void {
    this.manutencaoPreventivaService.buscarTodosMeses()
      .subscribe(m => {
        this.listaMes = m;
      });
  }

  public carregarAno(): void {
    let dataAtual = new Date();
    this.listaAno.push(new LabelValue(dataAtual.getFullYear().toString(), dataAtual.getFullYear()));
    this.listaAno.push(new LabelValue((dataAtual.getFullYear() + 1).toString(), (dataAtual.getFullYear() + 1)));
    this.listaAno = ArrayUtil.adicionarPrimeiroValor(this.listaAno, 'Selecione', null);
  }

  public blurCamposObrigatorios(valorCampo: any, nomeCampo: string) {
    if (nomeCampo === 'Quantidade de Horas Previstas') {
      this.validarHoraMask(nomeCampo);
      valorCampo = this.preventivaCadastro.qtdHoras;
    }

    const index = this.listaCampoObrigatoriosNaoPreenchidos.indexOf(nomeCampo);
    if (index > -1) {
      this.listaCampoObrigatoriosNaoPreenchidos.splice(index, 1);
    }
    if (isNullOrUndefined(valorCampo) || valorCampo.toString().trim().length === 0) {
      if (index > -1) {
        this.listaCampoObrigatoriosNaoPreenchidos[this.listaCampoObrigatoriosNaoPreenchidos.length] = nomeCampo;
        return;
      }
      this.listaCampoObrigatoriosNaoPreenchidos.push(nomeCampo);
    }
  }

  public desablitarQuantidadeHorasExecutadas(valorCampo: any, nomeCampo: string) {
    this.blurCamposObrigatorios(valorCampo, nomeCampo);
    if (this.preventivaCadastro.idStatus.toString() === StatusManutencaoPreventivaEnum.CONCLUIDA.toString() ||
      this.preventivaCadastro.idStatus.toString() === StatusManutencaoPreventivaEnum.MANUTENCAO.toString()) {
      this.isDesabilitarQuantidadeHorasExecutadas = false;
    } else {
      this.isDesabilitarQuantidadeHorasExecutadas = true;
    }
  }

  public isQuantidadeHorasExecutadasObrigatorio() {
    if (this.preventivaCadastro.idStatus.toString() === StatusManutencaoPreventivaEnum.CONCLUIDA.toString()) {
      return true;
    }
    return false;
  }
   
  public validarHoraMask(nomeCampo?: string) {
    if (nomeCampo === 'Quantidade de Horas Previstas') {
      if (!isNullOrUndefined(this.preventivaCadastro.qtdHoras)) {
        if (this.preventivaCadastro.qtdHoras.length < 7) {
          this.messagesService.addErrorMessage('Informe uma Quantidade de horas executadas válida.');
          this.preventivaCadastro.qtdHoras = null;
        } else {
          let qteHoras = this.preventivaCadastro.qtdHoras.split(':');
          let horasExecutadas = parseInt(qteHoras[0]);

          if (horasExecutadas === 0) {
            this.messagesService.addErrorMessage('Informe uma Quantidade de horas executadas válida.');
            this.preventivaCadastro.qtdHoras = null;
          }
        }
      }
    } else {
      if (!isNullOrUndefined(this.preventivaCadastro.qtdHorasExecutadas)) {
        if (this.preventivaCadastro.qtdHorasExecutadas.length < 7) {
          this.messagesService.addErrorMessage('Informe uma Quantidade de horas executadas válida.');
          this.preventivaCadastro.qtdHorasExecutadas = null;
        } else {
          let qteHorasExecutadas = this.preventivaCadastro.qtdHorasExecutadas.split(':');
          let horasExecutadas = parseInt(qteHorasExecutadas[0]);

          if (horasExecutadas === 0) {
            this.messagesService.addErrorMessage('Informe uma Quantidade de horas executadas válida.');
            this.preventivaCadastro.qtdHorasExecutadas = null;
          }
        }
      }
    }
  }  

  private verificarInclusaoSemInputMask(): boolean {
    return this.preventivaCadastro.qtdHoras.length === 6;
  }

  public incluir(): void {
    const preventivaCadastroAux = this.preventivaCadastro;
    if (this.isCamposvalidos()) {
      this.mesesSelecionados.forEach(mes => {
        this.preventivaCadastro.mes = mes;
        this.isMesAnteriorData();
        if (!this.isPreventivaJaIncluida()) {

          this.preventivaCadastro.mesAno = (moment().locale('pt-BR').month(this.preventivaCadastro.mes - 1).format('MMMM'))
            .concat('/').concat(this.preventivaCadastro.ano.toString());
          this.preventivaCadastro.matriculaSolicitante = this.auth.authInfo.username;
          this.preventivaCadastro.nomeSetor = this.setorOpcoes.find(item => item.value === this.preventivaCadastro.idSetor).label;

          this.listaPreventivaCadastro.push(this.preventivaCadastro);

          this.copiaPreventivaAux(preventivaCadastroAux);
        }
      });

      this.validaMesAnteriorData();

      this.preventivaCadastro = new PreventivaCadastro();
      this.preventivaCadastro.idEquipamento = preventivaCadastroAux.idEquipamento;
      this.preventivaCadastro.codigoCentroCusto = preventivaCadastroAux.codigoCentroCusto;
      this.preventivaCadastro.hierarquiaCentroCusto = preventivaCadastroAux.hierarquiaCentroCusto;
      this.preventivaCadastro.idSetor = preventivaCadastroAux.idSetor;

      this.mesesSelecionados = [];

      this.isDataInicioInvalida = false;
      this.isDataFimInvalida = false;
      this.isMesAnterior = false;
      this.preencherCamposObrigatoriosInclusao();
    }

  }

  private copiaPreventivaAux(preventivaCadastroAux: PreventivaCadastro): void {
    this.preventivaCadastro = new PreventivaCadastro();
    this.preventivaCadastro.idEquipamento = preventivaCadastroAux.idEquipamento;
    this.preventivaCadastro.codigoCentroCusto = preventivaCadastroAux.codigoCentroCusto;
    this.preventivaCadastro.hierarquiaCentroCusto = preventivaCadastroAux.hierarquiaCentroCusto;
    this.preventivaCadastro.ano = preventivaCadastroAux.ano;
    this.preventivaCadastro.diaInicio = preventivaCadastroAux.diaInicio;
    this.preventivaCadastro.diaFim = preventivaCadastroAux.diaFim;
    this.preventivaCadastro.qtdHoras = preventivaCadastroAux.qtdHoras;
    this.preventivaCadastro.idSetor = preventivaCadastroAux.idSetor;
  }

  private isPreventivaJaIncluida(): boolean {
    let incluida = false;
    this.listaPreventivaCadastro.forEach(preventiva => {
      if (preventiva.ano === this.preventivaCadastro.ano &&
        preventiva.mes === this.preventivaCadastro.mes &&
        ((parseInt(this.preventivaCadastro.diaInicio.toString()) >= parseInt(preventiva.diaInicio.toString()) &&
          parseInt(this.preventivaCadastro.diaInicio.toString()) <= parseInt(preventiva.diaFim.toString())) ||
          (parseInt(this.preventivaCadastro.diaFim.toString()) <= parseInt(preventiva.diaFim.toString()) &&
            parseInt(this.preventivaCadastro.diaFim.toString()) >= parseInt(preventiva.diaInicio.toString())) ||
          (parseInt(this.preventivaCadastro.diaInicio.toString()) <= parseInt(preventiva.diaInicio.toString()) &&
            parseInt(this.preventivaCadastro.diaFim.toString()) >= parseInt(preventiva.diaFim.toString()))) &&
        preventiva.idEquipamento === this.preventivaCadastro.idEquipamento) {
        this.messagesService.addErrorMessage('Já existe uma Manutenação Preventiva cadastrada para essa data em ' + preventiva.mesAno + ".");
        incluida = true;
      }
    });
    return incluida;
  }

  private isCamposvalidos(): boolean {    
    if (!isNullOrUndefined(this.preventivaCadastro.qtdHorasExecutadas) &&
      parseInt(this.preventivaCadastro.qtdHorasExecutadas.substring(4, 6)) >= 60) {
      this.messagesService.addErrorMessage('Informe minutos válido para Quantidade de horas executadas.');
      return false;
    }

    if (!isNullOrUndefined(this.listaCampoObrigatoriosNaoPreenchidos) && this.listaCampoObrigatoriosNaoPreenchidos.length > 0) {
      this.messagesService.addErrorMessage('O preenchimento do campo ' +
        this.listaCampoObrigatoriosNaoPreenchidos[0] + ' é obrigatório.');
      return false;
    }
    if (parseInt(this.preventivaCadastro.qtdHoras.toString()) === 0) {
      this.messagesService.addErrorMessage('O preenchimento do campo Quantidade de Horas Previstas é obrigatório.');
      return false;
    }

    if (parseInt(this.preventivaCadastro.diaFim.toString()) < parseInt(this.preventivaCadastro.diaInicio.toString())) {
      this.messagesService.addErrorMessage('Dia inválido. O dia final deve ser maior que o dia inicial.');
      return false;
    }
    if (this.preventivaCadastro.idStatus === StatusManutencaoPreventivaEnum.CONCLUIDA &&
      isNullOrUndefined(this.preventivaCadastro.qtdHorasExecutadas)) {
      this.messagesService.addErrorMessage('O preenchimento do campo Quantidade de horas executadas é obrigatório.');
      return false;
    }

    const minutos: number = parseInt(this.preventivaCadastro.qtdHoras.substring(4, 6));
    if (minutos >= 60) {
      this.messagesService.addErrorMessage('Informe minutos válido para Quantidade de horas.');
      return false;
    }

    if (!isNullOrUndefined(this.preventivaCadastro.qtdHorasExecutadas)){    
    const minutosExecutados: number = parseInt(this.preventivaCadastro.qtdHorasExecutadas.substring(5, 7));        
    if (minutosExecutados >= 60) {
      this.messagesService.addErrorMessage('Informe minutos válido para Quantidade de horas executadas.');
      return false;
    }

    }    

    return true;
  }

  private isQuantidadeHorasValida(): boolean {    
    if (this.preventivaCadastro.qtdHoras.length < 4) {
      this.messagesService.addErrorMessage('Informe uma Quantidade de Horas válida.');
      return false;
    }

    let quantHrsPermitida = ((this.preventivaCadastro.diaFim - this.preventivaCadastro.diaInicio) + 1) * 24;
    let quantHrs = parseInt(this.preventivaCadastro.qtdHoras.substring(0, 3));

    if (quantHrs > quantHrsPermitida) {
      this.messagesService.addErrorMessage('Quantidade de Horas superior ao permitido.');
      return false;
    }

    return true;
  }

  private isMesAnteriorData(): void {
    const dataInicioConcatenada = this.preventivaCadastro.ano.toString().concat('/').concat(this.preventivaCadastro.mes.toString())
      .concat('/').concat(this.preventivaCadastro.diaInicio.toString());
    const dataFimConcatenada = this.preventivaCadastro.ano.toString().concat('/').concat(this.preventivaCadastro.mes.toString())
      .concat('/').concat(this.preventivaCadastro.diaFim.toString());

    if (isNaN(new Date(dataInicioConcatenada).getDate())) {
      this.isDataInicioInvalida = true;
    }
    if (isNaN(new Date(dataFimConcatenada).getDate())) {
      this.isDataFimInvalida = true;
    }

    if ((this.preventivaCadastro.mes < (new Date().getMonth() + 1) &&
      this.preventivaCadastro.ano === new Date().getFullYear()) ||
      (this.preventivaCadastro.mes === new Date().getMonth() + 1 && this.preventivaCadastro.diaInicio < new Date().getDate() && this.preventivaCadastro.ano === new Date().getFullYear())) {
      this.isMesAnterior = true;
    }
  }

  private validaMesAnteriorData(): void {
    if (this.isDataInicioInvalida) {
      this.messagesService.addErrorMessage('Início da Manutenção inválido. Por favor, informe um dia válido.');
    }
    if (this.isDataFimInvalida) {
      this.messagesService.addErrorMessage('Fim da Manutenção inválido. Por favor, informe um dia válido. ');
    }
    if (this.isMesAnterior) {
      this.messagesService.addErrorMessage('Não é possível cadastrar Manutenção Preventiva para meses anteriores.');
    }
    if (this.isMesAnterior || this.isDataInicioInvalida || this.isDataFimInvalida) {
      this.buscarCentroCustoPorEquipamento();
    }
  }

  private preencherCamposObrigatorios(): void {
    if (!this.isEditar) {
      this.listaCampoObrigatoriosNaoPreenchidos.push('Centro de Custo');
      this.listaCampoObrigatoriosNaoPreenchidos.push('Equipamento');
      this.listaCampoObrigatoriosNaoPreenchidos.push('Ano');
      this.listaCampoObrigatoriosNaoPreenchidos.push('Mês');
      this.listaCampoObrigatoriosNaoPreenchidos.push('Início da Manutenção');
      this.listaCampoObrigatoriosNaoPreenchidos.push('Fim da Manutenção');
      this.listaCampoObrigatoriosNaoPreenchidos.push('Quantidade de Horas Previstas');
      this.listaCampoObrigatoriosNaoPreenchidos.push('Setor');
    }
  }

  private preencherCamposObrigatoriosInclusao(): void {
    if (!this.isEditar) {
      this.listaCampoObrigatoriosNaoPreenchidos.push('Ano');
      this.listaCampoObrigatoriosNaoPreenchidos.push('Mês');
      this.listaCampoObrigatoriosNaoPreenchidos.push('Início da Manutenção');
      this.listaCampoObrigatoriosNaoPreenchidos.push('Fim da Manutenção');
      this.listaCampoObrigatoriosNaoPreenchidos.push('Quantidade de Horas Previstas');
    }
  }

  public desabilitarExcluir(preventiva: PreventivaCadastro): boolean {
    return !isNullOrUndefined(preventiva.idManutencao);
  }

  public buscarPreventivasPorEquipamentoCentroCusto(): void {
    if (!isNullOrUndefined(this.preventivaCadastro.codigoCentroCusto) &&
      !isNullOrUndefined(this.preventivaCadastro.idEquipamento)) {
      this.manutencaoPreventivaService.buscarPreventivasPorEquipamentoCentroCusto(this.preventivaCadastro.idEquipamento,
        this.preventivaCadastro.codigoCentroCusto).subscribe(p => {
          this.listaPreventivaCadastro = p;
        });
    }
    this.blurCamposObrigatorios(this.preventivaCadastro.codigoCentroCusto, 'Centro de Custo');
    this.blurCamposObrigatorios(this.preventivaCadastro.idEquipamento, 'Equipamento');
  }

  public buscarCentroCustoPorEquipamento(): void {
    this.historicoSituacaoEquipamentoService.buscarCentroCustoAtivoPorIdEquipamento(this.preventivaCadastro.idEquipamento)
      .subscribe((h: HistoricoSituacaoEquipamentoDTO) => {
        this.preventivaCadastro.codigoCentroCusto = h.codigoCentroCusto;
        this.preventivaCadastro.hierarquiaCentroCusto = h.hierarquiaCentroCusto;

        this.buscarPreventivasPorEquipamentoCentroCusto();
      });
  }

  public salvar(): void {    
    if (this.listaPreventivaCadastro.length === 0) {
      this.messagesService.addErrorMessage('Informe ao menos uma Manutenção Preventiva.');
      return;
    }
    this.listaPreventivaCadastro.forEach(p => {
      p.matriculaUsuarioLogado = this.auth.authInfo.username;
    });
    this.manutencaoPreventivaService.salvar(this.listaPreventivaCadastro)
      .subscribe(p => {
        this.router.navigate(['app/manutencao/preventiva/consultar']);
        this.messagesService.addSuccessMessage('Cadastro realizado com sucesso.');
      }, error => {
        this.messagesService.addErrorMessage(error);
      });
  }

  public atualizar(): void {        
    
    if(this.isInicioManutencaoValido()){    
    
      if (this.isCamposvalidos()) {    
        this.preventivaCadastro.matriculaUsuarioLogado = this.auth.authInfo.username;
        this.manutencaoPreventivaService.atualizar(this.preventivaCadastro)
          .subscribe(p => {
            this.messagesService.addSuccessMessage('Cadastro realizado com sucesso.');    
          }, error => {
            this.messagesService.addErrorMessage(error);    
          });
      }
    }
  }

  private isInicioManutencaoValido(): boolean {
      let dataAtual = moment(); // Data de hoje
          
      let dia = this.preventivaCadastro.diaInicio;
      let mes = this.preventivaCadastro.mes;
      let ano = this.preventivaCadastro.ano
                  
      let dataSolicitacao = moment(ano+'-'+ mes+'-'+dia); // Data solicitacao   

    if (this.preventivaCadastro.idStatus === StatusManutencaoPreventivaEnum.MANUTENCAO &&
        dataAtual.isBefore(dataSolicitacao, 'day')) {        
        this.messagesService.addErrorMessage('Não é possível iniciar uma manutenção antes do dia previsto.');
        return false;        
      }else{       
        return true;        
      }      
  }

  public removerPreventiva(preventiva: PreventivaCadastro): void {
    var index = this.listaPreventivaCadastro.indexOf(preventiva);
    if (index > -1) {
      this.listaPreventivaCadastro.splice(index, 1);
      this.messagesService.addSuccessMessage('Exclusão realizada com sucesso.');
    }
  }

  public verificarStatusJustificativa():void{     
    if(this.preventivaCadastro.idStatus === StatusManutencaoPreventivaEnum.CANCELADA){
      this.isCancelada = true;      
    }else{
      this.isCancelada = false;      
    }
  }  

  public cancelar(): void {
    this.location.back();
  }

}
