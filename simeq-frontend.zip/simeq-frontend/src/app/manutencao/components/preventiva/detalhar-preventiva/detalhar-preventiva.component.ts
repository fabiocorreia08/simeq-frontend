import { StatusPreventivaService } from '../../../services/status-preventiva.service';
import { ActivatedRoute, Router } from '@angular/router';
import { BreadcrumbService } from '../../../../core/breadcrumb/breadcrumb.service';
import { AdministracaoGenericComponent } from '../../../../administracao/administracao-generic.component';
import { ManutencaoPreventivaService } from '../../../services/manutencao-preventiva.service';
import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';
import { isNullOrUndefined, error } from 'util';

import { AuthenticationService } from '../../../../core/security/auth.service';
import { CentroCustoService } from '../../../../shared/services/centro-custo.service';
import { EquipamentoService } from '../../../../administracao/equipamento/services/equipamento.service';
import { LabelValue } from '../../../../core/models/label-value';
import { ArrayUtil } from '../../../../shared/Utils/ArrayUtil';
import { PreventivaCadastro } from '../../../models/preventiva-cadastro.model';
import { MessagesService } from '../../../../core/messages/messages.service';
import { StatusManutencaoPreventivaEnum } from '../../../enums/status-manutencao-preventiva.enum';

@Component({
  selector: 'simeq-detalhar-preventiva',
  templateUrl: './detalhar-preventiva.component.html',
  styleUrls: ['./detalhar-preventiva.component.scss']
})
export class DetalharPreventivaComponent extends AdministracaoGenericComponent implements OnInit {

  public preventivaCadastro: PreventivaCadastro = new PreventivaCadastro();
  public listaPreventivaCadastro: PreventivaCadastro [] = [];
  public listaCentroCusto: LabelValue[] = [];
  public listaEquipamentos: LabelValue [] = [];
  public listaStatus: LabelValue [] = [];
  public listaAno: LabelValue [] = [];
  public listaMes: LabelValue [] = [];
  public tituloTela = 'Detalhar';
  public isDetalhar = true;
  public readonly SOLICITANTE: number = 3;
  public isPerfilSolicitante: boolean;
  public isCancelada = false;
  public isReprovada = false;
  public isReprogramada = false;

  constructor(messagesService: MessagesService,
    private equipamentoService: EquipamentoService,
    private centroCustoService: CentroCustoService,
    public auth: AuthenticationService,
    private manutencaoPreventivaService: ManutencaoPreventivaService,
    private breadcrumbService: BreadcrumbService,
    private route: ActivatedRoute,
    private statusPreventivaService: StatusPreventivaService,
    private location: Location,
    private router: Router) {
      super(messagesService);
      breadcrumbService.addRoute('/app/manutencao/preventiva/consultar', 'Preventivas', true);
  }

    ngOnInit() {            
      this.breadcrumbService.addRoute('/app/manutencao/preventiva/detalhar', 'Detalhar', false);
      this.preventivaCadastro = this.route.snapshot.data['preventivaResolve'];
      this.isPerfilSolicitante = this.auth.getPerfil(this.SOLICITANTE);
      this.carregarStatus();
      this.carregarEquipamento();     
      this.carregarMeses();
      this.carregarAno();
      this.verificarStatusJustificativa();
    }

    public carregarEquipamento(): void {      
      let idPerfil = this.auth.getIdPerfil(this.auth.authInfo.details.perfis);
      if (isNullOrUndefined(idPerfil)) {
        idPerfil = 0;
      }
      this.equipamentoService.buscarPorHierarquiaCCUsuarioLogado(idPerfil ,this.auth.authInfo.username).subscribe(e => {  
        this.listaEquipamentos = e;
        this.listaEquipamentos = ArrayUtil.adicionarPrimeiroValor(this.listaEquipamentos, 'Selecione', null);
      });      
    }

    public carregarStatus(): void { 
      let idPerfil = this.auth.getIdPerfil(this.auth.authInfo.details.perfis);
      if (isNullOrUndefined(idPerfil)) {
        idPerfil = 0;
      }              
      this.statusPreventivaService.buscarComboEditarPreventivaPerfil(this.preventivaCadastro.numeroSolicitacao, idPerfil).subscribe(s => {
      this.listaStatus = s;
      this.listaStatus = ArrayUtil.adicionarPrimeiroValor(this.listaStatus, 'Selecione', null);
    });

    } 
    
    public carregarMeses(): void {     
      this.manutencaoPreventivaService.buscarTodosMeses()
        .subscribe(m => {
          this.listaMes = m;
          this.listaMes = ArrayUtil.adicionarPrimeiroValor(this.listaMes, 'Selecione', null);
        });
    }

    public carregarAno(): void {      
      let dataAtual = new Date();
      this.listaAno.push(new LabelValue(dataAtual.getFullYear().toString(), dataAtual.getFullYear()));
      this.listaAno.push(new LabelValue((dataAtual.getFullYear() + 1).toString(), (dataAtual.getFullYear() + 1)));
      this.listaAno = ArrayUtil.adicionarPrimeiroValor(this.listaAno, 'Selecione', null);
    }

    public detalharStatus(): void {
      this.router.navigate(['app/manutencao/preventiva/detalhar-status/' + this.preventivaCadastro.numeroSolicitacao]);
    }

    public voltar(): void {
      this.location.back();
    }

    public getPerfil(perfil: number): boolean {
      this.auth.authInfo.details.perfis.forEach(p => {
        if (p.id_perfil === perfil) {
          return true;
        }
      });
      return false;
    }

    public verificarStatusJustificativa():void{         
      if(this.preventivaCadastro.idStatus === StatusManutencaoPreventivaEnum.CANCELADA){
        this.isCancelada = true;        
      }else{
        this.isCancelada = false;        
      }
    }

}
