import { LazyLoadEvent } from 'primeng/primeng';
import { Pagina } from './../../../../core/models/pagina.model';
import { StatusPreventivaService } from './../../../services/status-preventiva.service';
import { BreadcrumbService } from './../../../../core/breadcrumb/breadcrumb.service';
import { MessagesService } from './../../../../core/messages/messages.service';
import { ActivatedRoute } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { HistoricoStatusPreventiva } from '../../../models/historico-status-preventiva.model';
import { HistoricoStatusPreventivaFiltro } from '../../../models/historico-status-preventiva-filtro.model';
import { Location } from '@angular/common';

@Component({
  selector: 'simeq-status-preventiva',
  templateUrl: './status-preventiva.component.html',
  styleUrls: ['./status-preventiva.component.scss']
})
export class StatusPreventivaComponent implements OnInit {

  public numeroSolicitacao: string;
  public pagina: Pagina<HistoricoStatusPreventiva> = new Pagina<HistoricoStatusPreventiva>();
  public filtro: HistoricoStatusPreventivaFiltro = new HistoricoStatusPreventivaFiltro();

  constructor(private route: ActivatedRoute,
    private location: Location,
    private messagesService: MessagesService,
    private breadcrumbService: BreadcrumbService,
    private statusPreventivaService: StatusPreventivaService) {
      breadcrumbService.addRoute('/app/manutencao/preventiva/consultar', 'Preventivas', true);
  }

  ngOnInit() {
    this.filtro.numeroSolicitacao = this.route.snapshot.params['numeroSolicitacao'];
    this.numeroSolicitacao = this.route.snapshot.params['numeroSolicitacao'];
    this.breadcrumbService.addRoute('/app/manutencao/preventiva/detalhar-status/' + this.filtro.numeroSolicitacao, 'Listar Status', false);
    this.pesquisar();
  }

  public pesquisar(): void {
    this.pagina = new Pagina();
    this.filtrar();
  }

  public paginar(event: LazyLoadEvent): void {
    this.pagina = new Pagina<HistoricoStatusPreventiva>(event.first, event.rows);
    this.filtrar();
  }

  public filtrar(): void {
    this.statusPreventivaService.filtrar(this.filtro, this.pagina)
      .subscribe((pagina) => {
        this.pagina = pagina;
      },
      (error) => {
        this.messagesService.addErrorMessage(error);
      });
  }

  public voltar(): void {
    this.location.back();
  }
}
