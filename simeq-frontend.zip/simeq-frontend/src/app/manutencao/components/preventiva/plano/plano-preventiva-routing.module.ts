
import { Routes, RouterModule } from '@angular/router';
import { NgModule } from '@angular/core';
import { ConsultarPlanoPreventivaComponent } from './consultar-plano-preventiva/consultar-plano-preventiva.component';
import { MainComponent } from '../../../../main/main.component';
import { AuthGuard } from '../../../../core/security/auth.guard';
import { PerfisConstants } from '../../../../core/security/perfis.constants';

const routes: Routes = [
  { path: 'app', component: MainComponent,
    children: [
            
      {
        path: 'manutencao/preventiva/plano/consultar-plano-preventiva/:numeroSolicitacao',
        component: ConsultarPlanoPreventivaComponent,
        canActivate: [AuthGuard],
        data: { funcionalidade: [PerfisConstants.CADASTRAR_ATIVIDADES] },
      },      
   ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PlanoPreventivaRoutingModule { }
