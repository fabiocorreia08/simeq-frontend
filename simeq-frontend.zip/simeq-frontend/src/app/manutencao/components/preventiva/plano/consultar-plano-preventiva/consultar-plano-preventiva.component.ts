import { Component, OnInit, Input } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AdministracaoGenericComponent } from '../../../../../administracao/administracao-generic.component';
import { BreadcrumbService } from '../../../../../core/breadcrumb/breadcrumb.service';
import { MessagesService } from '../../../../../core/messages/messages.service';

import { isNullOrUndefined, error } from 'util';
import { ManutencaoPreventivaService } from '../../../../services/manutencao-preventiva.service';
import { LabelValue } from '../../../../../core/models/label-value';
import { AuthenticationService } from '../../../../../core/security/auth.service';
import { ArrayUtil } from '../../../../../shared/Utils/ArrayUtil';
import { EquipamentoService } from '../../../../../administracao/equipamento/services/equipamento.service';
import { StatusPreventivaService } from '../../../../services/status-preventiva.service';

import { CentroCustoService } from '../../../../../shared/services/centro-custo.service';
import { DatePipe, Location } from '@angular/common';
import { CalendarLocaleService } from '../../../../../core/calendar.locale.service';

import { PlanoPreventivaService } from '../../../../services/plano-preventiva.service';
import { PlanoPreventivaConsultaTabela } from '../../../../models/plano-preventiva-consulta-tabela.model';
import { PreventivaCadastro } from '../../../../models/preventiva-cadastro.model';
import { PlanoPreventivaConsultaFiltro } from '../../../../models/plano-preventiva-consulta-filtro.model';

import { ManutencaoCorretiva } from '../../../../models/manutencao-corretiva.model';
import { ManutencaoCorretivaService } from '../../../../services/manutencao-corretiva.service';

import { RelatorioService } from '../../../../../relatorios/services/relatorio.service';
import { RelatorioPlanoPreventivaFiltro } from '../../../../../relatorios/models/relatorio-plano-preventiva-filtro';

import { EquipamentoDTO } from '../../../../../administracao/equipamento/resources/dtos/equipamento-dto.class';
import { Atividade } from '../../../../models/atividade.model';
import { AtividadeConsulta } from '../../../../models/atividade-consulta.model';
import { AtividadeService } from '../../../../services/atividade.service';

@Component({
  selector: 'simeq-consultar-plano-preventiva',
  templateUrl: './consultar-plano-preventiva.component.html',
  styleUrls: ['./consultar-plano-preventiva.component.scss']
})
export class ConsultarPlanoPreventivaComponent extends AdministracaoGenericComponent implements OnInit {

  @Input('grupoSubGrupo') modalGrupoSubGrupo: String;

  public preventivaCadastro: PreventivaCadastro = new PreventivaCadastro();
  public planos: PlanoPreventivaConsultaTabela[] = [];
  public plano: PlanoPreventivaConsultaTabela = new PlanoPreventivaConsultaTabela();
  public filtro: PlanoPreventivaConsultaFiltro = new PlanoPreventivaConsultaFiltro();
  public filtroRelatorio: RelatorioPlanoPreventivaFiltro = new RelatorioPlanoPreventivaFiltro(); 

  public planosSelecionados: PlanoPreventivaConsultaTabela[] = [];

  public corretiva: ManutencaoCorretiva = new ManutencaoCorretiva();
  public corretivas: ManutencaoCorretiva[] = [];
  public idsManutencao: number[] = [];  

  public atividades: AtividadeConsulta[] = [];

  public listaCentroCusto: LabelValue[] = [];
  public listaEquipamentos: LabelValue [] = [];
  public listaStatus: LabelValue [] = [];
  public listaAno: LabelValue [] = [];
  public listaMes: LabelValue [] = [];  
  public tituloTela: string = 'Consultar';

  public equipamentoRelatorio: EquipamentoDTO = new EquipamentoDTO();

  public divModal: any;

  public grupo: string;
  public subGrupo: string;

  public grupoSubGrupos: string[] = [];

  public pt = this.calendarLocalService.pt_BR;
       
  constructor(
    public auth: AuthenticationService,
    private statusPreventivaService: StatusPreventivaService,
    private atividadeService: AtividadeService,
    private equipamentoService: EquipamentoService,
    private centroCustoService: CentroCustoService,    
    public manutencaoPreventivaService: ManutencaoPreventivaService,
    private manutencaoCorretivaService: ManutencaoCorretivaService,
    public planoPreventivaService: PlanoPreventivaService,    
    private route: ActivatedRoute,   
    private location: Location,
    public messagesService: MessagesService,
    public breadcrumbService: BreadcrumbService,
    private calendarLocalService: CalendarLocaleService,
    private relatorioService: RelatorioService,
    private dataPipe: DatePipe   
  ) { 
    super(messagesService);
    this.breadcrumbService.addRoute('/app/manutencao/preventiva/plano/consultar-plano-preventiva', 'Planos', true);
  }

  ngOnInit() {    
    this.breadcrumbService.addRoute('/app/manutencao/preventiva/plano/consultar-plano-preventiva', 'Consultar', false);
    this.preventivaCadastro.numeroSolicitacao = this.route.snapshot.params['numeroSolicitacao'];
    if (!isNullOrUndefined(this.preventivaCadastro.numeroSolicitacao)) {
      this.buscarManutencao();
    }
    this.carregarEquipamento();
    this.carregarCentroCusto();
    this.carregarStatus();
    this.carregarMeses();
    this.carregarAno();      
  }
  
  public buscarManutencao(): void {    
    this.manutencaoPreventivaService.
    buscarPreventivaPorNumeroSolicitacao(this.preventivaCadastro.numeroSolicitacao)
      .subscribe((m) => {   
         this.preventivaCadastro = m;              
         this.buscarUltimaPreventivaPorEquipamento(this.preventivaCadastro.idEquipamento);            
      },
        (error) => {          
          this.messagesService.addErrorMessage(error);
      });               
  }

  public buscarUltimaPreventivaPorEquipamento(idEquipamento: number): void{
    this.manutencaoPreventivaService.
    buscarUltimaPreventivaPorEquipamento(idEquipamento)
      .subscribe((m) => { 
         
         this.preventivaCadastro.dataUltimaConcluida = m.dataUltimaConcluida;   
         if(!isNullOrUndefined(m.id)){
          this.buscarAtividadePorManutencaoPreventiva(m.id); 
         }   
                       
      },
        (error) => {          
          this.messagesService.addErrorMessage(error);
      }); 
  }

  public buscarAtividadePorManutencaoPreventiva(idManutencao: number): void{
    
    this.atividadeService.
    buscarAtividadesPorManutencaoPreventiva(idManutencao)
      .subscribe((a) => {   
         this.atividades = a;                       
      },
        (error) => {          
          this.messagesService.addErrorMessage(error);
      }); 
  }

  public carregarEquipamento(): void {      
    let idPerfil = this.auth.getIdPerfil(this.auth.authInfo.details.perfis);
    if (isNullOrUndefined(idPerfil)) {
      idPerfil = 0;
    }
    this.equipamentoService.buscarPorHierarquiaCCUsuarioLogado(idPerfil ,this.auth.authInfo.username).subscribe(e => {
      this.listaEquipamentos = e;
      this.listaEquipamentos = ArrayUtil.adicionarPrimeiroValor(this.listaEquipamentos, 'Selecione', null);
    });    
  }

  public carregarCentroCusto(): void {
    this.centroCustoService.buscarTodos()
    .subscribe(c => {
      this.listaCentroCusto = c;
    });    
  }

  public carregarStatus(): void { 
    let idPerfil = this.auth.getIdPerfil(this.auth.authInfo.details.perfis);
      if (isNullOrUndefined(idPerfil)) {
        idPerfil = 0;
      }          
    this.statusPreventivaService.buscarComboEditarPreventivaPerfil(this.preventivaCadastro.numeroSolicitacao, idPerfil).subscribe(s => {
    this.listaStatus = s;
    this.listaStatus = ArrayUtil.adicionarPrimeiroValor(this.listaStatus, 'Selecione', null);
    });
  } 
  
  public carregarMeses(): void {     
    this.manutencaoPreventivaService.buscarTodosMeses()
      .subscribe(m => {
        this.listaMes = m;
        this.listaMes = ArrayUtil.adicionarPrimeiroValor(this.listaMes, 'Selecione', null);
      });
  }

  public carregarAno(): void {      
    let dataAtual = new Date();
    this.listaAno.push(new LabelValue(dataAtual.getFullYear().toString(), dataAtual.getFullYear()));
    this.listaAno.push(new LabelValue((dataAtual.getFullYear() + 1).toString(), (dataAtual.getFullYear() + 1)));
    this.listaAno = ArrayUtil.adicionarPrimeiroValor(this.listaAno, 'Selecione', null);
  }

  public pesquisar(): void{     
    this.filtrar();          
  }

  public filtrar(): void{    
    this.planoPreventivaService.buscarAtividadesCorretivaPorEquipamento(this.preventivaCadastro.idEquipamento, this.filtro.dataInicialFiltro, this.filtro.dataFinalFiltro)
      .subscribe(planos => {
        this.planos = planos;        
        if (this.planos.length==0) {
          this.messagesService.addErrorMessage('Não existe manutenção corretiva para este equipamento, nesse período.');
        }
      });      
  }  

  public exibirModalCorretivas(idsManutencao){     
    this.corretivas = new Array<ManutencaoCorretiva>();   
    this.idsManutencao = idsManutencao;    
    let ids = [];
    this.idsManutencao.forEach((id) => {
      if (!ids.includes(id)) {
        ids.push(id);
      }
    });    
    ids.forEach(idManuntecao => {
      this.manutencaoCorretivaService.buscarComAvariaPorIdManutencao(idManuntecao)
        .subscribe((c) => {         
          this.corretiva = c;
          this.corretivas.push(this.corretiva);
        },
          (error) => {
            this.messagesService.addErrorMessage(error);
          });
    });                 
  }  

  public cancelar(): void {
    this.location.back();
  }

  public desabilitarBotaoGerarPlano() {
    if (isNullOrUndefined(this.preventivaCadastro.diaInicio) 
    || isNullOrUndefined(this.preventivaCadastro.diaFim) 
    || (this.preventivaCadastro.diaFim < this.preventivaCadastro.diaInicio)) {
      return true;        
    }
    return false;
  }

  public gerarRelatorio(): void {  
    
    this.filtroRelatorio.dataInicialFiltro = this.dataPipe.transform(this.filtro.dataInicialFiltro, 'dd/MM/yyyy');
    this.filtroRelatorio.dataFinalFiltro = this.dataPipe.transform(this.filtro.dataFinalFiltro, 'dd/MM/yyyy');    
    this.filtroRelatorio.numeroSolicitacao = this.preventivaCadastro.numeroSolicitacao;
    this.filtroRelatorio.hierarquiaCentroCusto = this.preventivaCadastro.hierarquiaCentroCusto;
    this.filtroRelatorio.idEquipamento = this.preventivaCadastro.idEquipamento;
    this.filtroRelatorio.hierarquiaCentroCusto = this.preventivaCadastro.hierarquiaCentroCusto;    
    
    this.filtroRelatorio.dataInicial = this.preventivaCadastro.diaInicio+'/'+this.preventivaCadastro.mes+'/'+this.preventivaCadastro.ano;
    
    this.filtroRelatorio.qtdHoras = this.preventivaCadastro.qtdHoras;
    
    this.planosSelecionados.forEach(plano => {
      this.filtroRelatorio.grupoSubGrupos.push(plano.grupoSubGrupo);      
    });    

    this.relatorioService
      .gerarRelatorioPlanoPreventiva(this.filtroRelatorio)
      .subscribe((blobResponse: Blob) => {}); 

    this.filtroRelatorio = new RelatorioPlanoPreventivaFiltro();
    
  }  

  public desabilitarBotaoPesquisar() {
    if (isNullOrUndefined(this.filtro.dataInicialFiltro) || isNullOrUndefined(this.filtro.dataFinalFiltro) 
    || (this.filtro.dataFinalFiltro < this.filtro.dataInicialFiltro)) {
      return true;        
    }
    return false;
  }

  public desabilitarBotaoGerarRelatorio() {
    if (this.planos.length===0) {
      return true;        
    }
    return false;
  }

  public limparFiltros(): void{
    this.filtro = new PlanoPreventivaConsultaFiltro();
    this.planos = [];
  }  

}
