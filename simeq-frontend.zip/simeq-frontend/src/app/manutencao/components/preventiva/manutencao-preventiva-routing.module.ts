import { ManutencaoPreventivaResolve } from './../../resolves/manutencao-preventiva.resolve';
import { PerfisConstants } from './../../../core/security/perfis.constants';
import { AuthGuard } from './../../../core/security/auth.guard';
import { CadastrarPreventivaComponent } from './cadastrar-preventiva/cadastrar-preventiva.component';
import { MainComponent } from './../../../main/main.component';

import { Routes, RouterModule } from '@angular/router';
import { NgModule } from '@angular/core';
import { ConsultarPreventivaComponent } from './consultar-preventiva/consultar-preventiva.component';
import { DetalharPreventivaComponent } from './detalhar-preventiva/detalhar-preventiva.component';
import { StatusPreventivaComponent } from './status-preventiva/status-preventiva.component';
import { StatusPreventivaResolve } from '../../resolves/status-preventiva.resolve';

const routes: Routes = [
  { path: 'app', component: MainComponent,
    children: [
      {
        path: 'manutencao/preventiva/consultar',
        component: ConsultarPreventivaComponent,
        canActivate: [AuthGuard],
        data: {funcionalidade: [PerfisConstants.CONSULTAR_MANUTENCAO_PREVENTIVA_PERMISSOES]},            
      },
      {
        path: 'manutencao/preventiva/consultar/:idStatus',
        component: ConsultarPreventivaComponent,
        canActivate: [AuthGuard],
        data: {
          funcionalidade: PerfisConstants.CONSULTAR_MANUTENCAO_PREVENTIVA_PERMISSOES,
          isDashboard: true
        },
        resolve: {
          statusPreventivaResolve: StatusPreventivaResolve
        }
      },
      {
        path: 'manutencao/preventiva/cadastrar',
        component: CadastrarPreventivaComponent,
        canActivate: [AuthGuard],
        data: {funcionalidade: [PerfisConstants.CADASTRAR_MANUTENCAO_PREVENTIVA]},
      },               
      {
        path: 'manutencao/preventiva/editar/:idManutencao',
        component: CadastrarPreventivaComponent,
        canActivate: [AuthGuard],
        resolve: {
          preventivaResolve: ManutencaoPreventivaResolve
        },
        data: {funcionalidade: [PerfisConstants.EDITAR_MANUTENCAO_PREVENTIVA],
          isEditar: true},
      },
      {
        path: 'manutencao/preventiva/editar/informacao/:idManutencao',
        component: CadastrarPreventivaComponent,
        canActivate: [AuthGuard],
        resolve: {
          preventivaResolve: ManutencaoPreventivaResolve
        },
        data: {funcionalidade: [PerfisConstants.EDITAR_MANUTENCAO_PREVENTIVA],          
          isEditar: true,
          isEditarInformacao: true},
      },      
      {
        path: 'manutencao/preventiva/detalhar/:idManutencao',
        component: DetalharPreventivaComponent,
        canActivate: [AuthGuard],
        resolve: {
          preventivaResolve: ManutencaoPreventivaResolve
        },
        data: {funcionalidade: PerfisConstants.DETALHAR_MANUTENCAO_PREVENTIVA_PERMISSOES,
          isDetalhar: true},
      },
      {
        path: 'manutencao/preventiva/detalhar-status/:numeroSolicitacao',
        component: StatusPreventivaComponent,
        canActivate: [AuthGuard],
        data: {funcionalidade: PerfisConstants.LISTAR_STATUS_MANUTENCAO_PREVENTIVA_PERMISSOES},
      },      
   ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ManutencaoPreventivaRoutingModule { }
