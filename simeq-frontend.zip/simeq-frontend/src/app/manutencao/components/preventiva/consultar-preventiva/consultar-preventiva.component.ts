import { BreadcrumbService } from '../../../../core/breadcrumb/breadcrumb.service';
import { AdministracaoGenericComponent } from '../../../../administracao/administracao-generic.component';
import { ManutencaoPreventivaService } from '../../../services/manutencao-preventiva.service';
import { Component, OnDestroy, OnInit } from '@angular/core';

import { AuthenticationService } from '../../../../core/security/auth.service';
import { isNullOrUndefined } from 'util';
import { CentroCustoService } from '../../../../shared/services/centro-custo.service';
import { EquipamentoService } from '../../../../administracao/equipamento/services/equipamento.service';
import { LabelValue } from '../../../../core/models/label-value';
import { ArrayUtil } from '../../../../shared/Utils/ArrayUtil';
import { MessagesService } from '../../../../core/messages/messages.service';
import * as moment from 'moment';
import { CalendarLocaleService } from '../../../../core/calendar.locale.service';
import { GrupoService } from '../../../../administracao/grupo-subgrupo/services/grupo.service';
import { GrupoDTO } from '../../../../administracao/grupo-subgrupo/resources/dtos/grupo-dto.class';
import { PreventivaConsultaFiltro } from '../../../models/preventiva-consulta-filtro.model';
import { PreventivaConsultaTabela } from '../../../models/preventiva-consulta-tabela.model';
import { Pagina } from '../../../../core/models/pagina.model';
import { LazyLoadEvent } from 'primeng/components/common/api';
import { StatusManutencaoPreventivaEnum } from '../../../enums/status-manutencao-preventiva.enum';
import { StatusPreventivaService } from '../../../services/status-preventiva.service';
import { PerfisConstants } from '../../../../core/security/perfis.constants';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription } from 'rxjs';

declare var saveAs:any;

@Component({
  selector: 'simeq-consultar-preventiva',
  templateUrl: './consultar-preventiva.component.html',
  styleUrls: ['./consultar-preventiva.component.scss']
})
export class ConsultarPreventivaComponent extends AdministracaoGenericComponent implements OnInit, OnDestroy {

  public tituloTela = 'Consultar';
  public desabilitarBotoesVisitante = false;
  public desabilitarBotoesSolicitante = false;
  public desabilitarBotoesGestor = false;
  public desabilitarBotoesTecnico = false;
  public isPerfilSolicitante = false;
  public isPerfilTecnico = false;
  public isPerfilVisitante = false;

  public listaStatus: LabelValue[] = [];
  public listaCentroCusto: LabelValue[] = [];
  public listaEquipamento: LabelValue[] = [];
  public listaGrupo: LabelValue[] = [];

  public desabilitarGrupo = true;

  public readonly TECNICO: number = 2;
  public readonly VISITANTE: number = 6;
  public readonly SOLICITANTE: number = 3;
  public readonly GESTOR: number = 5;
  public readonly APROVADO_PELO_GESTOR: number = StatusManutencaoPreventivaEnum.APROVADA_GESTOR;
  public readonly EM_MANUTENCAO: number = StatusManutencaoPreventivaEnum.MANUTENCAO;
  public readonly REPROGRAMADO: number = StatusManutencaoPreventivaEnum.REPROGRAMADA;
  public readonly RECURSO_ALOCADO: number = StatusManutencaoPreventivaEnum.RECURSO_ALOCADO;

  public filtro: PreventivaConsultaFiltro = new PreventivaConsultaFiltro();
  public pagina: Pagina<PreventivaConsultaTabela> = new Pagina<PreventivaConsultaTabela>();

  private subscribeRefresh: Subscription;

  constructor(messagesService: MessagesService,
    private equipamentoService: EquipamentoService,
    private centroCustoService: CentroCustoService,
    public auth: AuthenticationService,
    private grupoService: GrupoService,
    private manutencaoPreventivaService: ManutencaoPreventivaService,
    private statusManutencaoService: StatusPreventivaService,
    private route: ActivatedRoute,
    private router: Router,
    public calendarLocaleService: CalendarLocaleService,
    private breadcrumbService: BreadcrumbService) {
      super(messagesService);
      breadcrumbService.addRoute('/app/manutencao/preventiva/consultar', 'Preventivas', true); 
      this.breadcrumbService.addRoute('/app/manutencao/preventiva/consultar', 'Consultar', false);     
      this.listaStatus = this.route.snapshot.data['statusPreventivaResolve'];
  }

  ngOnInit() {    
    this.desabilitarBotoesVisitante = this.getPerfil(this.VISITANTE);    
    this.desabilitarBotoesGestor = this.getPerfil(this.GESTOR);
    this.desabilitarBotoesSolicitante = this.getPerfil(this.SOLICITANTE);
    this.isPerfilSolicitante = this.auth.getPerfil(this.SOLICITANTE);
    this.isPerfilTecnico = this.auth.getPerfil(this.TECNICO); 
    this.isPerfilVisitante = this.auth.getPerfil(this.VISITANTE);
    this.carregarStatus();
    this.carregarEquipamentos();
    this.carregarCentroCusto();
    this.carregarDadosDashboard();
  }

  carregarDadosDashboard() {
    if (this.route.snapshot.data['isDashboard']) {
      this.filtro.idsStatus = [];
      if (this.listaStatus.filter(item => (item.value === parseInt(this.route.snapshot.params['idStatus']))).length > 0) {
        this.filtro.idsStatus.push(parseInt(this.route.snapshot.params['idStatus']));
        this.pesquisar();
      }
    }
  }

  ngOnDestroy(): void {
    if (this.subscribeRefresh) {
      this.subscribeRefresh.unsubscribe();
    }    
  }

  public getPerfil(perfil: number): boolean {
    let isPerfil = false;
    this.auth.authInfo.details.perfis.forEach(p => {
      if (p.id_perfil === perfil) {
        isPerfil = true;
      }
    });
    return isPerfil;
  }

  public carregarStatus(): void {
    this.statusManutencaoService.buscarTodosLabelValue().subscribe(s => {
      this.listaStatus = s;
    });
  }

  public carregarEquipamentos(): void {
    this.equipamentoService.buscarTodosLabelValue().subscribe( e => {
      this.listaEquipamento = e;
      this.listaEquipamento = ArrayUtil.adicionarPrimeiroValor(this.listaEquipamento, 'Selecione', null);
    });
  }

  public carregarCentroCusto(): void {
    this.centroCustoService.buscarTodos()
    .subscribe(c => {
      this.listaCentroCusto = c;
    });
    /*
    let idPerfil = this.auth.getIdPerfil(this.auth.authInfo.details.perfis);
    if (isNullOrUndefined(idPerfil)) {
      idPerfil = 0;
    }
    this.centroCustoService.buscarCentroCustoHierarquiaUsuarioLogadoPerfil(idPerfil, this.auth.authInfo.username)
    .subscribe(c => {
      this.listaCentroCusto = c;
    });
    */
  }

  public onChangeGrupo(): void {
    if (this.filtro.idEquipamento != null) {
      this.desabilitarGrupo = false;
      this.grupoService.buscarGruposPorEquipamento(this.filtro.idEquipamento).subscribe(g => {
        this.listaGrupo = g;
        this.listaGrupo = ArrayUtil.adicionarPrimeiroValor(this.listaGrupo, 'Selecione', null);
      });
      return;
    }
    this.listaGrupo = [];
    this.desabilitarGrupo = true;
  }

  public limparFiltros(): void {
    this.pagina = new Pagina();
    this.filtro = new PreventivaConsultaFiltro();
  }
  public pesquisar(): void {
    this.pagina = new Pagina();
    this.filtrar();
  }

  public filtrar(): void {
    this.filtro.matricula = this.auth.authInfo.username;
    this.filtro.perfil = this.auth.getIdPerfil(this.auth.authInfo.details.perfis);
    this.filtro.numeroSolicitacao = !isNullOrUndefined(this.filtro.numeroSolicitacao) ? this.filtro.numeroSolicitacao.toLocaleUpperCase() : undefined;
    if (!isNullOrUndefined(this.filtro.centroCustos)) {
      if (this.filtro.centroCustos.length <= 0) {
        this.filtro.centroCustos = null;
      }
    }
    if (this.isDatasFiltroValida()) {
      let primeiroRegistro = this.pagina.primeiroRegistro;
      let tamanho = this.pagina.tamanho;
      this.pagina = new Pagina<PreventivaConsultaTabela>();
      this.pagina.primeiroRegistro = primeiroRegistro;
      this.pagina.tamanho = tamanho;
      
      if (!isNullOrUndefined(this.filtro.centroCustos)) {
        if (this.filtro.centroCustos.length <= 0) {
          this.filtro.centroCustos = null;
        }
      }    

      this.manutencaoPreventivaService.filtrar(this.filtro, this.pagina)
        .subscribe((pagina) => {        
          this.pagina = pagina;
        },
          (error) => {
            this.messagesService.addErrorMessage(error);
          });
    }
  }

  private isDatasFiltroValida(): boolean {
    if (!isNullOrUndefined(this.filtro.periodoInicio) && !isNullOrUndefined(this.filtro.periodoFim)) {
      if (this.filtro.periodoFim < this.filtro.periodoInicio) {
        this.messagesService.addErrorMessage('Data inválida. A data final deve ser maior que a data inicial.');
        return false;
      }
    }
    return true;
  }

  public paginar(event: LazyLoadEvent): void {
    this.pagina = new Pagina<PreventivaConsultaTabela>(event.first, event.rows);
    this.filtrar();
  }

  validarBotaoAlocar(){
    return (!this.isPerfilSolicitante);
  }

  public cadastrarAtividade(codicoSolicitacao, idManutencao){
    this.router.navigate([`/app/manutencao/atividade/cadastrar-atividade/${idManutencao}/${codicoSolicitacao}`]);
  }

  public consultarPlano(codicoSolicitacao, idManutencao){
    this.router.navigate([`/app/manutencao/preventiva/plano/consultar-plano-preventiva/${codicoSolicitacao}`]);
  }
 
  public desabilitarBotaoAlocar(status: number): boolean {
    if(status !== this.APROVADO_PELO_GESTOR && status !== this.RECURSO_ALOCADO
      && status !== this.REPROGRAMADO && status !== this.EM_MANUTENCAO){
        return true;
      } else{
        return false;
      }
  }

  download(id: number) {
    this.manutencaoPreventivaService.buscarRelatorioPreventiva(id)
      .subscribe((blobResponse: Blob) => {
        var blob = new Blob([blobResponse], {type: 'application/pdf'});
        const blobUrl = URL.createObjectURL(blob);
        const iframe = document.createElement('iframe');
        iframe.style.display = 'none';
        iframe.src = blobUrl;
        document.body.appendChild(iframe);
        if (iframe.contentWindow) {
          iframe.contentWindow.print();
        } else {
          saveAs(blobResponse, 'Relatorio_manutencao_preventiva.pdf', false);
        }
      },
      (error) => {
        this.messagesService.addErrorMessage('Erro ao fazer download do arquivo.');
      });
  }

  isDesabilitarImprimir(manutencao: PreventivaConsultaTabela): boolean {
    if (//manutencao.idStatus === StatusManutencaoPreventivaEnum.CANCELADA ||
      manutencao.idStatus === StatusManutencaoPreventivaEnum.IMPROCEDENTE) {
        return true;
    }
    return false;
  }

  isDesabilitarEditar(manutencao: PreventivaConsultaTabela): boolean {
    if (this.isPerfilSolicitante &&
      manutencao.idStatus !== StatusManutencaoPreventivaEnum.ABERTA) {
        return true;
    }
    return false;
  }
}
