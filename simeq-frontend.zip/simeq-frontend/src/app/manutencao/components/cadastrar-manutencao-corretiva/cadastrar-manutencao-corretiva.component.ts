import { ModalConfirmacaoComponent } from './../../../core/modal-confirmacao/modal-confirmacao.component';
import { BreadcrumbService } from './../../../core/breadcrumb/breadcrumb.service';
import { StatusManutencaoCorretivaService } from './../../services/status-manutencao.service';
import { Router, ActivatedRoute } from '@angular/router';
import { AdministracaoGenericComponent } from './../../../administracao/administracao-generic.component';
import { CentroCustoService } from './../../../shared/services/centro-custo.service';
import { AuthenticationService } from './../../../core/security/auth.service';
import { PessoaService } from './../../../shared/services/pessoa.service';
import { ArrayUtil } from './../../../shared/Utils/ArrayUtil';
import { MessagesService } from './../../../core/messages/messages.service';
import { isNullOrUndefined } from 'util';
import { ManutencaoCorretivaService } from './../../services/manutencao-corretiva.service';
import { Component, OnInit, ViewChild } from '@angular/core';
import { LabelValue } from '../../../core/models/label-value';
import { EquipamentoService } from '../../../administracao/equipamento/services/equipamento.service';
import { ManutencaoCorretiva } from '../../models/manutencao-corretiva.model';
import { AssistenteProducao } from '../../../shared/models/assistente-producao.model';
import { StatusManutencaoCorretivaEnum } from '../../enums/status-manutencao-corretiva.enum';
import { HistoricoSituacaoEquipamentoService } from '../../../administracao/equipamento/services/historico-situacao-equipamento.service';
import { HistoricoSituacaoEquipamentoDTO } from '../../../administracao/equipamento/resources/dtos/historico-situacao-equipamento-dto.class';
import { ModalAssistenteProducaoComponent } from './modal-assistente-producao/modal-assistente-producao.component';
import { FamiliaService } from '../../../administracao/familia/service/familia.service';
import { SetorManutencaoService } from '../../../shared/services/setor-manutencao.service';
import { Location, DatePipe } from '@angular/common';
import { interval  } from 'rxjs/observable/interval';
import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';

declare var saveAs: any;

@Component({
  selector: 'simeq-cadastrar-manutencao-corretiva',
  templateUrl: './cadastrar-manutencao-corretiva.component.html',
  styleUrls: ['./cadastrar-manutencao-corretiva.component.scss']
})
export class CadastrarManutencaoCorretivaComponent extends AdministracaoGenericComponent implements OnInit {

  public classesManutencao: LabelValue[];
  public isTelaAltera: boolean = false;
  public isTelaDetalhar: boolean = false;
  public isDesabilitarParalisacao: boolean = false;  
  public isAtualizarHorasComESemParalisacao: boolean = false;
  public listaEquipamentos: LabelValue[] = [];
  public listaStatus: LabelValue[] = [];
  public manutencaoCorretiva: ManutencaoCorretiva = new ManutencaoCorretiva();
  public listaCentroCusto: LabelValue[] = [];
  public isDesabilitarCamposEditar = false;  
  public isDesabilitarBotaoSalvar = false; 
  public assistenteProducao: AssistenteProducao = new AssistenteProducao();
  public tituloTela = 'Cadastrar';
  public familiaOpcoes: LabelValue[] = [];
  public setorOpcoes: LabelValue[] = [];
  public isPerfilSolicitante = false;
  public readonly SOLICITANTE: number = 3;
  public isCancelada = false;
  public isConcluida = false;
  public isReprovada = false;
  public isJustificativaDiferenteNull = false;

  @ViewChild('modalConfirmacaoImprimir') public modalConfirmacaoImprimir: ModalConfirmacaoComponent;
  @ViewChild('modalAssistenteProducao') modalAssistenteProducao: ModalAssistenteProducaoComponent;
  @ViewChild('modalConfirmacaoAprovar') public modalConfirmacaoAprovar: ModalConfirmacaoComponent;

  constructor(private manutencaoCorretivaService: ManutencaoCorretivaService,
    private datePipe: DatePipe,
    private equipamentoService: EquipamentoService,
    messagesService: MessagesService,
    private pessoaService: PessoaService,
    public auth: AuthenticationService,
    private centroCustoService: CentroCustoService,
    private router: Router,
    private route: ActivatedRoute,
    private statusManutencaoService: StatusManutencaoCorretivaService,
    public historicoSituacaoEquipamentoService: HistoricoSituacaoEquipamentoService,
    private breadcrumbService: BreadcrumbService,
    private familiaService: FamiliaService,
    private location: Location,
    private setorService: SetorManutencaoService) {
    super(messagesService);
    breadcrumbService.addRoute('/app/manutencao/consultar-manutencao-corretiva', 'Corretivas', true);
  }

  ngOnInit() {
    this.isPerfilSolicitante = this.auth.getPerfil(this.SOLICITANTE);
    this.isTelaAltera = this.route.snapshot.data['isTelaAltera'];
    if (this.isTelaAltera) {
      this.tituloTela = 'Editar';
      this.breadcrumbService.addRoute('/app/manutencao/cadastrar-manutencao-corretiva', 'Editar', false);
      this.manutencaoCorretiva = this.route.snapshot.data['manutencaoCorretivaResolve'];      
      
      this.carregarStatus();
      this.desabilitarParalizacao();
      this.buscarSetores();
      this.verificarStatusConcluida();
      this.verificarStatusCancelada();
      this.desabilitarCamposEditar();
      
    } else {
      this.breadcrumbService.addRoute('/app/manutencao/cadastrar-manutencao-corretiva', 'Cadastrar', false);
      this.manutencaoCorretiva.matriculaAssistenteProducao = this.auth.authInfo.username;
      this.buscarAssistenteProducao();
    }
    this.buscarClassesManutencao();
    this.carregarEquipamento();
    this.carregarCentroCusto();

    if(this.manutencaoCorretiva.paralisacao){      
      if(this.manutencaoCorretiva.idStatus === StatusManutencaoCorretivaEnum.ABERTA ||
        this.manutencaoCorretiva.idStatus === StatusManutencaoCorretivaEnum.RECURSO_ALOCADO ||
        this.manutencaoCorretiva.idStatus === StatusManutencaoCorretivaEnum.MANUTENCAO ||
        this.manutencaoCorretiva.idStatus === StatusManutencaoCorretivaEnum.AG_MATERIAL ||
        this.manutencaoCorretiva.idStatus === StatusManutencaoCorretivaEnum.AG_FORNECEDOR){
          this.atualizarHorasComParalizacao();
        }    
    }else{
      if(this.manutencaoCorretiva.idStatus === StatusManutencaoCorretivaEnum.ABERTA ||
        this.manutencaoCorretiva.idStatus === StatusManutencaoCorretivaEnum.RECURSO_ALOCADO ||
        this.manutencaoCorretiva.idStatus === StatusManutencaoCorretivaEnum.MANUTENCAO ||
        this.manutencaoCorretiva.idStatus === StatusManutencaoCorretivaEnum.AG_MATERIAL ||
        this.manutencaoCorretiva.idStatus === StatusManutencaoCorretivaEnum.AG_FORNECEDOR){
          this.atualizarHorasSemParalizacao();
        }
    }          
  }  

  public buscarClassesManutencao(): void {
    this.manutencaoCorretivaService.buscarClassesManutencao().subscribe(c => {
      this.classesManutencao = c;
    });
  }

  setValorRadio(classeManutencao: LabelValue) {
    this.manutencaoCorretiva.classeManutencao = classeManutencao;
    this.desabilitarParalizacao();
  }

  private desabilitarParalizacao(): void {
    if (this.manutencaoCorretiva.classeManutencao.value === 'S') {
      this.isDesabilitarParalisacao = true;
      this.manutencaoCorretiva.paralisacao = false;
      return;
    }
    this.isDesabilitarParalisacao = false;
  }

  public carregarEquipamento(): void {
    let idPerfil = this.auth.getIdPerfil(this.auth.authInfo.details.perfis);
    if (isNullOrUndefined(idPerfil)) {
      idPerfil = 0;
    }
    this.equipamentoService.buscarPorHierarquiaCCUsuarioLogado(idPerfil, this.auth.authInfo.username).subscribe(e => {
      this.listaEquipamentos = e;
      this.listaEquipamentos = ArrayUtil.adicionarPrimeiroValor(this.listaEquipamentos, 'Selecione', null);
    });
  }

  public carregarCentroCusto(): void {
    let idPerfil = this.auth.getIdPerfil(this.auth.authInfo.details.perfis);
    if (isNullOrUndefined(idPerfil)) {
      idPerfil = 0;
    }
    this.centroCustoService.buscarCentroCustoHierarquiaUsuarioLogadoPerfil(idPerfil, this.auth.authInfo.username)
      .subscribe(c => {
        this.listaCentroCusto = c;
        this.listaCentroCusto = ArrayUtil.adicionarPrimeiroValor(this.listaCentroCusto, 'Selecione', null);
      });
  }

  public salvar(): void {    
    if (this.isCamposValidos()) {
      this.manutencaoCorretiva.matriculaSolicitante = this.auth.authInfo.username;
      this.manutencaoCorretiva.nomeSolicitante = this.auth.authInfo.details.nome;
      this.manutencaoCorretiva.matriculaUsuarioLogado = this.auth.authInfo.username;
      this.manutencaoCorretiva.avaria = this.manutencaoCorretiva.avaria.toLocaleUpperCase();
      if (isNullOrUndefined(this.manutencaoCorretiva.idManutencao)) {
        this.salvarNova();
      } else {
        if(this.manutencaoCorretiva.paralisacao){
          if(this.manutencaoCorretiva.idStatus === StatusManutencaoCorretivaEnum.ABERTA ||
            this.manutencaoCorretiva.idStatus === StatusManutencaoCorretivaEnum.RECURSO_ALOCADO ||
            this.manutencaoCorretiva.idStatus === StatusManutencaoCorretivaEnum.MANUTENCAO ||
            this.manutencaoCorretiva.idStatus === StatusManutencaoCorretivaEnum.AG_FORNECEDOR ||
            this.manutencaoCorretiva.idStatus === StatusManutencaoCorretivaEnum.AG_MATERIAL){
              if(this.atualizarHorasComParalizacao()){
                this.atualizar();
              }else {
                return;
              }              
          }else{           
                
                  if((this.manutencaoCorretiva.idStatus === StatusManutencaoCorretivaEnum.AG_APROPRIACAO ||
                    this.manutencaoCorretiva.idStatus === StatusManutencaoCorretivaEnum.CONCLUIDA) &&
                    this.manutencaoCorretiva.horasComParalisacao === '000000'){               
                      this.atualizarHorasComParalizacao();
                      this.messagesService.addErrorMessage('Informe as Horas com paralisação.'); 
                    }else{
                      this.atualizarHorasComParalizacao();
                      this.atualizar();  
                    } 
                                        
          }
        }else{
          if(this.manutencaoCorretiva.idStatus === StatusManutencaoCorretivaEnum.ABERTA ||
            this.manutencaoCorretiva.idStatus === StatusManutencaoCorretivaEnum.RECURSO_ALOCADO ||
            this.manutencaoCorretiva.idStatus === StatusManutencaoCorretivaEnum.MANUTENCAO ||
            this.manutencaoCorretiva.idStatus === StatusManutencaoCorretivaEnum.AG_FORNECEDOR ||
            this.manutencaoCorretiva.idStatus === StatusManutencaoCorretivaEnum.AG_MATERIAL){
              this.atualizarHorasSemParalizacao();
              this.atualizar();              
          }else{
            this.atualizar();            
          }
        }        
      }
    }
  }

  public atualizarHorasSemParalizacao(){      
        
      const now = new Date(); // Data de hoje
          
      const dia = this.manutencaoCorretiva.dataCriacao.substring(0,2);
      const mes = this.manutencaoCorretiva.dataCriacao.substring(3,5);
      const ano = this.manutencaoCorretiva.dataCriacao.substring(6,10);
      const hora = this.manutencaoCorretiva.horaCriacao;
            
      const past = new Date(ano+'-'+ mes+'-'+dia+' '+hora); // Data abertura
      const diff1 = Math.abs(now.getTime() - past.getTime()); // Subtrai uma data pela outra

      const horas = Math.floor(diff1/(1000*60*60));    
      const segundos = Math.ceil(diff1/1000);        
      const minutos = Math.floor(segundos/60)%60;

      //this.manutencaoCorretiva.horasComParalisacao  = '0000:00';
      this.manutencaoCorretiva.horasSemParalisacao  = this.formatarHoras(horas, minutos);      
      this.manutencaoCorretiva.horasTotal  = this.formatarHoras(horas, minutos);    
  }

  public atualizarHorasComParalizacao(): boolean{
    console.log('entrou aqui 2!');
    console.log('status '+this.manutencaoCorretiva.idStatus);
    console.log('horas com '+this.manutencaoCorretiva.horasComParalisacao);
    let hoje = new Date();

    let diaCad = this.manutencaoCorretiva.dataCriacao.substring(0,2);
    let mesCad = this.manutencaoCorretiva.dataCriacao.substring(3,5);
    let anoCad = this.manutencaoCorretiva.dataCriacao.substring(6,10);
    let horaCad = this.manutencaoCorretiva.horaCriacao;

    let abertura = new Date(anoCad+'-'+ mesCad+'-'+diaCad+' '+horaCad);
    let df = Math.abs(hoje.getTime() - abertura.getTime());

    let horasTotal = Math.floor(df/(1000*60*60));    
    let segundosTotal = Math.ceil(df/1000);        
    let minutosTotal = Math.floor(segundosTotal/60)%60;      
    
    //horas total    
    this.manutencaoCorretiva.horasTotal = this.formatarHoras(horasTotal, minutosTotal);
    //horas com
    let hc = this.manutencaoCorretiva.horasComParalisacao.replace(':', '');    
    let horasCom = parseInt(hc.substring(0,4));
    let minutosCom = parseInt(hc.substring(4,6));

    let somaMinutosTotal = (horasTotal)*60 + minutosTotal;
    let somaMinutosCom = (horasCom)*60 + minutosCom; 
   
    if(somaMinutosCom>somaMinutosTotal){
      this.messagesService.addErrorMessage('As Horas com Paralisação não podem ultrapassar o Tempo Total da SMA.'); 
      return false;     
    }else{
      this.manutencaoCorretiva.horasComParalisacao = this.formatarHoras(horasCom, minutosCom);
      let dfSem = somaMinutosTotal - somaMinutosCom;
      let horasSem = Math.floor(dfSem/60);
      let minutosSem = dfSem%60;
    
      //horas sem
      this.manutencaoCorretiva.horasSemParalisacao = this.formatarHoras(horasSem, minutosSem);  
      return true; 
    }  
  }

  private salvarNova(): void {
    this.manutencaoCorretivaService.salvar(this.manutencaoCorretiva).subscribe(c => {
      this.download(c.idManutencao);
      this.manutencaoCorretivaService.enviarEmailCriacao(c).subscribe(c => {
      }, error => {
        this.messagesService.addErrorMessage(error);
      });

    }, error => {
      this.messagesService.addErrorMessage(error);
      return;
    });     
  }

  download(id: number) {
    this.modalConfirmacaoImprimir.showDialog().subscribe(success => {
      if (success) {
        this.manutencaoCorretivaService.buscarRelatorioCorretiva(id)
          .subscribe((blobResponse: Blob) => {
            var blob = new Blob([blobResponse], { type: 'application/pdf' });
            const blobUrl = URL.createObjectURL(blob);
            const iframe = document.createElement('iframe');
            iframe.style.display = 'none';
            iframe.src = blobUrl;
            document.body.appendChild(iframe);
            if (iframe.contentWindow) {
              iframe.contentWindow.print();
            } else {
              saveAs(blobResponse, 'Relatorio_manutencao_corretiva.pdf', false);
            }
            this.router.navigate(['app/manutencao/consultar-manutencao-corretiva']);
            this.messagesService.addSuccessMessage('Operação realizada com sucesso.');
          },
            (error) => {
              this.messagesService.addErrorMessage('Erro ao fazer download do arquivo.');
            });
      }
      this.router.navigate(['app/manutencao/consultar-manutencao-corretiva']);      
      this.messagesService.addSuccessMessage('Operação realizada com sucesso.');
    }, error => {
      this.messagesService.addErrorMessage(error);
    });
  }

  public buscarCentroCustoPorEquipamento(): void {
    this.historicoSituacaoEquipamentoService.buscarCentroCustoAtivoPorIdEquipamento(this.manutencaoCorretiva.idEquipamento)
      .subscribe((h: HistoricoSituacaoEquipamentoDTO) => {
        this.manutencaoCorretiva.codigoCentroCusto = h.codigoCentroCusto;
        this.manutencaoCorretiva.hierarquiaCentroCusto = h.hierarquiaCentroCusto;        
      });
  }

  abrirModalAssistenteProducao() {
    this.modalAssistenteProducao.showDialog().then((retorno) => {
      if (!retorno.error) {
        this.assistenteProducao = retorno.assistenteProducao;
        this.manutencaoCorretiva.nomeAssistenteProducao = this.assistenteProducao.nome;
        this.manutencaoCorretiva.matriculaAssistenteProducao = this.assistenteProducao.matricula;
        this.buscarFamiliasAssistenteProducao();
      }
    }).catch(erro => {

    });
  }

  private atualizar(): void {        
    this.manutencaoCorretivaService.atualizar(this.manutencaoCorretiva).subscribe(m => {      
      this.router.navigate(['/app/manutencao/editar-manutencao-corretiva/' + this.manutencaoCorretiva.idManutencao]);        
      this.messagesService.addSuccessMessage('Operação realizada com sucesso.');           
    }, error => {           
      if(this.manutencaoCorretiva.paralisacao){
        this.messagesService.addErrorMessage(error); 
      }else{
        this.messagesService.addErrorMessage(error); 
        this.manutencaoCorretivaService.buscarPorId(this.manutencaoCorretiva.idManutencao).subscribe(m => {
          this.manutencaoCorretiva = m;
        });
      }      
    });    
  }

  public buscarAssistenteProducao(): void {
    if (this.isMatriculaPreenchida()) {
      this.pessoaService.buscarSolicitantesManutencao(this.manutencaoCorretiva.matriculaAssistenteProducao)
        .subscribe((a: AssistenteProducao) => {
          if (isNullOrUndefined(a)) {
            this.manutencaoCorretiva.nomeAssistenteProducao = null;
            this.messagesService.addErrorMessage('Matrícula não encontrada.');
            return;
          }
          if (a.situacao.trim().length !== 0) {
            this.manutencaoCorretiva.nomeAssistenteProducao = null;
            this.messagesService.addErrorMessage('Usuário inativo, informe um usuário ativo.');
            return;
          }
          this.assistenteProducao = a;
          this.manutencaoCorretiva.nomeAssistenteProducao = a.nome;
          this.buscarFamiliasAssistenteProducao();
        });
    }
  }

  private isCamposValidos(): boolean {
    const camposNaoPreenchidos: string[] = this.isCamposPreenchido();
    if (camposNaoPreenchidos.length > 0) {
      this.mostrarMensagemCamposObrigatorios(camposNaoPreenchidos);
      return false;
    }
    return true;
  }

  private isMatriculaPreenchida(): boolean {
    if (isNullOrUndefined(this.manutencaoCorretiva.matriculaAssistenteProducao) ||
      this.manutencaoCorretiva.matriculaAssistenteProducao.trim().length === 0) {
      this.messagesService.addErrorMessage('Falta informação obrigatória. Por favor, informe a Matrícula.');
      return false;
    }
    return true;
  }

  public limpar(): void {
    this.manutencaoCorretiva = new ManutencaoCorretiva();
    this.assistenteProducao = new AssistenteProducao();
    this.isDesabilitarParalisacao = false;
  }

  public cancelar(): void {
    this.location.back();
  }

  public carregarStatus(): void {
    let idPerfil = this.auth.getIdPerfil(this.auth.authInfo.details.perfis);
    let matricula = this.auth.authInfo.details.matricula;    
    this.statusManutencaoService.buscarComboEditarManutencao(this.manutencaoCorretiva.idManutencao, idPerfil, matricula).subscribe(s => {
      this.listaStatus = s;      
      this.listaStatus = ArrayUtil.adicionarPrimeiroValor(this.listaStatus, 'Selecione', null);
    });
  }

  private isCamposPreenchido(): string[] {
    let camposNaoPreenchidos: string[] = [];
    if (isNullOrUndefined(this.manutencaoCorretiva.idEquipamento)) {
      camposNaoPreenchidos.push('Equipamento');
    }
    if (isNullOrUndefined(this.manutencaoCorretiva.codigoCentroCusto)) {
      camposNaoPreenchidos.push('Centro de Custo');
    }
    if (isNullOrUndefined(this.manutencaoCorretiva.numeroRamal)) {
      camposNaoPreenchidos.push('Ramal');
    }
    if (!this.isTelaAltera) {
      if ((isNullOrUndefined(this.manutencaoCorretiva.nomeAssistenteProducao) ||
        this.manutencaoCorretiva.nomeAssistenteProducao.trim().length === 0) ||
        (isNullOrUndefined(this.manutencaoCorretiva.matriculaAssistenteProducao) ||
          this.manutencaoCorretiva.matriculaAssistenteProducao.trim().length === 0)) {
        camposNaoPreenchidos.push('Assistente Produção');
      }
      if (isNullOrUndefined(this.manutencaoCorretiva.idFamilia) || this.manutencaoCorretiva.idFamilia == 0) {
        camposNaoPreenchidos.push('Família');
      }
    }

    if (isNullOrUndefined(this.manutencaoCorretiva.avaria) || this.manutencaoCorretiva.avaria.trim().length === 0) {
      camposNaoPreenchidos.push('Avaria ou Anormalidade');
    }

    if(this.manutencaoCorretiva.idStatus === StatusManutencaoCorretivaEnum.CANCELADA){
          if (isNullOrUndefined(this.manutencaoCorretiva.justificativa) || this.manutencaoCorretiva.justificativa.trim().length === 0) {
            camposNaoPreenchidos.push('Justificativa');
          }
    }    

    if (!isNullOrUndefined(this.manutencaoCorretiva.idManutencao) && isNullOrUndefined(this.manutencaoCorretiva.idStatus)) {
      camposNaoPreenchidos.push('Status');
    }

    if (isNullOrUndefined(this.manutencaoCorretiva.idSetor)) {
      camposNaoPreenchidos.push('Setor');
    }
    return camposNaoPreenchidos;
  }

  private buscarFamiliasAssistenteProducao(): void {
    this.familiaService.buscarPorCentroCustoAssistenteProducao(this.assistenteProducao.centroCusto).subscribe(f => {
      this.familiaOpcoes = f;      
      if (this.familiaOpcoes.length == 1) {
        this.manutencaoCorretiva.idFamilia = this.familiaOpcoes[0].value;
        this.buscarSetoresPorFamilia();
      } else {
        this.familiaOpcoes = ArrayUtil.adicionarPrimeiroValor(this.familiaOpcoes, 'Selecione', null);
      }
    });
  }

  private buscarSetoresPorFamilia(): void {
    this.setorService.buscarPorIdFamilia(this.manutencaoCorretiva.idFamilia).subscribe(s => {
      this.setorOpcoes = s;      
      this.setorOpcoes = ArrayUtil.adicionarPrimeiroValor(this.setorOpcoes, 'Selecione', null);
    });
  }

  private buscarSetores(): void {
    this.setorService.buscarTodos().subscribe(s => {
      this.setorOpcoes = s;
    });
  }  

  private formatarHoras(hora: number, minuto: number): string {
    if (!isNullOrUndefined(hora)) {
      if (!isNullOrUndefined(minuto)) {
        if (hora > 999) {
          return minuto > 9 ? `${hora}${minuto}` : `${hora}0${minuto}`;
        }
        if (hora > 99) {
          return minuto > 9 ? `0${hora}${minuto}` : `0${hora}0${minuto}`;
        }
        if (hora < 10) {
          return minuto > 9 ? `000${hora}${minuto}` : `000${hora}0${minuto}`;
        }
        return minuto > 9 ? `00${hora}${minuto}` : `00${hora}0${minuto}`;
      } else {               
        return hora > 99 ? `0${hora}00` : hora < 10 ? `000${hora}00` : `00${hora}00`;
      }
    } else {
      if (!isNullOrUndefined(minuto)) {
        return minuto > 9 ? `${minuto}` : `0${minuto}`;
      } else {
        return '000000';
      }
    }
  }

  public validarMaskHorasEPrencherCamposAutomaticamente() {
    if (!isNullOrUndefined(this.manutencaoCorretiva.horasTotal)) {      
        let horasS: number;
        let minutosS = parseInt(this.manutencaoCorretiva.horasTotal.substr(3, 5)) + (60*parseInt(this.manutencaoCorretiva.horasTotal.substr(0, 3)));
      
        if (minutosS > 59) {
          horasS = Math.floor(minutosS / 60);
          minutosS = minutosS % 60;
        }
  
        this.manutencaoCorretiva.horasTotal = this.formatarHoras(horasS, minutosS);
      }    
  }  
  
  public verificarStatusJustificativa():void{    
    if(this.manutencaoCorretiva.idStatus === StatusManutencaoCorretivaEnum.CANCELADA
        || this.manutencaoCorretiva.justificativa !== null){
      this.isCancelada = true;
      this.isReprovada = true;
      this.isJustificativaDiferenteNull = true;
    }else{
      this.isCancelada = false;
      this.isReprovada = false;
      this.isJustificativaDiferenteNull = false;
    }
  }  

  public verificarStatusConcluida():void{    
    if(this.manutencaoCorretiva.idStatus === StatusManutencaoCorretivaEnum.CONCLUIDA){
      this.isConcluida = true;
    }else{
      this.isConcluida = false;
    }
  }

  public verificarStatusCancelada():void{    
    if(this.manutencaoCorretiva.idStatus === StatusManutencaoCorretivaEnum.CANCELADA){
      this.isCancelada = true;
    }else{
      this.isCancelada = false;
    }
  }

  public verificarJustificativaDiferenteNull():void{    
    if(this.manutencaoCorretiva.justificativa !== null){
      this.isJustificativaDiferenteNull = true;
    }else{
      this.isJustificativaDiferenteNull = false;
    }
  }

  private desabilitarCamposEditar(): void {
    if (this.manutencaoCorretiva.idStatus === StatusManutencaoCorretivaEnum.AG_APROPRIACAO ||
      this.manutencaoCorretiva.idStatus === StatusManutencaoCorretivaEnum.CANCELADA ||
      this.manutencaoCorretiva.idStatus === StatusManutencaoCorretivaEnum.CONCLUIDA) {
      this.isDesabilitarCamposEditar = true;
      return;
    }
  }

}