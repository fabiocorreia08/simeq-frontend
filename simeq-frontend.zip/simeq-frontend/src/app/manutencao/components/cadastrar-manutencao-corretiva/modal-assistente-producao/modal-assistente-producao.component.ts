import { isNullOrUndefined } from 'util';

import { Subject } from 'rxjs/Subject';
import { Component, OnInit, Input } from '@angular/core';
import { NgForm } from '@angular/forms';
import { MessagesService } from '../../../../core/messages/messages.service';
import { AdministracaoGenericComponent } from '../../../../administracao/administracao-generic.component';
import { AssistenteProducaoFiltro } from '../../../models/assistente-producao-filtro.model';
import { Pagina } from '../../../../core/models/pagina.model';
import { AssistenteProducao } from '../../../../shared/models/assistente-producao.model';
import { PessoaService } from '../../../../shared/services/pessoa.service';
import { LazyLoadEvent } from 'primeng/primeng';


declare var $:any;

@Component({
  selector: 'simeq-modal-assistente-producao',
  templateUrl: './modal-assistente-producao.component.html',
  styleUrls: ['./modal-assistente-producao.component.scss'] 
})
export class ModalAssistenteProducaoComponent extends AdministracaoGenericComponent implements OnInit {

  @Input('id') modalId: string;

  @Input('tituloAssistente') tituloAssistente: string;

  @Input('isEdicao') isEdicao: boolean;

  public paginaAssistenteProducao: Pagina<AssistenteProducao> = new Pagina<AssistenteProducao>();
  public assistenteSelecionado: AssistenteProducao = new AssistenteProducao();
  public assistenteProducaoFiltro: AssistenteProducaoFiltro = new AssistenteProducaoFiltro();
  private _eventBus: Subject<ModalAssistenteProducaoEvent> = new Subject<ModalAssistenteProducaoEvent>();
  public buscaHabilitada: boolean = false;
  
  modal: any;

  constructor(messagesService: MessagesService,
    private pessoaService: PessoaService, ) {
      super(messagesService);
  }

  ngOnInit() {
  }

  showDialog(): Promise<ModalAssistenteProducaoEvent> {
    this.modal = $('#id-' + this.modalId).modal('show');
       return new Promise<ModalAssistenteProducaoEvent> ((resolve, reject) => {
       return this._eventBus.asObservable().subscribe(message => {
         if (message.success) {
           resolve(message);
         } else {
           reject(message);
         }
      });
    });
  }

  public pesquisar(): void {    
    this.buscaHabilitada = true;
    this.paginaAssistenteProducao = new Pagina();
    if(this.assistenteProducaoFiltro.matricula.length >0){
      this.assistenteProducaoFiltro.nome = "";
    }   
    this.filtrar();
  }

  public filtrar(): void {
    this.pessoaService.buscarAssistentesProducao(this.assistenteProducaoFiltro, this.paginaAssistenteProducao)
      .subscribe((pagina) => {
        this.paginaAssistenteProducao = pagina;
      },
      (error) => {

      });
    }

  cancelClick() {
    this.assistenteSelecionado = new AssistenteProducao();  
    this.assistenteProducaoFiltro = new AssistenteProducaoFiltro();
    this.paginaAssistenteProducao = new Pagina();
    this._eventBus.next({ error: true });
    this.modal.modal('hide');
  }

  public paginarAssistenteProducao(event: LazyLoadEvent): void {
    if (this.buscaHabilitada) {
      this.paginaAssistenteProducao = new Pagina<AssistenteProducao>(event.first, event.rows);
      this.filtrar();
    }
  }

  public limpar(): void {
    this.buscaHabilitada = false;
    this.assistenteSelecionado = new AssistenteProducao();    
    this.paginaAssistenteProducao = new Pagina();
    this.assistenteProducaoFiltro = new AssistenteProducaoFiltro();
  }

  adicionar() { 
    if(isNullOrUndefined(this.assistenteSelecionado.matricula)){
      this.messagesService.addErrorMessage('Falta informação obrigatória. Por favor, informe o Solicitante.');   
    }else{
      this._eventBus.next({ success: true, assistenteProducao: this.assistenteSelecionado });
      this.limpar();
      this.modal.modal('hide');   
    }     
  }
  
 }


export class ModalAssistenteProducaoEvent {
  error?: boolean;
  success?: boolean;
  assistenteProducao?: any;
}
