import { BreadcrumbService } from './../../../core/breadcrumb/breadcrumb.service';
import { ManutencaoCorretivaService } from './../../services/manutencao-corretiva.service';
import { ActivatedRoute } from '@angular/router';
import { MessagesService } from './../../../core/messages/messages.service';
import { LazyLoadEvent } from 'primeng/components/common/api';
import { Pagina } from './../../../core/models/pagina.model';
import { Component, OnInit } from '@angular/core';
import { AlocacaoDetalhar } from '../../models/alocacao-detalhar.model';
import { AlocacaoDetalharFiltro } from '../../models/alocacao-detalhar-filtro.model';
import { ManutencaoCorretiva } from '../../models/manutencao-corretiva.model';
import { AlocacaoService } from '../../../alocacao/services/alocacao.service';
import { Location } from '@angular/common';
import { ManutencaoPreventivaService } from '../../services/manutencao-preventiva.service';

@Component({
  selector: 'simeq-detalhar-alocacao',
  templateUrl: './detalhar-alocacao.component.html',
  styleUrls: ['./detalhar-alocacao.component.scss']
})
export class DetalharAlocacaoComponent implements OnInit {

  public pagina: Pagina<AlocacaoDetalhar> = new Pagina<AlocacaoDetalhar>();
  public filtro: AlocacaoDetalharFiltro = new AlocacaoDetalharFiltro();
  public numeroSolicitacao: string;
  public isCorretiva : boolean;

  constructor(private alocacaoService: AlocacaoService,
    private messagesService: MessagesService,
    private manutencaoCorretivaService: ManutencaoCorretivaService,
    private manutencaoPreventivaService: ManutencaoPreventivaService,
    private route: ActivatedRoute,
    private location: Location,
    private breadcrumbService: BreadcrumbService,) {
    }

  ngOnInit() {
    this.isCorretiva = this.route.snapshot.data['isCorretiva'];
    this.filtro.idManutencao = this.route.snapshot.params['idManutencao'];
    if(this.isCorretiva === true){
      this.breadcrumbService.addRoute('/app/manutencao/consultar-manutencao-corretiva', 'Corretivas', true);
      this.breadcrumbService.addRoute('/app/manutencao/corretiva/detalhar-alocacao/' + this.filtro.idManutencao, 'Alocações', false);
      this.breadcrumbService.addRoute('/app/manutencao/detalhar-manutencao-corretiva/' + this.filtro.idManutencao, 'Detalhar', true);
      this.buscarManutencaoCorretiva();
    } else {
      this.breadcrumbService.addRoute('/app/manutencao/preventiva/consultar', 'Preventivas', true);
      this.breadcrumbService.addRoute('/app/manutencao/preventiva/detalhar-alocacao/' + this.filtro.idManutencao, 'Alocações', false);
      this.breadcrumbService.addRoute('/app/manutencao/preventiva/detalhar/' + this.filtro.idManutencao, 'Detalhar', true);
      this.buscarManutencaoPreventiva();
    }

    this.pesquisar();
  }

  public pesquisar(): void {
    this.pagina = new Pagina();
    this.filtrar();
  }

  private buscarManutencaoCorretiva(): void {
    this.manutencaoCorretivaService.buscarPorId(this.filtro.idManutencao).subscribe(m => {
      this.numeroSolicitacao = m.numeroSolicitacao;
    });
  }

  private buscarManutencaoPreventiva(): void {
    this.manutencaoPreventivaService.buscarPorId(this.filtro.idManutencao).subscribe(m => {
      this.numeroSolicitacao = m.numeroSolicitacao;
    });
  }

  public paginar(event: LazyLoadEvent): void {
    this.pagina = new Pagina<AlocacaoDetalhar>(event.first, event.rows);
    this.filtrar();
  }

  public filtrar(): void {
    if(this.isCorretiva){      
      this.alocacaoService.buscarAlocacaoManutencaoCorretiva(this.filtro, this.pagina)
      .subscribe((pagina) => {
        this.pagina = pagina;
      },
      (error) => {
        this.messagesService.addErrorMessage(error);
      });
    } else {          
      this.alocacaoService.buscarAlocacaoManutencaoPreventiva(this.filtro, this.pagina)
      .subscribe((pagina) => {
        this.pagina = pagina;
      },
      (error) => {
        this.messagesService.addErrorMessage(error);
      });
    }
    
  }

  public voltar(): void {
    this.location.back();
  }

}
