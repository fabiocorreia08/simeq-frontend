import { BreadcrumbService } from './../../../core/breadcrumb/breadcrumb.service';
import { ActivatedRoute } from '@angular/router';
import { MessagesService } from './../../../core/messages/messages.service';
import { LazyLoadEvent } from 'primeng/components/common/api';
import { Pagina } from './../../../core/models/pagina.model';
import { HistoricoStatusManutencaoFiltro } from './../../models/historico-status-filtro.model';
import { StatusManutencaoCorretivaService } from './../../services/status-manutencao.service';
import { Component, OnInit } from '@angular/core';
import { HistoricoStatusManutencao } from '../../models/historico-status-manutencao.model';
import { Location } from '@angular/common';

@Component({
  selector: 'simeq-detalhar-manutencao-corretiva-status',
  templateUrl: './detalhar-manutencao-corretiva-status.component.html',
  styleUrls: ['./detalhar-manutencao-corretiva-status.component.scss']
})
export class DetalharManutencaoCorretivaStatusComponent implements OnInit {

  public pagina: Pagina<HistoricoStatusManutencao> = new Pagina<HistoricoStatusManutencao>();
  public filtro: HistoricoStatusManutencaoFiltro = new HistoricoStatusManutencaoFiltro();
  public numeroSolicitacao: string;

  constructor(private statusManutencaoService: StatusManutencaoCorretivaService,
    private messagesService: MessagesService,
    private route: ActivatedRoute,
    private location: Location,
    private breadcrumbService: BreadcrumbService,) {
      breadcrumbService.addRoute('/app/manutencao/consultar-manutencao-corretiva', 'Corretivas', true);
     }

  ngOnInit() {
    this.filtro.idManutencao = this.route.snapshot.params['idManutencao'];
    this.numeroSolicitacao = this.route.snapshot.params['numeroSolicitacao'];
    this.breadcrumbService.addRoute('/app/manutencao/detalhar-manutencao-corretiva-status/' + this.filtro.idManutencao, 'Listar Status', false);
    this.pesquisar();
  }

  public pesquisar(): void {
    this.pagina = new Pagina();
    this.filtrar();
  }

  public paginar(event: LazyLoadEvent): void {
    this.pagina = new Pagina<HistoricoStatusManutencao>(event.first, event.rows);
    this.filtrar();
  }

  public filtrar(): void {
    this.statusManutencaoService.filtrar(this.filtro, this.pagina)
      .subscribe((pagina) => {
        this.pagina = pagina;
      },
      (error) => {
        this.messagesService.addErrorMessage(error);
      });
  }

  public voltar(): void {
    this.location.back();
  }

}
