import { PerfisConstants } from './../../../core/security/perfis.constants';
import { AuthenticationService } from './../../../core/security/auth.service';
import { ManutencaoCorretivaConsulta } from './../../models/manutencao-consulta.model';
import { MessagesService } from './../../../core/messages/messages.service';
import { ManutencaoCorretivaService } from './../../services/manutencao-corretiva.service';
import { StatusManutencaoCorretivaService } from './../../services/status-manutencao.service';
import { LazyLoadEvent } from 'primeng/components/common/api';
import { ArrayUtil } from './../../../shared/Utils/ArrayUtil';
import { LabelValue } from './../../../core/models/label-value';
import { Pagina } from './../../../core/models/pagina.model';
import { BreadcrumbService } from './../../../core/breadcrumb/breadcrumb.service';
import { CalendarLocaleService } from './../../../core/calendar.locale.service';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { ManutencaoCorretivaFiltro } from '../../models/manutencao-filtro.model';
import { EquipamentoService } from '../../../administracao/equipamento/services/equipamento.service';
import { GrupoService } from '../../../administracao/grupo-subgrupo/services/grupo.service';
import { CentroCustoService } from '../../../shared/services/centro-custo.service';
import { isNullOrUndefined, error } from 'util';
import { StatusManutencaoCorretivaEnum } from '../../enums/status-manutencao-corretiva.enum';
import { SituacaoEquipamento } from '../../enums/situacao-equipamento.enum';
import { timer } from 'rxjs/observable/timer';
import { Subscription } from 'rxjs';
import { ActivatedRoute, Router } from '@angular/router';
import { Location } from '@angular/common';

declare var saveAs: any;

@Component({
  selector: 'simeq-consultar-manutencao-corretiva',
  templateUrl: './consultar-manutencao-corretiva.component.html',
  styleUrls: ['./consultar-manutencao-corretiva.component.scss']
})
export class ConsultarManutencaoCorretivaComponent implements OnInit, OnDestroy {

  public pagina: Pagina<ManutencaoCorretivaConsulta> = new Pagina<ManutencaoCorretivaConsulta>();
  public filtro: ManutencaoCorretivaFiltro = new ManutencaoCorretivaFiltro();  
  public listaStatus: LabelValue[] = [];
  public listaCentroCusto: LabelValue[] = [];
  public listaSolicitante: LabelValue[] = [];
  public listaEquipamento: LabelValue[] = [];
  public listaGrupo: LabelValue[] = [];
  public listaClasseManutencao: LabelValue[] = [];
  public listaSituacaoEquipamento: LabelValue[] = [];
  public desabilitarGrupo = true;
  public readonly TECNICO: number = 2;
  public readonly SOLICITANTE: number = 3;
  public readonly VISITANTE: number = 6;
  public desabilitarBotoesVisitante = false;
  public isPerfilTecnico = false;
  public isPerfilSolicitante = false;  
  public isPerfilVisitante = false;
  private subscribeRefresh: Subscription;
  tempoRefreshMin;    

  public setor: String = null;

  constructor(public calendarLocaleService: CalendarLocaleService,
    breadcrumbService: BreadcrumbService,
    private location: Location,
    private equipamentoService: EquipamentoService,
    private grupoService: GrupoService,
    private statusManutencaoService: StatusManutencaoCorretivaService,
    private centroCustoService: CentroCustoService,
    private manutencaoCorretivaService: ManutencaoCorretivaService,
    private messagesService: MessagesService,
    private route: ActivatedRoute,
    private router: Router,
    public auth: AuthenticationService) {
    breadcrumbService.addRoute('/app/manutencao', 'Corretivas', false);
    breadcrumbService.addRoute('/app/manutencao/consultar-manutencao-corretiva', 'Consultar', false);
    this.listaStatus = this.route.snapshot.data['statusCorretivaResolve'];
  }

  ngOnInit() {    
    this.isPerfilTecnico = this.auth.getPerfil(this.TECNICO);
    this.isPerfilSolicitante = this.auth.getPerfil(this.SOLICITANTE); 
    this.isPerfilVisitante = this.auth.getPerfil(this.VISITANTE); 
    this.desabilitarBotoesVisitante = this.getPerfil(this.VISITANTE);   
    this.carregarEquipamentos();
    this.carregarCentroCusto();    
    this.buscarTempoRefreshParametrizado();
    this.carregarDadosDashboard();
    this.carregarClasses();
    this.carregarSituacaoEquipamentos();    
  }

  carregarDadosDashboard() {    
    if (this.route.snapshot.data['isDashboard']) {
      this.filtro.idsStatus = [];
      if (this.listaStatus.filter(item => (item.value === parseInt(this.route.snapshot.params['idStatus']))).length > 0) {
        this.filtro.idsStatus.push(parseInt(this.route.snapshot.params['idStatus']));
        this.pesquisar();
      }
    }
  } 

  ngOnDestroy(): void {
    if (this.subscribeRefresh) {
      this.subscribeRefresh.unsubscribe();
    }    
  }

  validarBotaoAlocar() {
    return (!this.isPerfilSolicitante);
  }

  cadastrarAtividade(codicoSolicitacao, idManutencao) {
    this.router.navigate([`/app/manutencao/atividade/cadastrar-atividade/${idManutencao}/${codicoSolicitacao}`]);
  }

  public buscarTempoRefreshParametrizado() {    
    this.manutencaoCorretivaService.buscarTempoRefreshParametrizado()
      .subscribe(t => {
        this.tempoRefreshMin = t;
        this.refreshPagina();
      });
  }

  public carregarEquipamentos(): void {    
    this.equipamentoService.buscarTodosLabelValue().subscribe(e => {
      this.listaEquipamento = e;
      this.listaEquipamento = ArrayUtil.adicionarPrimeiroValor(this.listaEquipamento, 'Selecione', null);
    });
  }

  public carregarCentroCusto(): void {    
    this.centroCustoService.buscarTodos()
    .subscribe(c => {
      this.listaCentroCusto = c;
    });     
  }

  public validaSituacaoEquipamento(manuntecao: ManutencaoCorretivaConsulta): number {
    if (!manuntecao.paralisacao ||
      (manuntecao.paralisacao && manuntecao.idStatus == StatusManutencaoCorretivaEnum.CONCLUIDA) ||
      (manuntecao.paralisacao && manuntecao.idStatus == StatusManutencaoCorretivaEnum.CANCELADA))
      return SituacaoEquipamento.VERDE;
    else if (manuntecao.paralisacao && manuntecao.idStatus == StatusManutencaoCorretivaEnum.ABERTA)
      return SituacaoEquipamento.VERMELHO;
    else if ((manuntecao.paralisacao && manuntecao.idStatus != StatusManutencaoCorretivaEnum.ABERTA) &&
      (manuntecao.idStatus != StatusManutencaoCorretivaEnum.CONCLUIDA))
      return SituacaoEquipamento.AMARELO;
  }

  public onChangeGrupo(): void {
    if (this.filtro.idEquipamento != null) {
      this.desabilitarGrupo = false;
      this.grupoService.buscarGruposPorEquipamento(this.filtro.idEquipamento).subscribe(g => {
        this.listaGrupo = g;
        this.listaGrupo = ArrayUtil.adicionarPrimeiroValor(this.listaGrupo, 'Selecione', null);
      });
      return;
    }
    this.listaGrupo = [];
    this.desabilitarGrupo = true;
  }

  public limparFiltros(): void {
    this.pagina = new Pagina();
    this.filtro = new ManutencaoCorretivaFiltro();
  }

  public pesquisar(): void {    
    this.pagina = new Pagina();    
    this.filtrar();
  }

  public pesquisarPorSetor(s: string): void {    
    this.filtro.setor = s; 
    this.pagina = new Pagina();      
    this.filtrar();
  }

  public paginar(event: LazyLoadEvent): void {
    this.pagina = new Pagina<ManutencaoCorretivaConsulta>(event.first, event.rows);
    this.filtrar();
  }

  private refreshPagina(): void {
    if (isNullOrUndefined(this.pagina.registros) || this.pagina.registros.length === 0) {
      this.pagina = new Pagina<ManutencaoCorretivaConsulta>(0, 10);
    }
    const tempoRefreshSeg = this.tempoRefreshMin * 60000;
    const source = timer(tempoRefreshSeg, tempoRefreshSeg);
    this.subscribeRefresh = source.subscribe(val => this.filtrar());
  }

  public filtrar(): void {    
    
    this.filtro.matricula = this.auth.authInfo.username;
    this.filtro.perfil = this.auth.getIdPerfil(this.auth.authInfo.details.perfis);
    this.filtro.numeroSolicitacao = !isNullOrUndefined(this.filtro.numeroSolicitacao) ? this.filtro.numeroSolicitacao.toLocaleUpperCase() : undefined;
    this.filtro.solicitante = !isNullOrUndefined(this.filtro.solicitante) ? this.filtro.solicitante.toLocaleUpperCase() : undefined;
    this.filtro.avaria = !isNullOrUndefined(this.filtro.avaria) ? this.filtro.avaria.toLocaleUpperCase() : undefined;
    if (!isNullOrUndefined(this.filtro.centroCustos)) {
      if (this.filtro.centroCustos.length <= 0) {
        this.filtro.centroCustos = null;
      }
    }
    if (this.isDatasFiltroValida()) {
      let primeiroRegistro = this.pagina.primeiroRegistro;
      let tamanho = this.pagina.tamanho;
      this.pagina = new Pagina<ManutencaoCorretivaConsulta>();
      this.pagina.primeiroRegistro = primeiroRegistro;
      this.pagina.tamanho = tamanho;
      
      if (!isNullOrUndefined(this.filtro.centroCustos)) {
        if (this.filtro.centroCustos.length <= 0) {
          this.filtro.centroCustos = null;
        }
      }      

      this.manutencaoCorretivaService.filtrar(this.filtro, this.pagina)
        .subscribe((pagina) => {                                
          this.pagina = pagina;
        },
          (error) => {
            this.messagesService.addErrorMessage(error);
          });
    }
  }

  private isDatasFiltroValida(): boolean {
    if (!isNullOrUndefined(this.filtro.periodoInicio) && !isNullOrUndefined(this.filtro.periodoFim)) {
      if (this.filtro.periodoFim < this.filtro.periodoInicio) {
        this.messagesService.addErrorMessage('Data inválida. A data final deve ser maior que a data inicial.');
        return false;
      }
    }
    return true;
  }

  public getPerfil(perfil: number): boolean {
    let isPerfil = false;
    this.auth.authInfo.details.perfis.forEach(p => {
      if (p.id_perfil === perfil) {
        isPerfil = true;
      }
    });
    return isPerfil;
  }

  download(id: number) {
    this.manutencaoCorretivaService.buscarRelatorioCorretiva(id)
      .subscribe((blobResponse: Blob) => {
        var blob = new Blob([blobResponse], { type: 'application/pdf' });
        const blobUrl = URL.createObjectURL(blob);
        const iframe = document.createElement('iframe');
        iframe.style.display = 'none';
        iframe.src = blobUrl;
        document.body.appendChild(iframe);
        if (iframe.contentWindow) {
          iframe.contentWindow.print();
        } else {
          saveAs(blobResponse, 'Relatorio_manutencao_corretiva.pdf', false);
        }
      },
        (error) => {
          this.messagesService.addErrorMessage('Erro ao fazer download do arquivo.');
        });
  }

  isDesabilitarImprimir(manutencao: ManutencaoCorretivaConsulta): boolean {
    if (//manutencao.idStatus === StatusManutencaoCorretivaEnum.CANCELADA ||
      manutencao.idStatus === StatusManutencaoCorretivaEnum.AG_MATERIAL) {
      return true;
    }
    return false;
  }

  isDesabilitarEditar(manutencao: ManutencaoCorretivaConsulta): boolean {
    if (this.isPerfilSolicitante && 
          manutencao.idStatus !== StatusManutencaoCorretivaEnum.ABERTA
      ) {
        return true;
    }
    return false;
  }

  exibirAvaria(numeroSolicitacao): void{        
    this.manutencaoCorretivaService.buscarAvariaPorNumeroSolicitacao(numeroSolicitacao).subscribe(m => {         
      this.filtro.avaria = m.avaria;   
    });    
  }  

  fecharModalAvaria(){        
    this.filtro.avaria = null;   
  }

  fecharModalLegenda(){        
    this.filtro.avaria = null;   
  }

  public carregarClasses(): void {    
    this.manutencaoCorretivaService.buscarClassesManutencao().subscribe(c => {      
      this.listaClasseManutencao = c;      
      this.listaClasseManutencao = ArrayUtil.adicionarPrimeiroValor(this.listaClasseManutencao, 'Selecione', null);
    });
  }

  public carregarSituacaoEquipamentos(): void {      
    this.listaSituacaoEquipamento = this.manutencaoCorretivaService.buscarSituacoesEquipamentos();
    this.listaSituacaoEquipamento = ArrayUtil.adicionarPrimeiroValor(this.listaSituacaoEquipamento, 'Selecione', null);    
  } 

}