import { isNullOrUndefined } from 'util';
import { ManutencaoCorretiva } from './../../models/manutencao-corretiva.model';
import { ManutencaoCorretivaService } from './../../services/manutencao-corretiva.service';
import { AdministracaoGenericComponent } from './../../../administracao/administracao-generic.component';
import { Component, OnInit } from '@angular/core';
import { MessagesService } from '../../../core/messages/messages.service';
import { BreadcrumbService } from '../../../core/breadcrumb/breadcrumb.service';
import { Informacao } from '../../models/informacao.model';
import { AuthenticationService } from '../../../core/security/auth.service';
import { User } from '../../../core/security/User';
import { InformacaoService } from '../../services/informacao.service';
import { Router, ActivatedRoute } from '@angular/router';
import { PessoaService } from '../../../shared/services/pessoa.service';
import { AssistenteProducao } from '../../../shared/models/assistente-producao.model';
import { Manutencao } from '../../models/manutencao.model';

@Component({
    selector: 'simeq-cadastrar-informacao',
    templateUrl: 'cadastrar-informacao.component.html',
    styleUrls: ['cadastrar-informacao.component.scss']
})

export class CadastrarInformacaoComponent extends AdministracaoGenericComponent implements OnInit {

    public manutencao: Manutencao = new Manutencao();
    public informacao: Informacao = new Informacao();
    public assitenteProducao = new AssistenteProducao();
    
    constructor(messagesService: MessagesService,
                private breadcrumbService: BreadcrumbService,
                private manutencaoCorretivaService: ManutencaoCorretivaService,
                private router: Router,
                private route: ActivatedRoute,
                public pessoaService: PessoaService,
                private informacaoService: InformacaoService,
                public auth: AuthenticationService) {
        super(messagesService);
        this.breadcrumbService.addRoute('/app/manutencao/atividade/consultar-atividade', 'Informações', true);
        this.breadcrumbService.addRoute('/app/manutencao/cadastrar-informacao', 'Cadastrar', false);
    }

    ngOnInit() { 
        this.recuperarUsuarioLogado();
        this.recuperarNumeroSolicitacaoURL();
    }

    public recuperarManutencao(){
        if(this.numeroSolicitacaoPreenchido()){
            this.informacao.numeroSolicitacao = this.informacao.numeroSolicitacao.toLocaleUpperCase();
            this.manutencaoCorretivaService.buscarPorPerfil(this.informacao.perfil, this.informacao.matriculaUsuarioLogado, this.informacao.numeroSolicitacao)
            .subscribe(manutencao => {
                if(!manutencao){
                    this.messagesService.addErrorMessage("Este Nº de Solicitação não existe.");
                }
                this.manutencao = manutencao;
                this.copiarDadosSolicitacao();
            },
            error => {
                this.manutencao = null;
                this.informacao.idManutencao = null;
                this.informacao.classeManutencao = null;
                this.messagesService.addErrorMessage(error);
            });
        }  
    }

    private recuperarUsuarioLogado(){
        this.informacao.matriculaUsuarioLogado = this.auth.authInfo.username;
        this.informacao.perfil = this.auth.getIdPerfil(this.auth.authInfo.details.perfis);

        this.pessoaService.buscarSolicitantesManutencao(this.informacao.matriculaUsuarioLogado)
            .subscribe((a: AssistenteProducao) => {
                if (isNullOrUndefined(a)) {
                this.assitenteProducao = new AssistenteProducao();
                this.messagesService.addErrorMessage('Matrícula não encontrada.');
                return;
                }
                if (a.situacao.length !== 0) {
                this.assitenteProducao = new AssistenteProducao();
                this.messagesService.addErrorMessage('Usuário inativo, informe um usuário ativo.');
                return;
                }
                this.assitenteProducao = a;
                this.informacao.nomeUsuarioLogado = a.nome;
            });
    }

    private numeroSolicitacaoPreenchido(){
        if(isNullOrUndefined(this.informacao.numeroSolicitacao) || 
        this.informacao.numeroSolicitacao.trim() == ""){
            this.messagesService.addErrorMessage("Informe o número da solicitação.");
            return false;
        }
        return true;
    }

    private copiarDadosSolicitacao(){
        if(this.manutencao){
            this.informacao.idManutencao = this.manutencao.idManutencao;
            this.informacao.idStatus = this.manutencao.idStatus;
            this.informacao.classeManutencao = this.manutencao.classeManutencao;
        }else{
            this.informacao.idManutencao = null;
            this.informacao.idStatus = null;
            this.informacao.classeManutencao = null;
        }
    }

    public salvar(){
        if(this.isCamposValidos()){
            this.informacao.descricaoInformacao = this.informacao.descricaoInformacao.toLocaleUpperCase();
            this.informacaoService.salvar(this.informacao).subscribe(informacao =>{ 
                this.router.navigate(['app/manutencao/informacao/cadastrar-informacao', this.manutencao.numeroSolicitacao]);
                this.messagesService.addSuccessMessage('Operação realizada com sucesso.');
            },
            error => {
                this.messagesService.addErrorMessage(error);
            });
        }
    }

    public limpar(){
        this.informacao.classeManutencao = null;
        this.informacao.descricaoInformacao = null;
        this.informacao.idManutencao = null;
        this.informacao.idStatus = null;
        this.informacao.numeroSolicitacao = null;
    }

    private  isCamposValidos(): boolean {
        const camposNaoPreenchidos: string[] = this.isCamposPreenchido();
        if (camposNaoPreenchidos.length > 0) {
          this.mostrarMensagemCamposObrigatorios(camposNaoPreenchidos);
          return false;
        }
        return true;
      }

    private isCamposPreenchido(): string[] {
        let camposNaoPreenchidos: string[] = [];

        if (isNullOrUndefined(this.informacao.numeroSolicitacao) || this.informacao.numeroSolicitacao.trim() == "") {
            camposNaoPreenchidos.push('Nº Solicitação');
        }
        if (isNullOrUndefined(this.informacao.classeManutencao)) {
            camposNaoPreenchidos.push('Classe da Manutenção');
        }
        if (isNullOrUndefined(this.informacao.matriculaUsuarioLogado) || this.informacao.matriculaUsuarioLogado.trim() == "") {
            camposNaoPreenchidos.push('Nº de Matrícula');
        }
        if (isNullOrUndefined(this.informacao.nomeUsuarioLogado) || this.informacao.nomeUsuarioLogado.trim() == "") {
            camposNaoPreenchidos.push('Colaborador');
        }
        if (isNullOrUndefined(this.informacao.descricaoInformacao) || this.informacao.descricaoInformacao.trim() == "") {
            camposNaoPreenchidos.push('Informação');
        }
        return camposNaoPreenchidos;
    }

    private recuperarNumeroSolicitacaoURL(){
        let codigo = this.route.snapshot.paramMap.get('codigo');
        if(!isNullOrUndefined(codigo) && codigo !== ''){
            this.informacao.numeroSolicitacao = codigo;
            this.recuperarManutencao();
        }
    }

    public cancelar(){
        let codigo = this.route.snapshot.paramMap.get('codigo');
        this.router.navigate(['app/manutencao/informacao/consultar-informacao', !isNullOrUndefined(codigo) ? codigo : '']);
    }
}