import { Resolve, ActivatedRouteSnapshot } from '@angular/router';
import { Injectable } from '@angular/core';

import { StatusManutencaoCorretivaService } from '../services/status-manutencao.service';
import { LabelValue } from '../../core/models/label-value';
import { StatusPreventivaService } from '../services/status-preventiva.service';

@Injectable()
export class StatusPreventivaResolve implements Resolve<LabelValue[]> {

  constructor(private statusPrevService: StatusPreventivaService) {}

  resolve(route: ActivatedRouteSnapshot) {
    return this.statusPrevService.buscarTodosLabelValue();
  }

}
