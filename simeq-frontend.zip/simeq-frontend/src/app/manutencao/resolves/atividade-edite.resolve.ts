import { Injectable } from '@angular/core';
import { AtividadeService } from './../services/atividade.service';
import { Resolve, ActivatedRouteSnapshot } from '@angular/router';
import { AtividadeDetalhar } from '../models/atividade-detalhar.model';
import { AtividadeEditar } from '../models/atividade-editar.model';

@Injectable()
export class AtividadeEditeResolve implements Resolve<AtividadeEditar> {

  constructor(private atividadeService: AtividadeService){}

    resolve(route: ActivatedRouteSnapshot) {
      return this.atividadeService.buscarAtividadeEdite(route.params['idAtividade'], route.params['numeroSolicitacao']);
    }
}
