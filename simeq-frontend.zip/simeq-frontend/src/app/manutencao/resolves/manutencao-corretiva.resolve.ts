import { Resolve, ActivatedRouteSnapshot } from '@angular/router';
import { ManutencaoCorretiva } from './../models/manutencao-corretiva.model';
import { Injectable } from '@angular/core';
import { ManutencaoCorretivaService } from '../services/manutencao-corretiva.service';

@Injectable()
export class ManutencaoCorretivaResolve implements Resolve<ManutencaoCorretiva> {

  constructor(private manutencaoService: ManutencaoCorretivaService) {}

  resolve(route: ActivatedRouteSnapshot) {
    return this.manutencaoService.buscarPorId(route.params['idManutencao']);
  }

}
