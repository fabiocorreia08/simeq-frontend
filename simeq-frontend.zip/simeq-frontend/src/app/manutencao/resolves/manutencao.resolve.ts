import { Resolve, ActivatedRouteSnapshot } from '@angular/router';
import { ManutencaoCorretiva } from './../models/manutencao-corretiva.model';
import { Injectable } from '@angular/core';
import { ManutencaoCorretivaService } from '../services/manutencao-corretiva.service';
import { Manutencao } from '../models/manutencao.model';

@Injectable()
export class ManutencaoResolve implements Resolve<Manutencao> {

  constructor(private manutencaoService: ManutencaoCorretivaService) {}

  resolve(route: ActivatedRouteSnapshot) {
    return this.manutencaoService.buscarPorIdManutencao(route.params['idManutencao'], route.params['numeroSolicitacao']);
  }
}
