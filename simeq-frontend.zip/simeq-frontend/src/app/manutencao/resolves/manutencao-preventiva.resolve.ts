import { ManutencaoPreventivaService } from './../services/manutencao-preventiva.service';
import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot } from '@angular/router';
import { PreventivaCadastro } from './../models/preventiva-cadastro.model';

@Injectable()
export class ManutencaoPreventivaResolve implements Resolve<PreventivaCadastro> {

  constructor(private manutencaoService: ManutencaoPreventivaService) {}

  resolve(route: ActivatedRouteSnapshot) {
    return this.manutencaoService.buscarPorId(route.params['idManutencao']);
  }

}
