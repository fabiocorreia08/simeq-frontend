import { Resolve, ActivatedRouteSnapshot } from '@angular/router';
import { Injectable } from '@angular/core';

import { StatusManutencaoCorretivaService } from '../services/status-manutencao.service';
import { LabelValue } from '../../core/models/label-value';

@Injectable()
export class StatusCorretivaResolve implements Resolve<LabelValue[]> {

  constructor(private statusService: StatusManutencaoCorretivaService) {}

  resolve(route: ActivatedRouteSnapshot) {
    return this.statusService.buscarTodosLabelValue();
  }

}
