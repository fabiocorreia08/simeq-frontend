import { Atividade } from './../models/atividade.model';
import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Injectable } from '@angular/core';
import { AtividadeService } from '../services/atividade.service';

@Injectable()
export class AtividadeResolve implements Resolve<Atividade> {

  constructor(private atividadeService: AtividadeService){}

  resolve(route: ActivatedRouteSnapshot) {
    return this.atividadeService.buscarPorId(route.params['idAtividade'], route.params['numeroSolicitacao']);
  }
}
