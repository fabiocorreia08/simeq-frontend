import { Component, OnInit } from "@angular/core";
import { ActivatedRoute, Router } from "@angular/router";

import { BreadcrumbService } from "../core/breadcrumb/breadcrumb.service";
import { AuthenticationService } from "../core/security/auth.service";
import { Subscription } from 'rxjs';

import { interval } from "rxjs/observable/interval";

import { Inject } from '@angular/core';    
import { DOCUMENT } from '@angular/common';
import { ManutencaoCorretivaService } from "../manutencao/services/manutencao-corretiva.service";


declare var $: any;

@Component({
  selector: 'simeq-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  visible: boolean = false;

  public readonly VISITANTE: number = 6;
  public isPerfilVisitante = false;

  centrosCustos: string[] = [];
  
  private updateSubscription: Subscription;

  constructor(
    breadcrumbService: BreadcrumbService,
    private route: ActivatedRoute,       
    public auth: AuthenticationService,
    @Inject(DOCUMENT) private document: Document    
  ) {    
    breadcrumbService.addRoute('/app/home/', 'Home', false);    
    this.centrosCustos = this.route.snapshot.data['centrosCustoUsuarioLogadoResolve'];    
  }

  ngOnInit() {    
    this.isPerfilVisitante = this.auth.getPerfil(this.VISITANTE);    
    this.updateSubscription = interval(300000).subscribe(
      (val) => {         
        this.document.location.reload();
    });          
  }    

  ngOnDestroy(): void {
    if (this.updateSubscription) {
      this.updateSubscription.unsubscribe();
    }    
  }
  
}