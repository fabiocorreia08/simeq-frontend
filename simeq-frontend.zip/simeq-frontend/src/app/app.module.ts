import { ManutecaoModule } from './manutencao/manutencao.module';
import { CoreModule } from './core/core.module';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { NgxChartsModule } from '@swimlane/ngx-charts';
import { AppComponent } from './app.component';
import { LoginModule } from './login/login.module';
import { XHRBackend, HttpModule } from '@angular/http';
import { ExtendedXHRBackend } from './core/http/extended-xhrbackend';
import { APP_BASE_HREF, LocationStrategy } from '@angular/common';
import { environment } from '../environments/environment';
import { CustomLocationStrategy } from './core/custom-location-strategy';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { HomeComponent } from './home/home.component';
import { MainComponent } from './main/main.component';
import { AdministracaoModule } from './administracao/administracao.module';
import { AlocacaoModule } from './alocacao/alocacao.module';
import { AvaliacaoSolicitacaoModule } from './avaliacao/avaliacao-solicitacao/avaliacao-solicitacao.module';
import { AprovacaoSolicitacaoModule } from './aprovação/aprovacao-manutencao-preventiva/aprovacao-solicitacao.module';
import { RelatoriosModule } from './relatorios/relatorios.module';
import { RelatoriosRoutingModule } from './relatorios/relatorios-routing.module';
import { ChartCorretivaComponent } from './charts/chart-corretiva/chart-corretiva.component';
import { ChartPreventivaComponent } from './charts/chart-preventiva/chart-preventiva.component';

@NgModule({
  declarations: [
    AppComponent,
    MainComponent,
    HomeComponent,
    ChartCorretivaComponent,
    ChartPreventivaComponent,
  ],
  imports: [
    HttpModule,
    BrowserModule,
    CoreModule,
    LoginModule,
    NgbModule.forRoot(),
    AdministracaoModule,
    ManutecaoModule,
    AlocacaoModule,
    AvaliacaoSolicitacaoModule,
    AprovacaoSolicitacaoModule,
    RelatoriosModule,
    NgxChartsModule,
    AppRoutingModule

  ],
  providers: [
    { provide: XHRBackend, useClass: ExtendedXHRBackend },
    { provide: APP_BASE_HREF, useValue: environment.baseUrl },
    { provide: LocationStrategy, useClass: CustomLocationStrategy }],
  bootstrap: [AppComponent]
})
export class AppModule { }
