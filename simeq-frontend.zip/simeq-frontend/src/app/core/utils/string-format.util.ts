export class StringFormatUtils {
    public static replaceAllMask(field: string): any {
        if (field) {
            return field.replace(' ', '%20').replace(' ', '%20').replace(' ', '%20').replace(' ', '%20').replace(/\./, '%2E').replace(/[\_\;\^\-\:\[\] ]/g, '');
        }
        return null;
    }

    public static replaceAllEspaco(field: string): any {        
        if (field) {
            return field.replace(' ', '_').replace(' ', '_').replace(' ', '_').replace(' ', '_').replace(' ', '_');
        }
        return null;
    }

}
