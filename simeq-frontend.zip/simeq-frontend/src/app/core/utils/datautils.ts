import * as moment from 'moment';

export class DataUtils {

  static horaInicioDia(data: Date) {
    return moment(data).hour(0).minute(0).second(0).toDate();
  }

  static convertFormat(data: Date) {
    if (data) {
      data = moment(data, "YYYY-MM-DD").toDate();
    }
    return data;
  }

  static formatar(data: Date) {
    if (data) {
      return moment(data).format("DD/MM/YYYY");
    }
    return "";
  }
}