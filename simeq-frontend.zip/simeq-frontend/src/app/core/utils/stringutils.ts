import { isNullOrUndefined } from "util";

export class StringUtils {

  static nullTransform(value: string) {
    return value == 'null' ? null : value;
  }

  static substring(value: string, length: number) {
    if (value && length && value.length > length) {
      value = value.substring(0, length - 1);
    }
    return value;
  }

  static padZeroes(value: number, zeroesToLeft: number): string {
    if(value != undefined) {
      let retorno: string = value.toString();
      for(let count = value.toString().length; count < zeroesToLeft; count++) {
        retorno = '0'+retorno;
      }
      return retorno;
    }
    return null;
  }

  static isNullOrUndefinedOrEmpty(value: Object) {
    return value === null || value === undefined || value.toString() === '';
  }
}