
export class MapBuilder<R> {
    public buildParam(params): Map<string, R> {
        const parametros: Map<string, R> = new Map<string, R>();
        for (const nomeAtributo of Object.keys(params)) {
            if (params[nomeAtributo] || typeof params[nomeAtributo] === 'boolean' ||
                typeof params[nomeAtributo] === 'number') {
                parametros.set(nomeAtributo, params[nomeAtributo]);
            }
        }
        return parametros;
    }
}
