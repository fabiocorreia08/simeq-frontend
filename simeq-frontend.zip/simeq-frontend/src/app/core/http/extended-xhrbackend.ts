import { Injectable } from '@angular/core';
import { Request, XHRBackend, BrowserXhr, ResponseOptions, XSRFStrategy, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
import 'rxjs/add/operator/finally';
import { SecurityConstants } from "../security/security.constants";
import { Ng2Storage } from "../security/ng2-storage";
import {LoadingIndicatorService} from "../loading-indicator/loading-indicator.service";
import {Router} from "@angular/router";
import {SessionExpirationService} from "../session-expiration/session-expiration.service";

@Injectable()
export class ExtendedXHRBackend extends XHRBackend {

  private storage: Ng2Storage = new Ng2Storage(localStorage);


  constructor(browserXhr: BrowserXhr, baseResponseOptions: ResponseOptions, xsrfStrategy: XSRFStrategy,
              private loadingIndicatorService: LoadingIndicatorService,
              private sessionExpirationService : SessionExpirationService,
              private router : Router) {
    super(browserXhr, baseResponseOptions, xsrfStrategy);
  }

  createConnection(request: Request) {
    this.loadingIndicatorService.show();
    let token: string = this.storage.getItem(SecurityConstants.TOKEN_NAME);

    request.headers.set(SecurityConstants.TOKEN_NAME, `${token}`);
    request.headers.set('Cache-Control', 'no-cache, no-store, must-revalidate');
    request.headers.set('Pragma', 'no-cache');


    if(!(request.getBody() instanceof FormData)) {
      request.headers.set('Content-Type', 'application/json');
    }

    let xhrConnection = super.createConnection(request);
    xhrConnection.response = xhrConnection.response.catch((error: Response) => {
      console.log('Erro:' + error);
      /*if (error.status === 0) {
        return Observable.throw(['Erro na leitura do certificado digital: Falha na leitura do certificado.']);
      } else */ if (error.status === 401 || error.status === 403) {
          if (error.status === 401) {
            this.storage.clearAll();
            this.sessionExpirationService.expire()
          } else if (error.status === 403) {
            this.router.navigate(['403']);
          }
          return Observable.throw(error);
      }

      let body = error.json() || '';

      if (body.erros) {
        return Observable.throw(body.erros);
      } else {
        return Observable.throw(['Ocorreu um erro. Tente novamente mais tarde ou entre em contato com a equipe técnica da Casa da Moeda.']);
      }
    }).finally(() => {this.loadingIndicatorService.hide()});
    return xhrConnection;
  }
}
