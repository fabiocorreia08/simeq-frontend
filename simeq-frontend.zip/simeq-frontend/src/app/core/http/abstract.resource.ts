import { log } from 'util';
import { Http, Response, Headers, ResponseContentType, RequestOptions, URLSearchParams } from "@angular/http";
import { environment } from "../../../environments/environment";
import { Pagina } from "../models/pagina.model";
import { SecurityConstants } from "../security/security.constants";
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import { LabelValue } from '../models/label-value';
import { StringFormatUtils } from '../utils/string-format.util';
import { take } from 'rxjs/operators';

declare var $: any;
declare var saveAs: any;

export abstract class AbstractResource<Entity> {
  private readonly APPLICATION_JSON_UTF_8 = 'application/json;charset=UTF-8';
  url: string = environment.apiUrl;

  constructor(private http: Http, private endPoint: string) {
    if (endPoint) {
      this.url = this.url + endPoint;
    }
  }

  public getQueryParams(endPoint: string, queryParams?: any): Observable<any> {
    return this.http.get(`${this.url}${endPoint}?${this.buildQueryParams(queryParams)}`)
      .pipe(take(1))
      .map(this.doQuerySucess)
      .catch(this.doError)
  }

  downloadQueryParams(endPoint: string, params?: any): Observable<any> {       
    return this.http.get(`${this.url}${endPoint}?${this.buildQueryParams(params)}`, { responseType: ResponseContentType.Blob })
      .pipe(take(1))
      .map(this.doDownloadSucess)
      .catch(this.doError);
  }

  public getFilterAndPage(endPoint: string, filter?: any, page?: any): Observable<any> {
    return this.http.get(`${this.url}${endPoint}?${this.buildQueryParams(filter)}&${this.buildQueryParams(page)}`)
      .pipe(take(1))
      .map(this.doQuerySucess)
      .catch(this.doError)
  }

  delete(endPoint: string, id: any): Observable<Entity> {
    return this.http.delete(this.url + endPoint + this.getPathParam(id))
      .pipe(take(1))
      .map(this.doQuerySucess)
      .catch(this.doError)
  }

  post(endPoint: string, requestBody: Entity): Observable<Entity> {
    return this.http.post(this.url + endPoint, requestBody)
      .pipe(take(1))
      .map(this.doSucess)
      .catch(this.doError);
  }

  put(endPoint: string, requestBody: Entity): Observable<Entity> {
    return this.http.put(this.url + endPoint, requestBody)
      .pipe(take(1))
      .map(this.doSucess)
      .catch(this.doError);
  }

  getOne(endPoint: string, param?: any): Observable<Entity> {
    if (param === undefined) {
      return this.getOneSemParametros(endPoint);
    }
    return this.getOneComParametro(endPoint, param);
  }

  getOneParams(endPoint: string, params: any): Observable<Entity> {
    const opcoesFinais = this.criarRequestOptions(params);
    return this.http.get(this.url + endPoint, opcoesFinais)
      .pipe(take(1))
      .map(this.doQuerySucess)
      .catch(this.doError);
  }

  private getOneSemParametros(endPoint: string): Observable<Entity> {
    return this.http.get(this.url + endPoint)
      .pipe(take(1))
      .map(this.doQuerySucess)
      .catch(this.doError);
  }

  private getOneComParametro(endPoint: string, param?: any): Observable<Entity> {
    return this.http.get(this.url + endPoint + this.getPathParam(param))
      .pipe(take(1))
      .map(this.doQuerySucess)
      .catch(this.doError);
  }

  getList(endPoint: string, param?: any): Observable<Entity[]> {
    if (param === undefined) {
      return this.retornarSemParametros(endPoint);
    }
    return this.retornarComParametros(endPoint, param);
  }

  private retornarSemParametros(endPoint: string): Observable<Entity[]> {
    return this.http.get(this.url + endPoint)
      .pipe(take(1))
      .map(this.doQuerySucess)
      .catch(this.doError);
  }

  private retornarComParametros(endPoint: string, param?: any): Observable<Entity[]> {
    return this.http.get(this.url + endPoint + '/' + param)
      .pipe(take(1))
      .map(this.doQuerySucess)
      .catch(this.doError);
  }

  getLabelValue(endPoint: string): Observable<LabelValue> {
    return this.http.get(this.url + endPoint)
      .pipe(take(1))
      .map(this.doQuerySucess)
      .catch(this.doError);
  }

  filter(endPoint: string, requestBody: any, params?: any): Observable<Pagina<Entity>> {
    return this.http.post(this.url + endPoint + '?' + this.getParams(params), requestBody)
      .pipe(take(1))
      .map(this.doQuerySucess)
      .catch(this.doError);
  }

  queryUrl(url: string): Observable<Entity[]> {
    return this.http.get(`${this.getUrl()}${url}`)
      .pipe(take(1))
      .map(this.doQuerySucess)
      .catch(this.doError);
  }

  download(endPoint: string, params?: any): Observable<any> {
    return this.http.get(this.url + endPoint, { responseType: ResponseContentType.Blob })
      .pipe(take(1))
      .map(this.doDownloadSucess)
      .catch(this.doError);
  }

  getBlob(endPoint: string, params?: any): Observable<any> {
    return this.http.get(this.url + endPoint, { responseType: ResponseContentType.Blob })
      .pipe(take(1))
      .map(this.doBlobSucess)
      .catch(this.doError);
  }

  downloadPost(endPoint: string, param?: any): Observable<any> {
    return this.http.post(this.url + endPoint, param, { responseType: ResponseContentType.Blob })
      .pipe(take(1))
      .map(this.doDownloadSucess)
      .catch(this.doError);
  }

  private doDownloadSucess(response: Response): Observable<any> {

    let nomeArquivo = response.headers.get('Content-Disposition').split(';')[1].split('=')[1];
    let contentType = response.headers.get('Content-Type');

    saveAs(response.blob(), nomeArquivo, false);
    return Observable.create({ blob: response.blob(), fileName: nomeArquivo });
  }

  private doBlobSucess(response: Response) {

    let nomeArquivo = response.headers.get('Content-Disposition').split(';')[1].split('=')[1];
    let contentType = response.headers.get('Content-Type');

    return response.blob();
  }

  private doQuerySucess(res: Response) {
    try {
      AbstractResource.refreshToken(res);
      let body = res.json();
      return body.data || body;
    } catch (e) {
      Observable.throw([]);
    }
  }

  private doSucess(response: Response) {
    try {
      AbstractResource.refreshToken(response);
      let body = response.json() || {};
      return body.data || body;
    } catch (e) {
      Observable.throw(e);
    }
  }

  private static refreshToken(response: Response) {
    let token = response.headers.get(SecurityConstants.TOKEN_NAME);

    if (token) {
      self.localStorage.setItem(SecurityConstants.TOKEN_NAME, token);
    }
  }

  private doError(error: Response | any) {

    if (error instanceof Response) {
      let err = '';
      let body = error.json() || error;
      err = body.data || body;

      return Observable.throw(err);
    } else {
      return Observable.throw(error);
    }
  }

  private getUrl(): string {
    return this.url;
  }

  private getParams(params: any): string {
    return params ? $.param(params) : null;
  }

  private getPathParam(param?: any) {
    if (param) {
      return "/" + param;
    } else {
      return "";
    }
  }

  private construirHeaders(): Headers {
    const headers = new Headers();
    headers.append('Content-Type', this.APPLICATION_JSON_UTF_8);
    return headers;
  }

  protected criarRequestOptions(param?: Map<string, string>, body?: any, responseType?: ResponseContentType): RequestOptions {
    const headers = new Headers();
    const params: URLSearchParams = new URLSearchParams();
    param.forEach((valor: string, chave: string) => {
      params.append(chave, valor);
    });
    return new RequestOptions({
      headers: this.construirHeaders(),
      params: params,
      body: body,
      responseType: responseType
    });
  }

  private addQueryParam(property: any, value: any, queryParams: string): any {
    if (property && value != null && value !== undefined && value.toString().trim() !== '') {
      if (Array.isArray(value)) {
        value.forEach(item => {
          queryParams += StringFormatUtils.replaceAllMask(`${property}=${item}`) + '&';
        });
      } else {
        queryParams += StringFormatUtils.replaceAllMask(`${property}=${value}`) + '&';
      }
    }
    return queryParams;
  }

  private buildQueryParams(params?: any): string {    
    let queryParams = '';
    for (const property in params) {
      queryParams = this.addQueryParam([property], params[property], queryParams);
    }    
    return queryParams;
  }

}

