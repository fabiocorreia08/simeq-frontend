import { Component, OnInit } from '@angular/core';
import {environment} from "../../../environments/environment";
import {AuthenticationService} from "../security/auth.service";

@Component({
  selector: 'simeq-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.css']
})
export class FooterComponent implements OnInit {

  ano : number = new Date().getFullYear()
  versao: string = environment.version;

  constructor(public auth: AuthenticationService) {

  }

  ngOnInit() {
  }

}
