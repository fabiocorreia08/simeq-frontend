import { Component, OnInit, Input, forwardRef, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'fieldset-component',
  templateUrl: './fieldset.component.html',
  styleUrls: ['./fieldset.component.css']
})
export class FieldsetComponent {

  @Input()
  public titulo: string;

  @Input()
  public classe: string = "fieldset-editar";
  
  @Input()
  public desabilitar:boolean = false;

  constructor() { }


}
