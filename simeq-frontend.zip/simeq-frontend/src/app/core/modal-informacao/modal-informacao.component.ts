import {Component, Input} from '@angular/core';
import {Subject} from 'rxjs/Subject';
import {Observable} from 'rxjs/Observable';
import 'rxjs/add/operator/filter';
import 'rxjs/add/operator/map';

declare var $:any;

@Component({
  selector: 'simeq-modal-informacao',
  templateUrl: 'modal-informacao.component.html'
})
export class ModalInformacaoComponent{

  @Input('id') modalId: String;
  @Input() headerModal: string;
  @Input() bodyModal: string;
  @Input() labelButton?: string;
  @Input() okButtonMessage?: string;
  @Input() icon?:string="fa-info-circle";
  @Input() closable?: boolean = true;

  private _eventBus: Subject<ModalEvent> = new Subject<ModalEvent>();

  modal: any;

  showDialog(): Promise<ModalEvent> {
    if (this.closable) {
      this.modal = $('#id-' + this.modalId).modal('show');
    } else {
      this.modal = $('#id-' + this.modalId).modal({backdrop: 'static', keyboard: false});
    }

    return new Promise<ModalEvent> ((resolve, reject) => {
       return this._eventBus.asObservable().subscribe(message => {
         if (message.success) {
           resolve(message);
         } else {
           reject(message);
         }
      });
    });
  }

  okClick() {
    this.modal.modal('hide');
    this._eventBus.next({success: true});
  }

  cancelClick() {
    this.modal.modal('hide');
    this._eventBus.next({error: true});
  }
}

export class ModalEvent {
  error?: boolean;
  success?: boolean;
}
