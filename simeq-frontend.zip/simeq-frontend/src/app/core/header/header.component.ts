import {Component, OnInit} from "@angular/core";
import {AuthenticationService} from "../security/auth.service";

@Component({
  selector: 'simeq-header',
  templateUrl: './header.component.html'
})
export class HeaderComponent implements OnInit {

  constructor(public auth: AuthenticationService) {

  }

  ngOnInit() {
  }

}

