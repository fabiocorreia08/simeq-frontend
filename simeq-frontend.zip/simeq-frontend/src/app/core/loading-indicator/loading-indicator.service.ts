import { Injectable } from '@angular/core';
import { BehaviorSubject } from "rxjs";

@Injectable()
export class LoadingIndicatorService {

  stack: number = 0;

  private _loaderStatusSubject = new BehaviorSubject<boolean>(false);
  // Observable loaderStatus stream
  loaderStatus$ = this._loaderStatusSubject.asObservable();

  show() {
    this.stack++;
    this._loaderStatusSubject.next(true);
  }

  hide() {
    this._loaderStatusSubject.next(--this.stack > 0);
  }

}
