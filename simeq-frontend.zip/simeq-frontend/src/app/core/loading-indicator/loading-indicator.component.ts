import {Component, OnDestroy, OnInit} from '@angular/core';
import {Subscription} from "rxjs";
import {LoadingIndicatorService} from "./loading-indicator.service";

@Component({
  selector: 'simeq-loading-indicator',
  templateUrl: './loading-indicator.component.html'
})
export class LoadingIndicatorComponent implements OnInit, OnDestroy {
  visible: boolean = false;
  subscription:Subscription;

  constructor(private loadingIndicatorService : LoadingIndicatorService) {  }

  ngOnInit() {
    this.subscription = this.loadingIndicatorService.loaderStatus$
      .subscribe(status => {
        this.visible = status;        
      })
  }


  ngOnDestroy() {
    this.subscription.unsubscribe();
  }
}





