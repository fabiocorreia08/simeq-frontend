import { StringUtils } from './../utils/stringutils';
import { Pipe, PipeTransform } from '@angular/core';
import { TipoRealocadoEnum } from '../../administracao/tecnico/resources/enums/tipo-realocacao.enum';
import { SimNaoEnum } from '../../shared/resources/enums/sim-nao.enum';

@Pipe({
    name: 'simNao'
})
export class SimNaoPipe implements PipeTransform {

    public transform(value: any, args: any[]): any {
        let descricao: string = '';
        if (value === SimNaoEnum.SIM) {
            return descricao = "Sim";
        }else if(value === SimNaoEnum.NAO){
            return descricao = "Não";
        }else{
            return descricao = "";
        }
    }
}