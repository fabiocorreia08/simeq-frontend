import { StringUtils } from './../utils/stringutils';
import { Pipe, PipeTransform } from '@angular/core';
import { AtivoInativoEnum } from '../../administracao/equipamento/resources/enums/AtivoInativo.enum';

@Pipe({
    name: 'descricaoAtivoInativo'
})
export class DescricaoAtivoInativoPipe implements PipeTransform {

    public transform(value: any, args: any[]): any {
        let descricao: string = '';
        if (value === AtivoInativoEnum.ATIVO) {
            return descricao = "Ativo";
        }else if(value === AtivoInativoEnum.INATIVO){
            return descricao = "Inativo";
        }else{
            return descricao = "";
        }
    }
}