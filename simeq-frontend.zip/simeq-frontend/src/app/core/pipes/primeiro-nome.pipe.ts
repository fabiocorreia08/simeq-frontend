import { StringUtils } from './../utils/stringutils';
import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
    name: 'primeiroNome'
})
export class PrimeiroNomePipe implements PipeTransform {

    public transform(value: any, args: any[]): any {
        let primeiroNome: string = '';

        if (value) {
            primeiroNome = value.split(' ')[0];
        }

        return primeiroNome;
    }
}