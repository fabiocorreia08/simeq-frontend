import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
    name: 'codigoManutencaoEquipamento'
})
export class CodigoManutencaoEquipamentoPipe implements PipeTransform {

    public transform(value: string, args: any[]): any {
        return (value) ? value.substring(0,2)+"-"+value.substring(2,3)+"-"+value.substring(3,6) : '';
    }
}