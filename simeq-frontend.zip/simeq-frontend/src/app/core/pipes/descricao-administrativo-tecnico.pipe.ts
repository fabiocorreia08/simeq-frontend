import { StringUtils } from './../utils/stringutils';
import { Pipe, PipeTransform } from '@angular/core';
import { TipoRealocadoEnum } from '../../administracao/tecnico/resources/enums/tipo-realocacao.enum';

@Pipe({
    name: 'descricaoAdministrativoTecnico'
})
export class DescricaoAdministrativoTecnicoPipe implements PipeTransform {

    public transform(value: any, args: any[]): any {
        let descricao: string = '';
        if (value === TipoRealocadoEnum.ADMINISTRATIVO) {
            return descricao = "Administrativo";
        }else if(value === TipoRealocadoEnum.TECNICO){
            return descricao = "Técnico";
        }else{
            return descricao = "";
        }
    }
}