import { Pipe, PipeTransform } from '@angular/core';
import { StringUtils } from '../utils/stringutils';
import { isNullOrUndefined } from 'util';

@Pipe({
    name: 'codigo'
})
export class CodigoPipe implements PipeTransform {

    public transform(value: number, arg: number): any {
        return !isNullOrUndefined(value) ? StringUtils.padZeroes(value, arg) : '';
    }
}