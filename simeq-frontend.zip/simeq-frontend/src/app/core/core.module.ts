import { DescricaoAtivoInativoPipe } from './pipes/descricao-ativo-inativo.pipe';
import { NgModule } from '@angular/core';
import { LoadingIndicatorComponent } from './loading-indicator/loading-indicator.component';
import { MessagesComponent } from './messages/messages.component';
import { FooterComponent } from './footer/footer.component';
import { HeaderLoginComponent } from './header-login/header-login.component';
import { MessagesService } from './messages/messages.service';
import { AuthenticationService } from './security/auth.service';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { SessionExpirationService } from './session-expiration/session-expiration.service';
import { AuthResource } from './security/auth.resource';
import { ModalInformacaoComponent } from './modal-informacao/modal-informacao.component';
import { ModalConfirmacaoComponent } from './modal-confirmacao/modal-confirmacao.component';
import { AuthGuard } from './security/auth.guard';
import { SessionExpirationComponent } from './session-expiration/session-expiration.component';
import { HeaderComponent } from './header/header.component';
import { UserinfoComponent } from './userinfo/userinfo.component';
import { NotFoundComponent } from './notfound/notfound.component';
import { ErrorPageComponent } from './errorpage/errorpage.component';
import { ForbiddenPageComponent } from './forbidden/forbidden.component';
import { PrimeiroNomePipe } from './pipes/primeiro-nome.pipe';
import { BreadcrumbComponent } from './breadcrumb/breadcrumb.component';
import { NavbarComponent } from './navbar/navbar.component';
import { FadeOnEnterDirective } from './navbar/fade-on-enter.directive';
import { LoadingIndicatorService } from './loading-indicator/loading-indicator.service';
import { BreadcrumbService } from './breadcrumb/breadcrumb.service';
import { DescricaoAdministrativoTecnicoPipe } from './pipes/descricao-administrativo-tecnico.pipe';
import { CodigoManutencaoEquipamentoPipe } from './pipes/codigo-manutencao-equipamento.pipe';
import { CalendarLocaleService } from './calendar.locale.service';
import { CodigoPipe } from './pipes/codigo.pipe';
import { OnlyNumberDirective } from './directives/only-number.directive';
import { SimNaoPipe } from './pipes/sim-nao-pipe';
import { HomeAuthGuard } from './security/home.auth.guard';
import { DetalharEditarAuthGuard } from './security/detalhar-editar-auth.guard';
import { FieldsetComponent } from './fieldset/fieldset.component';

@NgModule({
  declarations: [
    HeaderLoginComponent,
    FooterComponent,
    MessagesComponent,
    LoadingIndicatorComponent,
    ModalInformacaoComponent,
    ModalConfirmacaoComponent,
    SessionExpirationComponent,
    HeaderComponent,
    UserinfoComponent,
    NotFoundComponent,
    ErrorPageComponent,
    ForbiddenPageComponent,
    PrimeiroNomePipe,
    BreadcrumbComponent,
    NavbarComponent,
    FadeOnEnterDirective,
    DescricaoAtivoInativoPipe,
    DescricaoAdministrativoTecnicoPipe,
    CodigoManutencaoEquipamentoPipe,
    CodigoPipe,
    SimNaoPipe,
    OnlyNumberDirective,
    FieldsetComponent
  ],
  imports: [
    CommonModule,
    RouterModule,
    FormsModule,
    NgbModule.forRoot()
  ],
  exports: [
    HeaderLoginComponent,
    FooterComponent,
    MessagesComponent,
    LoadingIndicatorComponent,
    ModalInformacaoComponent,
    ModalConfirmacaoComponent,
    SessionExpirationComponent,
    HeaderComponent,
    UserinfoComponent,
    NotFoundComponent,
    ErrorPageComponent,
    ForbiddenPageComponent,
    BreadcrumbComponent,
    NavbarComponent,
    FadeOnEnterDirective,
    DescricaoAtivoInativoPipe,
    DescricaoAdministrativoTecnicoPipe,
    CodigoManutencaoEquipamentoPipe,
    CodigoPipe,
    SimNaoPipe,
    OnlyNumberDirective,
    FieldsetComponent
  ],
  providers: [
    MessagesService,
    BreadcrumbService,
    AuthenticationService,
    SessionExpirationService,
    LoadingIndicatorService,
    AuthResource,
    AuthGuard,
    DetalharEditarAuthGuard,
    HomeAuthGuard,
    CalendarLocaleService
  ]
})
export class CoreModule { }
