import {Component, Input} from '@angular/core';
import {Subject} from 'rxjs/Subject';
import {Observable} from 'rxjs/Observable';
import 'rxjs/add/operator/filter';
import 'rxjs/add/operator/map';
import { Observer } from 'rxjs';

declare var $:any; 

@Component({
  selector: 'simeq-modal-confirmacao',
  templateUrl: './modal-confirmacao.component.html'
})
export class ModalConfirmacaoComponent{

  @Input('id') modalId: String;  
  @Input() options: ModalConfirmacaoOptions;
  @Input() headerModal: string;
  @Input() bodyModal: string;
  @Input() showOkButton?: boolean = false;
  @Input() labelOkButton?: string;
  @Input() okButtonMessage?: string;
  @Input() showCancelButton?: boolean = false;
  @Input() cancelButtonMessage?: string;
  @Input() labelCancelButton?: string;
  @Input() closable?: boolean = true;

  observer: Observer<boolean>;
  modal: any;

  showDialog(): Observable<boolean> {
    this.modal = $('#id-' + this.modalId).modal('show');    

    return new Observable(observer => {
      this.observer = observer;
    });
  }

  okClick() {
    this.modal.modal('hide');
    this.observer.next(true);
    this.observer.complete();
  }

  cancelClick() {
    this.modal.modal('hide');
    this.observer.next(false);
    this.observer.complete();
  }
}

export class ModalConfirmacaoOptions {
  headerModal: string;
  bodyModal: string;
  showOkButton?: boolean = false;
  labelOkButton?: string;
  okButtonMessage?: string;
  showCancelButton?: boolean = false;
  cancelButtonMessage?: string;
  labelCancelButton?: string;
}
