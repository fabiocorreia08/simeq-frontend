import { root } from 'rxjs/util/root';
import { Observable } from 'rxjs/Observable';
import { Injectable } from '@angular/core';
import { ActivatedRoute, CanActivate, NavigationEnd, Router, ActivatedRouteSnapshot } from '@angular/router';
import { AuthenticationService } from "./auth.service";

@Injectable()
export class DetalharEditarAuthGuard implements CanActivate {

  constructor(private auth: AuthenticationService, private router: Router) { }

  canActivate(route: ActivatedRouteSnapshot) {
    let isDetalhar: boolean = (route.params['isDetalhar'] == 1) ? true : false;
    let funcionalidadeEditar: number[] = route.data['funcionalidadeEditar'];
    let funcionalidadeDetalhar: number[] = route.data['funcionalidadeDetalhar'];

    // Check to see if a user has a valid JWT
    if (this.auth.isLoggedIn() && ((isDetalhar && this.auth.hasAnyPermission(funcionalidadeDetalhar)) || (!isDetalhar && this.auth.hasAnyPermission(funcionalidadeEditar)))) {
      return true;
    } else if (this.auth.isLoggedIn()) {
      this.auth.acessDenied();
      return false;
    } else {
      this.auth.logout();
      return false;
    }
  }
}
