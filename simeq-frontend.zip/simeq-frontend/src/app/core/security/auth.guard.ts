import { Injectable } from '@angular/core';
import {  CanActivate,  Router, ActivatedRouteSnapshot } from '@angular/router';
import { AuthenticationService } from "./auth.service";

@Injectable()
export class AuthGuard implements CanActivate {

  constructor(private auth: AuthenticationService, private router: Router) { }

  canActivate(route: ActivatedRouteSnapshot) {
    let funcionalidade: number[] = route.data['funcionalidade'];
    if (this.auth.isLoggedIn() && this.auth.hasAnyPermission(funcionalidade)) {
      return true;
    } else if (this.auth.isLoggedIn()) {
      this.auth.acessDenied();
      return false;
    } else {
      this.auth.logout();
      return false;
    }
  }
}
