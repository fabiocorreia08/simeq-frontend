import { PerfisConstants } from './perfis.constants';
import { isNullOrUndefined } from 'util';
import { SessionExpirationService } from './../session-expiration/session-expiration.service';
import { Injectable } from "@angular/core";
import { AuthResource } from "./auth.resource";
import { Router } from "@angular/router";
import { Ng2Storage } from "./ng2-storage";
import { User, Perfil } from './User';
import { SecurityConstants } from "./security.constants";
import { JwtHelper, tokenNotExpired } from "angular2-jwt";
import { Observable } from 'rxjs/Observable';

@Injectable()
export class AuthenticationService {

  private storage: Ng2Storage = new Ng2Storage(localStorage);

  constructor(private authres: AuthResource, private router: Router,
              private sessionExpirationService : SessionExpirationService) {
  }

  login(username: string, password: string): Observable<User> {    
    return this.fromAuthResource(username, password);
  }

  logout() {
    this.router.navigate(['login']);
  }

  get authInfo(): User {
    return this.getAuthenticatedUser();
  }

  hasPermission(...verifyPermissions: number[]) {
    let user = this.getAuthenticatedUser();

    let permissions = user.permissions;
    let contains = false;

    permissions.forEach((perm) => {
      if (verifyPermissions.find(verify => verify === perm)) {
        contains = true;
      }
    })

    return contains;
  }

  hasAnyPermission(verifyPermissions: number[]) {
    let user = this.getAuthenticatedUser();
    let permissions = user.permissions;
    let contadorPermissoes = 0;
    for (let perm of permissions) {
      if (verifyPermissions.find(verify => parseInt(verify.toString()) === parseInt(perm.toString()))) {
        contadorPermissoes = contadorPermissoes + 1;
      }
    }

    return verifyPermissions.length === contadorPermissoes;
  }

  isLoggedIn(): boolean {
    try {
      return tokenNotExpired(SecurityConstants.TOKEN_NAME);
    } catch (e) {
      this.logout();
    }
  }

  public getAuthenticatedUser() {    
    let token = this.storage.getItem(SecurityConstants.TOKEN_NAME);
    let helper: JwtHelper = new JwtHelper();

    let decodedToken = helper.decodeToken(token);

    if(!helper.isTokenExpired(token)) {
      let user: User = new User();
      user.username = decodedToken.details.matricula;
      user.details = decodedToken.details;
      user.permissions = decodedToken.details.permissao;      
      user.token = token;
      return user;
    }
    this.sessionExpirationService.expire();
    return new User();
  }

  private getIdsPerfis(perfis: Perfil[]): number[] {
    if (!isNullOrUndefined(perfis)) {
      let ids = [];
      perfis.forEach(p => {
        ids.push(p.id_perfil);
      });
      return ids;
    }
    return [];
  }

  getIdPerfil(perfisUsuario: Perfil[]): number {
    let idPerfil;
    perfisUsuario.forEach(pu => {
      PerfisConstants.PERFIS.forEach(p => {
        if (pu.id_perfil === p) {
          idPerfil = p;
        }
      });
    });
    return idPerfil;
  }

  fromAuthResource(username: string, password: string): Observable<User> {    
    return this.authres.login(username, password);
  }

  acessDenied() {
    this.router.navigate(['403']);
  }

  public getPerfil(perfil: number): boolean {    
    let isPerfil = false;
    this.authInfo.details.perfis.forEach(p => {
      
      if (p.id_perfil === perfil) {
        isPerfil = true;
      }
    });
    return isPerfil;
  }
}
