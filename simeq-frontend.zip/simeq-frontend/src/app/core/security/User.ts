export class User {
    username?: string;
    senha?: string;
    token?: string;
    permissions?: Array<number>;
    details?: UserDetails;      
}

export class UserDetails {
  nome?: string;
  cpf?: string;
  perfis?: Perfil[];
  matricula: string;
  lotacoes?: Array<string>;
}

export class Perfil {
  id_perfil?: number;
  nm_perfil?: string;
  permissoes?: number[];
}
