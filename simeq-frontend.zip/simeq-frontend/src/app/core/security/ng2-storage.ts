export  class Ng2Storage {

  storageType : Storage;

  constructor(storageType : Storage) {
    this.storageType = storageType;
  }

  getItem(key : string, defaultValue? : any) {
    let item = this.storageType.getItem(key)

    if (item==null) {
      return defaultValue;
    }

    try {
      return JSON.parse(item);
    } catch (e) {
      return item;
    }
  }


   setItem(key: string, value : any) {
     if(value == null) {
       //null or undefined
     } else if(typeof value == "object") {
       this.storageType.setItem(key, JSON.stringify(value));
     } else {
       this.storageType.setItem(key, value);
     }
   }

   removeItem() {

   }

   clearAll() {
    this.storageType.clear();
   }
}
