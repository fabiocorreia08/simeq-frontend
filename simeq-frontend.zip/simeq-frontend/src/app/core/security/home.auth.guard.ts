import { root } from 'rxjs/util/root';
import { Observable } from 'rxjs/Observable';
import { Injectable } from '@angular/core';
import { ActivatedRoute, CanActivate, NavigationEnd, Router, ActivatedRouteSnapshot } from '@angular/router';
import { AuthenticationService } from "./auth.service";

@Injectable()
export class HomeAuthGuard implements CanActivate {

  constructor(private auth: AuthenticationService, private router: Router) { }

  canActivate(route: ActivatedRouteSnapshot) {
    if (this.auth.isLoggedIn()) {
      return true;
    } else {
      this.auth.logout();
      return false;
    }
  }
}
