export class SecurityConstants {
  public static readonly TOKEN_NAME = "Authorization";
}
