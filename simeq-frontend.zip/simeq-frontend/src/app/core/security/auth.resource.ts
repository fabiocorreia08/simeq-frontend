import {Injectable} from "@angular/core";
import {User} from "./User";
import {Http} from "@angular/http";
import {AbstractResource} from "../http/abstract.resource";
import { Observable } from 'rxjs/Observable';

@Injectable()
export class AuthResource extends AbstractResource<User>{

  constructor(http: Http) {
    super(http, '');
  }

  login(username: string, password: string) : Observable<User> {       
    return super.post('/login', {username: username, senha: password});
  }

}
