export class PerfisConstants {
  static readonly CONSULTAR_EQUIPAMENTO_PERMISSOES: number[] = [1,2];
	static readonly CADASTRAR_EQUIPAMENTO_PERMISSOES: number[] = [2];
	static readonly DETALHAR_EQUIPAMENTO_PERMISSOES: number[] = [1,2];
	static readonly EDITAR_EQUIPAMENTO_PERMISSOES: number[] = [2];
	static readonly CONSULTAR_GRUPO_SUBGRUPO_PERMISSOES: number[] = [3,4];
	static readonly CADASTRAR_GRUPO_SUBGRUPO_PERMISSOES: number[] = [4];
	static readonly REPLICAR_GRUPO_SUBGRUPO_PERMISSOES: number[] = [4];
	static readonly DETALHAR_GRUPO_SUBGRUPO_PERMISSOES: number[] = [3,4];
	static readonly EDITAR_GRUPO_SUBGRUPO_PERMISSOES: number[] = [4];
	static readonly CONSULTAR_TECNICO_PERMISSOES: number[] = [5,6];
	static readonly CADASTRAR_TECNICO_PERMISSOES: number[] = [6];
	static readonly DETALHAR_TECNICO_PERMISSOES: number[] = [5,6];
	static readonly EDITAR_TECNICO_PERMISSOES: number[] = [6];
  static readonly CONSULTAR_MANUTENCAO_CORRETIVA_PERMISSOES: number[] = [7];
  static readonly CADASTRAR_MANUTENCAO_CORRETIVA_PERMISSOES: number[] = [7,8];
  static readonly EDITAR_MANUTENCAO_CORRETIVA_PERMISSOES: number[] = [7,9];
  static readonly DETALHAR_MANUTENCAO_CORRETIVA_PERMISSOES: number[] = [7,10];
  static readonly PARA_ALOCAR_PERMISSOES: number[] = [11];
  static readonly CONSULTAR_ALOCACOES_PERMISSOES: number[] = [12];
  static readonly CONSULTAR_INFORMACOES_PERMISSOES: number[] = [17];
  static readonly CADASTRAR_INFORMACOES_PERMISSOES: number[] = [18];
  static readonly CONSULTAR_ATIVIDADES: number[] = [13];
  static readonly CADASTRAR_ATIVIDADES: number[] = [14];
  static readonly AVALIAR_SOLICITACOES_PERMISSOES: number[] = [16];
  static readonly CADASTRAR_ALOCACOES_PERMISSOES: number[] = [15];
  static readonly CADASTRAR_MANUTENCAO_PREVENTIVA: number[] = [19];
  static readonly EDITAR_MANUTENCAO_PREVENTIVA: number[] = [20];
  static readonly CONSULTAR_MANUTENCAO_PREVENTIVA_PERMISSOES: number[] = [21];
  static readonly DETALHAR_MANUTENCAO_PREVENTIVA_PERMISSOES: number[] = [22];
  static readonly LISTAR_STATUS_MANUTENCAO_PREVENTIVA_PERMISSOES: number[] = [23];
  static readonly APROVAR_SOLICITACOES_PREVENTIVAS_PERMISSOES: number[] = [24];
  static readonly CADASTAR_FUNCIONAMENTO_MAQUINA: number[] = [25];
  static readonly CONSULTAR_FAMILIA_PERMISSOES: number[] = [26];
  static readonly CADASTRAR_FAMILIA_PERMISSOES: number[] = [27];
  static readonly EDITAR_FAMILIA_PERMISSOES: number[] = [28];
  static readonly RELATORIOS_PERMISSOES: number[] = [29];

  /* novas funcionalidades */

  static readonly CONSULTAR_PARAMETRO_PERMISSOES: number[] = [30];
  static readonly CADASTRAR_PARAMETRO_PERMISSOES: number[] = [31];
  static readonly DETALHAR_PARAMETRO_PERMISSOES: number[] = [32];
  static readonly EDITAR_PARAMETRO_PERMISSOES: number[] = [33];
  static readonly DELETAR_PARAMETRO_PERMISSOES: number[] = [34];
  
  static readonly CONSULTAR_ACAO_PERMISSOES: number[] = [35];
  static readonly CADASTRAR_ACAO_PERMISSOES: number[] = [36];
  static readonly DETALHAR_ACAO_PERMISSOES: number[] = [37];
  static readonly EDITAR_ACAO_PERMISSOES: number[] = [38];
  
  static readonly CONSULTAR_COMPONENTE_PERMISSOES: number[] = [39];
  static readonly CADASTRAR_COMPONENTE_PERMISSOES: number[] = [40];
  static readonly DETALHAR_COMPONENTE_PERMISSOES: number[] = [41];
  static readonly EDITAR_COMPONENTE_PERMISSOES: number[] = [42];
  static readonly CADASTAR_FUNCIONAMENTO_MAQUINA_ANUAL: number[] = [43];

  /* ------------------------ */

  static readonly ADMINISTRADOR: number = 1;
  static readonly TECNICO: number = 2;
  static readonly SOLICITANTE: number = 3;
  static readonly MASTER: number = 4;
  static readonly GESTOR: number = 5;
  static readonly VISITANTE: number = 6;

  static readonly PERFIS: number[] = [PerfisConstants.TECNICO, PerfisConstants.SOLICITANTE, PerfisConstants.MASTER,
    PerfisConstants.GESTOR, PerfisConstants.VISITANTE, PerfisConstants.ADMINISTRADOR];
}
