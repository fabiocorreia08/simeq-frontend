import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'simeq-header-login',
  templateUrl: './header-login.component.html',
  styleUrls: ['./header-login.component.css']
})
export class HeaderLoginComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
