import { Injectable } from '@angular/core';
import {BehaviorSubject} from "rxjs";

@Injectable()
export class SessionExpirationService {

  private _sessionExpirationSubject = new BehaviorSubject<boolean>(false);
  // Observable sessionExpiration stream
  sessionExpiration$ = this._sessionExpirationSubject.asObservable();

  expire() {
    this._sessionExpirationSubject.next(true);
  }

}
