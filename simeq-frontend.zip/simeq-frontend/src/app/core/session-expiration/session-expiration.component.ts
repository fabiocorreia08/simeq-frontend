import {Component, OnInit, ViewChild} from '@angular/core';
import {ModalInformacaoComponent} from "../modal-informacao/modal-informacao.component";
import {Subscription} from "rxjs";
import {AuthenticationService} from "../security/auth.service";
import {SessionExpirationService} from "./session-expiration.service";

@Component({
  selector: 'simeq-session-expiration',
  templateUrl: './session-expiration.component.html'
})
export class SessionExpirationComponent implements OnInit {

  @ViewChild('sessionExpirationModal')
  sessionExpirationModal: ModalInformacaoComponent;

  subscription:Subscription;

  constructor(private auth: AuthenticationService, private sessionExpirationService : SessionExpirationService) { }

  ngOnInit() {
    this.subscription = this.sessionExpirationService.sessionExpiration$
      .subscribe(() => this.showModal())
  }

  showModal() {
      this.sessionExpirationModal.showDialog()
        .then(() => {  this.auth.logout();  })
        .catch(erro => {    });
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }
}
