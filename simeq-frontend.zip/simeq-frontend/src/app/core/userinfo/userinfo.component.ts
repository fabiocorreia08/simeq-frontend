import {Component, OnInit} from "@angular/core";
import {AuthenticationService} from "../security/auth.service";

@Component({
  selector: 'simeq-userinfo',
  templateUrl: './userinfo.component.html'
})
export class UserinfoComponent implements OnInit {

  constructor(public auth : AuthenticationService) {

  }

  ngOnInit() {
  }


}
