import {Component, Input, OnInit, OnChanges} from '@angular/core';
import {Router, NavigationEnd, NavigationStart} from '@angular/router';
import {BreadcrumbService, Item} from './breadcrumb.service';

@Component({
  selector: 'simeq-breadcrumb',
  template: `
        <ul [class.breadcrumb]="useBootstrap">
            <li><a [routerLink]="['home']"><i class="fa fa-home" aria-hidden="true"></i> <span class="sr-only">(current)</span></a></li>
            <li *ngFor="let item of _routes; let last = last" [ngClass]="{'breadcrumb-item': useBootstrap, 'active': last}"> <!-- disable link of last item -->
                <a role="button" *ngIf="!last && item.showLink" (click)="navigateTo(item.routerLink)">{{item.name}}</a>
                <span role="button" *ngIf="!last && !item.showLink" style="font-weight: bold">{{item.name}}</span>
                <span *ngIf="last">{{item.name}}</span>
            </li>
        </ul>
    `,
  styleUrls: ['./breadcrumb.component.css']
})
export class BreadcrumbComponent implements OnInit {
  @Input() useBootstrap: boolean = true;
  public _routes: Item[] = [];
  public _routerSubscription: any;

  constructor(private router: Router,
              private breadcrumbService: BreadcrumbService) {
    this._routes = this.breadcrumbService.routes;
  }

  ngOnInit(): void {
    this._routerSubscription = this.router.events.subscribe((event) => {

      if (event instanceof NavigationStart) {
        this.breadcrumbService.clear();
      }
    });
  }

  navigateTo(url: string): void {
    this.router.navigateByUrl(url);
  }

  ngOnDestroy(): void {
    this._routerSubscription.unsubscribe();
  }
}
