import {Injectable} from "@angular/core";

@Injectable()
export class BreadcrumbService {
    private _routes: Item[] = [];

  addRoute(routerLink: string, name: string, showLink: boolean = true){
    let item: Item = {routerLink,name,showLink}
    this._routes.push(item);
  }

  clear() {
    this._routes.length = 0;
  }

  get routes(): Item[] {
    return this._routes;
  }
}

export interface Item {
  routerLink: string,
  name: string,
  showLink? : boolean
}
