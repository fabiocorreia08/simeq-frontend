import {Directive, HostListener, ElementRef, Renderer} from '@angular/core';
declare var jQuery:any;

@Directive({
  selector: '[dropdown-fadein]'
})
export class FadeOnEnterDirective {

  constructor(private el: ElementRef,
              private renderer: Renderer) {

  }

  @HostListener('mouseover')
  onMouseOver() {
    let part = this.el.nativeElement.querySelector('.dropdown-menu');

    jQuery(part).stop(true, true).delay(10).fadeIn(300);
  }

  @HostListener('mouseout')
  onMouseOout() {
    let part = this.el.nativeElement.querySelector('.dropdown-menu');

    jQuery(part).stop(true, true).delay(10).fadeOut(300);
  }
}
