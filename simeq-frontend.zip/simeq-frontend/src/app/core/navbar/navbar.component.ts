import { AuthenticationService } from './../security/auth.service';
import { Component, OnInit } from '@angular/core';
import { PerfisConstants } from '../security/perfis.constants';
import { Router } from '@angular/router';
import { BreadcrumbService } from '../breadcrumb/breadcrumb.service';

@Component({
  selector: 'simeq-navbar',
  templateUrl: './navbar.component.html'
})
export class NavbarComponent implements OnInit {
  isPeriodoAntecipacaoDecimoTerceiro: boolean;
  public isPerfilSolicitante = false;
  public isPerfilTecnico = false;
  public readonly SOLICITANTE: number = 3;
  public readonly TECNICO: number = 2;

  constructor(
    public auth: AuthenticationService,
    private breadcrumbService: BreadcrumbService,
    private router: Router
  ) { }

  ngOnInit() {
    this.isPerfilSolicitante = this.auth.getPerfil(this.SOLICITANTE);
    this.isPerfilTecnico =  this.auth.getPerfil(this.TECNICO);    
  }

  public hasAcessoAdministracao(): boolean {
    return this.auth.hasAnyPermission(PerfisConstants.CONSULTAR_EQUIPAMENTO_PERMISSOES) ||
      this.auth.hasAnyPermission(PerfisConstants.CADASTRAR_EQUIPAMENTO_PERMISSOES) ||
      this.auth.hasAnyPermission(PerfisConstants.DETALHAR_EQUIPAMENTO_PERMISSOES) ||
      this.auth.hasAnyPermission(PerfisConstants.EDITAR_EQUIPAMENTO_PERMISSOES) ||
      this.auth.hasAnyPermission(PerfisConstants.CONSULTAR_GRUPO_SUBGRUPO_PERMISSOES) ||
      this.auth.hasAnyPermission(PerfisConstants.CADASTRAR_GRUPO_SUBGRUPO_PERMISSOES) ||
      this.auth.hasAnyPermission(PerfisConstants.REPLICAR_GRUPO_SUBGRUPO_PERMISSOES) ||
      this.auth.hasAnyPermission(PerfisConstants.DETALHAR_GRUPO_SUBGRUPO_PERMISSOES) ||
      this.auth.hasAnyPermission(PerfisConstants.EDITAR_GRUPO_SUBGRUPO_PERMISSOES) ||
      this.auth.hasAnyPermission(PerfisConstants.CONSULTAR_TECNICO_PERMISSOES) ||
      this.auth.hasAnyPermission(PerfisConstants.CADASTRAR_TECNICO_PERMISSOES) ||
      this.auth.hasAnyPermission(PerfisConstants.DETALHAR_TECNICO_PERMISSOES) ||
      this.auth.hasAnyPermission(PerfisConstants.EDITAR_TECNICO_PERMISSOES) ||
      this.auth.hasAnyPermission(PerfisConstants.CADASTAR_FUNCIONAMENTO_MAQUINA) ||
      this.auth.hasAnyPermission(PerfisConstants.CONSULTAR_FAMILIA_PERMISSOES) ||
      this.auth.hasAnyPermission(PerfisConstants.CADASTRAR_FAMILIA_PERMISSOES) ||
      this.auth.hasAnyPermission(PerfisConstants.EDITAR_FAMILIA_PERMISSOES);
  }

  public hasAcessoAdministracaoTecnico(): boolean {
    return this.auth.hasAnyPermission(PerfisConstants.CONSULTAR_TECNICO_PERMISSOES) ||
      this.auth.hasAnyPermission(PerfisConstants.CADASTRAR_TECNICO_PERMISSOES) ||
      this.auth.hasAnyPermission(PerfisConstants.DETALHAR_TECNICO_PERMISSOES) ||
      this.auth.hasAnyPermission(PerfisConstants.EDITAR_TECNICO_PERMISSOES);
  }

  public hasAcessoAdministracaoFamilia(): boolean {
    return this.auth.hasAnyPermission(PerfisConstants.CONSULTAR_FAMILIA_PERMISSOES) ||
      this.auth.hasAnyPermission(PerfisConstants.CADASTRAR_FAMILIA_PERMISSOES) ||
      this.auth.hasAnyPermission(PerfisConstants.EDITAR_FAMILIA_PERMISSOES);
  }

  public hasAcessoAdministracaoCalendario(): boolean {
    return this.auth.hasAnyPermission(PerfisConstants.CADASTAR_FUNCIONAMENTO_MAQUINA);
  }

  public hasAcessoAdministracaoGerenciarEquipamentos(): boolean {
    return this.auth.hasAnyPermission(PerfisConstants.CONSULTAR_EQUIPAMENTO_PERMISSOES) ||
      this.auth.hasAnyPermission(PerfisConstants.CADASTRAR_EQUIPAMENTO_PERMISSOES) ||
      this.auth.hasAnyPermission(PerfisConstants.DETALHAR_EQUIPAMENTO_PERMISSOES) ||
      this.auth.hasAnyPermission(PerfisConstants.EDITAR_EQUIPAMENTO_PERMISSOES) ||
      this.auth.hasAnyPermission(PerfisConstants.CONSULTAR_GRUPO_SUBGRUPO_PERMISSOES) ||
      this.auth.hasAnyPermission(PerfisConstants.CADASTRAR_GRUPO_SUBGRUPO_PERMISSOES) ||
      this.auth.hasAnyPermission(PerfisConstants.REPLICAR_GRUPO_SUBGRUPO_PERMISSOES) ||
      this.auth.hasAnyPermission(PerfisConstants.DETALHAR_GRUPO_SUBGRUPO_PERMISSOES) ||
      this.auth.hasAnyPermission(PerfisConstants.EDITAR_GRUPO_SUBGRUPO_PERMISSOES);
  }

  public hasAcessoAdministracaoEquipamentos(): boolean {
    return this.auth.hasAnyPermission(PerfisConstants.CONSULTAR_EQUIPAMENTO_PERMISSOES) ||
      this.auth.hasAnyPermission(PerfisConstants.CADASTRAR_EQUIPAMENTO_PERMISSOES) ||
      this.auth.hasAnyPermission(PerfisConstants.DETALHAR_EQUIPAMENTO_PERMISSOES) ||
      this.auth.hasAnyPermission(PerfisConstants.EDITAR_EQUIPAMENTO_PERMISSOES);
  }

  public hasAcessoAdministracaoGruposSubgrupos(): boolean {
    return this.auth.hasAnyPermission(PerfisConstants.CONSULTAR_GRUPO_SUBGRUPO_PERMISSOES) ||
      this.auth.hasAnyPermission(PerfisConstants.CADASTRAR_GRUPO_SUBGRUPO_PERMISSOES) ||
      this.auth.hasAnyPermission(PerfisConstants.REPLICAR_GRUPO_SUBGRUPO_PERMISSOES) ||
      this.auth.hasAnyPermission(PerfisConstants.DETALHAR_GRUPO_SUBGRUPO_PERMISSOES) ||
      this.auth.hasAnyPermission(PerfisConstants.EDITAR_GRUPO_SUBGRUPO_PERMISSOES);
  }

  public hasAcessoManutencao(): boolean {
    return this.auth.hasAnyPermission(PerfisConstants.CONSULTAR_MANUTENCAO_CORRETIVA_PERMISSOES) ||
      this.auth.hasAnyPermission(PerfisConstants.CADASTRAR_MANUTENCAO_CORRETIVA_PERMISSOES) ||
      this.auth.hasAnyPermission(PerfisConstants.EDITAR_MANUTENCAO_CORRETIVA_PERMISSOES) ||
      this.auth.hasAnyPermission(PerfisConstants.DETALHAR_MANUTENCAO_CORRETIVA_PERMISSOES) ||
      this.auth.hasAnyPermission(PerfisConstants.CONSULTAR_INFORMACOES_PERMISSOES);
  }

  /* novas permissoes */

  public hasAcessoAdministracaoParametro(): boolean {
    return this.auth.hasAnyPermission(PerfisConstants.CONSULTAR_PARAMETRO_PERMISSOES) ||
      this.auth.hasAnyPermission(PerfisConstants.CADASTRAR_PARAMETRO_PERMISSOES) ||
      this.auth.hasAnyPermission(PerfisConstants.EDITAR_PARAMETRO_PERMISSOES) ||
      this.auth.hasAnyPermission(PerfisConstants.DETALHAR_PARAMETRO_PERMISSOES) ||
      this.auth.hasAnyPermission(PerfisConstants.DELETAR_PARAMETRO_PERMISSOES);
  }

  public hasAcessoAdministracaoAcao(): boolean {
    return this.auth.hasAnyPermission(PerfisConstants.CONSULTAR_ACAO_PERMISSOES) ||
      this.auth.hasAnyPermission(PerfisConstants.CADASTRAR_ACAO_PERMISSOES) ||
      this.auth.hasAnyPermission(PerfisConstants.EDITAR_ACAO_PERMISSOES) ||
      this.auth.hasAnyPermission(PerfisConstants.DETALHAR_ACAO_PERMISSOES);
  }

  public hasAcessoAdministracaoComponente(): boolean {
    return this.auth.hasAnyPermission(PerfisConstants.CONSULTAR_COMPONENTE_PERMISSOES) ||
      this.auth.hasAnyPermission(PerfisConstants.CADASTRAR_COMPONENTE_PERMISSOES) ||
      this.auth.hasAnyPermission(PerfisConstants.EDITAR_COMPONENTE_PERMISSOES) ||
      this.auth.hasAnyPermission(PerfisConstants.DETALHAR_COMPONENTE_PERMISSOES);
  }

  /*--------*/


  public hasParaAlocar(): boolean {
    return this.auth.hasAnyPermission(PerfisConstants.PARA_ALOCAR_PERMISSOES);
  }

  public hasConsultarAlocacao(): boolean {
    return this.auth.hasAnyPermission(PerfisConstants.CONSULTAR_ALOCACOES_PERMISSOES);
  }

  public hasAcessoAtividade(): boolean {
    return this.auth.hasAnyPermission(PerfisConstants.CONSULTAR_ATIVIDADES);
  }

  public hasAcessoAvaliarSolicitacao(): boolean {
    return this.auth.hasAnyPermission(PerfisConstants.AVALIAR_SOLICITACOES_PERMISSOES);
  }

  public hasAcessoAprovarSolicitacaoPreventivas(): boolean {
    return this.auth.hasAnyPermission(PerfisConstants.APROVAR_SOLICITACOES_PREVENTIVAS_PERMISSOES);
  }

  public hasAcessoCadastrarCorretivas(): boolean {
    return this.auth.hasAnyPermission(PerfisConstants.CADASTRAR_MANUTENCAO_CORRETIVA_PERMISSOES);
  }
  public hasAcessoCadastrarPreventivas(): boolean {
    return this.auth.hasAnyPermission(PerfisConstants.CADASTRAR_MANUTENCAO_PREVENTIVA);
  }

  public hasAcessoConsultarPreventivas(): boolean {
    return this.auth.hasAnyPermission(PerfisConstants.CONSULTAR_MANUTENCAO_PREVENTIVA_PERMISSOES);
  }

  public hasAcessoRelatorios(): boolean {
    return this.auth.hasAnyPermission(PerfisConstants.RELATORIOS_PERMISSOES);
  }

  public criarBreadcrumbAlocacao(isCorretiva: boolean) {
    this.breadcrumbService.clear();
    if (isCorretiva === true) {
      this.breadcrumbService.addRoute('/app/manutencao/consultar-manutencao-corretiva', 'Corretivas', true);
      this.breadcrumbService.addRoute('/app/alocacao/consultar', 'Alocações', false);
      this.breadcrumbService.addRoute('/app/alocacao/consultar', 'Consultar', false);
    } else if (isCorretiva === false) {      
      this.breadcrumbService.addRoute('/app/manutencao/preventiva/consultar', 'Preventivas', true);
      this.breadcrumbService.addRoute('/app/alocacao/consultar', 'Alocações', false);
      this.breadcrumbService.addRoute('/app/alocacao/consultar', 'Consultar', false);
    }
  }
  public criarBreadcrumbAtividade(isCorretiva: boolean) {
    this.breadcrumbService.clear();
    if (isCorretiva === true) {
      this.breadcrumbService.addRoute('/app/manutencao/consultar-manutencao-corretiva', 'Corretivas', true);
      this.breadcrumbService.addRoute('/app/manutencao/atividade/consultar-atividade', 'Atividades', false);
      this.breadcrumbService.addRoute('/app/manutencao/atividade/consultar-atividade', 'Consultar', false);
    } else if (isCorretiva === false) {
      this.breadcrumbService.addRoute('/app/manutencao/preventiva/consultar', 'Preventivas', true);
      this.breadcrumbService.addRoute('/app/manutencao/atividade/consultar-atividade', 'Atividades', false);
      this.breadcrumbService.addRoute('/app/manutencao/atividade/consultar-atividade', 'Consultar', false);
    }
  }
  public criarBreadcrumbInformacao(isCorretiva: boolean) {
    this.breadcrumbService.clear();
    if (isCorretiva === true) {
      this.breadcrumbService.addRoute('/app/manutencao/consultar-manutencao-corretiva', 'Corretivas', true);
      this.breadcrumbService.addRoute('/app/manutencao/atividade/consultar-atividade', 'Informações', false);
      this.breadcrumbService.addRoute('/app/manutencao/atividade/consultar-atividade', 'Consultar', false);

    } else if (isCorretiva === false) {
      this.breadcrumbService.addRoute('/app/manutencao/preventiva/consultar', 'Preventivas', true);
      this.breadcrumbService.addRoute('/app/manutencao/atividade/consultar-atividade', 'Informações', false);
      this.breadcrumbService.addRoute('/app/manutencao/atividade/consultar-atividade', 'Consultar', false);
    }
  }
}
