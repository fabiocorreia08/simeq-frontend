export class Pagina<T> {

  registros?: T[];
  tamanho?: number;
  totalDeRegistros?: number;
  primeiroRegistro?: number;
  campoOrdenacao?: string;
  ordem?: string;  

  constructor(primeiroRegistro: number = 0, tamanho: number = 10) {
    this.primeiroRegistro = primeiroRegistro;
    this.tamanho = tamanho;
  }
  
}
