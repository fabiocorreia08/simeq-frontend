export class LabelValue{
    label: string;
    value: any;

    public constructor(label: string, value: any) {
      this.label = label;
      this.value = value;
    }
}
