import {Component, OnInit} from "@angular/core";
import { Location } from "@angular/common";
@Component({
  selector: 'simeq-errorpage',
  templateUrl: 'errorpage.component.html',
  styleUrls: ['errorpage.component.css']
})
export class ErrorPageComponent implements OnInit {

  constructor(private _location : Location) { }

  ngOnInit() {
  }

  backPage() {
    this._location.back();
  }

}
