export class RankEquipamentoFiltro {
    public centroCustos?: string[] = [];
    public periodoInicio: Date ;
    public periodoFim: Date ;
}
