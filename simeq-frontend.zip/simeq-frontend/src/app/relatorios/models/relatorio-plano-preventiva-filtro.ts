import { PlanoPreventivaConsultaTabela } from "../../manutencao/models/plano-preventiva-consulta-tabela.model";

export class RelatorioPlanoPreventivaFiltro {
    public dataInicialFiltro: string;
    public dataFinalFiltro: string;    
    public dataInicial: string;
    public horaInicial: string;

    public numeroSolicitacao: string;    
    public idEquipamento: number; 
    public hierarquiaCentroCusto: string;
    
    public matricula: string;
    public qtdHoras: string;

    public grupoSubGrupos: string[] = [];
    
}
