export class GestaoEstrategicaFiltro {
    public centrosCusto: string[] = [];
    public dataInicial: string;
    public dataFinal: string;
}
