export class RelatorioManutencaoPreventivaFiltro {
    public centrosCusto = [];
    public ano: number;
}