export class RelatorioCapacidadeProdutivaFiltro {
    public codigoManutencao: string;
    public nomeEquipamento: string;
    public centrosCusto: string;
    public flagPreventiva: string = "null";
    public dataInicial: String;
    public dataFinal: String;
    public sofrePreventiva: string;
    public centroCustos: number [] = [];    
}
