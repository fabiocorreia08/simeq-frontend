import { Http } from '@angular/http';
import { Injectable } from '@angular/core';
import { AbstractResource } from '../../core/http/abstract.resource';
import { RelatorioCapacidadeProdutivaFiltro } from '../models/relatorio-capacidade-produtiva-filtro';
import { Observable } from 'rxjs';
import { RelatorioCapacidadeProdutivaComponent } from '../components/relatorio-capacidade-produtiva/relatorio-capacidade-produtiva.component';
import { Pagina } from '../../core/models/pagina.model';

@Injectable()
export class RelatorioService extends AbstractResource<any>{

    private baseEndPoint: string = "/relatorio";

    constructor(http: Http) {
        super(http, '');
    }

    public gerarRelatorioCapacidadeProdutiva(filtro: any) {
        return this.downloadQueryParams(`${this.baseEndPoint}/download-relatorio-capacidade-produtiva`, filtro);
    }

    public gerarRelatorioPreventivaAnual(filtro: any) {
        return this.downloadQueryParams(`${this.baseEndPoint}/download-relatorio-preventiva-anual`, filtro);
    }

    public gerarRelatorioGestaoEstrategica(filtro: any){
        return this.downloadQueryParams(`${this.baseEndPoint}/download-relatorio-gestao-estrategica`, filtro);
    }

    public gerarRelatorioPlanoPreventiva(filtro: any){        
        return this.downloadQueryParams(`${this.baseEndPoint}/download-relatorio-plano-preventiva`, filtro);
    }

}
