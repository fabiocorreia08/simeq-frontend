import { DatePipe } from '@angular/common';
import { ActivatedRoute } from '@angular/router';
import { LabelValue } from '.././../../core/models/label-value';
import { Component, OnInit } from '@angular/core';
import { BreadcrumbService } from '../../../core/breadcrumb/breadcrumb.service';
import { CalendarLocaleService } from '../../../core/calendar.locale.service';
import { isNullOrUndefined } from 'util';
import { GestaoEstrategicaFiltro } from '../../models/relatorio-gestao-estrategica-filtro';
import { RelatorioService } from '../../services/relatorio.service';
import { RelatorioGenericoComponent } from '../relatorio-generico.component';


@Component({
  selector: 'simeq-gestao-estrategica',
  templateUrl: './relatorio-gestao-estrategica.component.html',
  styleUrls: ['./relatorio-gestao-estrategica.component.scss']
})
export class RelatorioGestaoEstrategicaComponent extends RelatorioGenericoComponent implements OnInit {
  
  public centrosCustoOpcoes: LabelValue[] = [];
  public filtro: GestaoEstrategicaFiltro = new GestaoEstrategicaFiltro();

  filtrarCentrosCustos = false;

  dataInicial: Date;
  dataFinal: Date;

  constructor(
    private route: ActivatedRoute,
    private breadcrumbService: BreadcrumbService,
    private dataPipe: DatePipe,
    private relatorioService: RelatorioService,
    public calendarLocalService: CalendarLocaleService
  ) {
    super();
  }

  ngOnInit() {
    this.breadcrumbService.addRoute('/app/relatorios/relatorio-capacidade-produtiva', 'Relatórios', false);
    this.breadcrumbService.addRoute('/app/relatorios/relatorio-capacidade-produtiva', 'Gestão Estratégica', false);
    this.centrosCustoOpcoes = this.route.snapshot.data['centrosCustoResolve'];
  }

  public limparFiltros(): void {
    this.filtro = new GestaoEstrategicaFiltro();
    this.dataInicial = null;
    this.dataFinal = null;
  }

  public gerarRelatorio() {

    this.processarDatas();
    this.relatorioService.gerarRelatorioGestaoEstrategica(this.filtro).subscribe((blobResponse: Blob) => {
    });
  }

  private processarDatas() {
    this.filtro.dataInicial = this.dataPipe.transform(this.dataInicial, 'yyyy/MM/dd');
    this.filtro.dataFinal = this.dataPipe.transform(this.dataFinal, 'yyyy/MM/dd');
  }


  filtrarCC() {
    if (!this.filtrarCentrosCustos) {
      this.filtro.centrosCusto = [];
    }
  }

  desabilitarCC() {
    return !this.filtrarCentrosCustos;
  }

  public desabilitarBotaoRelatorio() {
    if (isNullOrUndefined(this.dataInicial) || isNullOrUndefined(this.dataFinal) || (this.dataFinal < this.dataInicial)) {
      return true;
    }
    if(this.filtrarCentrosCustos){
      return this.filtro.centrosCusto.length <= 0;
    }
    return false;
  }

}
