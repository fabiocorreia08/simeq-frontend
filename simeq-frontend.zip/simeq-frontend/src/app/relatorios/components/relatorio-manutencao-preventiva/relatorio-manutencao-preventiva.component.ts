import { isNullOrUndefined } from 'util';
import { RelatorioManutencaoPreventivaFiltro } from './../../models/relatorio-manutencao-preventiva-filtro ';
import { ActivatedRoute } from '@angular/router';
import { ArrayUtil } from '../../../shared/Utils/ArrayUtil';
import { LabelValue } from '../../../core/models/label-value';
import { Component, OnInit } from '@angular/core';
import { BreadcrumbService } from '../../../core/breadcrumb/breadcrumb.service';
import { RelatorioService } from '../../services/relatorio.service';
import { RelatorioGenericoComponent } from '../relatorio-generico.component';

@Component({
  selector: 'simeq-relatorio-manutencao-preventiva',
  templateUrl: './relatorio-manutencao-preventiva.component.html',
  styleUrls: ['./relatorio-manutencao-preventiva.component.scss']
})
export class RelatorioManutencaoPreventivaComponent extends RelatorioGenericoComponent implements OnInit {

  public listaAnos: LabelValue[] = [];
  public centrosCustoOpcoes: LabelValue[] = [];
  public filtro: RelatorioManutencaoPreventivaFiltro = new RelatorioManutencaoPreventivaFiltro();
  public filtrarCentrosCustos = false;

  constructor(
    private route: ActivatedRoute,
    private breadcrumbService: BreadcrumbService,
    private relatorioService: RelatorioService
  ) {
    super();
  }

  ngOnInit() {
    this.breadcrumbService.addRoute('/app/relatorios/relatorio-manutencao-preventiva', 'Relatórios', false);
    this.breadcrumbService.addRoute('/app/relatorios/relatorio-manutencao-preventiva', 'Manutenção Preventiva Anual', false);
    this.carregarAno();
    this.centrosCustoOpcoes = this.route.snapshot.data['centrosCustoResolve'];
  }

  public carregarAno(): void {
    let dataAtual = new Date();
    this.listaAnos.push(new LabelValue((dataAtual.getFullYear() - 1).toString(), (dataAtual.getFullYear() - 1)));
    this.listaAnos.push(new LabelValue(dataAtual.getFullYear().toString(), dataAtual.getFullYear()));
    this.listaAnos.push(new LabelValue((dataAtual.getFullYear() + 1).toString(), (dataAtual.getFullYear() + 1)));
    this.listaAnos = ArrayUtil.adicionarPrimeiroValor(this.listaAnos, 'Selecione', null);
  }

  public limparFiltros(): void {
    this.filtro = new RelatorioManutencaoPreventivaFiltro();
  }

  public gerarRelatorio() {
    this.relatorioService.gerarRelatorioPreventivaAnual(this.filtro)
    .subscribe((blobResponse: Blob) => {});
  }

  filtrarCC(){
    if(!this.filtrarCentrosCustos){
      this.filtro.centrosCusto = [];
    }
  }

  desabilitarCC(){
    return !this.filtrarCentrosCustos;
  }

  public desabilitarBotaoRelatorio() {
    if(isNullOrUndefined(this.filtro.ano)) {
      return true;
    }
    if(this.filtrarCentrosCustos){
      return this.filtro.centrosCusto.length <= 0;
    }
    return false;
  }
}