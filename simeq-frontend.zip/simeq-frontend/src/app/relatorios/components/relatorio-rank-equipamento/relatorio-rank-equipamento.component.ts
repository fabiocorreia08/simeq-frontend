import { ActivatedRoute } from '@angular/router';
import { LabelValue } from '.././../../core/models/label-value';
import { Component, OnInit } from '@angular/core';
import { BreadcrumbService } from '../../../core/breadcrumb/breadcrumb.service';
import { RankEquipamentoFiltro } from '../../models/relatorio-rank-equipamento-filtro';
import { CalendarLocaleService } from '../../../core/calendar.locale.service';
import { isNullOrUndefined } from 'util';
import { ManutencaoCorretivaService } from '../../../manutencao/services/manutencao-corretiva.service';
import { RelatorioGenericoComponent } from '../relatorio-generico.component';

@Component({
  selector: 'simeq-rank-equipamento',
  templateUrl: './relatorio-rank-equipamento.component.html',
  styleUrls: ['./relatorio-rank-equipamento.component.scss']
})
export class RelatorioRankEquipamentoComponent extends RelatorioGenericoComponent  implements OnInit {
  public listaCentroCusto: LabelValue[] = [];
  public filtro: RankEquipamentoFiltro = new RankEquipamentoFiltro();

  constructor(
    private route: ActivatedRoute,
    private breadcrumbService: BreadcrumbService,
    public calendarLocaleService: CalendarLocaleService,
    private manutencaoCorretivaService: ManutencaoCorretivaService
  ) {
    super();
   }

  ngOnInit() {
    this.breadcrumbService.addRoute('/app/relatorios/rank-equipamento', 'Relatórios', false);
    this.breadcrumbService.addRoute('/app/relatorios/rank-equipamento', 'Ranking de Equipamentos', false);
    this.listaCentroCusto = this.route.snapshot.data['centrosCustoResolve'];
  }

  public limparFiltros(): void {
    this.filtro = new RankEquipamentoFiltro();
  }

  public gerarRelatorio(){
      this.manutencaoCorretivaService.buscarRelatorioRankEquipamento(this.filtro)
      .subscribe((retorno) => {});    
  }

  public desabilitarBotaoRelatorio() {
    if(this.filtro.centroCustos.length <= 0
    || isNullOrUndefined(this.filtro.periodoInicio)
    || isNullOrUndefined(this.filtro.periodoFim)) {
      return true;
    }
    return false;
  }
    

}
