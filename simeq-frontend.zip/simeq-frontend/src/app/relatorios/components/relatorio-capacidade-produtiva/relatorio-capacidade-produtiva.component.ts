import { isNullOrUndefined } from 'util';
import { LabelValue } from './../../../core/models/label-value';
import { ActivatedRoute } from '@angular/router';
import { BreadcrumbService } from './../../../core/breadcrumb/breadcrumb.service';
import { Component, OnInit } from '@angular/core';
import { RelatorioCapacidadeProdutivaFiltro } from '../../models/relatorio-capacidade-produtiva-filtro';
import { RelatorioService } from '../../services/relatorio.service';
import { MessagesService } from '../../../core/messages/messages.service';
import { CalendarLocaleService } from '../../../core/calendar.locale.service';
import { DatePipe } from '@angular/common';
import { RelatorioGenericoComponent } from '../relatorio-generico.component';
import { SituacaoEquipamento } from '../../../manutencao/enums/situacao-equipamento.enum';

@Component({
  selector: 'simeq-relatorio-capacidade-produtiva',
  templateUrl: './relatorio-capacidade-produtiva.component.html',
  styleUrls: ['./relatorio-capacidade-produtiva.component.scss']
})
export class RelatorioCapacidadeProdutivaComponent extends RelatorioGenericoComponent implements OnInit {

  private dataMesAno = { ano: new Date().getFullYear(), mes: new Date().getMonth() };
  public centrosCustoOpcoes: LabelValue[] = [];
  public filtro: RelatorioCapacidadeProdutivaFiltro = new RelatorioCapacidadeProdutivaFiltro();
  public pt = this.calendarLocalService.pt_BR;
  filtrarCentrosCustos = false;
  filtrarPreventivas = false;

  dataInicial: Date;
  dataFinal: Date;

  constructor(private messagesService: MessagesService,
    private route: ActivatedRoute,
    private breadcrumbService: BreadcrumbService,
    private dataPipe: DatePipe,
    private relatorioService: RelatorioService,
    private calendarLocalService: CalendarLocaleService
  ) {
    super();
  }

  ngOnInit() {
    this.breadcrumbService.addRoute('/app/relatorios/relatorio-capacidade-produtiva', 'Relatórios', false);
    this.breadcrumbService.addRoute('/app/relatorios/relatorio-capacidade-produtiva', 'Capacidade Produtiva de Equipamento', false);
    this.centrosCustoOpcoes = this.route.snapshot.data['centrosCustoResolve'];
  }

  public limparFiltros(): void {
    this.filtro = new RelatorioCapacidadeProdutivaFiltro();
    this.dataInicial = null;
    this.dataFinal = null;
  }

  public gerarRelatorio() {
      this.processarDatas();
      this.relatorioService
      .gerarRelatorioCapacidadeProdutiva(null)
      .subscribe((blobResponse: Blob) => {});
  }

  private processarDatas() {
    this.filtro.dataInicial = this.dataPipe.transform(this.dataInicial, 'yyyy/MM/dd');
    this.filtro.dataFinal = this.dataPipe.transform(this.dataFinal, 'yyyy/MM/dd');
  
  }

  filtrarCC(){    
    if(!this.filtrarCentrosCustos){
      this.filtro.centroCustos = [];
    }
  }

  desabilitarCC(){
    return !this.filtrarCentrosCustos;
  }


  public desabilitarBotaoRelatorio() {
    if (isNullOrUndefined(this.dataInicial) || isNullOrUndefined(this.dataFinal) || (this.dataFinal < this.dataInicial)) {
      return true;
    }
    if(this.filtrarCentrosCustos){
      return this.filtro.centroCustos.length <= 0;
    }
    return false;
  }

  filtrarPreventiva(){ 

    if(this.filtrarPreventivas){
      this.filtro.sofrePreventiva = 'S';
    }else{
      this.filtro.sofrePreventiva = 'N';
    }    

  }

  public validaSituacaoEquipamento(): number{
    return SituacaoEquipamento.VERDE;    
  }

}
