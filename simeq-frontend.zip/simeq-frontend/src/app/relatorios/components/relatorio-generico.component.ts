export class RelatorioGenericoComponent {
    
    public readonly MAXIMO_CENTROS_CUSTO_SELECIONADOS: number = 15;

    public onChangeCentroCustos(listaCentrosCusto: string[]) {
        if (listaCentrosCusto.length > this.MAXIMO_CENTROS_CUSTO_SELECIONADOS) {
            listaCentrosCusto.splice(listaCentrosCusto.length - 1, 1);
        }
    }
}