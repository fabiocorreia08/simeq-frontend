import { RelatorioService } from './services/relatorio.service';
import { RelatorioManutencaoPreventivaComponent } from './components/relatorio-manutencao-preventiva/relatorio-manutencao-preventiva.component';
import { RelatorioCapacidadeProdutivaComponent } from './components/relatorio-capacidade-produtiva/relatorio-capacidade-produtiva.component';
import { CoreModule } from './../core/core.module';
import { MultiSelectModule, DropdownModule, CalendarModule } from 'primeng/primeng';
import { SharedModule } from './../shared/shared.module';
import { FormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RelatoriosRoutingModule } from './relatorios-routing.module';
import { CentroCustoService } from '../shared/services/centro-custo.service';
import { BuscaCentrosCustoResolve } from '../shared/resolves/busca-centros-custo.resolve';
import { RelatorioRankEquipamentoComponent } from './components/relatorio-rank-equipamento/relatorio-rank-equipamento.component';
import { RelatorioGestaoEstrategicaComponent } from './components/relatorio-gestao-estrategica/relatorio-gestao-estrategica.component';


@NgModule({
  declarations: [
    RelatorioManutencaoPreventivaComponent,
    RelatorioRankEquipamentoComponent,
    RelatorioGestaoEstrategicaComponent,
    RelatorioCapacidadeProdutivaComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    SharedModule,
    CoreModule,
    MultiSelectModule,
    RelatoriosRoutingModule,
    DropdownModule,
    CalendarModule
  ],
  providers: [
    CentroCustoService,
    BuscaCentrosCustoResolve,
    RelatorioService
  ]
})
export class RelatoriosModule { }
