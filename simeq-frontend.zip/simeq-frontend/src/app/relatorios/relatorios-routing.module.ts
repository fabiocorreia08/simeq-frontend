import { RelatorioManutencaoPreventivaComponent } from './components/relatorio-manutencao-preventiva/relatorio-manutencao-preventiva.component';
import { BuscaCentrosCustoResolve } from './../shared/resolves/busca-centros-custo.resolve';
import { NgModule } from '@angular/core';
import { MainComponent } from './../main/main.component';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuard } from '../core/security/auth.guard';
import { PerfisConstants } from '../core/security/perfis.constants';
import { RelatorioRankEquipamentoComponent } from './components/relatorio-rank-equipamento/relatorio-rank-equipamento.component';
import { RelatorioGestaoEstrategicaComponent } from './components/relatorio-gestao-estrategica/relatorio-gestao-estrategica.component';
import { RelatorioCapacidadeProdutivaComponent } from './components/relatorio-capacidade-produtiva/relatorio-capacidade-produtiva.component';

const routes: Routes = [
  {
    path: 'app', component: MainComponent,
    children: [
      {
        path: 'relatorios/relatorio-manutencao-preventiva',
        component: RelatorioManutencaoPreventivaComponent,
        canActivate: [AuthGuard],
        data: { funcionalidade: PerfisConstants.RELATORIOS_PERMISSOES },
        resolve: {
          centrosCustoResolve: BuscaCentrosCustoResolve,
        }
      },
      {
        path: 'relatorios/relatorio-rank-equipamento',
        component: RelatorioRankEquipamentoComponent,
        canActivate: [AuthGuard],
        data: { funcionalidade: PerfisConstants.RELATORIOS_PERMISSOES },
        resolve: {
          centrosCustoResolve: BuscaCentrosCustoResolve,
        }
      },
      {
        path: 'relatorios/relatorio-gestao-estrategica',
        component: RelatorioGestaoEstrategicaComponent,
        canActivate: [AuthGuard],
        data: { funcionalidade: PerfisConstants.RELATORIOS_PERMISSOES },
        resolve: {
          centrosCustoResolve: BuscaCentrosCustoResolve,
        }
      },
      {
        path: 'relatorios/relatorio-capacidade-produtiva',
        component: RelatorioCapacidadeProdutivaComponent,
        canActivate: [AuthGuard],
        data: { funcionalidade: PerfisConstants.RELATORIOS_PERMISSOES },
        resolve: {
          centrosCustoResolve: BuscaCentrosCustoResolve,
        }
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class RelatoriosRoutingModule { }
