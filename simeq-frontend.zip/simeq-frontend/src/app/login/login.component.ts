import { Component, OnInit } from "@angular/core";
import { Router } from "@angular/router";
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import { environment } from "../../environments/environment";
import { MessagesService } from "../core/messages/messages.service";
import { AuthenticationService } from '../core/security/auth.service';
import { LoadingIndicatorService } from '../core/loading-indicator/loading-indicator.service';
import { Ng2Storage } from "../core/security/ng2-storage";

declare var startLogin;

@Component({
  selector: 'simeq-login',
  templateUrl: 'login.component.html',
  styleUrls: ['login.component.css']
})
export class LoginComponent implements OnInit {
  error: boolean = false;
  environment: any = environment;
  loginForm: FormGroup;
  private storage: Ng2Storage = new Ng2Storage(localStorage);

  constructor(private fb: FormBuilder,
    private router: Router,
    private msgService: MessagesService,
    private authService: AuthenticationService,
    private loadingIndicatorService: LoadingIndicatorService) {

    this.loginForm = this.fb.group({
      username: ['', Validators.required],
      password: ['', Validators.required]
    })

  }

  ngOnInit() {    
    localStorage.clear();
  }

  showIndicator() {
    this.loadingIndicatorService.show();
  }

  hideIndicator() {
    this.loadingIndicatorService.hide();
  }

  login(event) {
    
    event.preventDefault();
    this.msgService.clear();
    this.storage.clearAll();    
    
    const formValue = this.loginForm.value;
    if(this.validarObrigatoriedade()) {      
      this.authService.login(formValue.username, formValue.password)
        .subscribe((user) => {          
          this.router.navigate(['/app/home']);
        },(error) => {          
          this.msgService.addErrorMessage(error);
        })
    }
  }

  validarObrigatoriedade() {
    
    let valido = true;
    if(!this.loginForm.value.username || !this.loginForm.value.password) {
      valido = false;
      this.msgService.addErrorMessage(`Falta informação obrigatória. Por favor, informe o 'Usuário' e a 'Senha'.`);
    }

    return valido;
  }

  private redirecionarUsuarioInativoOuSuspensoInatividade(username) {
  }

}
