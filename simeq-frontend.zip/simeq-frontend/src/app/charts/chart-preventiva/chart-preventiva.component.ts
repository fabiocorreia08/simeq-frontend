import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { BehaviorSubject, Subject } from 'rxjs';
import { LoadingIndicatorService } from '../../core/loading-indicator/loading-indicator.service';
import { AuthenticationService } from '../../core/security/auth.service';
import { StatusPreventivaService } from '../../manutencao/services/status-preventiva.service';
import { DashboardDTO } from '../../shared/models/dashboardDTO.model';
import { DashboardVO } from '../../shared/models/dashboardVO.model';

@Component({
  selector: 'simeq-chart-preventiva',
  templateUrl: './chart-preventiva.component.html',
  styleUrls: ['./chart-preventiva.component.css']
})
export class ChartPreventivaComponent implements OnInit {

  public isPerfilVisitante = false;
  manutencaoStatusData: any[] = [];  
  public readonly VISITANTE: number = 6;
  centrosCustos: string[] = [];
  dashboardList: DashboardDTO[] = [];
  private emissor$: Subject<Boolean> = new Subject<Boolean>();
  ordem: number[] = [1, 2, 3, 4, 5, 8, 9]; 
  private loaderStatusSubject = new BehaviorSubject<boolean>(true);
  visible: boolean = false;

  view = [990, 300];
  colorScheme = {    
    domain: ['#FF0000', '#FFFF00', '#008000', '#0D77CA', '#0000FF', '#A020F0', '#00008B', '#8EC641', '#808080', '#F05624']
  }

  constructor(
    private authService: AuthenticationService,
    public auth: AuthenticationService,
    private statusService: StatusPreventivaService,
    private loadingIndicatorService: LoadingIndicatorService,
    private route: ActivatedRoute,
    private router: Router
  ) { 
    this.centrosCustos = this.route.snapshot.data['centrosCustoUsuarioLogadoResolve'];
    this.loadingIndicatorService.show();
    this.loaderStatusSubject
      .subscribe(visible => {
        this.visible = visible
      });
  }

  ngOnInit() {        
    let usuario = this.authService.getAuthenticatedUser();
    this.isPerfilVisitante = this.auth.getPerfil(this.VISITANTE);
    this.manutencaoStatusData = [];    
    this.statusService.buscarDashboardPreventiva(new DashboardVO(this.centrosCustos, usuario.details.matricula, this.authService.getIdPerfil(this.authService.authInfo.details.perfis)))
      .subscribe(response => {         
        this.dashboardList = response;
        while (this.dashboardList.length === 0) {
          if (this.dashboardList.length > 0) {            
            this.emissor$.next(true);
          }
        }
        this.emissor$.next(true);
      })

    this.emissor$.subscribe(
      (emit) => {
        if (emit) {
          let arr = this.dashboardList;   
          this.mudarPosicao(arr, 7, 2);       
          arr.forEach(status => {            
            this.ordem.forEach(ordem => {
              if (ordem === status.idStatus) {
                this.manutencaoStatusData.push({
                  name: status.nomeStatus,
                  value: status.total
                })
              }
            })
          });
          this.loaderStatusSubject.next(false);
          this.loadingIndicatorService.hide();
        }
      }); 
  }

  mudarPosicao(arr: any[], from: any, to: any){
    arr.splice(to, 0, arr.splice(from, 1)[0]);
    return arr;
  }

  click(statusName: string) {
    let status: DashboardDTO;    
    if (statusName.length > 18) {
      status = this.dashboardList.filter(item => item.nomeStatus.slice(0, 18) === statusName.slice(0, 18))[0];
    } else {
      status = this.dashboardList.filter(item => item.nomeStatus === statusName)[0];
    }
    this.router.navigate([`/app/manutencao/preventiva/consultar/${status.idStatus}`]);
  } 

}
