import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { BehaviorSubject, Subject, Subscription } from 'rxjs';
import { LoadingIndicatorService } from '../../core/loading-indicator/loading-indicator.service';
import { AuthenticationService } from '../../core/security/auth.service';
import { StatusManutencaoCorretivaService } from '../../manutencao/services/status-manutencao.service';
import { DashboardDTO } from '../../shared/models/dashboardDTO.model';
import { DashboardVO } from '../../shared/models/dashboardVO.model';
import { interval } from "rxjs/observable/interval";
import { ManutencaoCorretivaService } from '../../manutencao/services/manutencao-corretiva.service';
import { timer } from 'rxjs/observable/timer';

declare var $: any;

@Component({
  selector: 'simeq-chart-corretiva',
  templateUrl: './chart-corretiva.component.html',
  styleUrls: ['./chart-corretiva.component.css']
})
export class ChartCorretivaComponent implements OnInit {

  public isPerfilVisitante = false;
  manutencaoStatusData: any[] = [];  
  public readonly VISITANTE: number = 6;
  centrosCustos: string[] = [];
  dashboardList: DashboardDTO[] = [];
  private emissor$: Subject<Boolean> = new Subject<Boolean>();
  ordem: number[] = [1, 2, 4, 5, 8, 10]; 
  private loaderStatusSubject = new BehaviorSubject<boolean>(true);
  visible: boolean = false;
  
  view = [990, 300];
  colorScheme = {    
    domain: ['#FF0000', '#FFFF00', '#008000', '#0D77CA', '#0000FF', '#A020F0', '#00008B', '#8EC641', '#808080', '#F05624']
  }

  private updateSubscription: Subscription;  

  constructor(
    private authService: AuthenticationService,
    public auth: AuthenticationService,
    private statusService: StatusManutencaoCorretivaService,
    private route: ActivatedRoute,
    private loadingIndicatorService: LoadingIndicatorService,
    private router: Router    
  ) { 
    this.centrosCustos = this.route.snapshot.data['centrosCustoUsuarioLogadoResolve'];
    this.loadingIndicatorService.show();
    this.loaderStatusSubject
      .subscribe(visible => {
        this.visible = visible
      });
  }

  ngOnInit() {  
    this.carregarChart();    
  }

  carregarChart(){       
    let usuario = this.authService.getAuthenticatedUser();
    this.isPerfilVisitante = this.auth.getPerfil(this.VISITANTE);
    this.manutencaoStatusData = [];    
    this.statusService.buscarDashboard(new DashboardVO(this.centrosCustos, usuario.details.matricula, this.authService.getIdPerfil(this.authService.authInfo.details.perfis)))
      .subscribe(response => {         
        this.dashboardList = response;
        while (this.dashboardList.length === 0) {
          if (this.dashboardList.length > 0) {            
            this.emissor$.next(true);
          }
        }
        this.emissor$.next(true);
      })

    this.emissor$.subscribe(
      (emit) => {
        if (emit) {
          let arr = this.dashboardList;
          this.mudarPosicao(arr, 7, 2);
          arr.forEach(status => {            
            this.ordem.forEach(ordem => {
              if (ordem === status.idStatus) {
                this.manutencaoStatusData.push({
                  name: status.nomeStatus,
                  value: status.total
                })
              }
            })
          });
          this.loaderStatusSubject.next(false);
          this.loadingIndicatorService.hide();
        }
      });  

  }

  mudarPosicao(arr: any[], from: any, to: any){
    arr.splice(to, 0, arr.splice(from, 1)[0]);
    return arr;
  }

  click(statusName: string) {
    let status: DashboardDTO;    
    if (statusName.length > 18) {
      status = this.dashboardList.filter(item => item.nomeStatus.slice(0, 18) === statusName.slice(0, 18))[0];
    } else {
      status = this.dashboardList.filter(item => item.nomeStatus === statusName)[0];
    }
    this.router.navigate([`/app/manutencao/consultar-manutencao-corretiva/${status.idStatus}`]);
  } 

}
