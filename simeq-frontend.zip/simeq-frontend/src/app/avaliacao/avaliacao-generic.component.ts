import { MessagesService } from "../core/messages/messages.service";
import { GenericComponent } from "../shared/components/generic.component";

export class AvaliacaoGenericComponent extends GenericComponent {

    constructor(protected messagesService: MessagesService) {
        super(messagesService);
    }
}