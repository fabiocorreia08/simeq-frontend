import { SharedModule } from './../../shared/shared.module';
import { NgModule } from '@angular/core';
import { AvaliacaoSolicitacaoRoutingModule } from './avaliacao-solicitacao-routing.module';
import { InputMaskModule, DataTableModule, DropdownModule, InputTextareaModule, CheckboxModule, CalendarModule } from 'primeng/primeng';
import { FormsModule } from '@angular/forms';
import { CoreModule } from '../../core/core.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ButtonModule } from 'primeng/components/button/button';
import { AvaliarSolicitacaoComponent } from './components/avaliar-solicitacao/avaliar-solicitacao.component';
import { TextMaskModule } from "angular2-text-mask";
import { AvaliacaoSolicitacaoService } from './services/avaliacao-solicitacao.service';

@NgModule({
    declarations: [
        AvaliarSolicitacaoComponent
    ],
    imports: [
        AvaliacaoSolicitacaoRoutingModule,
        FormsModule,
        BrowserAnimationsModule,
        ButtonModule,
        CoreModule,
        InputMaskModule,
        InputTextareaModule,
        DataTableModule,
        DropdownModule,
        CalendarModule,
        CheckboxModule,
        TextMaskModule,
        SharedModule
    ],

    providers: [
        AvaliacaoSolicitacaoService
    ]
})
export class AvaliacaoSolicitacaoModule {}
