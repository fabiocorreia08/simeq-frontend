import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MainComponent } from '../../main/main.component';
import { AvaliarSolicitacaoComponent } from './components/avaliar-solicitacao/avaliar-solicitacao.component';
import { AuthGuard } from '../../core/security/auth.guard';
import { AuthenticationService } from '../../core/security/auth.service';
import { PerfisConstants } from '../../core/security/perfis.constants';

const routes: Routes = [
    { path: 'app', component: MainComponent,
        children: [
            { 
                path: 'avaliacao/avaliar-solicitacao', 
                component: AvaliarSolicitacaoComponent,
                canActivate: [AuthGuard],
                data: {funcionalidade: PerfisConstants.AVALIAR_SOLICITACOES_PERMISSOES},
                resolve: {
                }
            }
        ]
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class AvaliacaoSolicitacaoRoutingModule { }