export class AvaliacaoManutencaoCorretivaDTO {
    id: number;
    classeManutencao: string;
    numeroSolicitacao: string;
    descricaoStatus: string;
    dataAlteracao: string;
    codigoManutencao: string;
    centroCustoInstalacao: string;
    dataCadastro: string;
}