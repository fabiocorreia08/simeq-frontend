export class AprovacaoReprovacaoManutencaoCorretivaDTO {
    ids: number[];
    motivo: string;
    matriculaUsuarioLogado: string;
}