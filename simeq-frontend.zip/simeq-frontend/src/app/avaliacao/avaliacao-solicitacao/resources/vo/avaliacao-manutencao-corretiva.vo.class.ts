export class AvaliacaoManutencaoCorretivaVO{
    matriculaUsuarioLogado: string;
    perfisUsuarioLogado: number[];
}

