import { Observable } from 'rxjs/Observable';
import { Http } from '@angular/http';
import { Injectable } from '@angular/core';
import { AbstractResource } from '../../../core/http/abstract.resource';
import { Pagina } from '../../../core/models/pagina.model';
import { AvaliacaoManutencaoCorretivaDTO } from '../resources/dtos/avaliacao-manutencao-corretiva.dto';
import { AprovacaoReprovacaoManutencaoCorretivaDTO } from '../resources/dtos/aprovacao-reprovacao-manutencao-corretiva.dto';
import { AvaliacaoManutencaoCorretivaVO } from '../resources/vo/avaliacao-manutencao-corretiva.vo.class';

@Injectable()
export class AvaliacaoSolicitacaoService extends AbstractResource<any>{

  private baseEndPoint: string = "/avaliacao-solicitacao";

  constructor(http: Http) {
    super(http, '');
  }

  public filtrar(filtro: AvaliacaoManutencaoCorretivaVO, params?: any): Observable<Pagina<AvaliacaoManutencaoCorretivaDTO>> {
    return super.filter(this.baseEndPoint + '/filtrar', filtro, params);
  }

  public aprovar(aprovacaoReprovacaoManutencaoCorretivaDTO: AprovacaoReprovacaoManutencaoCorretivaDTO) {
    return super.post(this.baseEndPoint + '/aprovar', aprovacaoReprovacaoManutencaoCorretivaDTO);
  }

  public reprovar(aprovacaoReprovacaoManutencaoCorretivaDTO: AprovacaoReprovacaoManutencaoCorretivaDTO) {
    return super.post(this.baseEndPoint + '/reprovar', aprovacaoReprovacaoManutencaoCorretivaDTO);
  }

  public enviarEmailAprovacao(aprovacaoReprovacaoManutencaoCorretivaDTO: AprovacaoReprovacaoManutencaoCorretivaDTO) {
    return super.post(this.baseEndPoint + '/enviar-email-aprovacao', aprovacaoReprovacaoManutencaoCorretivaDTO);
  }

  public enviarEmailReprovacao(aprovacaoReprovacaoManutencaoCorretivaDTO: AprovacaoReprovacaoManutencaoCorretivaDTO) {
    return super.post(this.baseEndPoint + '/enviar-email-reprovacao', aprovacaoReprovacaoManutencaoCorretivaDTO);
  }
}
