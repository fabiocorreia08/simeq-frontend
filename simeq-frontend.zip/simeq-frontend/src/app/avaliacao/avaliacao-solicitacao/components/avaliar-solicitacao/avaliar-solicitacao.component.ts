import { CalendarLocaleService } from '../../../../core/calendar.locale.service';
import { Component, OnInit } from '@angular/core';
import { BreadcrumbService } from '../../../../core/breadcrumb/breadcrumb.service';
import { Location } from '@angular/common';
import { MessagesService } from '../../../../core/messages/messages.service';
import { ActivatedRoute } from '@angular/router';
import { AvaliacaoGenericComponent } from '../../../avaliacao-generic.component';
import { AuthenticationService } from '../../../../core/security/auth.service';
import { Pagina } from '../../../../core/models/pagina.model';
import { AvaliacaoManutencaoCorretivaDTO } from '../../resources/dtos/avaliacao-manutencao-corretiva.dto';
import { AvaliacaoManutencaoCorretivaVO } from '../../resources/vo/avaliacao-manutencao-corretiva.vo.class';
import { LazyLoadEvent } from 'primeng/components/common/api';
import { AvaliacaoSolicitacaoService } from '../../services/avaliacao-solicitacao.service';
import { AprovacaoReprovacaoManutencaoCorretivaDTO } from '../../resources/dtos/aprovacao-reprovacao-manutencao-corretiva.dto';
import { isNullOrUndefined } from 'util';
import { PerfisConstants } from '../../../../core/security/perfis.constants';

declare var $: any;

@Component({
  selector: 'simeq-avaliar-solicitacao',
  templateUrl: './avaliar-solicitacao.component.html',
  styleUrls: ['./avaliar-solicitacao.component.scss']
})
export class AvaliarSolicitacaoComponent extends AvaliacaoGenericComponent implements OnInit {

  private divModalMotivoReprovacao: any;

  private filtro: AvaliacaoManutencaoCorretivaVO = new AvaliacaoManutencaoCorretivaVO();
  public pagina: Pagina<AvaliacaoManutencaoCorretivaDTO> = new Pagina<AvaliacaoManutencaoCorretivaDTO>();
  public solicitacoesSelecionadas: AvaliacaoManutencaoCorretivaDTO[] = [];
  public aprovacaoReprovacaoManutencaoCorretiva: AprovacaoReprovacaoManutencaoCorretivaDTO = new AprovacaoReprovacaoManutencaoCorretivaDTO();

  constructor(breadcrumbService: BreadcrumbService,
    protected messagesService: MessagesService,
    private route: ActivatedRoute,
    private location: Location,
    public calendarLocaleService: CalendarLocaleService,
    public authenticationService: AuthenticationService,
    public avaliacaoSolicitacaoService: AvaliacaoSolicitacaoService,
  ) {
    super(messagesService);
    breadcrumbService.addRoute('/app/manutencao/consultar-manutencao-corretiva', 'Corretivas', true);
    breadcrumbService.addRoute('/app/avaliacao/avaliar-solicitacao', 'Aprovar Manutenções', false);
    // breadcrumbService.addRoute('/app/avaliacao/avaliar-solicitacao', 'Para Aprovar', false);
  }

  ngOnInit() {
    this.filtro.matriculaUsuarioLogado = this.authenticationService.authInfo.username;
    this.adicionarPerfisUsuarioLogado();
    this.pesquisar();
  }

  private adicionarPerfisUsuarioLogado() {
    this.filtro.perfisUsuarioLogado = [];
    this.authenticationService.authInfo.details.perfis.forEach(perfil => {
      this.filtro.perfisUsuarioLogado.push(perfil.id_perfil);
    });
  }

  private pesquisar() {
    this.pagina = new Pagina();
    this.filtrar();
  }

  public filtrar(): void {
    this.avaliacaoSolicitacaoService.filtrar(this.filtro, this.pagina)
      .subscribe((pagina) => {
        this.pagina = pagina;
      },
      (error) => {
        this.messagesService.addErrorMessage(error);
      });
  }

  public paginar(event: LazyLoadEvent): void {
    this.pagina = new Pagina<AvaliacaoManutencaoCorretivaDTO>(event.first, event.rows);
    this.filtrar();
  }

  public aprovar() {
    this.beforeAprovarReprovar();
    this.avaliacaoSolicitacaoService.aprovar(this.aprovacaoReprovacaoManutencaoCorretiva).subscribe(codigo => {
      this.messagesService.addSuccessMessage("Avaliação de solicitação aprovada com sucesso.");
      this.divModalMotivoReprovacao = $('#id-modal-motivo-reprovacao').modal('hide');
      this.resetar();
      this.avaliacaoSolicitacaoService.enviarEmailAprovacao(this.aprovacaoReprovacaoManutencaoCorretiva).subscribe(() => {
      }, error => {
        this.messagesService.addErrorMessage(error);        
      });
    }, error => {
      this.messagesService.addErrorMessage(error);
    });
  }

  public reprovar() {
    this.beforeAprovarReprovar();
    if(this.validarCamposObrigatorios()) {
      this.avaliacaoSolicitacaoService.reprovar(this.aprovacaoReprovacaoManutencaoCorretiva).subscribe(codigo => {
        this.messagesService.addSuccessMessage("Avaliação de solicitação reprovada com sucesso.");
        this.divModalMotivoReprovacao = $('#id-modal-motivo-reprovacao').modal('hide');
        this.resetar();
        this.avaliacaoSolicitacaoService.enviarEmailReprovacao(this.aprovacaoReprovacaoManutencaoCorretiva).subscribe(() => {
        }, error => {
          this.messagesService.addErrorMessage(error);
        });
      }, error => {
        this.messagesService.addErrorMessage(error);
      });
    }
  }

  private beforeAprovarReprovar() {
    this.aprovacaoReprovacaoManutencaoCorretiva.ids = [];
    this.aprovacaoReprovacaoManutencaoCorretiva.motivo = !isNullOrUndefined(this.aprovacaoReprovacaoManutencaoCorretiva.motivo) ? this.aprovacaoReprovacaoManutencaoCorretiva.motivo.toLocaleUpperCase() : undefined;
    this.aprovacaoReprovacaoManutencaoCorretiva.matriculaUsuarioLogado = this.authenticationService.authInfo.username;
    this.solicitacoesSelecionadas.forEach(solicitacao => {
      this.aprovacaoReprovacaoManutencaoCorretiva.ids.push(solicitacao.id);
    });
  }

  public abrirModalMotivoReprovacao() {
    this.divModalMotivoReprovacao = $('#id-modal-motivo-reprovacao').modal('show');
  }

  public cancelarReprovar() {
    this.aprovacaoReprovacaoManutencaoCorretiva.motivo = null;
    this.divModalMotivoReprovacao = $('#id-modal-motivo-reprovacao').modal('hide');
  }

  private resetar() {
    this.aprovacaoReprovacaoManutencaoCorretiva.motivo = null;
    this.solicitacoesSelecionadas = [];
    this.filtrar();
  }

  private validarCamposObrigatorios(): boolean {
    if(isNullOrUndefined(this.aprovacaoReprovacaoManutencaoCorretiva.motivo) || this.aprovacaoReprovacaoManutencaoCorretiva.motivo.length == 0) {
      this.mostrarMensagemCamposObrigatorios(['Motivo da reprovação']);
      return false;
    }
    return true;
  }

  public isUsuarioLogadoVisitante(): boolean {
    return this.authenticationService.getPerfil(PerfisConstants.VISITANTE);
  }
}
