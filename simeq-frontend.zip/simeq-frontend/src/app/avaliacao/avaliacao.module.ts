// Angular modules
import { NgModule } from '@angular/core';
import { AvaliacaoSolicitacaoModule } from './avaliacao-solicitacao/avaliacao-solicitacao.module';
import { SharedModule } from '../shared/shared.module';

@NgModule({
    imports: [
        SharedModule,
        AvaliacaoSolicitacaoModule,
    ],
    providers: [
    ]
})
export class AvaliacaoModule {}
