import { Injectable } from '@angular/core';
import { AbstractResource } from '../../core/http/abstract.resource';
import { LabelValue } from '../../core/models/label-value';
import { Observable } from 'rxjs';
import { Http } from '@angular/http';

@Injectable()
export class SetorManutencaoService extends AbstractResource<LabelValue> {

  private readonly baseEndPoint:string = "/setor-manutencao";

  constructor(http: Http) {
    super(http, '');
  }

  public buscarTodos(): Observable<LabelValue[]> {
    return this.getList(this.baseEndPoint);
  }

  public buscarTodosLabelValue(): Observable<LabelValue[]> {
    return super.getList(this.baseEndPoint);
  }

  public buscarPorIdFamilia(idFamilia: number): Observable<LabelValue[]> {
    return this.getList(this.baseEndPoint  + '/familia/'+ idFamilia);
  }

  public buscarPorId(id: number): Observable<LabelValue> {
    return super.getOne(this.baseEndPoint + '/id', id);
  }

  public buscarPorNomeSetorManutencao(nomeSetorManutencao: string): Observable<LabelValue[]> {
    return this.getList(this.baseEndPoint  + '/nomeSetorManutencao', nomeSetorManutencao);
  }

}
