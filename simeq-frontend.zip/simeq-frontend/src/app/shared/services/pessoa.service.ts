import { AssistenteProducao } from './../models/assistente-producao.model';
import { LabelValue } from './../../core/models/label-value';
import { Observable } from 'rxjs/Observable';
import { Http } from '@angular/http';
import { Injectable } from '@angular/core';
import { AbstractResource } from '../../core/http/abstract.resource';
import { AssistenteProducaoFiltro } from '../../manutencao/models/assistente-producao-filtro.model';
import { Pagina } from '../../core/models/pagina.model';
import { TecnicoDTO } from '../../administracao/tecnico/resources/dtos/tecnico-dto.class';

@Injectable()
export class PessoaService extends AbstractResource<any> {

  private baseEndPoint: string = '/pessoas';

  constructor(http: Http) {
      super(http, '');
  }

  public buscarSolicitantesManutencao(matricula: string): Observable<AssistenteProducao> {
    return super.getOne(this.baseEndPoint + '/matricula', matricula);
  }

  public buscarPessoa(matricula: string): Observable<any> {
    return super.getOne(this.baseEndPoint, matricula);
  }

  public buscarAssistentesProducao(filtro: AssistenteProducaoFiltro, params?: any): Observable<Pagina<AssistenteProducao>> {
    return super.filter(this.baseEndPoint + '/pagina-assistente-producao', filtro, params);
  }
}
