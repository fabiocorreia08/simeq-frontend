import { Observable } from 'rxjs/Observable';
import { Http } from '@angular/http';
import { Injectable } from '@angular/core';
import { AbstractResource } from '../../core/http/abstract.resource';
import { LabelValue } from '../../core/models/label-value';

@Injectable()
export class TurnoService extends AbstractResource<LabelValue>{


  private readonly baseEndPoint:string = "/turno";

  constructor(http: Http) {
    super(http, '');
  }

  public buscarTodos(): Observable<LabelValue[]> {
    return this.getList(this.baseEndPoint);
  }

}
