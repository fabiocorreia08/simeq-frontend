import { Observable } from 'rxjs/Observable';
import { Http } from '@angular/http';
import { Injectable } from '@angular/core';
import { AbstractResource } from '../../core/http/abstract.resource';
import { LabelValue } from '../../core/models/label-value';

@Injectable()
export class CentroCustoService extends AbstractResource<any>{


  private readonly baseEndPoint:string = "/centro-custo";

  constructor(http: Http) {
    super(http, '');
  }

  public buscarTodos(): Observable<LabelValue[]> {
    return this.getList(this.baseEndPoint);
  }

  public buscarTodosNomes(): Observable<LabelValue[]> {
    return this.getList(this.baseEndPoint + '/nomes');
  }

  public buscarCentroCustoHierarquiaUsuarioLogadoPerfil(idPerfil: number, matricula: string): Observable<LabelValue[]> {
    return this.getList(this.baseEndPoint + '/hierarquia-usuario-logado/' + idPerfil, matricula);
  }

  public buscarCentroCustoUsuarioLogadoPerfil(idPerfil: number, matricula: string): Observable<string[]> {
    return this.getList(this.baseEndPoint + '/usuario-logado/' + idPerfil, matricula);
  }
}
