export class SimNaoEnum {
    static readonly NAO: string = 'N';
    static readonly SIM: string = 'S';

    public static readonly lista: {chave: any, valor: any}[] = [  {chave: SimNaoEnum.SIM, valor: 'Sim'},
                                                                {chave: SimNaoEnum.NAO, valor: 'Não'}]

    public static getValor(chave: any): any {
        let retorno: {chave: any, valor: any}[] = SimNaoEnum.lista.filter(item => item.chave === chave);
        if(retorno && retorno.length > 0) {
            return retorno[0].valor;
        } else {
            return null;
        }
    }
}