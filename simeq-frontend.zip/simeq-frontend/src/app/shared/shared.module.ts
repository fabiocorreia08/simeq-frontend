import { CoreModule } from './../core/core.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { BrowserModule } from '@angular/platform-browser';
import { ButtonModule, InputMaskModule, InputTextareaModule } from 'primeng/primeng';
import { TextMaskModule } from 'angular2-text-mask';
import { FormsModule } from '@angular/forms';
import { NgbModule, NgbTooltipModule } from '@ng-bootstrap/ng-bootstrap';
import { UpperCaseDirective } from './directives/upper-case.directive';
// Angular modules
import { NgModule } from '@angular/core';
import { CentroCustoService } from './services/centro-custo.service';
import { BuscaCentrosCustoResolve } from './resolves/busca-centros-custo.resolve';
import { PessoaService } from './services/pessoa.service';
import { SetorManutencaoService } from './services/setor-manutencao.service';
import { BuscaSetoresManutencaoResolve } from './resolves/busca-setores-manutencao.resolve';
import { CalendarioMesAnoComponent } from './components/calendario-mes-ano/calendario-mes-ano.component';
import { BuscaCentrosCustoPerfilUsuarioResolve } from './resolves/busca-centros-custo-perfil-usuario.resolve';


@NgModule({
    imports: [
      FormsModule,
      TextMaskModule,
      ButtonModule,
      BrowserModule,
      BrowserAnimationsModule,
      CoreModule,
      InputMaskModule,
      InputTextareaModule,
      NgbTooltipModule,
      NgbModule.forRoot()
    ],
    providers: [
        CentroCustoService,
        SetorManutencaoService,
        BuscaCentrosCustoResolve,
        BuscaCentrosCustoPerfilUsuarioResolve,
        BuscaSetoresManutencaoResolve,
        PessoaService
    ],
    exports: [
      UpperCaseDirective,
      CalendarioMesAnoComponent
    ],
    declarations:[
      UpperCaseDirective,
      CalendarioMesAnoComponent
    ]
})
export class SharedModule {}
