import { ControlValueAccessor } from '@angular/forms';
import { Component, OnInit, Input, ViewChild, Output, EventEmitter } from '@angular/core';
import { NgbDropdown } from '@ng-bootstrap/ng-bootstrap';
import { MessagesService } from '../../../core/messages/messages.service';

interface Idata {
  mes: number;
  ano: number;
}

@Component({
  selector: 'app-calendario-mes-ano',
  templateUrl: './calendario-mes-ano.component.html',
  styleUrls: ['./calendario-mes-ano.component.css']
})
export class CalendarioMesAnoComponent implements ControlValueAccessor {

  @Input() public data: Idata;
  @Input() public dataTxt: string;
  @Input() public titulo: string;

  public separator: string;
  public primeiroMes: boolean;
  public place: number;
  public isAno: boolean = false;
  public incr: number = 0;
  @Output() public emitirDataSelecionada: EventEmitter<string> = new EventEmitter();

  public meses: string[] = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago',
    'Set', 'Out', 'Nov', 'Dez'];
  @Input() public disabled = false;
  @Input() public mask = 'mm/yyyy';
  public masks = [/[0-9]/,  /\d/, '/',  /\d/,  /\d/,  /\d/,  /\d/];

  @ViewChild('calendarPanel') calendar: NgbDropdown;

  constructor(public messagesService: MessagesService) {
    this.separator = this.mask.replace(/m|y|M/gi, '');
    this.primeiroMes = this.mask.indexOf('y') > 0;
    this.place = this.mask.indexOf(this.separator);
  }

  change (value: string) {
    value = value.replace(/[\_]/g,  '');
    value = value.length <= 4 ? value.replace('/',  '') : value;
    value = this.separator === ' ' ? value.replace(/\.|-|\//, ' ') :
          this.separator === '-' ? value.replace(/\.|-| /, '-') :
          this.separator === '/' ? value.replace(/\.| |\//, '/') :
          value.replace(/.| |\/ /, '/');
    let ultimoChar = value.substr(value.length - 1);
    if (ultimoChar === this.separator && value.length <= this.place) {
      if (this.primeiroMes) {
        value = '0' + value;
      }
    }
    if (value.length > this.place && value.indexOf(this.separator) < 0) {
      value = value.substr(0, value.length - 1) + this.separator + ultimoChar;
    }
    this.dataTxt = value;
    let items = value.split(this.separator);
    if (parseInt(items[0]) > 12) {
      this.messagesService.addErrorMessage('Por favor, informe um mês válido');
      return;
    }
    if (items.length === 2) {
      let ano = this.primeiroMes ? items[1] : items[0];
      let mes = this.primeiroMes ? items[0] : items[1];
      let imes = this.meses.indexOf(mes);
      if ((imes) < 0) {
        imes = mes.length !== 0 ? parseInt(mes) : 0;
      } else {
        imes = imes + 1;
      }
      let iano = ano.length !== 0 ? parseInt(ano) : 0;
      this.data = {
        ano: iano,
        mes: imes
      }
      this.incr = this.getIncr(this.data.ano);
    }
    this.writeValue(this.data);

  }

  selectAnoMes ($event, index: number) {
    if (this.isAno) {
      $event.stopPropagation();
      this.data.ano = index + this.incr;
      this.dataTxt = this.formatData(this.data);
      this.isAno = false;
      this.incr = this.getIncr(this.data.ano);
    } else {
      this.data.mes = index + 1;
      this.dataTxt = this.formatData(this.data);
    }
    this.emitirDataSelecionada.emit(this.dataTxt);
  }

  showAno($event: any, show: boolean) {
    $event.stopPropagation();
    this.isAno =! this.isAno;
  }

  addAno ($event: any , incr: number) {
    $event.stopPropagation();
    let year = this.isAno ? this.data.ano + 10 * incr : this.data.ano + incr;
    this.data.ano = year;
    this.incr = this.getIncr(year);
    this.dataTxt = this.formatData(this.data);
    this.emitirDataSelecionada.emit(this.dataTxt);
  }

  onChange = (data: Idata) => {
    this.data = data;
      this.incr = this.getIncr(this.data.ano);
    this.emitirDataSelecionada.emit(this.dataTxt);
  };

  getIncr(year: number): number {
    return (year - year % 10) - 1;
  }

  formatData(data: Idata): string {
    let monthTxt = data.mes < 10 ? '0' + data.mes : '' + data.mes;
    return  this.primeiroMes ?  monthTxt + this.separator + data.ano :
    '' + data.ano + this.separator + monthTxt;

  }

  onTouched = () => { };

  writeValue(data: Idata): void {
    this.data = data;
    this.onChange(this.data);
  }

  registerOnChange(fn: (data: Idata) => void): void {
    this.onChange = fn;
  }

  registerOnTouched(fn: () => void): void {
    this.onTouched = fn;
  }

  setDisabledState(isDisabled: boolean): void {
    this.disabled = isDisabled;
  }

}
