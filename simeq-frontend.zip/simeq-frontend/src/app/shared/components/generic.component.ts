import { MessagesService } from "../../core/messages/messages.service";

export class GenericComponent {

    constructor(protected messagesService: MessagesService) {
    }

    protected mostrarMensagemGuardada() {
        if(localStorage.getItem("mensagem") && localStorage.getItem("mensagem").length > 0) {
            this.messagesService.addSuccessMessage(localStorage.getItem("mensagem"));
            localStorage.removeItem("mensagem");
        }
    }

    protected guardarMensagem(mensagem: string) {
        localStorage.setItem("mensagem", mensagem);
    }

    protected mostrarMensagemCamposObrigatorios(campos: string[]) {
        this.messagesService.addErrorMessage(`Falta informação obrigatória. Por favor, informe o/a ${this.montarListaCampos(campos)}.`);
    }

    private montarListaCampos(campos: string[]) {
        let retorno: string = '';
        campos.forEach((item, indice) => {
            retorno += '\''+item+'\''+((indice+1 == campos.length) ? '' : ', ');
        });
        return retorno;
    }
}