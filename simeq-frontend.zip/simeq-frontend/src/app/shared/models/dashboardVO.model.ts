export class DashboardVO{
    listaCC: string[] = [];
    matricula: string;
    perfil: number;

    constructor(listaCC: string[], matricula: string, perfil: number){
        this.listaCC = listaCC;
        this.matricula = matricula;
        this.perfil = perfil;
    }
}