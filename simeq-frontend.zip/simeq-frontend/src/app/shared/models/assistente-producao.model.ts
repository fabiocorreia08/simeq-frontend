export class AssistenteProducao {
  public matricula: string;
  public nome: string;
  public situacao: string;
  public centroCusto: string;
}
