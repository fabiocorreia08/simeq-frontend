export class DashboardDTO{
    idStatus: number;
    nomeStatus: string;
    total: number;

    constructor(idStatus: number, nomeStatus: string, total?: number){
        this.idStatus = idStatus;
        this.nomeStatus = nomeStatus;
        this.total = total;
    }
}