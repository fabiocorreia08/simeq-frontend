import { Directive, ElementRef, HostListener } from '@angular/core';

@Directive({
  selector: '[somenteNumerosInteiros]'
})
export class SomenteNumerosDirective {

  private regex: RegExp = new RegExp(/^\d{0,8}\,\d{0,2}$/g);
  private regex2: RegExp = new RegExp(/^\d{0,8}$/g);
  private specialKeys: Array<string> = ['Backspace', 'Tab', 'End', 'Home', 'ArrowRight', 'ArrowLeft', 'Delete'];

  constructor(private el: ElementRef) {  }

  @HostListener('keydown', ['$event'])
  onKeyDown(event: KeyboardEvent) {
    if (this.specialKeys.indexOf(event.key) !== -1) {
      return;
    }

    const current: string = this.el.nativeElement.value;
    const next: string = current.concat(event.key);

    if (next && (!String(next).match(this.regex) && !String(next).match(this.regex2)) ) {
      event.preventDefault();
    }
  }

}
