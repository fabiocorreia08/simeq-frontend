import { Directive, ElementRef, HostListener } from '@angular/core';

@Directive({
  selector: '[somenteNumerosPrefixo]'
})
export class SomenteNumerosPrefixo {

  private regex: RegExp = new RegExp(/^([A-Z]){2}-\d*\,?\d{0,2}$/g);
  private specialKeys: Array<string> = ['Backspace', 'Tab', 'End', 'Home', 'ArrowRight', 'ArrowLeft', 'Delete'];

  constructor(private el: ElementRef) {  }

  @HostListener('keydown', ['$event'])
  onKeyDown(event: KeyboardEvent) {
    if (this.specialKeys.indexOf(event.key) !== -1) {
      return;
    }

    const current: string = this.el.nativeElement.value;
    const next: string = current.concat(event.key);

    if (next && !String(next).match(this.regex)) {
      event.preventDefault();
    }
  }

}
