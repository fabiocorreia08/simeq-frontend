import { LabelValue } from "../../core/models/label-value";

export class ArrayUtil {

    static adicionarPrimeiroValor(lista: LabelValue[], label: string, valor: any): LabelValue[] {
        let novaLista: LabelValue[] = new Array();
        let selecione: LabelValue = new LabelValue(label, valor);
        novaLista.push(selecione);
        lista.forEach(item => {
            novaLista.push(item);
        });
        return novaLista;
    }

}
