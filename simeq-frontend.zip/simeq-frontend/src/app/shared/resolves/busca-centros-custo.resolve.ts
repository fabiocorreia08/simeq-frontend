import { ActivatedRouteSnapshot, Resolve } from "@angular/router";
import { Injectable } from "@angular/core";
import { CentroCustoService } from "../services/centro-custo.service";
import { LabelValue } from "../../core/models/label-value";

@Injectable()
export class BuscaCentrosCustoResolve implements Resolve<LabelValue[]> {

  constructor(private centroCustoService: CentroCustoService) { }

  resolve(route: ActivatedRouteSnapshot) {
    return this.centroCustoService.buscarTodos();
  }
  
}