import { ActivatedRouteSnapshot, Resolve } from "@angular/router";
import { Injectable } from "@angular/core";

import { CentroCustoService } from "../services/centro-custo.service";
import { AuthenticationService } from "../../core/security/auth.service";

@Injectable()
export class BuscaCentrosCustoPerfilUsuarioResolve implements Resolve<string[]> {

  private usuario: any;

  constructor(
    private centroCustoService: CentroCustoService,
    private authService: AuthenticationService
    ) {}

  resolve(route: ActivatedRouteSnapshot) {
    this.usuario = this.authService.getAuthenticatedUser();
    return this.centroCustoService.buscarCentroCustoUsuarioLogadoPerfil(this.usuario.details.perfis[0].id_perfil, this.usuario.details.matricula);
  }
  
}