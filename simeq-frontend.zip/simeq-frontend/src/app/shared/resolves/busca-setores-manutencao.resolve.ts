import { ActivatedRouteSnapshot, Resolve } from "@angular/router";
import { Injectable } from "@angular/core";

import { LabelValue } from "../../core/models/label-value";
import { SetorManutencaoService } from "../services/setor-manutencao.service";

@Injectable()
export class BuscaSetoresManutencaoResolve implements Resolve<LabelValue[]> {

  constructor(
      private setorManutencaoService: SetorManutencaoService
      ) { }

  resolve(route: ActivatedRouteSnapshot) {
    return this.setorManutencaoService.buscarTodos();
  }
  
}