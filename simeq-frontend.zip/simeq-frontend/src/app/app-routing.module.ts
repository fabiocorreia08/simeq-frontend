import { NgModule } from '@angular/core';
import { Routes, RouterModule, ActivatedRoute } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { NotFoundComponent } from './core/notfound/notfound.component';
import { ErrorPageComponent } from './core/errorpage/errorpage.component';
import { ForbiddenPageComponent } from './core/forbidden/forbidden.component';
import { HomeComponent } from './home/home.component';
import { MainComponent } from './main/main.component';
import { HomeAuthGuard } from './core/security/home.auth.guard';
import { BuscaCentrosCustoPerfilUsuarioResolve } from './shared/resolves/busca-centros-custo-perfil-usuario.resolve';

const routes: Routes = [
  { path: '', redirectTo: '/app/home', pathMatch: 'full' },
  {
    path: 'app', component: MainComponent,
    children: [
      {
        path: 'home', component: HomeComponent, canActivate: [HomeAuthGuard],
        resolve: {
          centrosCustoUsuarioLogadoResolve: BuscaCentrosCustoPerfilUsuarioResolve
        }
      }
    ]
  },
  { path: 'login', component: LoginComponent },
  { path: '404', component: NotFoundComponent },
  { path: '500', component: ErrorPageComponent },
  { path: '403', component: ForbiddenPageComponent },
  { path: '**', redirectTo: '/404' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { enableTracing: false, useHash: true })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
