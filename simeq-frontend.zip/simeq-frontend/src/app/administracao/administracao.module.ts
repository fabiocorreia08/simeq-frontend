import { FamiliaModule } from './familia/familia.module';
// Angular modules
import { NgModule } from '@angular/core';
import { TecnicoModule } from './tecnico/tecnico.module';
import { GrupoSubgrupoModule } from './grupo-subgrupo/grupo-subgrupo.module';
import { EquipamentoModule } from './equipamento/equipamento.module';
import { SharedModule } from '../shared/shared.module';
import { FamiliaService } from './familia/service/familia.service';
import { FuncionamentoMaquinaModule } from './funcionamento-maquina/funcionamento-maquina.module';
import { CalendarModule } from 'primeng/primeng';
import { CapacidadeProdutivaModule } from './capacidade-produtiva/capacidade.produtiva.module';
import { ParametroModule } from './parametro/parametro.module';
import { AcaoModule } from './acao/acao.module';
import { ComponenteModule } from './componente/componente.module';



@NgModule({
    imports: [
        SharedModule,
        EquipamentoModule,
        GrupoSubgrupoModule,
        TecnicoModule,
        FamiliaModule,
        FuncionamentoMaquinaModule,
        CalendarModule,
        CapacidadeProdutivaModule,
        ParametroModule,
        AcaoModule,
        ComponenteModule
    ],
    exports: [
    ],
    providers: [
        FamiliaService
    ],
    declarations: [        
    ]
})
export class AdministracaoModule {}
