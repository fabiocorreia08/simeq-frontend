import { LabelValue } from '../../../core/models/label-value';
import { Observable } from 'rxjs/Observable';
import { Http } from '@angular/http';
import { Injectable } from '@angular/core';
import { AbstractResource } from '../../../core/http/abstract.resource';
import { Pagina } from '../../../core/models/pagina.model';
import { AcaoVO } from '../resources/vos/acao-vo.class';
import { AcaoDTO } from '../resources/dtos/acao-dto.class';

@Injectable()
export class AcaoService extends AbstractResource<any>{

  private baseEndPoint: string = "/acao";

  constructor(http: Http) {
    super(http, '');
  }

  public filtrar(filtro: AcaoVO,  params?: any): Observable<Pagina<AcaoDTO>> {
    return super.filter(this.baseEndPoint + '/filtrar', filtro, params);
  }

  public buscarPorId(id:number): Observable<AcaoDTO>{
    return super.getOne(this.baseEndPoint + "/id", id);
  }

  public buscarPor(nome: string) : Observable<AcaoDTO> {
    return super.getOne(this.baseEndPoint + "/nome", nome);
  }

  public buscarPorCodigo(codigo: string) : Observable<AcaoDTO> {
    return super.getOne(this.baseEndPoint + "/codigo", codigo);
  }
  
  public buscarTodos(): Observable<LabelValue[]> {
    return super.getList(this.baseEndPoint);
  }

  public salvar(acaoDTO:AcaoDTO){
    return super.post(this.baseEndPoint,acaoDTO);
  }  

  public atualizar(acaoDTO:AcaoDTO): Observable<AcaoDTO> {
    return super.put(this.baseEndPoint, acaoDTO);
  }

  public remover(codigo: string): Observable<AcaoDTO>{    
    return super.delete(this.baseEndPoint, codigo);
  }
  
}
