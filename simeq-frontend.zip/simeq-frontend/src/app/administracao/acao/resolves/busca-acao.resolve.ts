import { AcaoService } from "../service/acao.service";
import { ActivatedRouteSnapshot, Resolve } from "@angular/router";
import { Injectable } from "@angular/core";
import { AcaoDTO } from "../resources/dtos/acao-dto.class";

@Injectable()
export class BuscaAcaoResolve implements Resolve<AcaoDTO> {

  constructor(private acaoService: AcaoService) { }

  /* resolve(route: ActivatedRouteSnapshot) {
    return this.acaoService.buscarPorId(route.params['idAcao']);
  } */

  resolve(route: ActivatedRouteSnapshot) {
    return this.acaoService.buscarPorCodigo(route.params['codigo']);
  }
  
}