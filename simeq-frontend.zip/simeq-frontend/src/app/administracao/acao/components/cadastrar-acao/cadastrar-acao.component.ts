import { Component, OnInit } from '@angular/core';
import { BreadcrumbService } from '../../../../core/breadcrumb/breadcrumb.service';
import { MessagesService } from '../../../../core/messages/messages.service';
import { AdministracaoGenericComponent } from '../../../administracao-generic.component';
import { AcaoDTO } from '../../resources/dtos/acao-dto.class';
import { AcaoService } from '../../service/acao.service';
import { Location } from '@angular/common';

@Component({
  selector: 'simeq-cadastrar-acao',
  templateUrl: './cadastrar-acao.component.html',
  styleUrls: ['./cadastrar-acao.component.scss']
})
export class CadastrarAcaoComponent extends AdministracaoGenericComponent implements OnInit {

  acaoDTO: AcaoDTO = new AcaoDTO;

  constructor(breadcrumbService: BreadcrumbService, 
    messagesService: MessagesService,
    private acaoService: AcaoService,
    private location:Location) {
      super(messagesService);
      breadcrumbService.addRoute('/app/administracao', 'Administração', false);
      breadcrumbService.addRoute('/app/administracao/consultar-parametro', 'Parâmetros', true);
      breadcrumbService.addRoute('/app/administracao/cadastrar-parametro', 'Cadastrar', false);
      
     }

  ngOnInit() {
  }

  public salvar() {   
    this.acaoService.salvar(this.acaoDTO).subscribe(
      retorno => {
        this.messagesService.addSuccessMessage('Cadastro realizado com sucesso.');
        //this.location.back();
      }, error => {
        this.messagesService.addErrorMessage(error);
      });    
}  

public cancelar() {
  this.location.back();
}

}
