import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { BreadcrumbService } from '../../../../core/breadcrumb/breadcrumb.service';
import { MessagesService } from '../../../../core/messages/messages.service';
import { AdministracaoGenericComponent } from '../../../administracao-generic.component';
import { AcaoDTO } from '../../resources/dtos/acao-dto.class';
import { AcaoService } from '../../service/acao.service';
import { Location } from '@angular/common';

@Component({
  selector: 'simeq-detalhar-editar-acao',
  templateUrl: './detalhar-editar-acao.component.html',
  styleUrls: ['./detalhar-editar-acao.component.scss']
})
export class DetalharEditarAcaoComponent extends AdministracaoGenericComponent implements OnInit {

  public isDetalhar: boolean;
  public acaoDTO: AcaoDTO = new AcaoDTO();  
  public titulo: string;

  constructor(
    private breadcrumbService: BreadcrumbService,
    private acaoService: AcaoService,
    private activatedRoute: ActivatedRoute,
    private route: ActivatedRoute,
    private location: Location,    
    protected messagesService: MessagesService)
  {super(messagesService)
  }

  ngOnInit() {
    this.verificarRota();
    this.acaoDTO = this.route.snapshot.data['acaoResolve'];
  }

  private verificarRota(): void {
    var isDetalhar = this.activatedRoute.snapshot.params['isDetalhar'];
    (isDetalhar == 0) ? this.isDetalhar = true : this.isDetalhar = false;
    this.mudarNome();
  }

  private mudarNome(): void {
    (this.isDetalhar) ? this.titulo = "Detalhar" : this.titulo = "Editar"; 
    this.breadcrumbService.addRoute('/app/administracao', 'Administração',false);
    this.breadcrumbService.addRoute('/app/administracao/consultar-acao', 'Ações ', true);
    this.breadcrumbService.addRoute('/app/administracao/detalhar-editar-acao', this.titulo, false);
  }

  public atualizar(): void { 
    this.acaoDTO.codigo = this.acaoDTO.codigo;
    this.acaoDTO.nome = this.acaoDTO.nome;  
      this.acaoService.atualizar(this.acaoDTO).subscribe(acao => {
        this.messagesService.addSuccessMessage('Atualização realizada com sucesso.');  
        //this.location.back();      
      }, error => {
        this.messagesService.addErrorMessage(error);
      });   
  }  

  public voltar(): void {
    this.location.back();
  }

}
