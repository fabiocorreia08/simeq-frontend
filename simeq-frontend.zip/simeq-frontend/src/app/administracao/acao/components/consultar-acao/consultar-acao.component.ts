import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { LazyLoadEvent } from 'primeng/primeng';
import { BreadcrumbService } from '../../../../core/breadcrumb/breadcrumb.service';
import { MessagesService } from '../../../../core/messages/messages.service';
import { ModalConfirmacaoComponent } from '../../../../core/modal-confirmacao/modal-confirmacao.component';
import { Pagina } from '../../../../core/models/pagina.model';
import { AuthenticationService } from '../../../../core/security/auth.service';
import { AdministracaoGenericComponent } from '../../../administracao-generic.component';
import { AcaoDTO } from '../../resources/dtos/acao-dto.class';
import { AcaoVO } from '../../resources/vos/acao-vo.class';
import { AcaoService } from '../../service/acao.service';

@Component({
  selector: 'simeq-consultar-acao',
  templateUrl: './consultar-acao.component.html',
  styleUrls: ['./consultar-acao.component.scss']
})
export class ConsultarAcaoComponent extends AdministracaoGenericComponent implements OnInit {

  @ViewChild('modalConfirmaExclusao')
  modalConfirmaExclusao: ModalConfirmacaoComponent;

  public buscaHabilitada: boolean = false;
  public filtro: AcaoVO = new AcaoVO;
  public pagina: Pagina<AcaoDTO> = new Pagina<AcaoDTO>();

  constructor(
    private auth: AuthenticationService,
    private breadcrumbService: BreadcrumbService,
    protected messagesService: MessagesService,
    private router: Router,    
    private acaoService: AcaoService
  ) {
    super(messagesService);
    breadcrumbService.addRoute('/app/administracao', 'Administração', false);
    breadcrumbService.addRoute('/app/administracao/consultar-acao', 'Ações', false);
    breadcrumbService.addRoute('/app/administracao/consultar-acao', 'Consultar', false);
  }

  ngOnInit() {
    this.limparFiltros();    
  }

  ngOnDestroy(): void {
    localStorage.setItem("buscaHabilitada", JSON.stringify(this.buscaHabilitada));
    localStorage.setItem("filtroAcao", JSON.stringify(this.filtro))
  }

  public pesquisar(): void {
    this.buscaHabilitada = true;
    this.pagina = new Pagina();    
    this.filtrar();
  }

  public filtrar(): void {
    this.acaoService.filtrar(this.filtro, this.pagina)
      .subscribe((pagina) => {
        this.pagina = pagina;
      },
      (error) => {
        this.messagesService.addErrorMessage(error);
      });
  }

  public paginar(event: LazyLoadEvent): void {
    if(this.buscaHabilitada) {
      this.pagina = new Pagina<AcaoDTO>(event.first, event.rows);
      this.filtrar();
    }
  }

  public limparFiltros(): void {
    this.buscaHabilitada = false;
    this.pagina = new Pagina();
    this.filtro = new AcaoVO();
  }

  private popularFiltros(): void {
    this.buscaHabilitada = localStorage.getItem("buscaHabilitada") ? JSON.parse(localStorage.getItem("buscaHabilitada")) : false;
    this.filtro = localStorage.getItem("filtroAcao") ? JSON.parse(localStorage.getItem("filtroAcao")) : new AcaoVO();
    localStorage.removeItem("buscaHabilitada");
    localStorage.removeItem("filtroAcao");
    if(this.buscaHabilitada) {
      this.pesquisar();
    }
  }

  public remover(codigo:string): void {    
    this.modalConfirmaExclusao.showDialog().subscribe(success => {
      if (success) {
        this.acaoService.remover(codigo).subscribe(() => {          
          this.messagesService.addSuccessMessage("Exclusão realizada com sucesso");
          this.filtrar();
        }
        , error => {
          this.messagesService.addErrorMessage(error);
        })        
      }
    });
  }

}
