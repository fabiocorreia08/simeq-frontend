import { NgModule } from '@angular/core';
import { CadastrarAcaoComponent } from './components/cadastrar-acao/cadastrar-acao.component';
import { DetalharEditarAcaoComponent } from './components/detalhar-editar-acao/detalhar-editar-acao.component';

import { AcaoRoutingModule } from './acao-routing.module';
import {
    ButtonModule,
    DataTableModule,
    InputMaskModule,
    DropdownModule,
    CalendarModule
  } from 'primeng/primeng';
import { ConsultarAcaoComponent } from './components/consultar-acao/consultar-acao.component';
import { CoreModule } from '../../core/core.module';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { SharedModule } from '../../shared/shared.module';
import { BuscaAcaoResolve } from './resolves/busca-acao.resolve';
import { AcaoService } from './service/acao.service';

@NgModule({
    declarations: [
        ConsultarAcaoComponent,
        CadastrarAcaoComponent,
        DetalharEditarAcaoComponent
    ],
    imports: [
        AcaoRoutingModule,
        FormsModule,
        BrowserModule,
        BrowserAnimationsModule,
        CoreModule,
        ButtonModule,
        DataTableModule,
        InputMaskModule,
        CalendarModule,
        DropdownModule,
        SharedModule
    ],
    providers: [
        AcaoService,        
        BuscaAcaoResolve]
})
export class AcaoModule {}
