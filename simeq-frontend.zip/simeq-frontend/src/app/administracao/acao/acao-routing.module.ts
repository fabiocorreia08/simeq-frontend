import { PerfisConstants } from '../../core/security/perfis.constants';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MainComponent } from '../../main/main.component';
import { CadastrarAcaoComponent } from './components/cadastrar-acao/cadastrar-acao.component';
import { DetalharEditarAcaoComponent } from './components/detalhar-editar-acao/detalhar-editar-acao.component';
import { ConsultarAcaoComponent } from './components/consultar-acao/consultar-acao.component';

import { BuscaCentrosCustoResolve } from '../../shared/resolves/busca-centros-custo.resolve';
import { AuthGuard } from '../../core/security/auth.guard';
import { AuthenticationService } from '../../core/security/auth.service';
import { DetalharEditarAuthGuard } from '../../core/security/detalhar-editar-auth.guard';
import { BuscaAcaoResolve } from './resolves/busca-acao.resolve';

const routes: Routes = [
    { path: 'app', component: MainComponent,
        children: [
            {
                path: 'administracao/consultar-acao',
                component: ConsultarAcaoComponent,
                canActivate: [AuthGuard],
                data: {funcionalidade: PerfisConstants.CONSULTAR_TECNICO_PERMISSOES},                
            },
            {
                path: 'administracao/cadastrar-acao',
                component: CadastrarAcaoComponent,
                canActivate: [AuthGuard],
                data: {funcionalidade: PerfisConstants.CADASTRAR_TECNICO_PERMISSOES},
            },
            {
                path: 'administracao/detalhar-editar-acao/:isDetalhar/:codigo',
                component: DetalharEditarAcaoComponent,
                canActivate: [DetalharEditarAuthGuard],
                data: {funcionalidadeDetalhar: PerfisConstants.DETALHAR_TECNICO_PERMISSOES, funcionalidadeEditar: PerfisConstants.EDITAR_TECNICO_PERMISSOES},
                resolve: {
                    acaoResolve: BuscaAcaoResolve
                }
            }
        ]
    },
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class AcaoRoutingModule { }
