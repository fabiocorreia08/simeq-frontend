export class AcaoDTO {		
	codigo: string;
	nome: string;
}
