export class AcaoVO {	
	codigo: string;
	nome: string;    
}