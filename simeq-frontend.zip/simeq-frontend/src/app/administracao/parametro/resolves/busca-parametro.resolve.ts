import { ParametroService } from "../service/parametro.service";
import { ActivatedRouteSnapshot, Resolve } from "@angular/router";
import { Injectable } from "@angular/core";
import { ParametroDTO } from "../resources/dtos/parametro-dto.class";

@Injectable()
export class BuscaParametroResolve implements Resolve<ParametroDTO> {

  constructor(private parametroService: ParametroService) { }

  resolve(route: ActivatedRouteSnapshot) {
    return this.parametroService.buscarPorId(route.params['idParametro']);
  }
  
}