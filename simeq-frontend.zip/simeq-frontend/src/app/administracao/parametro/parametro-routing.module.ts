import { PerfisConstants } from '../../core/security/perfis.constants';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MainComponent } from '../../main/main.component';
import { CadastrarParametroComponent } from './components/cadastrar-parametro/cadastrar-parametro.component';
import { DetalharEditarParametroComponent } from './components/detalhar-editar-parametro/detalhar-editar-parametro.component';
import { ConsultarParametroComponent } from './components/consultar-parametro/consultar-parametro.component';

import { BuscaCentrosCustoResolve } from '../../shared/resolves/busca-centros-custo.resolve';
import { AuthGuard } from '../../core/security/auth.guard';
import { AuthenticationService } from '../../core/security/auth.service';
import { DetalharEditarAuthGuard } from '../../core/security/detalhar-editar-auth.guard';
import { BuscaParametroResolve } from './resolves/busca-parametro.resolve';

const routes: Routes = [
    { path: 'app', component: MainComponent,
        children: [
            {
                path: 'administracao/consultar-parametro',
                component: ConsultarParametroComponent,
                canActivate: [AuthGuard],
                data: {funcionalidade: PerfisConstants.CONSULTAR_TECNICO_PERMISSOES},                
            },
            {
                path: 'administracao/cadastrar-parametro',
                component: CadastrarParametroComponent,
                canActivate: [AuthGuard],
                data: {funcionalidade: PerfisConstants.CADASTRAR_TECNICO_PERMISSOES},
            },
            {
                path: 'administracao/detalhar-editar-parametro/:isDetalhar/:idParametro',
                component: DetalharEditarParametroComponent,
                canActivate: [DetalharEditarAuthGuard],
                data: {funcionalidadeDetalhar: PerfisConstants.DETALHAR_TECNICO_PERMISSOES, funcionalidadeEditar: PerfisConstants.EDITAR_TECNICO_PERMISSOES},
                resolve: {
                    parametroResolve: BuscaParametroResolve
                }
            }
        ]
    },
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class ParametroRoutingModule { }
