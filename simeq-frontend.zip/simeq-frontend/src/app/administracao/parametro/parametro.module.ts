import { NgModule } from '@angular/core';
import { DetalharEditarParametroComponent } from './components/detalhar-editar-parametro/detalhar-editar-parametro.component';

import { ParametroRoutingModule } from './parametro-routing.module';
import {
    ButtonModule,
    DataTableModule,
    InputMaskModule,
    DropdownModule,
    CalendarModule
  } from 'primeng/primeng';
import { ConsultarParametroComponent } from './components/consultar-parametro/consultar-parametro.component';
import { CoreModule } from '../../core/core.module';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { SharedModule } from '../../shared/shared.module';
import { BuscaParametroResolve } from './resolves/busca-parametro.resolve';
import { ParametroService } from './service/parametro.service';
import { CadastrarParametroComponent } from './components/cadastrar-parametro/cadastrar-parametro.component';

@NgModule({
    declarations: [
        ConsultarParametroComponent,
        CadastrarParametroComponent,
        DetalharEditarParametroComponent
    ],
    imports: [
        ParametroRoutingModule,
        FormsModule,
        BrowserModule,
        BrowserAnimationsModule,
        CoreModule,
        ButtonModule,
        DataTableModule,
        InputMaskModule,
        CalendarModule,
        DropdownModule,
        SharedModule
    ],
    providers: [
        ParametroService,        
        BuscaParametroResolve]
})
export class ParametroModule {}
