export class ParametroDTO {	
	id: number;
	nome: string;
	valor: string;
}
