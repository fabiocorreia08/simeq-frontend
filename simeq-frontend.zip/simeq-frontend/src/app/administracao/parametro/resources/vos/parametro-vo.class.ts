export class ParametroVO {	
	nome: string;
	valor: string;    
}