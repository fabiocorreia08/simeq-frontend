import { LabelValue } from '../../../core/models/label-value';
import { Observable } from 'rxjs/Observable';
import { Http } from '@angular/http';
import { Injectable } from '@angular/core';
import { AbstractResource } from '../../../core/http/abstract.resource';
import { Pagina } from '../../../core/models/pagina.model';
import { ParametroVO } from '../resources/vos/parametro-vo.class';
import { ParametroDTO } from '../resources/dtos/parametro-dto.class';

@Injectable()
export class ParametroService extends AbstractResource<any>{

  private baseEndPoint: string = "/parametro";

  constructor(http: Http) {
    super(http, '');
  }

  public filtrar(filtro: ParametroVO,  params?: any): Observable<Pagina<ParametroDTO>> {
    return super.filter(this.baseEndPoint + '/filtrar', filtro, params);
  }

  public buscarPorId(id:number): Observable<ParametroDTO>{
    return super.getOne(this.baseEndPoint + "/id", id);
  }

  public buscarPor(nome: string) : Observable<ParametroDTO> {
    return super.getOne(this.baseEndPoint + "/nome", nome);
  }

  public buscarPorValor(valor: string) : Observable<ParametroDTO> {
    return super.getOne(this.baseEndPoint + "/valor", valor);
  }
  
  public buscarTodos(): Observable<LabelValue[]> {
    return super.getList(this.baseEndPoint);
  }

  public salvar(parametroDTO: ParametroDTO){
    return super.post(this.baseEndPoint, parametroDTO);
  }  

  public atualizar(parametroDTO: ParametroDTO): Observable<ParametroDTO> {
    return super.put(this.baseEndPoint, parametroDTO);
  }

  public remover(id: number): Observable<ParametroDTO>{    
    return super.delete(this.baseEndPoint, id);
  }
  
}
