import { Component, OnInit } from '@angular/core';
import { BreadcrumbService } from '../../../../core/breadcrumb/breadcrumb.service';
import { MessagesService } from '../../../../core/messages/messages.service';
import { AdministracaoGenericComponent } from '../../../administracao-generic.component';
import { ParametroDTO } from '../../resources/dtos/parametro-dto.class';
import { ParametroService } from '../../service/parametro.service';
import { Location } from '@angular/common';

@Component({
  selector: 'simeq-cadastrar-parametro',
  templateUrl: './cadastrar-parametro.component.html',
  styleUrls: ['./cadastrar-parametro.component.scss']
})
export class CadastrarParametroComponent extends AdministracaoGenericComponent implements OnInit {

  parametroDTO: ParametroDTO = new ParametroDTO;

  constructor(breadcrumbService: BreadcrumbService, 
    messagesService: MessagesService,
    private parametroService: ParametroService,
    private location:Location) {
  super(messagesService);
  breadcrumbService.addRoute('/app/administracao', 'Administração', false);
  breadcrumbService.addRoute('/app/administracao/consultar-parametro', 'Parâmetros', true);
  breadcrumbService.addRoute('/app/administracao/cadastrar-parametro', 'Cadastrar', false);
  }

  ngOnInit() {
  }

  public salvar() {   
      this.parametroService.salvar(this.parametroDTO).subscribe(
        retorno => {
          this.messagesService.addSuccessMessage('Cadastro realizado com sucesso.');
          //this.location.back();
        }, error => {
          this.messagesService.addErrorMessage(error);
        });    
  }  

  public cancelar() {
    this.location.back();
  }

}
