import { Component, OnInit, ViewChild } from '@angular/core';
import { BreadcrumbService } from '../../../../core/breadcrumb/breadcrumb.service';
import { MessagesService } from '../../../../core/messages/messages.service';
import { AuthenticationService } from '../../../../core/security/auth.service';
import { AdministracaoGenericComponent } from '../../../administracao-generic.component';
import { ActivatedRoute, Router } from '@angular/router';
import { ParametroService } from '../../service/parametro.service';
import { ParametroVO } from '../../resources/vos/parametro-vo.class';
import { Pagina } from '../../../../core/models/pagina.model';
import { ParametroDTO } from '../../resources/dtos/parametro-dto.class';
import { LazyLoadEvent } from 'primeng/components/common/api';
import { isNullOrUndefined } from 'util';
import { PerfisConstants } from '../../../../core/security/perfis.constants';
import { ModalConfirmacaoComponent } from '../../../../core/modal-confirmacao/modal-confirmacao.component';

@Component({
  selector: 'simeq-consultar-parametro',
  templateUrl: './consultar-parametro.component.html',
  styleUrls: ['./consultar-parametro.component.scss']
})
export class ConsultarParametroComponent extends AdministracaoGenericComponent implements OnInit {

  @ViewChild('modalConfirmaExclusao')
  modalConfirmaExclusao: ModalConfirmacaoComponent;

  public buscaHabilitada: boolean = false;
  public filtro: ParametroVO = new ParametroVO;
  public pagina: Pagina<ParametroDTO> = new Pagina<ParametroDTO>();

  constructor(private auth: AuthenticationService,
    private breadcrumbService: BreadcrumbService,
    protected messagesService: MessagesService,
    private router: Router,    
    private parametroService: ParametroService) {
    super(messagesService);
    breadcrumbService.addRoute('/app/administracao', 'Administração', false);
    breadcrumbService.addRoute('/app/administracao/consultar-parametro', 'Parâmetros', false);
    breadcrumbService.addRoute('/app/administracao/consultar-parametro', 'Consultar', false);
  }

  ngOnInit() {
    this.limparFiltros();
    this.filtrar();
  }

  ngOnDestroy(): void {
    localStorage.setItem("buscaHabilitada", JSON.stringify(this.buscaHabilitada));
    localStorage.setItem("filtroParametro", JSON.stringify(this.filtro))
  }

  public pesquisar(): void {
    this.buscaHabilitada = true;
    this.pagina = new Pagina();    
    this.filtrar();
  }

  public filtrar(): void {
    this.parametroService.filtrar(this.filtro, this.pagina)
      .subscribe((pagina) => {
        this.pagina = pagina;
      },
      (error) => {
        this.messagesService.addErrorMessage(error);
      });
  }

  public paginar(event: LazyLoadEvent): void {
    if(this.buscaHabilitada) {
      this.pagina = new Pagina<ParametroDTO>(event.first, event.rows);
      this.filtrar();
    }
  }

  public limparFiltros(): void {
    this.buscaHabilitada = false;
    this.pagina = new Pagina();
    this.filtro = new ParametroVO();
  }

  private popularFiltros(): void {
    this.buscaHabilitada = localStorage.getItem("buscaHabilitada") ? JSON.parse(localStorage.getItem("buscaHabilitada")) : false;
    this.filtro = localStorage.getItem("filtroParametro") ? JSON.parse(localStorage.getItem("filtroParametro")) : new ParametroVO();
    localStorage.removeItem("buscaHabilitada");
    localStorage.removeItem("filtroParametro");
    if(this.buscaHabilitada) {
      this.pesquisar();
    }
  }

  public remover(idParametro:number): void {    
    this.modalConfirmaExclusao.showDialog().subscribe(success => {
      if (success) {
        this.parametroService.remover(idParametro).subscribe(() => {          
          this.messagesService.addSuccessMessage("Exclusão realizada com sucesso");
          this.filtrar();
        }
        , error => {
          this.messagesService.addErrorMessage(error);
        })        
      }
    });
  }

}
