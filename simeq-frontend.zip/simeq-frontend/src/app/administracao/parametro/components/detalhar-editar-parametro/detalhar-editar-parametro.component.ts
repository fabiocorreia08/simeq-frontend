import { Component, OnInit } from '@angular/core';
import { BreadcrumbService } from '../../../../core/breadcrumb/breadcrumb.service';
import { MessagesService } from '../../../../core/messages/messages.service';
import { AdministracaoGenericComponent } from '../../../administracao-generic.component';
import { ParametroDTO } from '../../resources/dtos/parametro-dto.class';
import { ActivatedRoute } from '@angular/router';
import { ParametroService } from '../../service/parametro.service';
import { Location } from '@angular/common';

@Component({
  selector: 'simeq-detalhar-editar-parametro',
  templateUrl: './detalhar-editar-parametro.component.html',
  styleUrls: ['./detalhar-editar-parametro.component.scss']
})
export class DetalharEditarParametroComponent extends AdministracaoGenericComponent implements OnInit {

  public isDetalhar: boolean;
  public parametroDTO: ParametroDTO = new ParametroDTO();  
  public titulo: string;
  
  constructor(private breadcrumbService: BreadcrumbService,
    private parametroService: ParametroService,
    private activatedRoute: ActivatedRoute,
    private route: ActivatedRoute,
    private location: Location,    
    protected messagesService: MessagesService) {
    super(messagesService);
   }

  ngOnInit() {
    this.verificarRota();
    this.parametroDTO = this.route.snapshot.data['parametroResolve'];
  }

  private verificarRota(): void {
    var isDetalhar = this.activatedRoute.snapshot.params['isDetalhar'];
    (isDetalhar == 0) ? this.isDetalhar = true : this.isDetalhar = false;
    this.mudarNome();
  }

  private mudarNome(): void {
    (this.isDetalhar) ? this.titulo = "Detalhar" : this.titulo = "Editar"; 
    this.breadcrumbService.addRoute('/app/administracao', 'Administração',false);
    this.breadcrumbService.addRoute('/app/administracao/consultar-parametro', 'Parâmetros ', true);
    this.breadcrumbService.addRoute('/app/administracao/detalhar-editar-parametro', this.titulo, false);
  }

  public atualizar(): void { 
    this.parametroDTO.nome = this.parametroDTO.nome;
    this.parametroDTO.valor = this.parametroDTO.valor;  
      this.parametroService.atualizar(this.parametroDTO).subscribe(parametro => {
        this.messagesService.addSuccessMessage('Atualização realizada com sucesso.');  
        //this.location.back();      
      }, error => {
        this.messagesService.addErrorMessage(error);
      });   
  }  

  public voltar(): void {
    this.location.back();
  }
   

}
