import { Component, OnInit } from '@angular/core';
import { BreadcrumbService } from '../../../../core/breadcrumb/breadcrumb.service';
import { AdministracaoGenericComponent } from '../../../administracao-generic.component';
import { MessagesService } from '../../../../core/messages/messages.service';
import { ActivatedRoute } from '@angular/router';
import { GrupoService } from '../../services/grupo.service';
import { EquipamentoDTO } from '../../../equipamento/resources/dtos/equipamento-dto.class';
import { GrupoDTO } from '../../resources/dtos/grupo-dto.class';
import { Location } from '@angular/common';
import { StringUtils } from '../../../../core/utils/stringutils';
import { isNullOrUndefined } from 'util';

@Component({
  selector: 'simeq-detalhar-editar-grupo-subgrupo',
  templateUrl: './detalhar-editar-grupo-subgrupo.component.html',
  styleUrls: ['./detalhar-editar-grupo-subgrupo.component.scss']
})
export class DetalharEditarGrupoSubgrupoComponent extends AdministracaoGenericComponent implements OnInit {

  public equipamento: EquipamentoDTO = new EquipamentoDTO();
  public grupo: GrupoDTO = new GrupoDTO();
  public isDetalhar: boolean = null;

  public flagMecanico: boolean = null;
  public flagEletricista: boolean = null;
  public flagEletronico: boolean = null;
  public flagTI: boolean = null;
  public flagUtilidades: boolean = null;
  public flagEngenharia: boolean = null;
  public flagPreventiva: boolean = null;

  public codigoGrupo: string;
  public codigoSubgrupo: string;
  public sinalizarCamposObrigatoriosGrupoSubgrupo:string;

  constructor(private breadcrumbService: BreadcrumbService,
              messagesService: MessagesService,
              private location: Location,
              private activatedRoute: ActivatedRoute,
              private grupoService: GrupoService) {
    super(messagesService);
  }

  ngOnInit() {    
    this.isDetalhar = (this.activatedRoute.snapshot.params['isDetalhar'] == 1) ? true : false;
    this.equipamento = this.activatedRoute.snapshot.data['equipamentoResolve'];
    this.grupo = this.activatedRoute.snapshot.data['grupoResolve'];
    this.modificarBreadcrumb();
    this.atribuirCamposObrigatoriosRealocacaoTecnico();
    this.processarGrupo();
    if(this.isGrupo()) {
      this.codigoGrupo = this.grupo.codigoSequencia;
      this.codigoSubgrupo = null;
    } else {
      this.codigoGrupo = this.grupo.codigoSequenciaPai;
      this.codigoSubgrupo = this.grupo.codigoSequencia;
    }
  }

  private modificarBreadcrumb(){
    let titulo;
    (this.isDetalhar) ? titulo = "Detalhar" : titulo = "Editar";
    this.breadcrumbService.addRoute('/app/administracao', 'Administração', false);
    this.breadcrumbService.addRoute('/app/administracao/consultar-grupo-subgrupo', 'Grupos e Subgrupos', true);
    this.breadcrumbService.addRoute('/app/administracao/editar-detalhar-grupo-subgrupo', titulo, false);
  }

  private processarGrupo() {
    this.flagMecanico = (this.grupo.flagMecanico === 'S') ? true : false;
    this.flagEletricista = (this.grupo.flagEletricista === 'S') ? true : false;
    this.flagEletronico = (this.grupo.flagEletronico === 'S') ? true : false;
    this.flagTI = (this.grupo.flagTI === 'S') ? true : false;
    this.flagUtilidades = (this.grupo.flagUtilidades === 'S') ? true : false;
    this.flagEngenharia = (this.grupo.flagEngenharia === 'S') ? true : false;
    this.flagPreventiva = (this.grupo.flagPreventiva === 'S') ? true : false;
  }

  private atribuirCamposObrigatoriosRealocacaoTecnico():void{
    (this.isDetalhar) ? this.sinalizarCamposObrigatoriosGrupoSubgrupo = "" : this.sinalizarCamposObrigatoriosGrupoSubgrupo = "*";
  }

  public atualizar() {    
    this.beforeAtualizar();
    if(this.validarCamposObrigatorios()) {
      this.grupoService.atualizar(this.grupo).subscribe(codigo => {
        this.guardarMensagem(this.isGrupo() ? `Atualização de Grupo efetuada com sucesso!` : `Atualização de Subgrupo efetuado com sucesso!`);
        this.location.back();
      }, error => {
        this.messagesService.addErrorMessage(error);
      });
    }
  }

  private beforeAtualizar() {
    this.grupo.descricaoGrupo = this.grupo.descricaoGrupo.toLocaleUpperCase();
    this.grupo.descricaoObservacao = !isNullOrUndefined(this.grupo.descricaoObservacao) ? this.grupo.descricaoObservacao.toLocaleUpperCase() : undefined;
    this.grupo.flagMecanico = this.flagMecanico ? 'S' : 'N';
    this.grupo.flagEletricista = this.flagEletricista ? 'S' : 'N';
    this.grupo.flagEletronico = this.flagEletronico ? 'S' : 'N';
    this.grupo.flagTI = this.flagTI ? 'S' : 'N';
    this.grupo.flagUtilidades = this.flagUtilidades ? 'S' : 'N';
    this.grupo.flagEngenharia = this.flagEngenharia ? 'S' : 'N';
    this.grupo.flagPreventiva = this.flagPreventiva ? 'S' : 'N';
  }

  private validarCamposObrigatorios(): boolean {
    let campos: string[] = [];
    if(StringUtils.isNullOrUndefinedOrEmpty(this.grupo.descricaoGrupo)) {
      campos.push('Descrição');
    }
    if(campos.length > 0) {
      this.mostrarMensagemCamposObrigatorios(campos);
      return false;
    }
    return true;
  }

  public voltar() {
    this.location.back();
  }

  public isGrupo(): boolean {
    return (this.grupo.idGrupoPai == undefined) ? true : false;
  }
}
