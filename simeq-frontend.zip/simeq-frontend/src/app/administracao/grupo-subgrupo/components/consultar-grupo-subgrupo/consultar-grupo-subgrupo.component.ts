import { PerfisConstants } from './../../../../core/security/perfis.constants';
import { Component, OnInit, ViewChild } from "@angular/core";
import { BreadcrumbService } from "../../../../core/breadcrumb/breadcrumb.service";
import { EquipamentoDTO } from "../../../equipamento/resources/dtos/equipamento-dto.class";
import { GrupoDTO } from "../../resources/dtos/grupo-dto.class";
import { GrupoService } from "../../services/grupo.service";
import { EquipamentoService } from "../../../equipamento/services/equipamento.service";
import { AdministracaoGenericComponent } from "../../../administracao-generic.component";
import { MessagesService } from "../../../../core/messages/messages.service";
import { Observable } from "rxjs/Observable";
import { isNullOrUndefined } from "util";
import { StringUtils } from "../../../../core/utils/stringutils";
import { ModalConfirmacaoComponent } from "../../../../core/modal-confirmacao/modal-confirmacao.component";
import { TreeNode } from "primeng/primeng";
import { AuthenticationService } from "../../../../core/security/auth.service";

declare var $: any;

@Component({
    selector: 'simeq-consultar-grupo-subgrupo',
    templateUrl: './consultar-grupo-subgrupo.component.html',
    styleUrls: ['./consultar-grupo-subgrupo.component.scss']
  })
  export class ConsultarGrupoSubgrupoComponent extends AdministracaoGenericComponent implements OnInit {

    @ViewChild('modalConfirmaExclusao') public modalConfirmaExclusao: ModalConfirmacaoComponent;

    public codigoMask = [/[aA-zZ]/, /[aA-zZ]/, '-', /[aA-zZ]/, '-', /\d/, /\d/, /\d/,];

    private divModalSelecaoEquipamento: any;
    private divModalReplicarGrupoSubgrupo: any;

    public codigoManutencao: string = null;
    public nomeEquipamento: string = null;

    public equipamentos: EquipamentoDTO[] = [];
    public equipamento: EquipamentoDTO = null;

    public grupos: GrupoDTO[] = [];
    public subgrupos: GrupoDTO[] = [];
    public grupo: GrupoDTO = null;

    public confirmarSelecaoEquipamentoDesabilitada: boolean = null;
    public isBotaoReplicarGrupoSubgrupoExibido: boolean = null;
    public confirmarReplicarGrupoSubgrupoDesabilitado: boolean = null;
    public equipamentoSelecionado: boolean = false;

    public replicarGrupoSubgrupoFabricanteModelo: string = null;
    public replicarGrupoSubgrupoSequencial: string = null;
    public replicarGrupoSubgrupoPasso: number = 1;
    public replicarEquipamento: EquipamentoDTO = new EquipamentoDTO();
    public replicarGrupos: GrupoDTO[] = [];
    public replicarGruposSubgruposTree: TreeNode[] = [];
    public replicarGruposSubgruposTreeSelecionados: TreeNode[] = [];

    constructor(messagesService: MessagesService,
      breadcrumbService: BreadcrumbService,
      private auth: AuthenticationService,
      private grupoService: GrupoService,
      private equipamentoService: EquipamentoService) {
      super(messagesService);
      breadcrumbService.addRoute('/app/administracao', 'Administração', false);
      breadcrumbService.addRoute('/app/administracao/consultar-grupo-subgrupo', 'Grupos e Subgrupos', false);
      breadcrumbService.addRoute('/app/administracao/cadastrar-grupo-subgrupo', 'Consultar', false);
    }

    ngOnInit() {
      this.limparFiltros();
      this.recuperarInformacoes();
      this.mostrarMensagemGuardada();
    }

    ngOnDestroy() {
      this.guardarInformacoes();
    }

    private guardarInformacoes() {
      if(this.equipamento) {
        localStorage.setItem("idEquipamento", JSON.stringify(this.equipamento.idEquipamento));
      }
      if(this.grupo) {
        localStorage.setItem("idGrupo", JSON.stringify(this.grupo.idGrupo));
      }
    }

    private recuperarInformacoes() {
      let idEquipamento: number = (!isNullOrUndefined(localStorage.getItem("idEquipamento"))) ? (new Number(localStorage.getItem("idEquipamento"))).valueOf() : null;
      let idGrupo: number = (!isNullOrUndefined(localStorage.getItem("idGrupo"))) ? (new Number(localStorage.getItem("idGrupo"))).valueOf() : null;
      if(!isNullOrUndefined(idEquipamento)) {
        this.equipamentoService.buscarPorId(idEquipamento).subscribe(equipamento => {
          this.equipamento = equipamento;
          this.equipamentoSelecionado = true;
          this.grupoService.buscarGruposPai(idEquipamento).subscribe(grupos=> {
            this.grupos = grupos;
            this.esconderBotaoReplicarGrupoSubgrupo();
            this.processarGruposSubgrupos(this.grupos);
            if(!isNullOrUndefined(idGrupo)) {
              this.grupo = this.grupos.filter(grupo => grupo.idGrupo==idGrupo)[0];
              this.grupoService.buscarGruposFilho(idGrupo).subscribe(subgrupos => {
                this.subgrupos = subgrupos;
                this.processarGruposSubgrupos(this.subgrupos);
              });
            }
          });
        });
      }
      this.reiniciarInformacoes();
    }

    private reiniciarInformacoes() {
      localStorage.removeItem("idEquipamento");
      localStorage.removeItem("idGrupo");
    }

    public pesquisar() {
      this.codigoManutencao = this.limparRegex(this.codigoManutencao);
      this.equipamentoSelecionado = false;
      this.codigoManutencao = !isNullOrUndefined(this.codigoManutencao) ? this.codigoManutencao.toLocaleUpperCase() : null;
      this.nomeEquipamento = !isNullOrUndefined(this.nomeEquipamento) ? this.nomeEquipamento.toLocaleUpperCase() : null;
      this.equipamentoService.buscarPorCodigoManutencaoNomeEquipamento(this.codigoManutencao, this.nomeEquipamento).subscribe(equipamentos => {
        this.equipamentos = equipamentos;
        if(this.equipamentos.length == 1) {
          this.equipamentoSelecionado = true;
          this.equipamento = this.equipamentos[0];
          this.pesquisarGrupos().subscribe();
        } else if(this.equipamentos.length > 1) {
          this.abrirModalSelecionarEquipamento();
        } else {
          this.messagesService.addErrorMessage('Nenhum equipamento encontrado.');
        }
      });
    }


    private limparRegex(input: string) {
      if (input) {
        input = input.replace(/_/g,'');
        input = input.replace("-", '');
        input = input.replace("-", '');
      }
      return input;
    }

    public limparFiltros() {
      this.codigoManutencao = null;
      this.nomeEquipamento = null;
      this.equipamento = null;
      this.equipamentos = [];
      this.grupo = null;
      this.grupos = [];
      this.subgrupos = [];
      this.equipamentoSelecionado = false;
    }

    public deletarGrupo(grupo: GrupoDTO) {
      this.modalConfirmaExclusao.showDialog().subscribe(ok => {
        if(ok) {
          this.grupoService.remover(grupo.idGrupo).subscribe(() => {
            this.grupos.splice(this.grupos.indexOf(grupo), 1);
            this.grupos = this.grupos.filter(grupo => true);
            this.grupo = null;
            this.messagesService.addSuccessMessage("Remoção realizada com sucesso!");
            this.esconderBotaoReplicarGrupoSubgrupo();
          }, error => {
            this.messagesService.addErrorMessage(error);
          });
        }
      });
    }

    private esconderBotaoReplicarGrupoSubgrupo(){
      this.isBotaoReplicarGrupoSubgrupoExibido = this.grupos.length == 0 ? true : false;
    }

    public deletarSubgrupo(subgrupo: GrupoDTO) {
      this.modalConfirmaExclusao.showDialog().subscribe(ok => {
        if(ok) {
          this.grupoService.remover(subgrupo.idGrupo).subscribe(() => {
            this.subgrupos.splice(this.subgrupos.indexOf(subgrupo), 1);
            this.subgrupos = this.subgrupos.filter(subgrupo => true);
            this.messagesService.addSuccessMessage("Remoção realizada com sucesso!");
          }, error => {
            this.messagesService.addErrorMessage(error);
          });
        }
      });
    }

    public pesquisarGrupos(): Observable<any> {
      return new Observable(observer => {
        this.grupoService.buscarGruposPai(this.equipamento.idEquipamento).subscribe(grupos => {
          this.grupos = grupos;
          this.esconderBotaoReplicarGrupoSubgrupo();
          this.processarGruposSubgrupos(this.grupos);
          this.grupo = null;
          observer.next();
          observer.complete();
        });
      });
    }

    public pesquisarSubgrupos(event) {
      this.grupoService.buscarGruposFilho(event.data.idGrupo).subscribe(subgrupos => {
        this.subgrupos = subgrupos;
        this.processarGruposSubgrupos(this.subgrupos);
      });
    }

    private processarGruposSubgrupos(lista: GrupoDTO[]) {
      lista.forEach(item => {
        item.areaApoio = '';
        item.areaApoio = this.incluirAreaApoio(item.areaApoio, 'Eletricista', item.flagEletricista === 'S');
        item.areaApoio = this.incluirAreaApoio(item.areaApoio, 'Eletrônico', item.flagEletronico === 'S');
        item.areaApoio = this.incluirAreaApoio(item.areaApoio, 'Engenharia', item.flagEngenharia === 'S');
        item.areaApoio = this.incluirAreaApoio(item.areaApoio, 'Mecânico', item.flagMecanico === 'S');
        item.areaApoio = this.incluirAreaApoio(item.areaApoio, 'Preventiva', item.flagPreventiva === 'S');
        item.areaApoio = this.incluirAreaApoio(item.areaApoio, 'TI', item.flagTI === 'S');
        item.areaApoio = this.incluirAreaApoio(item.areaApoio, 'Utilidades', item.flagUtilidades === 'S');
      });
    }

    private incluirAreaApoio(areaApoio: string, flag: string, flagHabilitada: boolean): string {
      return areaApoio + ((areaApoio !== '' && flagHabilitada) ? ', ' : '') + ((flagHabilitada) ? flag : '');
    }

    private abrirModalSelecionarEquipamento(): void {
      this.divModalSelecaoEquipamento = $('#id-modal-selecionar-equipamento').modal('show');
      this.confirmarSelecaoEquipamentoDesabilitada = true;
    }

    public selecionarEquipamento() {
      this.pesquisarGrupos().subscribe(() => {
        this.divModalSelecaoEquipamento.modal('hide');
        this.equipamentoSelecionado = true;
      });
    }

    public cancelarSelecaoEquipamento() {
      this.divModalSelecaoEquipamento.modal('hide');
    }

    public habilitarBotaoSelecaoEquipamento() {
      this.confirmarSelecaoEquipamentoDesabilitada = false;
    }

    //******************************
    //Modal replicar grupo/subgrupo.
    //******************************

    public replicarGrupoSubgrupo() {
      this.abrirModalReplicarGrupoSubgrupo();
    }

    private abrirModalReplicarGrupoSubgrupo(): void {
      this.replicarGrupoSubgrupoPasso = 1;
      this.divModalReplicarGrupoSubgrupo = $('#id-modal-replicar-grupo-subgrupo').modal('show');
      this.confirmarReplicarGrupoSubgrupoDesabilitado = true;
      this.replicarGrupoSubgrupoFabricanteModelo = this.equipamento.codigoManutencao.substr(0, 3);
      this.replicarGrupoSubgrupoSequencial = '';
    }

    public confirmarReplicarGrupoSubgrupo() {
      this.pesquisarHierarquiaGrupoSubgrupo().subscribe(sucesso => {
        if(sucesso == true) {
          this.replicarGrupoSubgrupoPasso += 1;
          this.replicarGruposSubgruposTree = this.construirHierarquiaArvore(this.replicarGrupos);
          this.replicarGruposSubgruposTreeSelecionados = this.selecionarTodosHierarquiaArvore(this.replicarGruposSubgruposTree);
        } else {
          this.messagesService.addErrorMessage("Equipamento não encontrado.");
        }
      });
    }

    private selecionarTodosHierarquiaArvore(replicarGruposSubgruposTree: TreeNode[]): TreeNode[] {
      let retorno: TreeNode[] = [];
      replicarGruposSubgruposTree.forEach(replicarGrupoSubgrupoTree => {
        retorno.push(replicarGrupoSubgrupoTree);
        replicarGrupoSubgrupoTree.children.forEach(child => {
          retorno.push(child);
        })
      });
      return retorno;
    }

    private pesquisarHierarquiaGrupoSubgrupo(): Observable<boolean> {
      return new Observable<boolean>(observer => {
        this.equipamentoService.buscarPorCodigoManutencaoNomeEquipamento(this.replicarGrupoSubgrupoFabricanteModelo+this.replicarGrupoSubgrupoSequencial, null).subscribe(equipamentos => {
          if(equipamentos.length > 0) {
            this.replicarEquipamento = equipamentos[0];
            this.grupoService.buscarGruposPai(this.replicarEquipamento.idEquipamento).subscribe(grupos => {
              let subgruposRetornados = 0;
              this.replicarGrupos = grupos;
              this.replicarGrupos.forEach(replicarGrupo => {
                this.grupoService.buscarGruposFilho(replicarGrupo.idGrupo).subscribe(subgrupos => {
                  replicarGrupo.subgrupos = subgrupos;
                  if((subgruposRetornados += 1) == this.replicarGrupos.length) {
                    observer.next(true);
                    observer.complete();
                  }
                });
              })
            });
          } else {
            observer.next(false);
            observer.complete();
          }
        })
      });
    }

    private construirHierarquiaArvore(replicarGrupos: GrupoDTO[]): TreeNode[] {
      let replicarGruposSubgruposTree: TreeNode[] = [];
      replicarGrupos.forEach(replicarGrupo => {
        replicarGruposSubgruposTree.push({  label: replicarGrupo.descricaoGrupo,
                                            data: replicarGrupo,
                                            expandedIcon: "",
                                            collapsedIcon: "",
                                            children: replicarGrupo.subgrupos ? this.construirHierarquiaArvore(replicarGrupo.subgrupos) : []});
      });
      return replicarGruposSubgruposTree;
    }

    public cancelarReplicarGrupoSubgrupo() {
      this.divModalReplicarGrupoSubgrupo.modal('hide');
    }

    public voltarReplicarGrupoSubgrupo() {
      this.divModalReplicarGrupoSubgrupo.modal('hide');
    }

    public salvarReplicarGrupoSubgrupo() {
      this.salvarHierarquiaArvore(this.replicarGruposSubgruposTreeSelecionados, null, 0);
    }

    private salvarHierarquiaArvore(replicarGruposSubgruposTree: TreeNode[], ultimoIdGrupoPaiSalvo: number, indice: number) {
      replicarGruposSubgruposTree[indice].data['idGrupo'] = null;
      replicarGruposSubgruposTree[indice].data['idEquipamento'] = this.equipamento.idEquipamento;
      replicarGruposSubgruposTree[indice].data['idGrupoPai'] = (!isNullOrUndefined(replicarGruposSubgruposTree[indice].data['idGrupoPai'])) ? ultimoIdGrupoPaiSalvo : null;
      this.grupoService.salvar(replicarGruposSubgruposTree[indice].data, false).subscribe(idGrupo => {
        if(indice+1 < replicarGruposSubgruposTree.length) {
          this.salvarHierarquiaArvore(replicarGruposSubgruposTree, isNullOrUndefined(replicarGruposSubgruposTree[indice].data['idGrupoPai']) ? idGrupo : ultimoIdGrupoPaiSalvo, indice+1);
        } else {
          this.pesquisarGrupos().subscribe(() => {
            this.messagesService.addSuccessMessage("Réplica de grupo efetuada com sucesso!");
            this.divModalReplicarGrupoSubgrupo.modal('hide');
          });
        }
      }, error => {
        this.messagesService.addErrorMessage(error);
      });
    }

    public verificarReplicarGrupoSubgrupoSequencial() {
      this.confirmarReplicarGrupoSubgrupoDesabilitado = this.replicarGrupoSubgrupoSequencial.length >= 3 ? false : true;
    }

    public isBotaoCadastrarExibido() {
      return this.auth.hasAnyPermission(PerfisConstants.CADASTRAR_GRUPO_SUBGRUPO_PERMISSOES);
    }

    public isBotaoEditarExibido() {
      return this.auth.hasAnyPermission(PerfisConstants.EDITAR_GRUPO_SUBGRUPO_PERMISSOES);
    }

    public isBotaoReplicarExibido() {
      return this.auth.hasAnyPermission(PerfisConstants.REPLICAR_GRUPO_SUBGRUPO_PERMISSOES);
    }

    public isBotaoRemoverExibido() {
      return this.auth.hasAnyPermission(PerfisConstants.EDITAR_GRUPO_SUBGRUPO_PERMISSOES);
    }
  }
