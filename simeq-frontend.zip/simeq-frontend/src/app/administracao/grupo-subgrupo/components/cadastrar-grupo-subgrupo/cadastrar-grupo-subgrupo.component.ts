import { SimNaoEnum } from './../../../../shared/resources/enums/sim-nao.enum';
import { Component, OnInit } from '@angular/core';
import { BreadcrumbService } from '../../../../core/breadcrumb/breadcrumb.service';
import { EquipamentoDTO } from '../../../equipamento/resources/dtos/equipamento-dto.class';
import { GrupoDTO } from '../../resources/dtos/grupo-dto.class';
import { Location } from '@angular/common';
import { AdministracaoGenericComponent } from '../../../administracao-generic.component';
import { MessagesService } from '../../../../core/messages/messages.service';
import { ActivatedRoute } from '@angular/router';
import { GrupoService } from '../../services/grupo.service';
import { StringUtils } from '../../../../core/utils/stringutils';
import { isNullOrUndefined } from 'util';

@Component({
  selector: 'simeq-cadastrar-grupo-subgrupo',
  templateUrl: './cadastrar-grupo-subgrupo.component.html',
  styleUrls: ['./cadastrar-grupo-subgrupo.component.scss']
})
export class CadastrarGrupoSubgrupoComponent extends AdministracaoGenericComponent implements OnInit {

  public equipamento: EquipamentoDTO = new EquipamentoDTO();
  public grupo: GrupoDTO = new GrupoDTO();

  public flagMecanico: boolean = null;
  public flagEletricista: boolean = null;
  public flagEletronico: boolean = null;
  public flagTI: boolean = null;
  public flagUtilidades: boolean = null;
  public flagEngenharia: boolean = null;
  public flagPreventiva: boolean = null;

  constructor(breadcrumbService: BreadcrumbService,
              messagesService: MessagesService,
              private location: Location,
              private activatedRoute: ActivatedRoute,
              private grupoService: GrupoService) {
    super(messagesService);
    breadcrumbService.addRoute('/app/administracao', 'Administração', false);
    breadcrumbService.addRoute('/app/administracao/consultar-grupo-subgrupo', 'Grupos e Subgrupos', true);
    breadcrumbService.addRoute('/app/administracao/cadastrar-grupo-subgrupo', 'Cadastrar', false);
  }

  ngOnInit() {    
    this.grupo.idEquipamento = this.activatedRoute.snapshot.params['idEquipamento'];
    this.grupo.idGrupoPai = (this.activatedRoute.snapshot.params['idGrupo'] == 'null') ? null : this.activatedRoute.snapshot.params['idGrupo'];
    this.equipamento = this.activatedRoute.snapshot.data['equipamentoResolve'];
    this.inicializarChecks();
  }

  private inicializarChecks() {
    if (!isNullOrUndefined(this.grupo.idGrupoPai)) {
      let grupo = this.activatedRoute.snapshot.data['grupoResolve'];
      if (grupo.flagMecanico === SimNaoEnum.SIM) {
        this.flagMecanico = true;
      }
      if (grupo.flagEletricista === SimNaoEnum.SIM) {
        this.flagEletricista = true;
      }
      if (grupo.flagEletronico === SimNaoEnum.SIM) {
        this.flagEletronico = true;
      }
      if (grupo.flagTI === SimNaoEnum.SIM) {
        this.flagTI = true;
      }
      if (grupo.flagUtilidades === SimNaoEnum.SIM) {
        this.flagUtilidades = true;
      }
      if (grupo.flagEngenharia === SimNaoEnum.SIM) {
        this.flagEngenharia = true;
      }
      if (grupo.flagPreventiva === SimNaoEnum.SIM) {
        this.flagPreventiva = true;
      }
    }
  }

  public salvar() {
    this.beforeSalvar();
    if(this.validarCamposObrigatorios()) {
      this.grupoService.salvar(this.grupo).subscribe(codigo => {
        this.guardarMensagem(this.isGrupo() ? `Cadastro de Grupo efetuado com sucesso! Código gerado: ${StringUtils.padZeroes(codigo, 2)}` : `Cadastro de Subgrupo efetuado com sucesso! Código gerado: ${StringUtils.padZeroes(codigo, 2)}`);
        this.location.back();
      }, error => {
        this.messagesService.addErrorMessage(error);
      });
    }
  }

  private beforeSalvar() {
    this.grupo.descricaoGrupo = this.grupo.descricaoGrupo.toLocaleUpperCase();
    this.grupo.descricaoObservacao = !isNullOrUndefined(this.grupo.descricaoObservacao) ? this.grupo.descricaoObservacao.toLocaleUpperCase() : undefined;
    this.grupo.flagMecanico = this.flagMecanico ? 'S' : 'N';
    this.grupo.flagEletricista = this.flagEletricista ? 'S' : 'N';
    this.grupo.flagEletronico = this.flagEletronico ? 'S' : 'N';
    this.grupo.flagTI = this.flagTI ? 'S' : 'N';
    this.grupo.flagUtilidades = this.flagUtilidades ? 'S' : 'N';
    this.grupo.flagEngenharia = this.flagEngenharia ? 'S' : 'N';
    this.grupo.flagPreventiva = this.flagPreventiva ? 'S' : 'N';
  }

  private validarCamposObrigatorios(): boolean {
    let campos: string[] = [];
    if(StringUtils.isNullOrUndefinedOrEmpty(this.grupo.descricaoGrupo)) {
      campos.push('Descrição');
    }
    if(campos.length > 0) {
      this.mostrarMensagemCamposObrigatorios(campos);
      return false;
    }
    return true;
  }

  public cancelar() {
    this.location.back();
  }

  public isGrupo(): boolean {
    return (this.grupo.idGrupoPai == undefined) ? true : false;
  }
}
