import { PerfisConstants } from './../../core/security/perfis.constants';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MainComponent } from '../../main/main.component';
import { DetalharEditarGrupoSubgrupoComponent } from './components/detalhar-editar-grupo-subgrupo/detalhar-editar-grupo-subgrupo.component';
import { CadastrarGrupoSubgrupoComponent } from './components/cadastrar-grupo-subgrupo/cadastrar-grupo-subgrupo.component';
import { ConsultarGrupoSubgrupoComponent } from './components/consultar-grupo-subgrupo/consultar-grupo-subgrupo.component';
import { BuscaGrupoResolve } from './resolves/busca-grupo.resolve';
import { BuscaEquipamentoResolve } from '../equipamento/resolves/busca-equipamento.resolve';
import { AuthGuard } from '../../core/security/auth.guard';
import { AuthenticationService } from '../../core/security/auth.service';
import { DetalharEditarAuthGuard } from '../../core/security/detalhar-editar-auth.guard';

const routes: Routes = [
    { path: 'app', component: MainComponent,
        children: [
            {
                path: 'administracao/consultar-grupo-subgrupo',
                component: ConsultarGrupoSubgrupoComponent,
                canActivate: [AuthGuard],
                data: {funcionalidade: PerfisConstants.CONSULTAR_GRUPO_SUBGRUPO_PERMISSOES}
            },
            {
                path: 'administracao/cadastrar-grupo-subgrupo/:idEquipamento/:idGrupo',
                component: CadastrarGrupoSubgrupoComponent,
                canActivate: [AuthGuard],
                data: {funcionalidade: PerfisConstants.CADASTRAR_GRUPO_SUBGRUPO_PERMISSOES},
                resolve: {equipamentoResolve: BuscaEquipamentoResolve,
                grupoResolve: BuscaGrupoResolve}
            },
            {
                path: 'administracao/detalhar-editar-grupo-subgrupo/:isDetalhar/:idEquipamento/:idGrupo/:idGrupoPai',
                component: DetalharEditarGrupoSubgrupoComponent,
                canActivate: [DetalharEditarAuthGuard],
                data: {funcionalidadeDetalhar: PerfisConstants.DETALHAR_GRUPO_SUBGRUPO_PERMISSOES, funcionalidadeEditar: PerfisConstants.EDITAR_GRUPO_SUBGRUPO_PERMISSOES},
                resolve: {equipamentoResolve: BuscaEquipamentoResolve,
                grupoResolve: BuscaGrupoResolve}
            }
        ]
    },
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class GrupoSubgrupoRoutingModule { }
