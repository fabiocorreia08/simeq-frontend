import { SharedModule } from './../../shared/shared.module';
import { NgModule } from '@angular/core';
import { GrupoService } from './services/grupo.service';
import { GrupoSubgrupoRoutingModule } from './grupo-subgrupo-routing.module';
import { DetalharEditarGrupoSubgrupoComponent } from './components/detalhar-editar-grupo-subgrupo/detalhar-editar-grupo-subgrupo.component';
import { CadastrarGrupoSubgrupoComponent } from './components/cadastrar-grupo-subgrupo/cadastrar-grupo-subgrupo.component';
import { ConsultarGrupoSubgrupoComponent } from './components/consultar-grupo-subgrupo/consultar-grupo-subgrupo.component';
import { EquipamentoService } from '../equipamento/services/equipamento.service';
import { FormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ButtonModule, InputMaskModule, DataTableModule, DropdownModule, CheckboxModule, InputTextareaModule, TreeModule } from 'primeng/primeng';
import { CoreModule } from '../../core/core.module';
import { BuscaEquipamentoResolve } from '../equipamento/resolves/busca-equipamento.resolve';
import { BuscaGrupoResolve } from './resolves/busca-grupo.resolve';
import { TextMaskModule } from 'angular2-text-mask';
import {TooltipModule} from 'primeng/tooltip';

@NgModule({
    declarations: [
        ConsultarGrupoSubgrupoComponent,
        CadastrarGrupoSubgrupoComponent,
        DetalharEditarGrupoSubgrupoComponent
    ],
    imports: [GrupoSubgrupoRoutingModule,
                FormsModule,
                BrowserAnimationsModule,
                ButtonModule,
                CoreModule,
                InputMaskModule,
                DataTableModule,
                DropdownModule,
                CheckboxModule,
                InputTextareaModule,
                TreeModule,
                TextMaskModule,
                SharedModule,
                TooltipModule
  ],

    providers: [GrupoService,
                EquipamentoService,
                BuscaEquipamentoResolve,
                BuscaGrupoResolve]
})
export class GrupoSubgrupoModule {}
