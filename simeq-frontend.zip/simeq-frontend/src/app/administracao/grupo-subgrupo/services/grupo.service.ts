import { Observable } from 'rxjs/Observable';
import { LabelValue } from './../../../core/models/label-value';
import { Http } from '@angular/http';
import { Injectable } from '@angular/core';
import { AbstractResource } from '../../../core/http/abstract.resource';
import { GrupoDTO } from '../resources/dtos/grupo-dto.class';

@Injectable()
export class GrupoService extends AbstractResource<any>{

  private baseEndPoint: string = "/grupo";

  constructor(http: Http) {
    super(http, '');
  }

  public buscarGrupo(idGrupo: number): Observable<GrupoDTO> {
    return super.getOne(this.baseEndPoint, idGrupo);
  }

  public buscarGruposPai(idEquipamento: number): Observable<GrupoDTO[]> {
    return super.getList(this.baseEndPoint + `/grupos-pai/${idEquipamento}`);
  }

  public buscarGruposFilho(idGrupoPai: number): Observable<GrupoDTO[]> {
    return super.getList(this.baseEndPoint + `/grupos-filho/${idGrupoPai}`);
  }

  public salvar(grupoDTO: GrupoDTO, retornarCodigo?: boolean): Observable<number>{
    return super.post(this.baseEndPoint+((retornarCodigo != undefined) ? `/${retornarCodigo}` : ``), grupoDTO);
  }

  public atualizar(grupoDTO: GrupoDTO): Observable<any>{
    return super.put(this.baseEndPoint, grupoDTO);
  }

  public remover(idGrupo: number): Observable<any>{
    return super.delete(this.baseEndPoint, idGrupo);
  }

  public buscarGruposPorEquipamento(idEquipamento: number): Observable<LabelValue[]> {
    return super.getList(this.baseEndPoint + '/equipamento', idEquipamento);
  }


}
