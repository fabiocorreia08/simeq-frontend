import { isNullOrUndefined } from 'util';
import { GrupoService } from "../services/grupo.service";
import { ActivatedRouteSnapshot, Resolve } from "@angular/router";
import { Injectable } from "@angular/core";
import { GrupoDTO } from "../resources/dtos/grupo-dto.class";

@Injectable()
export class BuscaGrupoResolve implements Resolve<GrupoDTO> {

  constructor(private grupoService: GrupoService) { }

  resolve(route: ActivatedRouteSnapshot) {
    let param = route.params['idGrupo'];
    if(!isNullOrUndefined(param) && param !== "null"){
      return this.grupoService.buscarGrupo(param);
    }
    return null;
  }
  
}