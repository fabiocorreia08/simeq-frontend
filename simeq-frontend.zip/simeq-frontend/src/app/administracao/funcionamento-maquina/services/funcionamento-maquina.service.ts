import { Injectable } from "@angular/core";
import { AbstractResource } from "../../../core/http/abstract.resource";
import { FuncionamentoMaquinaDTO } from "../resources/dtos/funcionamento-maquina.dto";
import { Http } from "@angular/http";
import { FuncionamentoMaquinaVO } from "../resources/vo/funcionamento-maquina.vo";
import { Observable } from 'rxjs/Observable';
import { Pagina } from "../../../core/models/pagina.model";
import { LabelValue } from "../../../core/models/label-value";

@Injectable()
export class FuncionamentoMaquinaService extends AbstractResource<any> {

    private readonly baseEndPoint: string = '/funcionamento-maquina';

    constructor(http: Http) {
        super(http, '');
    }

    public buscarTodosMeses(): Observable<LabelValue[]> {
        return super.getList(this.baseEndPoint + '/meses');
    }

    public buscarCalendario(idEquipamento: number, mes: number, ano: number): Observable<FuncionamentoMaquinaDTO> {
        return super.getOne(this.baseEndPoint + '/buscar-calendario/' + idEquipamento + '/' + mes + '/' + ano);
    }

    public filtrar(filtro: FuncionamentoMaquinaVO, params?: any): Observable<Pagina<FuncionamentoMaquinaDTO>> {
        return super.filter(this.baseEndPoint + '/filtrar', filtro, params);
    }

    public salvar(funcionamentoMaquinaDTO: FuncionamentoMaquinaDTO) {
        return super.post(this.baseEndPoint, funcionamentoMaquinaDTO);
    }

    public atualizar(funcionamentoMaquinaDTO: FuncionamentoMaquinaDTO) {
        return super.put(this.baseEndPoint, funcionamentoMaquinaDTO);
    }

    public buscarFiltro(filtro: FuncionamentoMaquinaVO) {
        return super.getQueryParams(this.baseEndPoint, filtro);
    }

    public gerarCalendarioAnual(funcionamentoMaquinaDTO: FuncionamentoMaquinaDTO): Observable<any> {        
        return super.post(this.baseEndPoint + '/gerar-calendario-anual', funcionamentoMaquinaDTO);
    }
}
