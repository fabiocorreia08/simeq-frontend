export class FuncionamentoMaquinaVO {
    public idEquipamento: number;
    public codigoManutencao:string;
    public nomeEquipamento:string;
    public codigoCentroCusto: number;
    public quantidadeHorasPadrao: any;
    public hierarquiaCentroCusto: string;
    public data: Date;
    public ano: number;
    public numeroAno: number;   
    public mes: number;   
    public meses: number [] = [];     
}