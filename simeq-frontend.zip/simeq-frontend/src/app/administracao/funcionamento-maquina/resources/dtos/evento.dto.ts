export class EventoDTO {
    public id: number;
    public title: string;
    public start: string;

    constructor(title?, start?, id?) {
        this.id = id;
        this.title = title;
        this.start = start;
    }
}
