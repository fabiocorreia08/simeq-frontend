import { FuncionamentoMaquinaDiaDTO } from "./funcionamento-maquina-dia.dto";

export class FuncionamentoMaquinaDTO {
    public id: number;
    public idEquipamento: number;
    public codigoCentroCusto: number;
    public codigoManutencao:string;
    public quantidadeHorasPadrao: any;
    public ano: number;
    public mes: number;
    public codigoUsuario: string;
    public dataUltimaAlteracao: string;
    public timestamp: Date;
    public diasFuncionamento: FuncionamentoMaquinaDiaDTO [] = [];    
    public equipamentos: number [] = [];
    public meses: number [] = [];    
}
