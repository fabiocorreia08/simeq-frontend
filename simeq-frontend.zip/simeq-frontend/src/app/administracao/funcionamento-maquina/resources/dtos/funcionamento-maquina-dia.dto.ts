export class FuncionamentoMaquinaDiaDTO {
    public id: number;
    public dia: number;
    public quantidadeHoras: any;

    constructor(dia?, quantidadeHoras?, id?) {
        this.dia = dia;
        this.quantidadeHoras = quantidadeHoras;
        this.id = id;
    }
}
