import { PerfisConstants } from './../../core/security/perfis.constants';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MainComponent } from '../../main/main.component';
import { AuthGuard } from '../../core/security/auth.guard';
import { CadastarFuncionamentoMaquinaComponent } from './components/cadastro-funcionamento-maquina/cadastrar-funcionamento-maquina.component';
import { BuscarEquipamentosResolve } from './resolves/buscar-equipamentos.resolve';
import { CadastrarFuncionamentoMaquinaAnualComponent } from './components/cadastrar-funcionamento-maquina-anual/cadastrar-funcionamento-maquina-anual.component';
import { ConsultarFuncionamentoMaquinaAnualComponent } from './components/consultar-funcionamento-maquina-anual/consultar-funcionamento-maquina-anual.component';

const routes: Routes = [
    { path: 'app', component: MainComponent,
        children: [
            {
                path: 'administracao/cadastrar-funcionamento-maquina',
                component: CadastarFuncionamentoMaquinaComponent,
                canActivate: [AuthGuard],
                data: {funcionalidade: PerfisConstants.CADASTAR_FUNCIONAMENTO_MAQUINA},
                resolve : {
                   equipamentosResolve : BuscarEquipamentosResolve
                }
            },
            {
                path: 'administracao/consultar-funcionamento-maquina-anual',
                component: ConsultarFuncionamentoMaquinaAnualComponent,
                canActivate: [AuthGuard],
                data: {funcionalidade: PerfisConstants.CADASTAR_FUNCIONAMENTO_MAQUINA},
                resolve : {
                   equipamentosResolve : BuscarEquipamentosResolve
                }
            },
            {
                path: 'administracao/cadastrar-funcionamento-maquina-anual',
                component: CadastrarFuncionamentoMaquinaAnualComponent,
                canActivate: [AuthGuard],
                data: {funcionalidade: PerfisConstants.CADASTAR_FUNCIONAMENTO_MAQUINA},
                resolve : {
                   equipamentosResolve : BuscarEquipamentosResolve
                }
            }

        ]
    },
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class FuncionamentoMaquinaRoutingModule { }
