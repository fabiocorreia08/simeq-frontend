import { Component, OnInit } from '@angular/core';
import { BreadcrumbService } from '../../../../core/breadcrumb/breadcrumb.service';
import { MessagesService } from '../../../../core/messages/messages.service';
import { Pagina } from '../../../../core/models/pagina.model';
import { AdministracaoGenericComponent } from '../../../administracao-generic.component';
import { FuncionamentoMaquinaDTO } from '../../resources/dtos/funcionamento-maquina.dto';
import { FuncionamentoMaquinaVO } from '../../resources/vo/funcionamento-maquina.vo';
import { FuncionamentoMaquinaService } from '../../services/funcionamento-maquina.service';
import { Location } from '@angular/common';
import { AuthenticationService } from '../../../../core/security/auth.service';
import { ActivatedRoute } from "@angular/router";
import { LazyLoadEvent } from 'primeng/components/common/api';
import { LabelValue } from '../../../../core/models/label-value';
import { ArrayUtil } from '../../../../shared/Utils/ArrayUtil';

@Component({
  selector: 'simeq-consultar-funcionamento-maquina-anual',
  templateUrl: './consultar-funcionamento-maquina-anual.component.html',
  styleUrls: ['./consultar-funcionamento-maquina-anual.component.scss']
})
export class ConsultarFuncionamentoMaquinaAnualComponent extends AdministracaoGenericComponent implements OnInit {

  public buscaHabilitada = false;
  public pagina: Pagina<FuncionamentoMaquinaDTO> = new Pagina<FuncionamentoMaquinaDTO>();
  public filtro: FuncionamentoMaquinaVO = new FuncionamentoMaquinaVO();  
  public codigoMask = [/[aA-zZ]/, /[aA-zZ]/, '-', /[aA-zZ]/, '-', /\d/, /\d/, /\d/,];
  public listaMes: LabelValue[] = [];
  public listaAno: LabelValue[] = [];
  public mesesSelecionados: number[] = null;
  
  constructor(private auth: AuthenticationService,
    private breadcrumbService: BreadcrumbService,
    private route: ActivatedRoute,
    private location: Location,
    private funcionamentoMaquinaService: FuncionamentoMaquinaService,
    messagesService: MessagesService
  ) {
    super(messagesService);
    this.breadcrumbService.addRoute('/app/administracao', 'Administração', false);
    this.breadcrumbService.addRoute('/app/administracao/consultar-funcionamento-maquina-anual', 'Calendário de Equipamentos Anual', false);
    this.breadcrumbService.addRoute('/app/administracao/consultar-funcionamento-maquina-anual', 'Consultar', false);
   }

  ngOnInit() {    
    //this.limparFiltros();
    //this.filtrar();   
    this.carregarMeses();
    this.carregarAno(); 
  }

  ngOnDestroy(): void {
    localStorage.setItem("buscaHabilitada", JSON.stringify(this.buscaHabilitada));
    localStorage.setItem("filtroFuncionamentoMaquina", JSON.stringify(this.filtro))
  }

  public carregarMeses(): void {
    this.funcionamentoMaquinaService.buscarTodosMeses()
      .subscribe(m => {
        this.listaMes = m;
      });
  }

  public carregarAno(): void {
    let dataAtual = new Date();
    this.listaAno.push(new LabelValue((dataAtual.getFullYear() - 1).toString(), (dataAtual.getFullYear() - 1)));
    this.listaAno.push(new LabelValue(dataAtual.getFullYear().toString(), dataAtual.getFullYear()));
    this.listaAno.push(new LabelValue((dataAtual.getFullYear() + 1).toString(), (dataAtual.getFullYear() + 1)));
    this.listaAno = ArrayUtil.adicionarPrimeiroValor(this.listaAno, 'Selecione', null);
  }

  public pesquisar(): void {
    this.buscaHabilitada = true;
    this.pagina = new Pagina(); 
    this.filtro.codigoManutencao = this.limparRegex(this.filtro.codigoManutencao);   
    this.filtrar();
  }

  public filtrar(): void {   
    this.funcionamentoMaquinaService.filtrar(this.filtro, this.pagina)
      .subscribe((pagina) => {
        this.pagina = pagina;
      },
      (error) => {
        this.messagesService.addErrorMessage(error);
      });
  }

  public paginar(event: LazyLoadEvent): void {
    if(this.buscaHabilitada) {
      this.pagina = new Pagina<FuncionamentoMaquinaDTO>(event.first, event.rows);
      this.filtrar();
    }
  }

  public limparFiltros(): void {
    this.buscaHabilitada = false;
    this.pagina = new Pagina();
    this.filtro = new FuncionamentoMaquinaVO();
  }

  private popularFiltros(): void {
    this.buscaHabilitada = localStorage.getItem("buscaHabilitada") ? JSON.parse(localStorage.getItem("buscaHabilitada")) : false;
    this.filtro = localStorage.getItem("filtroFuncionamentoMaquina") ? JSON.parse(localStorage.getItem("filtroFuncionamentoMaquina")) : new FuncionamentoMaquinaVO();
    localStorage.removeItem("buscaHabilitada");
    localStorage.removeItem("filtroFuncionamentoMaquina");
    if(this.buscaHabilitada) {
      this.pesquisar();
    }
  }  

  private limparRegex(input: string) {
    if (input) {
      input = input.replace(/_/g, "");
      input = input.replace("-", "");
      input = input.replace("-", "");
    }
    return input;
  }  

  public cancelar() {
    this.location.back();
  }

  exibirHorasPadrao(codigoManutencao): void{        
    //this.manutencaoPreventivaService.buscarPreventivaPorNumeroSolicitacao(numeroSolicitacao).subscribe(m => {         
    //  this.sugestao = m.sugestao;     
    //  this.numeroSolicitacao = m.numeroSolicitacao;
    //}); 
    
  } 

  atualizar(){
  }

}
