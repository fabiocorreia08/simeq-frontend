import { Component, OnInit } from '@angular/core';
import { AdministracaoGenericComponent } from '../../../administracao-generic.component';
import { BreadcrumbService } from '../../../../core/breadcrumb/breadcrumb.service';
import { MessagesService } from '../../../../core/messages/messages.service';
import { Location } from '@angular/common';
import { FuncionamentoMaquinaDTO } from '../../resources/dtos/funcionamento-maquina.dto';
import { Pagina } from '../../../../core/models/pagina.model';
import { FuncionamentoMaquinaVO } from '../../resources/vo/funcionamento-maquina.vo';
import { FuncionamentoMaquinaService } from '../../services/funcionamento-maquina.service';
import { LazyLoadEvent } from 'primeng/components/common/api';
import { MesEnum } from '../../resolves/enums/mes.enum';
import { AuthenticationService } from '../../../../core/security/auth.service';
import { ActivatedRoute } from "@angular/router";
import { CentroCustoService } from '../../../../shared/services/centro-custo.service';
import { LabelValue } from '../../../../core/models/label-value';
import { EquipamentoService } from '../../../equipamento/services/equipamento.service';
import { isNull, isNullOrUndefined, log } from 'util';

import { EquipamentoDTO } from '../../../equipamento/resources/dtos/equipamento-dto.class';
import { StringUtils } from '../../../../core/utils/stringutils';
import { ArrayUtil } from '../../../../shared/Utils/ArrayUtil';

@Component({
  selector: 'simeq-cadastrar-funcionamento-maquina-anual',
  templateUrl: './cadastrar-funcionamento-maquina-anual.component.html',
  styleUrls: ['./cadastrar-funcionamento-maquina-anual.component.scss']
})
export class CadastrarFuncionamentoMaquinaAnualComponent extends AdministracaoGenericComponent implements OnInit {

  public readonly MAXIMO_EQUIPAMENTOS_SELECIONADOS: number = 10;

  public buscaHabilitada = false;
  public filtro: FuncionamentoMaquinaVO = new FuncionamentoMaquinaVO();
  public funcionamentoMaquina = new FuncionamentoMaquinaDTO();     
  public pagina: Pagina<FuncionamentoMaquinaDTO> = new Pagina<FuncionamentoMaquinaDTO>();
  public codigoMask = [/[aA-zZ]/, /[aA-zZ]/, '-', /[aA-zZ]/, '-', /\d/, /\d/, /\d/,];
  public listaMes: LabelValue[] = [];
  public listaAno: LabelValue[] = [];
  public mesesSelecionados: number[] = null;
  public listaCentroCusto: LabelValue[] = [];
  public listaEquipamento: LabelValue[] = [];
  public equipamento: EquipamentoDTO;

  constructor(private auth: AuthenticationService,
    private breadcrumbService: BreadcrumbService,
    private route: ActivatedRoute,    
    private location: Location,    
    private equipamentoService: EquipamentoService,
    private funcionamentoMaquinaService: FuncionamentoMaquinaService,
    messagesService: MessagesService) { 
    super(messagesService);
    this.breadcrumbService.addRoute('/app/administracao', 'Administração', false);
    this.breadcrumbService.addRoute('/app/administracao/cadastrar-funcionamento-maquina-anual', 'Calendário de Equipamentos Anual', false);
    this.breadcrumbService.addRoute('/app/administracao/cadastrar-funcionamento-maquina-anual', 'Cadastrar', false);    
  }

  ngOnInit() {     
    this.carregarEquipamento(); 
    this.carregarMeses(); 
    this.carregarAno();     
  }

  ngOnDestroy(): void {
    localStorage.setItem("buscaHabilitada", JSON.stringify(this.buscaHabilitada));
    localStorage.setItem("filtroFuncionamentoMaquina", JSON.stringify(this.filtro))
  }

  public carregarMeses(): void {
    this.funcionamentoMaquinaService.buscarTodosMeses()
      .subscribe(m => {
        this.listaMes = m;
      });
  }

  public carregarAno(): void {
    let dataAtual = new Date();
    this.listaAno.push(new LabelValue(dataAtual.getFullYear().toString(), dataAtual.getFullYear()));
    this.listaAno.push(new LabelValue((dataAtual.getFullYear() + 1).toString(), (dataAtual.getFullYear() + 1)));
    this.listaAno = ArrayUtil.adicionarPrimeiroValor(this.listaAno, 'Selecione', null);
  }

  public carregarEquipamento(): void {
    this.equipamentoService.buscarTodosLabelValue()
    .subscribe(e => {
      this.listaEquipamento = e;
    });     
  }

  public onChangeEquipamentos(equipamentos: number[]) {
    if (equipamentos.length > this.MAXIMO_EQUIPAMENTOS_SELECIONADOS) {
      equipamentos.splice(equipamentos.length - 1, 1);
    }
  }

  public pesquisar(): void {
    this.buscaHabilitada = true;
    this.pagina = new Pagina(); 
    this.filtro.codigoManutencao = this.limparRegex(this.filtro.codigoManutencao);   
    this.filtrar();
  }

  public filtrar(): void {   
    this.funcionamentoMaquinaService.filtrar(this.filtro, this.pagina)
      .subscribe((pagina) => {
        this.pagina = pagina;
      },
      (error) => {
        this.messagesService.addErrorMessage(error);
      });
  }

  public paginar(event: LazyLoadEvent): void {
    if(this.buscaHabilitada) {
      this.pagina = new Pagina<FuncionamentoMaquinaDTO>(event.first, event.rows);
      this.filtrar();
    }
  }

  public limparFiltros(): void {
    this.buscaHabilitada = false;
    this.pagina = new Pagina();
    this.filtro = new FuncionamentoMaquinaVO();
  }

  private popularFiltros(): void {
    this.buscaHabilitada = localStorage.getItem("buscaHabilitada") ? JSON.parse(localStorage.getItem("buscaHabilitada")) : false;
    this.filtro = localStorage.getItem("filtroFuncionamentoMaquina") ? JSON.parse(localStorage.getItem("filtroEquipamento")) : new FuncionamentoMaquinaVO();
    localStorage.removeItem("buscaHabilitada");
    localStorage.removeItem("filtroFuncionamentoMaquina");
    if(this.buscaHabilitada) {
      this.pesquisar();
    }
  }

  private limparRegex(input: string) {
    if (input) {
      input = input.replace(/_/g, "");
      input = input.replace("-", "");
      input = input.replace("-", "");
    }
    return input;
  }

  public gerarCalendarioAnual(): void {    
    this.recuperarUsuarioLogado();  
    this.funcionamentoMaquinaService.gerarCalendarioAnual(this.funcionamentoMaquina)
      .subscribe(result => {
        this.messagesService.addSuccessMessage("Operação realizada com sucesso");  
        this.funcionamentoMaquina = new FuncionamentoMaquinaDTO();                           
      },
        erro => {
          this.messagesService.addErrorMessage("Já existe calendário para esse(s) equipamento(s)");
    });        
  }

  public verifiarCalendarioExiste(): void {    
    this.funcionamentoMaquina.equipamentos.forEach(e => {        
      this.funcionamentoMaquina.meses.forEach(m =>{
         this.funcionamentoMaquinaService.buscarCalendario(e, m, this.funcionamentoMaquina.ano)          
           .subscribe(result => {
             if(result==null){
              this.messagesService.addSuccessMessage("Não existe calendário para esse equipamento");               
             }else{
              this.equipamentoService.buscarPorId(e).subscribe(equipamento => {
                this.equipamento = equipamento;
                this.messagesService.addErrorMessage("Já existe calendário para o equipamento: "+this.equipamento.codigoManutencao+" | Mês: "+m+" | Ano: "+this.funcionamentoMaquina.ano); 
              });                
             }                                  
           },
             erro => {
               this.messagesService.addErrorMessage("Ocorreu um erro inesperado");
         });
      });
   }); 
  }

  private recuperarUsuarioLogado(): any {
    let usuario: any = this.auth.getAuthenticatedUser();
    if (!isNullOrUndefined(usuario)) {
      this.funcionamentoMaquina.codigoUsuario = usuario.details.matricula;
      this.funcionamentoMaquina.timestamp = new Date();      
    }
  }

  public desabilitarBotaoGerarCalendarioAnual() {        
    if (this.funcionamentoMaquina.equipamentos.length==0 
        || isNullOrUndefined(this.funcionamentoMaquina.quantidadeHorasPadrao)
        || isNullOrUndefined(this.funcionamentoMaquina.ano)
        )
    {
      return true;        
    }
    return false;
  }

  public cancelar() {
    this.location.back();
  }
  
}
