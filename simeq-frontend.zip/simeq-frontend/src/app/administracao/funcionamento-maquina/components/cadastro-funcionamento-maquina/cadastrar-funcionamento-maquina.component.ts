import { Location } from '@angular/common';
import { Component, OnInit, ViewChild, HostListener } from '@angular/core';
import { ActivatedRoute, NavigationStart, Router } from '@angular/router';
import { Options } from 'fullcalendar';
import { CalendarComponent } from 'ng-fullcalendar';
import { isNullOrUndefined, log } from 'util';
import { BreadcrumbService } from '../../../../core/breadcrumb/breadcrumb.service';
import { CalendarLocaleService } from '../../../../core/calendar.locale.service';
import { MessagesService } from '../../../../core/messages/messages.service';
import { ModalConfirmacaoComponent } from '../../../../core/modal-confirmacao/modal-confirmacao.component';
import { LabelValue } from '../../../../core/models/label-value';
import { AuthenticationService } from '../../../../core/security/auth.service';
import { PessoaService } from '../../../../shared/services/pessoa.service';
import { ArrayUtil } from '../../../../shared/Utils/ArrayUtil';
import { AdministracaoGenericComponent } from '../../../administracao-generic.component';
import { HistoricoSituacaoEquipamentoService } from '../../../equipamento/services/historico-situacao-equipamento.service';
import { EventoDTO } from '../../resources/dtos/evento.dto';
import { FuncionamentoMaquinaDiaDTO } from '../../resources/dtos/funcionamento-maquina-dia.dto';
import { FuncionamentoMaquinaDTO } from '../../resources/dtos/funcionamento-maquina.dto';
import { FuncionamentoMaquinaVO } from '../../resources/vo/funcionamento-maquina.vo';
import { FuncionamentoMaquinaService } from '../../services/funcionamento-maquina.service';
import { PerfisConstants } from './../../../../core/security/perfis.constants';

declare var $: any;

@Component({
  selector: 'simeq-cadastrar-funcionamento-maquina',
  templateUrl: './cadastrar-funcionamento-maquina.component.html',
  styleUrls: ['./cadastrar-funcionamento-maquina.component.scss']
})

export class CadastarFuncionamentoMaquinaComponent extends AdministracaoGenericComponent implements OnInit {

  public listaEquipamentos: LabelValue[] = [];
  public quantidadeHorasDiarias: string;
  public eventoSelecionado: any;
  public listaAnos: LabelValue[] = [];
  public nomeUsuarioAlteracao: string;
  public dataUltimaAlteracao;
  public divModal: any;
  public maquinaVO: FuncionamentoMaquinaVO = new FuncionamentoMaquinaVO();
  public funcionamentoMaquina = new FuncionamentoMaquinaDTO();
  public calendarOptions: Options;
  public esconderUsuario = true;
  public esconderInformacoes = true;
  private dataCalendario: Date;
  private isRedirect: boolean = false;
  private events = [];
  private eventsBackup = [];
  private url: string;
  private mesPesquisa;
  existeEvento = false;

  private readonly rotaAtual = "/app/administracao/cadastrar-funcionamento-maquina";
  private readonly mensagemQuantidadeHoras = 'A quantidade de horas informada está inválida';
  viewDate: Date = new Date();
  public dataText: string;
  public isDataFuncionamentoValida: boolean = true;
  public dataMesAno = { ano: new Date().getFullYear(), mes: new Date().getMonth() };

  @ViewChild('calendar') ucCalendar: CalendarComponent;
  @ViewChild('modalConfirmaAlteracao') modalConfirmarAlteracao: ModalConfirmacaoComponent;

  constructor(private breadcrumbService: BreadcrumbService,
    public calendarLocaleService: CalendarLocaleService,
    private route: ActivatedRoute,
    private router: Router,
    private location: Location,
    private funcionamentoMaquinaService: FuncionamentoMaquinaService,
    private pessoaService: PessoaService,
    private auth: AuthenticationService,
    private historicoSituacaoEquipamentoService: HistoricoSituacaoEquipamentoService,
    messagesService: MessagesService) {
    super(messagesService);
    this.breadcrumbService.addRoute('/app/administracao', 'Administração', false);
    this.breadcrumbService.addRoute('/app/administracao/cadastrar-funcionamento-maquina', 'Calendário de Equipamentos', false);
    this.breadcrumbService.addRoute('/app/administracao/cadastrar-funcionamento-maquina', 'Cadastrar', false);
    this.interceptarRotas();
  }

  ngOnInit() {
    this.recuperarUsuarioLogado();
    this.configuracaoCalendario();
    this.listaEquipamentos = ArrayUtil.adicionarPrimeiroValor(this.route.snapshot.data['equipamentosResolve'], "Selecione", "null");
  }

  private interceptarRotas(): void {
    this.router.events.subscribe((event) => {
      if (event instanceof NavigationStart) {
        if (this.houveModificacao() && !this.isRedirect) {
          this.url = event.url;
          this.isRedirect = true;
          this.modalAlteracao();
          this.router.navigate([this.rotaAtual]);
        }
      }
    });
  }

  private modalAlteracao(): void {
    this.modalConfirmarAlteracao.showDialog().subscribe(sucesso => {
      if (sucesso) {
        this.confirmarModalAlteracao();
      } else {
        this.cancelarModalAlteracao();
      }
    },
      () => {
        this.cancelarModalAlteracao();
      });
  }

  private confirmarModalAlteracao(): void {
    this.isRedirect = true;
    if (isNullOrUndefined(this.url)) {
      this.location.back();
    } else {
      this.router.navigate([this.url]);
      this.url = null;
    }
  }

  private cancelarModalAlteracao(): void {
    this.isRedirect = false;
    this.router.navigate([this.rotaAtual]);
  }


  public configuracaoCalendario() {

    this.calendarOptions = {
      header: {
        left: 'none',
        center: 'none',
        right: 'none'
      },
      events: [],
      locale: 'pt'
    };
  }

  public adicionarHoras() {
    if (this.validarQuantidadeHoras(this.maquinaVO.quantidadeHorasPadrao)) {
      const dataInicial = this.dataInicial();
      const dataFinal = this.dataFinal(dataInicial);
      this.adicionarEventosMesVigente(this.maquinaVO.quantidadeHorasPadrao, dataInicial, dataFinal);
    }
  }

  private validarQuantidadeHoras(horas): boolean {
    if (isNullOrUndefined(horas) || horas < 1 || horas > 24) {
      this.messagesService.addErrorMessage(this.mensagemQuantidadeHoras);
      return false;
    }

    return true;
  }

  public limpar() {
    this.calendarOptions.events = [];
    this.mesPesquisa = null;
    this.dataText = null;
    this.ucCalendar.renderEvents(this.calendarOptions.events);
    this.maquinaVO = new FuncionamentoMaquinaVO();
    this.esconderInformacoes = true;
  }

  public cancelar() {
    if(this.houveModificacao() && !this.isRedirect) {
      this.modalAlteracao();
    }else{
      this.location.back();
    }
  }

  private dataInicial(data?: Date): Date {
    this.ucCalendar.fullCalendar('gotoDate', this.zerarHoras(this.maquinaVO.data));
    let dataInicial = null;
    if (isNullOrUndefined(data)) {
      dataInicial = new Date(this.maquinaVO.data.getTime());
    } else {
      this.zerarHoras(data);
      dataInicial = data;
    }
    dataInicial.setDate(1);
    return dataInicial;
  }

  private dataFinal(dataInicial: Date): Date {
    const dataFinal: Date = new Date(dataInicial.getTime());
    dataFinal.setMonth(dataInicial.getMonth() + 1);
    dataFinal.setDate(0);
    return dataFinal;
  }

  public recuperarEvento(event: any) {
    this.eventoSelecionado = null;
    if (!isNullOrUndefined(event.event)) {
      let data: Date = event.event.start._d;
      this.adicionarDia(data);
      this.eventoSelecionado = event;
      this.encontrarEvento(this.converterData(data));
    }
    this.abrirModal();
  }


  private abrirModal(): void {
    this.quantidadeHorasDiarias = this.recuperarHorasEvento();
    this.divModal = $('#id-modal-adicionar-hora').modal('show');
  }

  public recuperarEventoDia(event: any): void {
    this.eventoSelecionado = null;
    this.dataCalendario = event.date._d;
    this.adicionarDia(this.dataCalendario);
    if (!isNullOrUndefined(this.dataCalendario) && this.mesPesquisa.getMonth() === this.dataCalendario.getMonth()) {
      this.encontrarEvento(this.converterData(this.dataCalendario));
      this.abrirModal();
    }
  }

  private encontrarEvento(data: string) {
    this.existeEvento = false;
    this.calendarOptions.events.forEach(event => {
      if (event.start == data) {
        this.eventoSelecionado = event;
        this.quantidadeHorasDiarias = this.recuperarHorasEvento();
      }
    });
    if (!isNullOrUndefined(this.eventoSelecionado)) {
      this.existeEvento = true;
    }
  }

  private recuperarHorasEvento(): string {
    return isNullOrUndefined(this.eventoSelecionado)
      ? null
      : this.recuperarHoras(this.eventoSelecionado.title);
  }

  public fecharModalQuantidadeHoras(): void {
    this.divModal.modal('hide');
  }

  public modificarEvento() {
    if (this.validarQuantidadeHoras(this.quantidadeHorasDiarias)) {
      if (isNullOrUndefined(this.eventoSelecionado)) {
        this.calendarOptions
          .events
          .push(new EventoDTO(this.formatarTituloEvento(this.quantidadeHorasDiarias), this.converterData(this.dataCalendario)));
      } else {
        this.eventoSelecionado.title = this.formatarTituloEvento(this.quantidadeHorasDiarias);
      }
      this.ucCalendar.renderEvents(this.calendarOptions.events);
      this.fecharModalQuantidadeHoras();
    }
  }

  deletarEvento() {
    let removeIndex = this.calendarOptions.events.indexOf(this.eventoSelecionado);
    this.calendarOptions.events.splice(removeIndex, 1);
    this.ucCalendar.renderEvents(this.calendarOptions.events);
    this.fecharModalQuantidadeHoras();
  }


  private recuperarEventoEdicao(dataInicial: Date): any {
    if (!isNullOrUndefined(this.funcionamentoMaquina.id)) {
      return this.funcionamentoMaquina.diasFuncionamento.filter(t => t.dia == dataInicial.getDate())[0];
    }
  }

  private adicionarEventosMesVigente(quantidadeHoras?, dataInicial?: Date, dataFinal?: Date): void {
    this.events = [];
    for (dataInicial; dataInicial <= dataFinal; dataInicial.setDate(dataInicial.getDate() + 1)) {
      let eventoRegistrado = this.recuperarEventoEdicao(dataInicial);
      if (isNullOrUndefined(eventoRegistrado)) {
        this.events.push(new EventoDTO(this.formatarTituloEvento(quantidadeHoras), this.converterData(dataInicial)));
      } else {
        this.events.push(new EventoDTO(this.formatarTituloEvento(quantidadeHoras), this.converterData(dataInicial), eventoRegistrado.id));
      }
    }
    this.ucCalendar.fullCalendar('gotoDate', this.maquinaVO.data);
    this.calendarOptions.events = [...this.events];
    this.ucCalendar.renderEvents(this.calendarOptions.events);
  }

  public buscarCentroCustoPorEquipamento(): void {    
    this.historicoSituacaoEquipamentoService.buscarCentroCustoInstalacaoPorIdEquipamento(this.maquinaVO.idEquipamento)
      .subscribe((h: any) => {
        let idEquipamento = this.maquinaVO.idEquipamento;
        this.limpar();
        this.maquinaVO.idEquipamento = idEquipamento;
        this.maquinaVO.codigoCentroCusto = h.codigoCentroCusto;
        this.maquinaVO.hierarquiaCentroCusto = h.hierarquiaCentroCusto;
      });
   
  }

  private converterData(data: Date): string {
    this.zerarHoras(data);
    return new Date(data).toISOString().slice(0, 10);
  }
  private formatarTituloEvento(titulo: string): string {
    return `${titulo} hrs`;
  }

  public persistir(): void {

    if (isNullOrUndefined(this.funcionamentoMaquina.id)) {
      this.salvar();
    } else {
      this.editar();
    }
    this.copiarEventos();
    this.buscarUsuarioAlteracao();
  }

  private copiarEventos(): void {
    this.eventsBackup = this.calendarOptions.events.map(a => Object.assign({}, a));
  }

  private salvar(): void {
    this.prepararDadosFuncionamentoMaquina();
    this.funcionamentoMaquinaService.salvar(this.funcionamentoMaquina)
      .subscribe(result => {
        this.messagesService.addSuccessMessage("Cadastro realizado com sucesso");
        this.buscar();
      },
        erro => {
          this.messagesService.addErrorMessage("Ocorreu um erro inesperado");
        });
  }

  private recuperarUsuarioLogado(): any {
    let usuario: any = this.auth.getAuthenticatedUser();
    if (!isNullOrUndefined(usuario)) {
      this.funcionamentoMaquina.codigoUsuario = usuario.details.matricula;
      this.funcionamentoMaquina.timestamp = new Date();
    }
  }

  private buscarUsuarioAlteracao(): void {
    this.pessoaService.buscarPessoa(this.funcionamentoMaquina.codigoUsuario)
      .subscribe(result => {
        this.nomeUsuarioAlteracao = result.nomeEmpregado;
        this.esconderUsuario = false;
      });
  }

  private editar(): void {
    this.prepararDadosEditar();
    this.funcionamentoMaquinaService.atualizar(this.funcionamentoMaquina)
      .subscribe(result => {
        this.messagesService.addSuccessMessage("Edição realizada com sucesso");
        this.funcionamentoMaquina = result;
        this.dataUltimaAlteracao = new Date();
      },
        erro => {
          this.messagesService.addErrorMessage("Ocorreu um erro inesperado");
        });
  }

  private prepararDadosEditar(): void {
    this.funcionamentoMaquina.diasFuncionamento = [];
    this.prepararDiasFuncionamento();
    this.recuperarUsuarioLogado();
  }

  private prepararDadosFuncionamentoMaquina() {
    this.funcionamentoMaquina = new FuncionamentoMaquinaDTO();
    this.funcionamentoMaquina.quantidadeHorasPadrao = this.maquinaVO.quantidadeHorasPadrao;
    this.funcionamentoMaquina.idEquipamento = this.maquinaVO.idEquipamento;
    this.funcionamentoMaquina.codigoCentroCusto = this.maquinaVO.codigoCentroCusto;
    this.funcionamentoMaquina.ano = this.maquinaVO.data.getFullYear();
    this.funcionamentoMaquina.mes = this.maquinaVO.data.getMonth() + 1;
    this.recuperarUsuarioLogado();
    this.prepararDiasFuncionamento();
  }

  private prepararDiasFuncionamento() {
    this.calendarOptions.events.forEach(evento => {
      this.funcionamentoMaquina.diasFuncionamento
        .push(new FuncionamentoMaquinaDiaDTO(this.recuperarDia(evento.start), this.recuperarHoras(evento.title), evento.id));
    });
  }

  public buscar() {
    this.prepararFiltro();
    this.funcionamentoMaquinaService.buscarFiltro(this.maquinaVO)
      .subscribe(result => {
        this.ucCalendar.fullCalendar('gotoDate', this.maquinaVO.data);
        if (isNullOrUndefined(result)) {
          this.esconderUsuario = true;
          this.funcionamentoMaquina = new FuncionamentoMaquinaDTO();
          this.eventsBackup = [];
          this.configuracaoCalendario();
        } else {
          this.configuracaoCalendario();
          this.dataUltimaAlteracao = result.dataUltimaAlteracao;
          this.funcionamentoMaquina = result;
          this.recuperarEventosBusca();
          this.buscarUsuarioAlteracao();
        }
        this.ucCalendar.renderEvents(this.calendarOptions.events);
        this.esconderInformacoes = false;
      });
  }

  private recuperarEventosBusca(): void {
    this.calendarOptions.events = [];
    this.eventsBackup = [];
    this.funcionamentoMaquina.diasFuncionamento.forEach(maq => {
      this.adicionarEventos(maq);
      this.backupEventos(maq);
    });

  }

  private adicionarEventos(maq: any) {
    this.calendarOptions.events.push(new EventoDTO(this.formatarTituloEvento(maq.quantidadeHoras),
      this.recuperarHoraEvento(maq.dia, this.funcionamentoMaquina.mes - 1, this.funcionamentoMaquina.ano),
      maq.id));
  }

  private recuperarHoraEvento(dia, mes, ano): any {
    return this.converterData(new Date(ano, mes, dia));
  }

  private zerarHoras(date: Date): void {
    date.setHours(0);
  }

  private prepararFiltro() {
    this.maquinaVO.ano = this.maquinaVO.data.getFullYear();
    this.maquinaVO.mes = this.maquinaVO.data.getMonth() + 1;
    this.mesPesquisa = new Date(this.maquinaVO.data.getTime());
  }

  private backupEventos(maq: any) {
    this.eventsBackup.push(new EventoDTO(this.formatarTituloEvento(maq.quantidadeHoras),
      this.recuperarHoraEvento(maq.dia, this.funcionamentoMaquina.mes - 1, this.funcionamentoMaquina.ano),
      maq.id));
  }

  public desabilitarBotaoAdicionarHoras(): boolean {
    if (!isNullOrUndefined(this.maquinaVO.data) && !isNullOrUndefined(this.mesPesquisa)) {
      return this.mesPesquisa.getMonth() != this.maquinaVO.data.getMonth();
    }
    return false;
  }

  public desabilitarBotaoPesquisar(): boolean {
    // tslint:disable-next-line:max-line-length
    return (!isNullOrUndefined(this.maquinaVO)) ? isNullOrUndefined(this.maquinaVO.codigoCentroCusto) ||
      (isNullOrUndefined(this.maquinaVO.ano) && isNullOrUndefined(this.maquinaVO.mes)) : false;
  }

  private recuperarDia(dia: string): string {
    return dia.split('-')[2];
  }

  private adicionarDia(data: Date): void {
    data.setDate(data.getDate() + 1);
  }

  private recuperarHoras(hora: string): string {
    return hora.slice(0, 2).trim();
  }

  private houveModificacao(): boolean {
    let modificacao = false;

    if (this.calendarOptions.events.length > 0 && this.eventsBackup.length == 0) {
      return true;
    }

    if (this.calendarOptions.events.length != this.eventsBackup.length) {
      return true;
    }

    if (this.calendarOptions.events.length > 0 && this.eventsBackup.length > 0) {
      for (let index = 0; index < this.calendarOptions.events.length; index++) {
        if (JSON.stringify(this.calendarOptions.events[index]) !== JSON.stringify(this.eventsBackup[index])) {
          modificacao = true;
        }
      }
    }


    return modificacao;
  }
  public setarDataFuncionamento(dataTxt: string): void {
    this.dataText = dataTxt;
    if (this.dataText.length === 7) {
      let items = dataTxt.split('/');
      this.maquinaVO.mes = parseInt(items[0]);
      this.maquinaVO.ano = parseInt(items[1]);
      this.maquinaVO.data = new Date(this.maquinaVO.ano, this.maquinaVO.mes - 1);
    }
  }

  public setarDataFuncionamentoValida(dataValida: boolean): void {
    this.isDataFuncionamentoValida = dataValida;
  }

  public isDataUltimaAlteracaoInstanceOfDate(): Boolean {
    return this.dataUltimaAlteracao instanceof Date;
  }

  public isBotaoCadastrarExibido() {
    return this.auth.hasAnyPermission(PerfisConstants.CADASTRAR_EQUIPAMENTO_PERMISSOES);
  }

}
