import { SharedModule } from './../../shared/shared.module';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {
    ButtonModule, InputMaskModule, DataTableModule,
    DropdownModule, CheckboxModule, InputTextareaModule, TreeModule, SharedModule as SharedModulePrimng, MultiSelectModule, CalendarModule, AccordionModule
} from 'primeng/primeng';
import { CoreModule } from '../../core/core.module';
// tslint:disable-next-line:max-line-length
import { CadastarFuncionamentoMaquinaComponent } from './components/cadastro-funcionamento-maquina/cadastrar-funcionamento-maquina.component';
import { FuncionamentoMaquinaRoutingModule } from './funcionamento-maquina-routing.module';
import { EquipamentoModule } from '../equipamento/equipamento.module';
import { TextMaskModule } from 'angular2-text-mask';
import { BuscarEquipamentosResolve } from './resolves/buscar-equipamentos.resolve';
import { FullCalendarModule } from 'ng-fullcalendar';
import { FuncionamentoMaquinaService } from './services/funcionamento-maquina.service';
import { CadastrarFuncionamentoMaquinaAnualComponent } from './components/cadastrar-funcionamento-maquina-anual/cadastrar-funcionamento-maquina-anual.component';
import { ConsultarFuncionamentoMaquinaAnualComponent } from './components/consultar-funcionamento-maquina-anual/consultar-funcionamento-maquina-anual.component';

@NgModule({
    declarations: [
        CadastarFuncionamentoMaquinaComponent,
        CadastrarFuncionamentoMaquinaAnualComponent,
        ConsultarFuncionamentoMaquinaAnualComponent
    ],
    imports: [
        FullCalendarModule,
        FuncionamentoMaquinaRoutingModule,
        SharedModulePrimng,
        EquipamentoModule,
        FormsModule,
        BrowserAnimationsModule,
        ButtonModule,
        CoreModule,
        InputMaskModule,
        InputTextareaModule,
        MultiSelectModule,
        DataTableModule,
        DropdownModule,
        CalendarModule,
        TextMaskModule,
        SharedModule,
        AccordionModule
    ],

    providers: [BuscarEquipamentosResolve, FuncionamentoMaquinaService]
})
export class FuncionamentoMaquinaModule { }
