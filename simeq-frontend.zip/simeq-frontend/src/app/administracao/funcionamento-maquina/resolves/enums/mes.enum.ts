export class MesEnum {
    static readonly JANEIRO: number = 1;
    static readonly FEVEREIRO: number = 2;
    static readonly MARCO: number = 3;
    static readonly ABRIL: number = 4;
    static readonly MAIO: number = 5;
    static readonly JUNHO: number = 6;
    static readonly JULHO: number = 7;
    static readonly AGOSTO: number = 8;
    static readonly SETEMBRO: number = 9;
    static readonly OUTUBRO: number = 10;
    static readonly NOVEMBRO: number = 11;
    static readonly DEZEMBRO: number = 12;

    public static readonly lista: {chave: any, valor: any}[] = [{chave: MesEnum.JANEIRO, valor: 'Janeiro'},
                                                                {chave: MesEnum.FEVEREIRO, valor: 'Fevereiro'},
                                                                {chave: MesEnum.MARCO, valor: 'Março'},
                                                                {chave: MesEnum.ABRIL, valor: 'Abril'},
                                                                {chave: MesEnum.MAIO, valor: 'Maio'},
                                                                {chave: MesEnum.JUNHO, valor: 'Junho'},
                                                                {chave: MesEnum.JULHO, valor: 'Julho'},
                                                                {chave: MesEnum.AGOSTO, valor: 'Agosto'},
                                                                {chave: MesEnum.SETEMBRO, valor: 'Setembro'},
                                                                {chave: MesEnum.OUTUBRO, valor: 'Outrubro'},
                                                                {chave: MesEnum.NOVEMBRO, valor: 'Novembro'},
                                                                {chave: MesEnum.DEZEMBRO, valor: 'Dezembro'}]

    public static getValor(chave: any): any {
        let retorno: {chave: any, valor: any}[] = MesEnum.lista.filter(item => item.chave === chave);
        if(retorno && retorno.length > 0) {
            return retorno[0].valor;
        } else {
            return null;
        }
    }
}