import { isNullOrUndefined } from 'util';
import { AuthenticationService } from './../../../core/security/auth.service';
import { ActivatedRouteSnapshot, Resolve } from "@angular/router";
import { Injectable } from "@angular/core";
import { LabelValue } from "../../../core/models/label-value";
import { EquipamentoService } from "../../equipamento/services/equipamento.service";

@Injectable()
export class BuscarEquipamentosResolve implements Resolve<LabelValue[]> {

  constructor(public auth: AuthenticationService,
    private equipamentoService: EquipamentoService) { }

  resolve(route: ActivatedRouteSnapshot) {
    let idPerfil = this.auth.getIdPerfil(this.auth.authInfo.details.perfis);
    if (isNullOrUndefined(idPerfil)) {
      idPerfil = 0;
    }
    return this.equipamentoService.buscarPorHierarquiaCCUsuarioLogado(idPerfil, this.auth.authInfo.username);
  }

}