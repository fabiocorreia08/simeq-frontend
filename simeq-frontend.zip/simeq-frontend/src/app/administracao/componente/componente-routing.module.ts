import { PerfisConstants } from '../../core/security/perfis.constants';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MainComponent } from '../../main/main.component';
import { CadastrarComponenteComponent } from './components/cadastrar-componente/cadastrar-componente.component';
import { DetalharEditarComponenteComponent } from './components/detalhar-editar-componente/detalhar-editar-componente.component';
import { ConsultarComponenteComponent } from './components/consultar-componente/consultar-componente.component';

import { BuscaCentrosCustoResolve } from '../../shared/resolves/busca-centros-custo.resolve';
import { AuthGuard } from '../../core/security/auth.guard';
import { AuthenticationService } from '../../core/security/auth.service';
import { DetalharEditarAuthGuard } from '../../core/security/detalhar-editar-auth.guard';
import { BuscaComponenteResolve } from './resolves/busca-componente.resolve';

const routes: Routes = [
    { path: 'app', component: MainComponent,
        children: [
            {
                path: 'administracao/consultar-componente',
                component: ConsultarComponenteComponent,
                canActivate: [AuthGuard],
                data: {funcionalidade: PerfisConstants.CONSULTAR_TECNICO_PERMISSOES},                
            },
            {
                path: 'administracao/cadastrar-componente',
                component: CadastrarComponenteComponent,
                canActivate: [AuthGuard],
                data: {funcionalidade: PerfisConstants.CADASTRAR_TECNICO_PERMISSOES},
            },
            {
                path: 'administracao/detalhar-editar-componente/:isDetalhar/:codigo',
                component: DetalharEditarComponenteComponent,
                canActivate: [DetalharEditarAuthGuard],
                data: {funcionalidadeDetalhar: PerfisConstants.DETALHAR_TECNICO_PERMISSOES, funcionalidadeEditar: PerfisConstants.EDITAR_TECNICO_PERMISSOES},
                resolve: {
                    componenteResolve: BuscaComponenteResolve
                }
            }
        ]
    },
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class ComponenteRoutingModule { }
