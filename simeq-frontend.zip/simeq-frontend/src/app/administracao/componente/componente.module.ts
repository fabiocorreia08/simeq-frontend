import { NgModule } from '@angular/core';
import { CadastrarComponenteComponent } from './components/cadastrar-componente/cadastrar-componente.component';
import { DetalharEditarComponenteComponent } from './components/detalhar-editar-componente/detalhar-editar-componente.component';

import { ComponenteRoutingModule } from './componente-routing.module';
import {
    ButtonModule,
    DataTableModule,
    InputMaskModule,
    DropdownModule,
    CalendarModule
  } from 'primeng/primeng';
import { ConsultarComponenteComponent } from './components/consultar-componente/consultar-componente.component';
import { CoreModule } from '../../core/core.module';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { SharedModule } from '../../shared/shared.module';
import { BuscaComponenteResolve } from './resolves/busca-componente.resolve';
import { ComponenteService } from './service/componente.service';

@NgModule({
    declarations: [
        ConsultarComponenteComponent,
        CadastrarComponenteComponent,
        DetalharEditarComponenteComponent
    ],
    imports: [
        ComponenteRoutingModule,
        FormsModule,
        BrowserModule,
        BrowserAnimationsModule,
        CoreModule,
        ButtonModule,
        DataTableModule,
        InputMaskModule,
        CalendarModule,
        DropdownModule,
        SharedModule
    ],
    providers: [
        ComponenteService,        
        BuscaComponenteResolve]
})
export class ComponenteModule {}
