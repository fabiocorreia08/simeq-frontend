import { ComponenteService } from "../service/componente.service";
import { ActivatedRouteSnapshot, Resolve } from "@angular/router";
import { Injectable } from "@angular/core";
import { ComponenteDTO } from "../resources/dtos/componente-dto.class";

@Injectable()
export class BuscaComponenteResolve implements Resolve<ComponenteDTO> {

  constructor(private componenteService: ComponenteService) { }

  resolve(route: ActivatedRouteSnapshot) {
    return this.componenteService.buscarPorCodigo(route.params['codigo']);
  }
  
}