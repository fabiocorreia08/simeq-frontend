export class ComponenteDTO {	
	codigo: string;
	nome: string;
	nomeClasse: string;
}
