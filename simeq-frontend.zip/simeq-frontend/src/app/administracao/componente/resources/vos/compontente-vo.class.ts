export class ComponenteVO {	
	codigo: string;
	nome: string;
	nomeClasse: string;    
}