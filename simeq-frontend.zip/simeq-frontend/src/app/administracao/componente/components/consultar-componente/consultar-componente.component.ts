import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { LazyLoadEvent } from 'primeng/primeng';
import { BreadcrumbService } from '../../../../core/breadcrumb/breadcrumb.service';
import { MessagesService } from '../../../../core/messages/messages.service';
import { ModalConfirmacaoComponent } from '../../../../core/modal-confirmacao/modal-confirmacao.component';
import { Pagina } from '../../../../core/models/pagina.model';
import { AuthenticationService } from '../../../../core/security/auth.service';
import { AdministracaoGenericComponent } from '../../../administracao-generic.component';
import { ParametroService } from '../../../parametro/service/parametro.service';
import { ComponenteDTO } from '../../resources/dtos/componente-dto.class';
import { ComponenteVO } from '../../resources/vos/compontente-vo.class';
import { ComponenteService } from '../../service/componente.service';


@Component({
  selector: 'simeq-consultar-componente',
  templateUrl: './consultar-componente.component.html',
  styleUrls: ['./consultar-componente.component.scss']
})
export class ConsultarComponenteComponent extends AdministracaoGenericComponent implements OnInit {

  @ViewChild('modalConfirmaExclusao')
  modalConfirmaExclusao: ModalConfirmacaoComponent;

  public buscaHabilitada: boolean = false;
  public filtro: ComponenteVO = new ComponenteVO;
  public pagina: Pagina<ComponenteDTO> = new Pagina<ComponenteDTO>();

  constructor(private auth: AuthenticationService,
    private breadcrumbService: BreadcrumbService,
    protected messagesService: MessagesService,
    private router: Router,    
    private componenteService: ComponenteService) { 
      super(messagesService);
    breadcrumbService.addRoute('/app/administracao', 'Administração', false);
    breadcrumbService.addRoute('/app/administracao/consultar-componente', 'Componentes', false);
    breadcrumbService.addRoute('/app/administracao/consultar-componente', 'Consultar', false);
  
    }

  ngOnInit() {
    this.limparFiltros();
    //this.filtrar();
  }

  ngOnDestroy(): void {
    localStorage.setItem("buscaHabilitada", JSON.stringify(this.buscaHabilitada));
    localStorage.setItem("filtroComponente", JSON.stringify(this.filtro))
  }

  public pesquisar(): void {
    this.buscaHabilitada = true;
    this.pagina = new Pagina();    
    this.filtrar();
  }

  public filtrar(): void {
    this.componenteService.filtrar(this.filtro, this.pagina)
      .subscribe((pagina) => {
        this.pagina = pagina;
      },
      (error) => {
        this.messagesService.addErrorMessage(error);
      });
  }

  public paginar(event: LazyLoadEvent): void {
    if(this.buscaHabilitada) {
      this.pagina = new Pagina<ComponenteDTO>(event.first, event.rows);
      this.filtrar();
    }
  }

  public limparFiltros(): void {
    this.buscaHabilitada = false;
    this.pagina = new Pagina();
    this.filtro = new ComponenteVO();
  }

  private popularFiltros(): void {
    this.buscaHabilitada = localStorage.getItem("buscaHabilitada") ? JSON.parse(localStorage.getItem("buscaHabilitada")) : false;
    this.filtro = localStorage.getItem("filtroComponente") ? JSON.parse(localStorage.getItem("filtroComponente")) : new ComponenteVO();
    localStorage.removeItem("buscaHabilitada");
    localStorage.removeItem("filtroComponente");
    if(this.buscaHabilitada) {
      this.pesquisar();
    }
  }

  public remover(codigo:string): void {    
    this.modalConfirmaExclusao.showDialog().subscribe(success => {
      if (success) {
        this.componenteService.remover(codigo).subscribe(() => {          
          this.messagesService.addSuccessMessage("Exclusão realizada com sucesso");
          this.filtrar();
        }
        , error => {
          this.messagesService.addErrorMessage(error);
        })        
      }
    });
  }

}
