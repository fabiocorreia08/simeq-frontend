import { Component, OnInit } from '@angular/core';
import { BreadcrumbService } from '../../../../core/breadcrumb/breadcrumb.service';
import { MessagesService } from '../../../../core/messages/messages.service';
import { AdministracaoGenericComponent } from '../../../administracao-generic.component';
import { ComponenteDTO } from '../../resources/dtos/componente-dto.class';
import { ComponenteService } from '../../service/componente.service';
import { Location } from '@angular/common';

@Component({
  selector: 'simeq-cadastrar-componente',
  templateUrl: './cadastrar-componente.component.html',
  styleUrls: ['./cadastrar-componente.component.scss']
})
export class CadastrarComponenteComponent extends AdministracaoGenericComponent implements OnInit {

  componenteDTO: ComponenteDTO = new ComponenteDTO;

  constructor(
    breadcrumbService: BreadcrumbService, 
    messagesService: MessagesService,
    private componenteService: ComponenteService,
    private location:Location
  ) {
    super(messagesService);
      breadcrumbService.addRoute('/app/administracao', 'Administração', false);
      breadcrumbService.addRoute('/app/administracao/consultar-componente', 'Componentes', true);
      breadcrumbService.addRoute('/app/administracao/cadastrar-componente', 'Cadastrar', false);
      
   }

  ngOnInit() {
  }

  public salvar() {   
    this.componenteService.salvar(this.componenteDTO).subscribe(
      retorno => {
        this.messagesService.addSuccessMessage('Cadastro realizado com sucesso.');
        //this.location.back();
      }, error => {
        this.messagesService.addErrorMessage(error);
      });    
  }

  public cancelar() {
    this.location.back();
  }

}
