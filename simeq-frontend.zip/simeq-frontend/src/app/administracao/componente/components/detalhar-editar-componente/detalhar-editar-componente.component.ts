import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { BreadcrumbService } from '../../../../core/breadcrumb/breadcrumb.service';
import { MessagesService } from '../../../../core/messages/messages.service';
import { AdministracaoGenericComponent } from '../../../administracao-generic.component';
import { ComponenteDTO } from '../../resources/dtos/componente-dto.class';
import { ComponenteService } from '../../service/componente.service';
import { Location } from '@angular/common';

@Component({
  selector: 'simeq-detalhar-editar-componente',
  templateUrl: './detalhar-editar-componente.component.html',
  styleUrls: ['./detalhar-editar-componente.component.scss']
})
export class DetalharEditarComponenteComponent extends AdministracaoGenericComponent implements OnInit {

  public isDetalhar: boolean;
  public componenteDTO: ComponenteDTO = new ComponenteDTO();  
  public titulo: string;

  constructor(
    private breadcrumbService: BreadcrumbService,
    private componenteService: ComponenteService,
    private activatedRoute: ActivatedRoute,
    private route: ActivatedRoute,
    private location: Location,    
    protected messagesService: MessagesService
  ) { super(messagesService) }

  ngOnInit() {
    this.verificarRota();
    this.componenteDTO = this.route.snapshot.data['componenteResolve'];
  }

  private verificarRota(): void {
    var isDetalhar = this.activatedRoute.snapshot.params['isDetalhar'];
    (isDetalhar == 0) ? this.isDetalhar = true : this.isDetalhar = false;
    this.mudarNome();
  }

  private mudarNome(): void {
    (!this.isDetalhar) ? this.titulo = "Detalhar" : this.titulo = "Editar"; 
    this.breadcrumbService.addRoute('/app/administracao', 'Administração',false);
    this.breadcrumbService.addRoute('/app/administracao/consultar-componente', 'Ações ', true);
    this.breadcrumbService.addRoute('/app/administracao/detalhar-editar-componente', this.titulo, false);
  }

  public atualizar(): void { 
    this.componenteDTO.codigo = this.componenteDTO.codigo;
    this.componenteDTO.nome = this.componenteDTO.nome;  
    this.componenteDTO.nomeClasse = this.componenteDTO.nomeClasse;  
      this.componenteService.atualizar(this.componenteDTO).subscribe(componente => {
        this.messagesService.addSuccessMessage('Atualização realizada com sucesso.');  
        //this.location.back();      
      }, error => {
        this.messagesService.addErrorMessage(error);
      });   
  } 

  public voltar(): void {
    this.location.back();
  }

}
