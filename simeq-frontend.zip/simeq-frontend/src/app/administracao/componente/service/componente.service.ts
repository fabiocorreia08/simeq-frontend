import { LabelValue } from '../../../core/models/label-value';
import { Observable } from 'rxjs/Observable';
import { Http } from '@angular/http';
import { Injectable } from '@angular/core';
import { AbstractResource } from '../../../core/http/abstract.resource';
import { Pagina } from '../../../core/models/pagina.model';
import { ComponenteDTO } from '../resources/dtos/componente-dto.class';
import { ComponenteVO } from '../resources/vos/compontente-vo.class';

@Injectable()
export class ComponenteService extends AbstractResource<any>{

  private baseEndPoint: string = "/componente";

  constructor(http: Http) {
    super(http, '');
  }

  public filtrar(filtro: ComponenteVO,  params?: any): Observable<Pagina<ComponenteDTO>> {
    return super.filter(this.baseEndPoint + '/filtrar', filtro, params);
  }

  public buscarPorId(id:number): Observable<ComponenteDTO>{
    return super.getOne(this.baseEndPoint + "/id", id);
  }

  public buscarPorCodigo(codigo: string) : Observable<ComponenteDTO> {
    return super.getOne(this.baseEndPoint + "/codigo", codigo);
  }

  public buscarPorNome(nome: string) : Observable<ComponenteDTO> {
    return super.getOne(this.baseEndPoint + "/nome", nome);
  }

  public buscarPorNomeClasse(nomeClasse: string) : Observable<ComponenteDTO> {
    return super.getOne(this.baseEndPoint + "/nomeClasse", nomeClasse);
  }

  public buscarPorValor(valor: string) : Observable<ComponenteDTO> {
    return super.getOne(this.baseEndPoint + "/valor", valor);
  }
  
  public buscarTodos(): Observable<LabelValue[]> {
    return super.getList(this.baseEndPoint);
  }

  public salvar(componenteDTO:ComponenteDTO){
    return super.post(this.baseEndPoint,componenteDTO);
  }  

  public atualizar(componenteDTO:ComponenteDTO): Observable<ComponenteDTO> {
    return super.put(this.baseEndPoint, componenteDTO);
  }

  public remover(codigo: string): Observable<ComponenteDTO>{    
    return super.delete(this.baseEndPoint, codigo);
  }
  
}
