import { HistoricoSituacaoEquipamentoDTO } from './../../resources/dtos/historico-situacao-equipamento-dto.class';
import { EquipamentoService } from './../../services/equipamento.service';
import { EquipamentoDTO } from './../../resources/dtos/equipamento-dto.class';
import { CalendarLocaleService } from './../../../../core/calendar.locale.service';
import { Component, OnInit } from '@angular/core';
import { BreadcrumbService } from '../../../../core/breadcrumb/breadcrumb.service';
import { Location } from '@angular/common';
import { AtivoInativoEnum } from '../../resources/enums/AtivoInativo.enum';
import { AdministracaoGenericComponent } from '../../../administracao-generic.component';
import { MessagesService } from '../../../../core/messages/messages.service';
import { ActivatedRoute } from '@angular/router';
import { isNullOrUndefined } from 'util';
import { StringUtils } from '../../../../core/utils/stringutils';
import { HistoricoSituacaoEquipamentoService } from '../../services/historico-situacao-equipamento.service';
import { LabelValue } from '../../../../core/models/label-value';

@Component({
  selector: 'simeq-cadastrar-equipamento',
  templateUrl: './cadastrar-equipamento.component.html',
  styleUrls: ['./cadastrar-equipamento.component.scss']
})
export class CadastrarEquipamentoComponent extends AdministracaoGenericComponent implements OnInit {

  public isPreventiva: boolean = false;
  public listaCentroCusto: LabelValue[] = [];
  public equipamentoDTO: EquipamentoDTO = new EquipamentoDTO();
  public listaStatus = AtivoInativoEnum.lista;

  public codigoMaskFabricante = [/[aA-zZ]/, /[aA-zZ]/];
  public codigoMaskModelo = [/[aA-zZ]/];

  constructor(breadcrumbService: BreadcrumbService,
    protected messagesService: MessagesService,
    private route: ActivatedRoute,
    private location: Location,
    public calendarLocaleService: CalendarLocaleService,
    private historicoSituacaoEquipamentoService: HistoricoSituacaoEquipamentoService,
    private equipamentoService: EquipamentoService
  ) {
    super(messagesService);
    breadcrumbService.addRoute('/app/administracao', 'Administração',false);
    breadcrumbService.addRoute('/app/administracao/consultar-equipamento', 'Equipamentos ', true);
    breadcrumbService.addRoute('/app/administracao/cadastrar-equipamento', 'Cadastrar', false);
  }

  ngOnInit() {
    this.listaCentroCusto = this.route.snapshot.data['centrosCustoResolve'];
  }

  public cancelar() {
    this.location.back();
  }

  public concatenarCodigoManutencao() {
    this.equipamentoDTO.codigoManutencao = this.equipamentoDTO.fabricante.toLocaleUpperCase() + this.equipamentoDTO.modelo.toLocaleUpperCase();
  }

  public changePreventiva() {
    if (this.isPreventiva) {
      this.equipamentoDTO.flagPreventiva = "S";
    } else {
      this.equipamentoDTO.flagPreventiva = "N";
    }
  }

  public salvar(): void {   
    if (this.validarCamposObrigatorios()) {
        if( this.validarCampoAnoFabricacao()){
          this.concatenarCodigoManutencao();
          let equipamentoAux: EquipamentoDTO = this.equipamentoDTO;
          this.equipamentoDTO.nomeEquipamento = this.equipamentoDTO.nomeEquipamento.toLocaleUpperCase();
          this.equipamentoDTO.numeroPatrimonio = !isNullOrUndefined(this.equipamentoDTO.numeroPatrimonio) ? this.equipamentoDTO.numeroPatrimonio.toLocaleUpperCase() : undefined;
          this.equipamentoDTO.numeroPredio = !isNullOrUndefined(this.equipamentoDTO.numeroPredio) ? this.equipamentoDTO.numeroPredio.toLocaleUpperCase() : undefined;
          this.equipamentoDTO.descricaoObservacao = !isNullOrUndefined(this.equipamentoDTO.descricaoObservacao) ? this.equipamentoDTO.descricaoObservacao.toLocaleUpperCase() : undefined;
          this.equipamentoDTO.descricaoPreRequisitoInformacao = !isNullOrUndefined(this.equipamentoDTO.descricaoPreRequisitoInformacao) ? this.equipamentoDTO.descricaoPreRequisitoInformacao.toLocaleUpperCase() : undefined;
          this.equipamentoService.salvar(this.equipamentoDTO).subscribe(equipamentoSalvo => {
            this.historicoSituacaoEquipamentoService.salvar(this.obterSituacaoEquipamento(equipamentoSalvo, equipamentoAux)).subscribe(situacaoEquipamento => {
              this.guardarMensagem("Cadastro realizado com sucesso. Código do equipamento:" + this.getCodigoManutencaoFormatado(equipamentoSalvo.codigoManutencao));
              this.location.back();
            })
          }, error => {
            this.messagesService.addErrorMessage(error);
          });    
        }
      }     
  }

  private getCodigoManutencaoFormatado(value: string): string {
    return (value) ? value.substring(0, 2) + "-" + value.substring(2, 3) + "-" + value.substring(3, 6) : '';
  }

  private obterSituacaoEquipamento(equipamentoSalvo: EquipamentoDTO, equipamento: EquipamentoDTO): HistoricoSituacaoEquipamentoDTO {
    let historicoSituacaoEquipamentoDTO: HistoricoSituacaoEquipamentoDTO = new HistoricoSituacaoEquipamentoDTO();
    historicoSituacaoEquipamentoDTO.idEquipamento = equipamentoSalvo.idEquipamento;
    historicoSituacaoEquipamentoDTO.dataInicio = equipamento.dataInstalacao;
    historicoSituacaoEquipamentoDTO.flagStatus = equipamento.flagStatus;
    historicoSituacaoEquipamentoDTO.codigoCentroCusto = equipamento.codigoCentroCusto;
    historicoSituacaoEquipamentoDTO.descricaoObservacao = equipamento.descricaoObservacao;
    return historicoSituacaoEquipamentoDTO;
  }

  private validarCampoAnoFabricacao(): boolean {
    let anoInstalacao = this.equipamentoDTO.dataInstalacao.getFullYear();

    if(this.equipamentoDTO.numeroAno > anoInstalacao ){
      this.messagesService.addErrorMessage('Ano de instalação não pode ser inferior ao Ano de fabricação.');
      return false;
    }
    return true;
  }

  private validarCamposObrigatorios(): boolean {
    let campos: string[] = [];
    if (this.equipamentoDTO.flagStatus === "null") {
      campos.push("Status");
    }
    if (StringUtils.isNullOrUndefinedOrEmpty(this.equipamentoDTO.modelo) || StringUtils.isNullOrUndefinedOrEmpty(this.equipamentoDTO.fabricante)) {
      campos.push("Código do equipamento");
    }
    if (StringUtils.isNullOrUndefinedOrEmpty(this.equipamentoDTO.nomeEquipamento)) {
      campos.push("Nome do equipamento");
    }
    if (isNullOrUndefined(this.equipamentoDTO.numeroTensao) || this.equipamentoDTO.numeroTensao.toString() === "") {
      campos.push("Tensão");
    }
    if (this.equipamentoDTO.codigoCentroCusto === "null") {
      campos.push("Centro Custo");
    }
    if (isNullOrUndefined(this.equipamentoDTO.numeroPotencia) || this.equipamentoDTO.numeroPotencia.toString() === "") {
      campos.push("Potência");
    }
    if (StringUtils.isNullOrUndefinedOrEmpty(this.equipamentoDTO.nomeTipoPotencia)) {
      campos.push("Tipo Potência");
    }
    if (isNullOrUndefined(this.equipamentoDTO.numeroPeso) || this.equipamentoDTO.numeroPeso.toString() === "") {
      campos.push("Peso");
    }
    if (isNullOrUndefined(this.equipamentoDTO.numeroAno) || this.equipamentoDTO.numeroAno.toString() === "") {
      campos.push("Ano de fabricação");
    }
    if (isNullOrUndefined(this.equipamentoDTO.dataInstalacao) || this.equipamentoDTO.dataInstalacao.toString() === "") {
      campos.push("Data da instalação");
    }
    if (campos.length > 0) {
      this.mostrarMensagemCamposObrigatorios(campos);
      return false;
    }   
    return true;
  }

}
