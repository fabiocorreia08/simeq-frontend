import { DataTable } from 'primeng/primeng';
import { HistoricoSituacaoEquipamentoService } from './../../services/historico-situacao-equipamento.service';
import { HistoricoSituacaoEquipamentoDTO } from './../../resources/dtos/historico-situacao-equipamento-dto.class';
import { ModalConfirmacaoComponent } from './../../../../core/modal-confirmacao/modal-confirmacao.component';
import { MessagesService } from './../../../../core/messages/messages.service';
import { CalendarLocaleService } from './../../../../core/calendar.locale.service';
import { EquipamentoDTO } from './../../resources/dtos/equipamento-dto.class';
import { ActivatedRoute } from '@angular/router';
import { Component, OnInit, ViewChild } from '@angular/core';
import { BreadcrumbService } from '../../../../core/breadcrumb/breadcrumb.service';
import { Location } from '@angular/common';
import { isNullOrUndefined } from 'util';
import { EquipamentoService } from '../../services/equipamento.service';
import { AdministracaoGenericComponent } from '../../../administracao-generic.component';
import { StringUtils } from '../../../../core/utils/stringutils';
import { AtivoInativoEnum } from '../../resources/enums/AtivoInativo.enum';
import { LabelValue } from '../../../../core/models/label-value';
import * as moment from 'moment';

declare var $: any;
@Component({
  selector: 'simeq-detalhar-editar-equipamento',
  templateUrl: './detalhar-editar-equipamento.component.html',
  styleUrls: ['./detalhar-editar-equipamento.component.scss']
})
export class DetalharEditarEquipamentoComponent extends AdministracaoGenericComponent implements OnInit {

  @ViewChild('dataTable') private dataTable: DataTable;
  @ViewChild('modalConfirmaExclusao') public modalConfirmaExclusao: ModalConfirmacaoComponent;
  public listaCentroCusto: LabelValue[] = [];
  public listaStatus = AtivoInativoEnum.lista;
  public historicoSituacoesEquipamento: HistoricoSituacaoEquipamentoDTO[] = [];
  public equipamentoDTO: EquipamentoDTO = new EquipamentoDTO();
  public historicoEquipamentoDTO = new HistoricoSituacaoEquipamentoDTO();
  public isPreventiva: boolean = false;
  public habilitarDataFimDaSituacao: boolean = false;
  public isDetalharSituacao: boolean;
  public isDetalhar: boolean;
  public titulo: string;
  public divModal: any;
  public sinalizarCamposObrigatoriosEquipamento="*";
  public sinalizarCamposObrigatoriosSituacaoEquipamento="*";

  constructor(private breadcrumbService: BreadcrumbService,
    private activatedRoute: ActivatedRoute,
    private location: Location,
    public calendarLocaleService: CalendarLocaleService,
    private route: ActivatedRoute,
    private equipamentoService: EquipamentoService,
    private historicoSituacaoEquipamentoService: HistoricoSituacaoEquipamentoService,
    protected messagesService: MessagesService) {
    super(messagesService);
  }

  ngOnInit() {
    this.verificarRota();
    this.listaCentroCusto = this.route.snapshot.data['centrosCustoResolve'];
    this.equipamentoDTO = this.route.snapshot.data['equipamentoResolve'];
    this.historicoSituacoesEquipamento = this.route.snapshot.data['historicoSituacaoEquipamentoResolve'];
    this.habilitarAcaoEditarDasSituacoes(this.historicoSituacoesEquipamento);
    this.habilitarAcaoExcluirDasSituacoes(this.historicoSituacoesEquipamento);
    this.inicializarDados();
    this.atribuirAsterisco();
    this.getCodigoManutencaoFormatado();
  }

  private verificarRota(): void {
    var isDetalhar = this.activatedRoute.snapshot.params['isDetalhar'];
    (isDetalhar == 0) ? this.isDetalhar = true : this.isDetalhar = false;
    this.mudarNome();
  }

  private mudarNome(): void {
    (this.isDetalhar) ? this.titulo = "Detalhar" : this.titulo = "Editar"; 
    this.breadcrumbService.addRoute('/app/administracao', 'Administração',false);
    this.breadcrumbService.addRoute('/app/administracao/consultar-equipamento', 'Equipamentos ', true);
    this.breadcrumbService.addRoute('/app/administracao/detalhar-editar-equipamento', this.titulo, false);
  }

  private inicializarDados(): void {
    if (this.equipamentoDTO.flagPreventiva === "S") {
      this.isPreventiva = true;
    } else {
      this.isPreventiva = false;
    }
  }

  public voltar(): void {
    this.location.back();
  }

  public abrirModalParaSalvarSituacao(): void {
    this.isDetalharSituacao = false;
    this.habilitarDataFimDaSituacao = true;
    this.abrirModalSituacaoEquipamento();
  }

  public abrirModalParaEditarSituacao(idSituacao: number): void {
    this.sinalizarCamposObrigatoriosSituacaoEquipamento="*";
    this.isDetalharSituacao = false;
    this.habilitarDataFimDaSituacao = true;
    this.recuperarSituacao(idSituacao);
  }

  public abrirModalParaDetalharSituacao(idSituacao: number): void {
    this.sinalizarCamposObrigatoriosSituacaoEquipamento="";
    this.isDetalharSituacao = true;
    this.habilitarDataFimDaSituacao = true;
    this.recuperarSituacao(idSituacao);
  }

  public abrirModalSituacaoEquipamento(): void {
    this.divModal = $('#id-modal-situacao-equipamento').modal('show');
  }

  public fecharModalSituacaoEquipamento(): void {
    this.historicoEquipamentoDTO = new HistoricoSituacaoEquipamentoDTO();
    this.divModal = $('#id-modal-situacao-equipamento').modal('hide');
  }

  private recuperarSituacao(idHistoricoSituacao: number): void {
    this.historicoSituacaoEquipamentoService.buscarSituacaoPorId(idHistoricoSituacao).subscribe(situacao => {
      this.historicoEquipamentoDTO = situacao;
      if(!isNullOrUndefined(this.historicoEquipamentoDTO.dataInicio)){
        this.historicoEquipamentoDTO.dataInicio = moment(this.historicoEquipamentoDTO.dataInicio).toDate();
      }
      if(!isNullOrUndefined(this.historicoEquipamentoDTO.dataFim)){
        this.historicoEquipamentoDTO.dataFim = moment(this.historicoEquipamentoDTO.dataFim).toDate();
      }
      this.abrirModalSituacaoEquipamento();
    })
  }

  public salvarOuEditarSituacao(): void {
    this.historicoEquipamentoDTO.descricaoObservacao = !isNullOrUndefined(this.historicoEquipamentoDTO.descricaoObservacao) ? this.historicoEquipamentoDTO.descricaoObservacao.toLocaleUpperCase() : undefined;
    this.historicoEquipamentoDTO.hierarquiaCentroCusto = this.listaCentroCusto
      .find(c => c.value === this.historicoEquipamentoDTO.codigoCentroCusto).label;
    this.historicoEquipamentoDTO.idHistoricoSituacaoEquipamento == null ? this.salvarSituacao() : this.editarSituacao();
  }

  public salvarSituacao(): void {
    if (this.camposObrigatoriosPreenchidosNaModalSituacao() && this.periodoValido()) {
      this.historicoEquipamentoDTO.idEquipamento = this.equipamentoDTO.idEquipamento;
      this.historicoSituacaoEquipamentoService.salvar(this.historicoEquipamentoDTO).subscribe(equipamento => {
        this.atualizarTabelaSituacoes();
        this.fecharModalSituacaoEquipamento();
        this.messagesService.addSuccessMessage('Cadastro realizado com sucesso.');
      }, error => {
        this.messagesService.addErrorMessage(error);
      });
    }
  }

  public editarSituacao(): void {
    if (this.camposObrigatoriosPreenchidosNaModalSituacao() && this.periodoValido()) {
      this.historicoSituacaoEquipamentoService.atualizar(this.historicoEquipamentoDTO).subscribe(equipamento => {
        this.atualizarTabelaSituacoes();
        this.fecharModalSituacaoEquipamento();
        this.messagesService.addSuccessMessage('Alteração realizada com sucesso.');
      }, error => {
        this.messagesService.addErrorMessage(error);
      });
    }
  }

  private atribuirAsterisco():void{
    (this.isDetalhar) ? this.sinalizarCamposObrigatoriosEquipamento = "" : this.sinalizarCamposObrigatoriosEquipamento="*";
  }

  private atualizarTabelaSituacoes(): void {
    this.historicoSituacaoEquipamentoService.buscarTodosPor(this.equipamentoDTO.idEquipamento).subscribe(situacoes => {
      this.habilitarAcaoEditarDasSituacoes(situacoes);
      this.habilitarAcaoExcluirDasSituacoes(situacoes);
      this.historicoSituacoesEquipamento = situacoes;
    })
  }
  private isUnicaSitacao(historicoSituacoes: HistoricoSituacaoEquipamentoDTO[]): boolean {
    return (historicoSituacoes.length == 1);
  }

  private habilitarAcaoEditarDasSituacoes(historicoSituacoesEquipamentoDTO: HistoricoSituacaoEquipamentoDTO[]): void {
    historicoSituacoesEquipamentoDTO.forEach(situacao => {
      if (isNullOrUndefined(situacao.dataFim)) {
        situacao.hasAcaoEditarHabilitado = true;
      } else {
        situacao.hasAcaoEditarHabilitado = false;
      }
    })
  }

  private habilitarAcaoExcluirDasSituacoes(historicoSituacoesEquipamentoDTO: HistoricoSituacaoEquipamentoDTO[]): void {
    historicoSituacoesEquipamentoDTO.forEach(situacao => {
      if (isNullOrUndefined(situacao.dataFim) && !this.isUnicaSitacao(historicoSituacoesEquipamentoDTO)) {
        situacao.hasAcaoExcluirHabilitado = true;
      } else {
        situacao.hasAcaoExcluirHabilitado = false;
      }
    })
  }

  private camposObrigatoriosPreenchidosNaModalSituacao(): boolean {
    let campos: string[] = [];
    if (this.historicoEquipamentoDTO.flagStatus === "null") {
      campos.push("Status");
    }
    if (isNullOrUndefined(this.historicoEquipamentoDTO.dataInicio)|| this.historicoEquipamentoDTO.dataInicio.toString() === "" ){
      campos.push('Data início');
    }
    if (this.historicoEquipamentoDTO.codigoCentroCusto === "null") {
      campos.push('Centro de custo da instalação');
    }
    if (campos.length > 0) {
      this.mostrarMensagemCamposObrigatorios(campos);
      return false;
    }
    return true;
  }

  public atualizar(): void {
    if (this.camposObrigatoriosPreenchidos()) {
      if(this.validarSequencia(this.equipamentoDTO.sequencia)){
        this.equipamentoDTO.codigoManutencao = this.equipamentoDTO.fabricante.toLocaleUpperCase() + this.equipamentoDTO.modelo.toLocaleUpperCase() + this.equipamentoDTO.sequencia;
        this.equipamentoDTO.nomeEquipamento = this.equipamentoDTO.nomeEquipamento.toLocaleUpperCase();
        this.equipamentoDTO.numeroPatrimonio = !isNullOrUndefined(this.equipamentoDTO.numeroPatrimonio) ? this.equipamentoDTO.numeroPatrimonio.toLocaleUpperCase() : undefined;
        this.equipamentoDTO.descricaoObservacao = !isNullOrUndefined(this.equipamentoDTO.descricaoObservacao) ? this.equipamentoDTO.descricaoObservacao.toLocaleUpperCase() : undefined;
        this.equipamentoDTO.descricaoPreRequisitoInformacao = !isNullOrUndefined(this.equipamentoDTO.descricaoPreRequisitoInformacao) ? this.equipamentoDTO.descricaoPreRequisitoInformacao.toLocaleUpperCase() : undefined;
        this.equipamentoService.atualizar(this.equipamentoDTO).subscribe(equipamento => {
        this.guardarMensagem('Atualização realizada com sucesso.');
        this.location.back();
      }, error => {
        this.messagesService.addErrorMessage(error);
      });
      }else{
        this.messagesService.addErrorMessage("Sequência inválida.");
      }
    }
  }

  private validarSequencia(sequencia): boolean{
    if (sequencia.length<3||(sequencia==="000")) {      
      return false;
    }
    return true;    
  }

  private getCodigoManutencaoFormatado() {        
    this.equipamentoDTO.fabricante = this.equipamentoDTO.codigoManutencao.substring(0, 2);
    this.equipamentoDTO.modelo = this.equipamentoDTO.codigoManutencao.substring(2, 3);
    this.equipamentoDTO.sequencia = this.equipamentoDTO.codigoManutencao.substring(3, 6);    
  }

  private camposObrigatoriosPreenchidos(): boolean {
    let campos: string[] = [];
    if (StringUtils.isNullOrUndefinedOrEmpty(this.equipamentoDTO.nomeEquipamento)) {
      campos.push("Nome do equipamento");
    }
    if (isNullOrUndefined(this.equipamentoDTO.numeroTensao) || this.equipamentoDTO.numeroTensao.toString() === "") {
      campos.push("Tensão");
    }
    if (isNullOrUndefined(this.equipamentoDTO.numeroPotencia) || this.equipamentoDTO.numeroPotencia.toString() === "") {
      campos.push("Potência");
    }
    if (StringUtils.isNullOrUndefinedOrEmpty(this.equipamentoDTO.nomeTipoPotencia)) {
      campos.push("Tipo Potência");
    }
    if (isNullOrUndefined(this.equipamentoDTO.numeroPeso) || this.equipamentoDTO.numeroPeso.toString() === "") {
      campos.push("Peso");
    }
    if (isNullOrUndefined(this.equipamentoDTO.numeroAno) || this.equipamentoDTO.numeroAno.toString() === "") {
      campos.push("Ano de fabricação");
    }
    if (isNullOrUndefined(this.equipamentoDTO.dataInstalacao) || this.equipamentoDTO.dataInstalacao.toString() === "") {
      campos.push("Data da instalação");
    }
    if (campos.length > 0) {
      this.mostrarMensagemCamposObrigatorios(campos);
      return false;
    }
    return true;
  }

  private periodoValido(): boolean {
    if (!isNullOrUndefined(this.historicoEquipamentoDTO.dataFim) && (this.historicoEquipamentoDTO.dataFim < this.historicoEquipamentoDTO.dataInicio)) {
      this.messagesService.addErrorMessage("A data fim não pode ser menor do que a data início");
      return false;
    }
    return true;
  }

  public remover(historicoSituacaoEquipamento: HistoricoSituacaoEquipamentoDTO): void {
    this.modalConfirmaExclusao.showDialog().subscribe(success => {
      if (success) {
        this.historicoSituacaoEquipamentoService.remover(historicoSituacaoEquipamento.idHistoricoSituacaoEquipamento).subscribe(() => {
          this.atualizarTabelaSituacoes();
          this.messagesService.addSuccessMessage("Exclusão realizada com sucesso");
        }, error => {
          this.messagesService.addErrorMessage(error);
        })
      }
    });
  }

  public changePreventiva(): void {
    if (this.isPreventiva) {
      this.equipamentoDTO.flagPreventiva = "S";
    } else {
      this.equipamentoDTO.flagPreventiva = "N";
    }
  }

}
