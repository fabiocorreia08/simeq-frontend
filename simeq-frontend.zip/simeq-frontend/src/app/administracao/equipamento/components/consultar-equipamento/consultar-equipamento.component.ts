import { PerfisConstants } from './../../../../core/security/perfis.constants';
import { EquipamentoService } from './../../services/equipamento.service';
import { EquipamentoDTO } from './../../resources/dtos/equipamento-dto.class';
import { AtivoInativoEnum } from './../../resources/enums/AtivoInativo.enum';
import { OnInit, Component } from "@angular/core";
import { BreadcrumbService } from "../../../../core/breadcrumb/breadcrumb.service";
import { ActivatedRoute } from "@angular/router";
import { Pagina } from '../../../../core/models/pagina.model';
import { EquipamentoVO } from '../../resources/vo/equipamento.vo.class';
import { CentroCustoService } from '../../../../shared/services/centro-custo.service';
import { AdministracaoGenericComponent } from '../../../administracao-generic.component';
import { MessagesService } from '../../../../core/messages/messages.service';
import { LazyLoadEvent } from 'primeng/components/common/api';
import { OnDestroy } from '@angular/core/src/metadata/lifecycle_hooks';
import { AuthenticationService } from '../../../../core/security/auth.service';
import { LabelValue } from '../../../../core/models/label-value';
import { ArrayUtil } from '../../../../shared/Utils/ArrayUtil';
import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';

@Component({
  selector: 'simeq-consultar-equipamento',
  templateUrl: './consultar-equipamento.component.html',
  styleUrls: ['./consultar-equipamento.component.scss']
})
export class ConsultarEquipamentoComponent extends AdministracaoGenericComponent implements OnInit, OnDestroy {

  public buscaHabilitada = false;
  public filtro: EquipamentoVO = new EquipamentoVO();
  public listaStatus = AtivoInativoEnum.lista;
  public listaCentroCusto: LabelValue[] = [];
  public pagina: Pagina<EquipamentoDTO> = new Pagina<EquipamentoDTO>();
  public codigoMask = [/[aA-zZ]/, /[aA-zZ]/, '-', /[aA-zZ]/, '-', /\d/, /\d/, /\d/,];


  constructor(private auth: AuthenticationService,
    private breadcrumbService: BreadcrumbService,
    private centroCustoService: CentroCustoService,
    private route: ActivatedRoute,
    protected messagesService: MessagesService,
    private equipamentoService: EquipamentoService) {
    super(messagesService);
    breadcrumbService.addRoute('/app/administracao', 'Administração',false);
    breadcrumbService.addRoute('/app/administracao/consultar-equipamento', 'Equipamentos ', false);
    breadcrumbService.addRoute('/app/administracao/consultar-equipamento','Consultar', false);
  }

  ngOnInit() {       
    this.listaCentroCusto = this.route.snapshot.data['centrosCustoResolve'];
    this.listaCentroCusto = ArrayUtil.adicionarPrimeiroValor(this.listaCentroCusto, "Selecione", "null");
    //this.popularFiltros();
    this.limparFiltros();
    this.mostrarMensagemGuardada();
  }

  ngOnDestroy(): void {
    localStorage.setItem("buscaHabilitada", JSON.stringify(this.buscaHabilitada));
    localStorage.setItem("filtroEquipamento", JSON.stringify(this.filtro))
  }

  public pesquisar(): void {
    this.buscaHabilitada = true;
    this.pagina = new Pagina();
    this.filtro.codigoManutencao = this.limparRegex(this.filtro.codigoManutencao);
    this.filtrar();
  }

  public filtrar(): void {
    this.equipamentoService.filtrar(this.filtro, this.pagina)
      .subscribe((pagina) => {
        this.pagina = pagina;
      },
      (error) => {
        this.messagesService.addErrorMessage(error);
      });
  }

  public paginar(event: LazyLoadEvent): void {
    if(this.buscaHabilitada) {
      this.pagina = new Pagina<EquipamentoDTO>(event.first, event.rows);
      this.filtrar();
    }
  }

  public limparFiltros(): void {
    this.buscaHabilitada = false;
    this.pagina = new Pagina();
    this.filtro = new EquipamentoVO();
  }

  private popularFiltros(): void {
    this.buscaHabilitada = localStorage.getItem("buscaHabilitada") ? JSON.parse(localStorage.getItem("buscaHabilitada")) : false;
    this.filtro = localStorage.getItem("filtroEquipamento") ? JSON.parse(localStorage.getItem("filtroEquipamento")) : new EquipamentoVO();
    localStorage.removeItem("buscaHabilitada");
    localStorage.removeItem("filtroEquipamento");
    if(this.buscaHabilitada) {
      this.pesquisar();
    }
  }

  private limparRegex(input: string) {
    if (input) {
      input = input.replace(/_/g, "");
      input = input.replace("-", "");
      input = input.replace("-", "");
    }
    return input;
  }

  public isBotaoCadastrarExibido() {
    return this.auth.hasAnyPermission(PerfisConstants.CADASTRAR_EQUIPAMENTO_PERMISSOES);
  }

  public isBotaoEditarExibido() {
    return this.auth.hasAnyPermission(PerfisConstants.EDITAR_EQUIPAMENTO_PERMISSOES);
  }
}