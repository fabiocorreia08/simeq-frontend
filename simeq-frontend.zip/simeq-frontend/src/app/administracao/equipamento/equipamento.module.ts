import { SharedModule } from './../../shared/shared.module';
import { BuscaEquipamentoResolve } from './resolves/busca-equipamento.resolve';
import { NgModule } from '@angular/core';
import { EquipamentoService } from './services/equipamento.service';
import { EquipamentoRoutingModule } from './equipamento-routing.module';
import { DetalharEditarEquipamentoComponent } from './components/detalhar-editar-equipamento/detalhar-editar-equipamento.component';
import { CadastrarEquipamentoComponent } from './components/cadastrar-equipamento/cadastrar-equipamento.component';
import { InputMaskModule, DataTableModule, DropdownModule, InputTextareaModule, CheckboxModule, CalendarModule } from 'primeng/primeng';
import { FormsModule } from '@angular/forms';
import { CoreModule } from '../../core/core.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ButtonModule } from 'primeng/components/button/button';
import { ConsultarEquipamentoComponent } from './components/consultar-equipamento/consultar-equipamento.component';
import { CentroCustoService } from '../../shared/services/centro-custo.service';
import { HistoricoSituacaoEquipamentoService } from './services/historico-situacao-equipamento.service';
import { BuscaHistoricoSituacaoEquipamentoResolve } from './resolves/busca-historico-situacao-equipamento.resolve';
import { TextMaskModule } from "angular2-text-mask";

@NgModule({
    declarations: [
        ConsultarEquipamentoComponent,
        CadastrarEquipamentoComponent,
        DetalharEditarEquipamentoComponent,
    ],
    imports: [
        EquipamentoRoutingModule,
        FormsModule,
        BrowserAnimationsModule,
        ButtonModule,
        CoreModule,
        InputMaskModule,
        InputTextareaModule,
        DataTableModule,
        DropdownModule,
        CalendarModule,
        CheckboxModule,
        TextMaskModule,
        SharedModule
    ],

    providers: [
        EquipamentoService,
        HistoricoSituacaoEquipamentoService,
        CentroCustoService,
        BuscaEquipamentoResolve,
        BuscaHistoricoSituacaoEquipamentoResolve
    ]
})
export class EquipamentoModule {}
