import { HistoricoSituacaoEquipamentoService } from './../services/historico-situacao-equipamento.service';
import { HistoricoSituacaoEquipamentoDTO } from './../resources/dtos/historico-situacao-equipamento-dto.class';
import { ActivatedRouteSnapshot, Resolve } from "@angular/router";
import { Injectable } from "@angular/core";

@Injectable()
export class BuscaHistoricoSituacaoEquipamentoResolve implements Resolve<HistoricoSituacaoEquipamentoDTO[]> {

  constructor(private historicoSituacaoEquipamentoService: HistoricoSituacaoEquipamentoService) { }

  resolve(route: ActivatedRouteSnapshot) {
    return this.historicoSituacaoEquipamentoService.buscarTodosPor(route.params['idEquipamento']);
  }

}