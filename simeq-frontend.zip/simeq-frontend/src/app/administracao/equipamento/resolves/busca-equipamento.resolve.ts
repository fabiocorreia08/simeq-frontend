import { AuthenticationService } from './../../../core/security/auth.service';
import { ActivatedRouteSnapshot, Resolve } from "@angular/router";
import { Injectable } from "@angular/core";
import { EquipamentoDTO } from "../resources/dtos/equipamento-dto.class";
import { EquipamentoService } from "../services/equipamento.service";

@Injectable()
export class BuscaEquipamentoResolve implements Resolve<EquipamentoDTO> {

  constructor(private equipamentoService: EquipamentoService,
    public auth: AuthenticationService) { }

  resolve(route: ActivatedRouteSnapshot) {
    return this.equipamentoService.buscarPorId(route.params['idEquipamento']);
  }
  
}