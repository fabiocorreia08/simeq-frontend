import { Injectable } from "@angular/core";
import { AbstractResource } from "../../../core/http/abstract.resource";
import { Http } from "@angular/http";
import { Observable } from "rxjs/Observable";
import { HistoricoSituacaoEquipamentoDTO } from '../resources/dtos/historico-situacao-equipamento-dto.class';

@Injectable()
export class HistoricoSituacaoEquipamentoService extends AbstractResource<HistoricoSituacaoEquipamentoDTO>{

    private readonly baseEndPoint: string = "/historico-situacao-equipamento"

    constructor(http: Http) {
        super(http, '');
    }

    public buscarTodosPor(id: number): Observable<HistoricoSituacaoEquipamentoDTO[]> {
        return super.getList(this.baseEndPoint + "/todos", id);
    }

    public buscarSituacaoPorId(id: number): Observable<HistoricoSituacaoEquipamentoDTO> {
        return super.getOne(this.baseEndPoint, id);
    }

    public remover(id: number): Observable<HistoricoSituacaoEquipamentoDTO> {
        return super.delete(this.baseEndPoint, id);
    }

    public salvar(historicoSituacaoEquipamentoDTO: HistoricoSituacaoEquipamentoDTO): Observable<HistoricoSituacaoEquipamentoDTO> {
        return super.post(this.baseEndPoint, historicoSituacaoEquipamentoDTO);
    }

    public atualizar(historicoSituacaoEquipamentoDTO: HistoricoSituacaoEquipamentoDTO): Observable<HistoricoSituacaoEquipamentoDTO> {
        return super.put(this.baseEndPoint, historicoSituacaoEquipamentoDTO);
    }

    public buscarCentroCustoInstalacaoPorIdEquipamento(idEquipamento: number): Observable<HistoricoSituacaoEquipamentoDTO> {
        return  super.getOne(this.baseEndPoint + '/equipamento-centro-custo-instalacao', idEquipamento);
    }

    public buscarCentroCustoAtivoPorIdEquipamento(idEquipamento: number): Observable<HistoricoSituacaoEquipamentoDTO> {
        return  super.getOne(this.baseEndPoint + '/centro-custo-ativo', idEquipamento);
    }

}
