import { LabelValue } from './../../../core/models/label-value';
import { EquipamentoVO } from './../resources/vo/equipamento.vo.class';
import { EquipamentoDTO } from './../resources/dtos/equipamento-dto.class';
import { Observable } from 'rxjs/Observable';
import { Http } from '@angular/http';
import { Injectable } from '@angular/core';
import { AbstractResource } from '../../../core/http/abstract.resource';
import { Pagina } from '../../../core/models/pagina.model';

@Injectable()
export class EquipamentoService extends AbstractResource<any>{

  private baseEndPoint: string = "/equipamento";

  constructor(http: Http) {
    super(http, '');
  }

  public buscarPorId(id: number): Observable<EquipamentoDTO> {
    return super.getOne(this.baseEndPoint, id);
  }

  public filtrar(filtro: EquipamentoVO, params?: any): Observable<Pagina<EquipamentoDTO>> {
    return super.filter(this.baseEndPoint + '/filtrar', filtro, params);
  }

  public salvar(equipamentoDTO: EquipamentoDTO) {
    return super.post(this.baseEndPoint, equipamentoDTO);
  }
  public buscarPorCodigoManutencaoNomeEquipamento(codigoManutencao: string, nomeEquipamento: string): Observable<EquipamentoDTO[]> {
    let url: string = `/buscar-codigo-nome?${codigoManutencao ? 'codigoManutencao=' + codigoManutencao : ''}${nomeEquipamento ? '&nomeEquipamento=' + nomeEquipamento : ''}`
    return super.getList(this.baseEndPoint + url);
  }

  public atualizar(realocacaoTecnicoDTO: EquipamentoDTO): Observable<EquipamentoDTO> {
    return super.put(this.baseEndPoint, realocacaoTecnicoDTO);
  }

  public buscarTodosLabelValue(): Observable<LabelValue[]> {
    return super.getList(this.baseEndPoint);
  }

  public buscarPorHierarquiaCCUsuarioLogado(idPerfil :number, ccUsuarioLogado :string):Observable<LabelValue[]>{
    return super.getList(this.baseEndPoint + '/hierarquia/' + idPerfil, ccUsuarioLogado);
  }

  public buscarPorHierarquiaFamilia(idPerfil :number, ccUsuarioLogado :string):Observable<LabelValue[]>{
    return super.getList(this.baseEndPoint + '/hierarquia/familia/' + idPerfil, ccUsuarioLogado);
  }
}
