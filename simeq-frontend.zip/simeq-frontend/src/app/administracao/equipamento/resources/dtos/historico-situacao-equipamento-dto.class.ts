export class HistoricoSituacaoEquipamentoDTO {
    idHistoricoSituacaoEquipamento: number;
	flagStatus: string = "A";
  	codigoCentroCusto: string = "null";
  	hierarquiaCentroCusto: string = "null";
	dataInicio: Date;
	dataFim: Date;
	descricaoObservacao: string;
	idEquipamento: number;
	hasAcaoEditarHabilitado: boolean;
	hasAcaoExcluirHabilitado: boolean;
}
