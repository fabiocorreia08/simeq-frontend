export class EquipamentoDTO{
    idEquipamento?:number;
    codigoManutencao:string;
    flagStatus:string = "A";
    nomeEquipamento:string;
    dataInstalacao?:Date;
    codigoCentroCusto: string = "null";
    numeroAno: number;
    descricaoPreRequisitoInformacao: string;
    descricaoObservacao: string;
    numeroPatrimonio: string;
    numeroPredio: string;
    numeroPeso: number;
    numeroTensao: number;
    numeroPotencia: number;
    fabricante: string;
    modelo: string;
    sequencia: string;
    flagPreventiva:string = "N";
    nomeTipoPotencia:string;    
}
