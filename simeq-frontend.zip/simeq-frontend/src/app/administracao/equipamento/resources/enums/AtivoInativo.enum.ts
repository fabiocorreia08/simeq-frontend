export class AtivoInativoEnum {
    static readonly ATIVO: string = 'A';
    static readonly INATIVO: string = 'I';

    public static readonly lista: {chave: any, valor: any}[] = [  {chave: AtivoInativoEnum.ATIVO, valor: 'Ativo'},
                                                                {chave: AtivoInativoEnum.INATIVO, valor: 'Inativo'}]

    public static getValor(chave: any): any {
        let retorno: {chave: any, valor: any}[] = AtivoInativoEnum.lista.filter(item => item.chave === chave);
        if(retorno && retorno.length > 0) {
            return retorno[0].valor;
        } else {
            return null;
        }
    }
}