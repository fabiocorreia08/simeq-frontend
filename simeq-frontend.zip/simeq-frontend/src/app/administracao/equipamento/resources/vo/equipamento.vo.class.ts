export class EquipamentoVO{
    idEquipamento: number;
    codigoManutencao:string;
    nomeEquipamento:string;
    numeroAno:Date;
    flagStatus:string = "null";
    codigoCentroCusto: string = "null";
    dataInstalacao:Date;

}

