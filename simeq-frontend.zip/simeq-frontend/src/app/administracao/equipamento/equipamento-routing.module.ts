import { PerfisConstants } from './../../core/security/perfis.constants';
import { BuscaHistoricoSituacaoEquipamentoResolve } from './resolves/busca-historico-situacao-equipamento.resolve';
import { BuscaEquipamentoResolve } from './resolves/busca-equipamento.resolve';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MainComponent } from '../../main/main.component';
import { DetalharEditarEquipamentoComponent } from './components/detalhar-editar-equipamento/detalhar-editar-equipamento.component';
import { CadastrarEquipamentoComponent } from './components/cadastrar-equipamento/cadastrar-equipamento.component';
import { ConsultarEquipamentoComponent } from './components/consultar-equipamento/consultar-equipamento.component';
import { BuscaCentrosCustoResolve } from '../../shared/resolves/busca-centros-custo.resolve';
import { AuthGuard } from '../../core/security/auth.guard';
import { AuthenticationService } from '../../core/security/auth.service';
import { DetalharEditarAuthGuard } from '../../core/security/detalhar-editar-auth.guard';

const routes: Routes = [
    { path: 'app', component: MainComponent,
        children: [
            {
                path: 'administracao/consultar-equipamento',
                component: ConsultarEquipamentoComponent,
                canActivate: [AuthGuard],
                data: {funcionalidade: PerfisConstants.CONSULTAR_EQUIPAMENTO_PERMISSOES},
                resolve: {
                    centrosCustoResolve: BuscaCentrosCustoResolve
                }
            },            
            {
                path: 'administracao/cadastrar-equipamento',
                component: CadastrarEquipamentoComponent,
                canActivate: [AuthGuard],
                data: {funcionalidade: PerfisConstants.CADASTRAR_EQUIPAMENTO_PERMISSOES},
                resolve: {
                    centrosCustoResolve: BuscaCentrosCustoResolve
                }
            },
            {
                path: 'administracao/detalhar-editar-equipamento/:isDetalhar/:idEquipamento',
                component: DetalharEditarEquipamentoComponent ,
                canActivate: [DetalharEditarAuthGuard],
                data: {funcionalidadeDetalhar: PerfisConstants.DETALHAR_EQUIPAMENTO_PERMISSOES, funcionalidadeEditar: PerfisConstants.EDITAR_EQUIPAMENTO_PERMISSOES},
                resolve: {
                    equipamentoResolve: BuscaEquipamentoResolve,
                    historicoSituacaoEquipamentoResolve: BuscaHistoricoSituacaoEquipamentoResolve,
                    centrosCustoResolve: BuscaCentrosCustoResolve
                }
            }
        ]
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class EquipamentoRoutingModule { }
