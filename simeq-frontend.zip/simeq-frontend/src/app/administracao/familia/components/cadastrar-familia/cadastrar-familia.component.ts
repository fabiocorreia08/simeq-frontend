import { Component, OnInit, ViewChild } from '@angular/core';
import { Location } from '@angular/common';
import { ActivatedRoute } from '@angular/router';

import { take } from 'rxjs/operators';

import { BreadcrumbService } from '../../../../core/breadcrumb/breadcrumb.service';
import { MessagesService } from '../../../../core/messages/messages.service';
import { AdministracaoGenericComponent } from '../../../administracao-generic.component';
import { LabelValue } from '../../../../core/models/label-value';
import { FamiliaDTO } from '../../resources/dtos/familia-dto';
import { FamiliaService } from '../../service/familia.service';
import { StringUtils } from '../../../../core/utils/stringutils';
import { ModalConfirmacaoComponent } from '../../../../core/modal-confirmacao/modal-confirmacao.component';
import { FamiliaSetorDTO } from '../../resources/dtos/familia-setor-dto';
import { FamiliaCCDTO } from '../../resources/dtos/familia-cc-dto';


@Component({
  selector: 'simeq-cadastrar-familia',
  templateUrl: './cadastrar-familia.component.html',
  styleUrls: ['./cadastrar-familia.component.scss']
})
export class CadastrarFamiliaComponent extends AdministracaoGenericComponent implements OnInit {

  @ViewChild('modalConfirmaEditar')
  modalConfirmaEditar: ModalConfirmacaoComponent;

  header: string = "Cadastrar";

  labelValueList: LabelValue[] = [];

  centroCustoOpcoes: FamiliaCCDTO[] = [];
  centroCustoSelecionados: FamiliaCCDTO[] = [];

  setorOpcoes: FamiliaSetorDTO[] = [];
  setorSelecionados: FamiliaSetorDTO[] = [];

  familiaDTO: FamiliaDTO = new FamiliaDTO();
  isEditar = false;

  inputErrors: string[] = [];

  constructor(
    messagesService: MessagesService,
    private breadcrumbService: BreadcrumbService,
    private familiaService: FamiliaService,
    private route: ActivatedRoute,
    private location: Location
  ) {
    super(messagesService);
  }

  ngOnInit() {
    this.breadcrumbService.addRoute('/app/administracao', 'Administração', false);
    this.breadcrumbService.addRoute('/app/administracao/consultar-familia', 'Famílias de Manutenção', true);
    this.isEditar = this.route.snapshot.data['isEditar'];

    if (this.isEditar) {
      this.breadcrumbService.addRoute('/app/administracao/editar-familia', 'Editar', false);
      this.header = "Editar";
      
      this.labelValueList = this.route.snapshot.data['centrosCustoResolve'];
      this.centroCustoOpcoes = this.labelValueList.map(setor => new FamiliaCCDTO(setor.value, setor.label));

      this.labelValueList = this.route.snapshot.data['setoresManutencaoResolve'];
      this.setorOpcoes = this.labelValueList.map(setor => new FamiliaSetorDTO(setor.value, setor.label));

      this.familiaDTO = this.route.snapshot.data['familiaManutencaoResolve'];
      this.popularPicklistEditar();

    } else {
      this.breadcrumbService.addRoute('/app/administracao/cadastrar-familia', 'Cadastrar', false);
      this.labelValueList = this.route.snapshot.data['centrosCustoResolve'];
      this.centroCustoOpcoes = this.labelValueList.map(setor => new FamiliaCCDTO(setor.value, setor.label));

      this.labelValueList = this.route.snapshot.data['setoresManutencaoResolve'];
      this.setorOpcoes = this.labelValueList.map(setor => new FamiliaSetorDTO(setor.value, setor.label));

    }
  }

  salvar() {
    if (this.validarCamposObrigatorios()) {
      this.familiaDTO.nomeFamilia = this.familiaDTO.nomeFamilia.toLocaleUpperCase();
      this.familiaDTO.descricaoFamilia = this.familiaDTO.descricaoFamilia.toLocaleUpperCase();
      if (this.isEditar) {        
        this.modalConfirmaEditar.showDialog().subscribe(success => {
          if (success) {
            this.familiaService.editar(this.familiaDTO)
              .pipe(take(1))
              .subscribe(
                Error, (e) => {         
                  this.messagesService.addErrorMessage(e);
                },
                () => {
                  this.guardarMensagem('Cadastro realizado com sucesso');
                  this.location.back();
                }
              );
          }
        }, error => {
          this.messagesService.addErrorMessage(error);
        });

      } else {
        this.familiaDTO.ccList = this.centroCustoSelecionados;
        this.familiaDTO.setorList = this.setorSelecionados;
        this.familiaDTO.nomeFamilia = this.familiaDTO.nomeFamilia.toLocaleUpperCase();

        this.familiaService.salvar(this.familiaDTO)
          .pipe(take(1))
          .subscribe(
            Error, (e) => {
              this.messagesService.addErrorMessage(e);
            },
            () => {
              this.guardarMensagem('Cadastro realizado com sucesso');
              this.location.back();
            }
          );
      }
    }
  }

  cancelar() {
    this.location.back();
  }

  validarCamposObrigatorios() {
    this.inputErrors = [];

    if (StringUtils.isNullOrUndefinedOrEmpty(this.familiaDTO.nomeFamilia) || this.familiaDTO.nomeFamilia.trim().length === 0) {
      this.inputErrors.push("Nome da Familia");
    }

    if (this.centroCustoSelecionados.length === 0) {
      this.inputErrors.push("Centro de Custo");
    }

    if (this.setorSelecionados.length === 0) {
      this.inputErrors.push("Setor de Manutenção");
    }

    if (this.inputErrors.length > 0) {
      this.mostrarMensagemCamposObrigatorios(this.inputErrors);
      return false;
    }
    return true;
  }

  popularPicklistEditar() {
    
    this.familiaDTO.ccList.map(CC => {
      CC.label = (this.centroCustoOpcoes.find(item => item.codigoCC === CC.codigoCC)).label;
    });

    this.centroCustoSelecionados = this.familiaDTO.ccList;

    this.centroCustoSelecionados.forEach(CC => {
      this.centroCustoOpcoes
        .filter((item, index) =>
          item.codigoCC === CC.codigoCC ? this.centroCustoOpcoes.splice(index, 1) : null);
    });
    
    this.familiaDTO.setorList.map(setor => {
      setor.label = (this.setorOpcoes.find(item => item.idSetor === setor.idSetor)).label;
    });

    this.setorSelecionados = this.familiaDTO.setorList;

    this.setorSelecionados.forEach((setor) => {
      this.setorOpcoes
        .filter((item, index) =>
          item.idSetor === setor.idSetor ? this.setorOpcoes.splice(index, 1) : null);
    });

  }
}
