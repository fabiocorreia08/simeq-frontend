import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { LazyLoadEvent, DataTable } from 'primeng/primeng';

import { FamiliaService } from './../../service/familia.service';
import { LabelValue } from './../../../../core/models/label-value';
import { AdministracaoGenericComponent } from './../../../administracao-generic.component';
import { BreadcrumbService } from './../../../../core/breadcrumb/breadcrumb.service';
import { AuthenticationService } from './../../../../core/security/auth.service';
import { FamiliaFiltro } from './../../resources/models/familia-filtro';
import { MessagesService } from '../../../../core/messages/messages.service';
import { Pagina } from '../../../../core/models/pagina.model';
import { FamiliaTabelaDTO } from '../../resources/dtos/familia-tabela-dto';
import { ModalConfirmacaoComponent } from '../../../../core/modal-confirmacao/modal-confirmacao.component';
import { groupBy, mergeMap } from 'rxjs/operators';


@Component({
  selector: 'simeq-consultar-familia',
  templateUrl: './consultar-familia.component.html',
  styleUrls: ['./consultar-familia.component.scss']
})
export class ConsultarFamiliaComponent extends AdministracaoGenericComponent implements OnInit {

  @ViewChild('dataTable')
  dataTable;

  @ViewChild('modalConfirmaExclusao')
  modalConfirmaExclusao: ModalConfirmacaoComponent;

  pagina: Pagina<FamiliaTabelaDTO> = new Pagina<FamiliaTabelaDTO>();
  filtro: FamiliaFiltro = new FamiliaFiltro();
  centrosCustoOpcoes: LabelValue[] = [];
  setorOpcoes: LabelValue[] = [];
  familiaOpcoes: LabelValue[] = [];

  constructor(
    private auth: AuthenticationService,
    breadcrumbService: BreadcrumbService,
    messagesService: MessagesService,
    private familiaService: FamiliaService,
    private route: ActivatedRoute) {
    super(messagesService);
    breadcrumbService.addRoute('/app/administracao', 'Administração', false);
    breadcrumbService.addRoute('/app/administracao/consultar-familia', 'Famílias de Manutenção', false);
    breadcrumbService.addRoute('/app/administracao/consultar-familia', 'Consultar', false);
  }

  ngOnInit() {
    this.mostrarMensagemGuardada();
    this.centrosCustoOpcoes = this.route.snapshot.data['centrosCustoResolve'];
    this.setorOpcoes = this.route.snapshot.data['setoresManutencaoResolve'];
    this.familiaOpcoes = this.route.snapshot.data['familiasResolve'];
    this.filtrar();
  }

  public limparFiltros(): void {
    this.filtro = new FamiliaFiltro();
    this.pagina = new Pagina();
  }

  public pesquisar(): void {
    this.pagina = new Pagina();
    this.filtrar();
  }

  public filtrar(): void {
    this.familiaService.filtrar(this.filtro, this.pagina)
      .subscribe((pagina) => {
        this.pagina = pagina;
      },
        (error) => {
          this.messagesService.addErrorMessage(error);
        });
  }

  public paginar(event: LazyLoadEvent): void {
    this.pagina = new Pagina<FamiliaTabelaDTO>(event.first, event.rows);
    this.filtrar();
  }

  public remover(familiaId: number): void {
    this.modalConfirmaExclusao.showDialog().subscribe(success => {
      if (success) {
        this.familiaService.remover(familiaId).subscribe(() => {
          this.filtrar();
          this.familiaOpcoes.splice(this.familiaOpcoes.indexOf(
            this.familiaOpcoes.filter(familiaOpcao => familiaOpcao.value == familiaId)[0]
          ),1);
          this.messagesService.addSuccessMessage("Exclusão realizada com sucesso");
        }
        , error => {
          this.messagesService.addErrorMessage(error);
        })
        
      }
    });
  }


}
