import { FamiliasManutencaoResolve } from './resolves/familia-todas.resolve.service';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AuthGuard } from './../../core/security/auth.guard';
import { PerfisConstants } from './../../core/security/perfis.constants';
import { ConsultarFamiliaComponent } from './components/consultar-familia/consultar-familia.component';
import { MainComponent } from './../../main/main.component';
import { CadastrarFamiliaComponent } from './components/cadastrar-familia/cadastrar-familia.component';
import { BuscaCentrosCustoResolve } from '../../shared/resolves/busca-centros-custo.resolve';
import { BuscaSetoresManutencaoResolve } from '../../shared/resolves/busca-setores-manutencao.resolve';
import { BuscaFamiliaManutencaoResolve } from './resolves/familia-manutencao.resolve.service';

const routes: Routes = [
  {
    path: 'app', component: MainComponent,
    children: [
      {
        path: 'administracao/consultar-familia',
        component: ConsultarFamiliaComponent,
        canActivate: [AuthGuard],
        data: { funcionalidade: PerfisConstants.CONSULTAR_FAMILIA_PERMISSOES },
        resolve: {
          centrosCustoResolve: BuscaCentrosCustoResolve,
          setoresManutencaoResolve: BuscaSetoresManutencaoResolve,
          familiasResolve: FamiliasManutencaoResolve
        }
      },
      {
        path: 'administracao/cadastrar-familia',
        component: CadastrarFamiliaComponent,
        canActivate: [AuthGuard],
        data: { funcionalidade: PerfisConstants.CADASTRAR_FAMILIA_PERMISSOES },
        resolve: {
          centrosCustoResolve: BuscaCentrosCustoResolve,
          setoresManutencaoResolve: BuscaSetoresManutencaoResolve
        }
      },
      {
        path: 'administracao/editar-familia/:idFamilia',
        component: CadastrarFamiliaComponent,
        canActivate: [AuthGuard],
        data: { funcionalidade: PerfisConstants.EDITAR_FAMILIA_PERMISSOES, isEditar: true },
        resolve: {
          centrosCustoResolve: BuscaCentrosCustoResolve,
          setoresManutencaoResolve: BuscaSetoresManutencaoResolve,
          familiaManutencaoResolve: BuscaFamiliaManutencaoResolve
        }
      }
    ]
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class FamiliaRoutingModule { }