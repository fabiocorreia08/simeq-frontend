import { LabelValue } from './../../../core/models/label-value';
import { FamiliaService } from './../service/familia.service';
import { Resolve, ActivatedRouteSnapshot } from '@angular/router';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable()
export class FamiliasManutencaoResolve implements Resolve<LabelValue[]>{
    constructor(private familiaManutencaoService: FamiliaService) { }
    
    resolve(route: ActivatedRouteSnapshot){
      return new Observable<LabelValue[]>(observe => {
        this.familiaManutencaoService.buscarTodos()
          .subscribe(familias => {
            let familiaOpcoes: LabelValue[] = familias.map(item => {
              return new LabelValue(item.nomeFamilia, item.id);
            });

            observe.next(familiaOpcoes);
            observe.complete();
          });
      });
    }
}