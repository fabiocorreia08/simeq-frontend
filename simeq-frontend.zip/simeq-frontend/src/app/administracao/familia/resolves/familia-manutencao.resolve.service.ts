import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot } from '@angular/router';
import { FamiliaDTO } from '../resources/dtos/familia-dto';
import { FamiliaService } from '../service/familia.service';


@Injectable()
export class BuscaFamiliaManutencaoResolve implements Resolve<FamiliaDTO>{

  constructor(private familiaManutencaoService: FamiliaService) { }

  resolve(route: ActivatedRouteSnapshot){
    return this.familiaManutencaoService.buscarPorId(route.params['idFamilia']);
  }
}
