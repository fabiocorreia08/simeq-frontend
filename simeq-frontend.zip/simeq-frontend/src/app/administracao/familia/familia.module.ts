import { FamiliasManutencaoResolve } from './resolves/familia-todas.resolve.service';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { PickListModule, DataTableModule, MultiSelectModule } from 'primeng/primeng';

import { ConsultarFamiliaComponent } from './components/consultar-familia/consultar-familia.component';
import { FamiliaRoutingModule } from './familia-routing.module';
import { CadastrarFamiliaComponent } from './components/cadastrar-familia/cadastrar-familia.component';
import { CoreModule } from '../../core/core.module';
import { SharedModule } from '../../shared/shared.module';
import { CentroCustoService } from '../../shared/services/centro-custo.service';
import { SetorManutencaoService } from '../../shared/services/setor-manutencao.service';
import { BuscaCentrosCustoResolve } from '../../shared/resolves/busca-centros-custo.resolve';
import { BuscaSetoresManutencaoResolve } from '../../shared/resolves/busca-setores-manutencao.resolve';
import { BuscaFamiliaManutencaoResolve } from './resolves/familia-manutencao.resolve.service';



@NgModule({
  declarations: [
    ConsultarFamiliaComponent,
    CadastrarFamiliaComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    SharedModule,
    FamiliaRoutingModule,
    CoreModule,
    PickListModule,
    DataTableModule,
    MultiSelectModule
  ],
  providers: [
    CentroCustoService,
    SetorManutencaoService,
    BuscaCentrosCustoResolve,
    BuscaSetoresManutencaoResolve,
    BuscaFamiliaManutencaoResolve,
    FamiliasManutencaoResolve
  ]
})
export class FamiliaModule { }
