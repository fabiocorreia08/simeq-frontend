import { LabelValue } from './../../../core/models/label-value';
import { Injectable } from '@angular/core';
import { Http } from '@angular/http';

import { Observable } from 'rxjs';

import { FamiliaFiltro } from './../resources/models/familia-filtro';
import { FamiliaTabelaDTO } from './../resources/dtos/familia-tabela-dto';
import { AbstractResource } from '../../../core/http/abstract.resource';
import { FamiliaDTO } from '../resources/dtos/familia-dto';
import { Pagina } from '../../../core/models/pagina.model';

@Injectable()
export class FamiliaService extends AbstractResource<any>{

  private baseEndPoint: string = "/familia-manutencao";

  constructor(http: Http) {
    super(http, '')
  }

  public buscarTodos(): Observable<FamiliaDTO[]> {
    return this.getList(this.baseEndPoint);
  }  

  public buscarPorId(id: number): Observable<FamiliaDTO> {
    return super.getOne(this.baseEndPoint, id);
  }

  public salvar(familiaDTO: FamiliaDTO) {
    return super.post(this.baseEndPoint, familiaDTO);
  }

  public editar(familiaDTO: FamiliaDTO) {
    return super.put(this.baseEndPoint, familiaDTO);
  }

  public remover(idFamilia: number){
    return super.delete(this.baseEndPoint, idFamilia);
  }

  public filtrar(filtro: FamiliaFiltro, params?: any): Observable<Pagina<FamiliaTabelaDTO>> {
    return super.filter(this.baseEndPoint + '/pagina', filtro, params);
  }

  public buscarFamilias(): Observable<LabelValue[]> {
    return this.getList(this.baseEndPoint + '/todos-familia');
  }

  public buscarPorCentroCustoAssistenteProducao(centroCusto: string): Observable<LabelValue[]> {
    return this.getList(this.baseEndPoint + '/assistente-producao/'+ centroCusto);
  }

  public buscarSetoresPorCC(centroCusto: string): Observable<number[]> {
    return this.getList(this.baseEndPoint + '/setores-familia/'+ centroCusto);
  }
}
