import { FamiliaDTO } from "../dtos/familia-dto";


export class FamiliaFiltro {
    public centrosCusto: string[] = null;
    public setoresManutencao: number[] = null;
    public familias: FamiliaDTO[] = null;
}