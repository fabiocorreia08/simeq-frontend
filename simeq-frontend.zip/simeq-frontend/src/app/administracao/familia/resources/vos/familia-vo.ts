export class FamiliaVO {
}
