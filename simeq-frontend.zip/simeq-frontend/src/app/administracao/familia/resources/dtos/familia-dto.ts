import { FamiliaCCDTO } from "./familia-cc-dto";
import { FamiliaSetorDTO } from "./familia-setor-dto";

export class FamiliaDTO {
    id :number;
    nomeFamilia :string;
    descricaoFamilia :string;
    ccList: FamiliaCCDTO[] = [];
    setorList: FamiliaSetorDTO[] = [];
}
