export class FamiliaCCDTO {

    label: string;
    id: number = null;
    codigoCC: string;

    constructor(codigoCC: string, label?: string, id?: number){
        this.codigoCC = codigoCC;
        this.label = label;
        this.id= null;
    }
}