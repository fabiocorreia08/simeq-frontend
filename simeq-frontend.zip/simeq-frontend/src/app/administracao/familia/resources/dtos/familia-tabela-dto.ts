export class FamiliaTabelaDTO {
    id :number;
    nomeFamilia :string;
    descricaoFamilia :string;
    centroCusto :string;
    setoresManutencao :string;
    setoresCentroCusto :string;

}
