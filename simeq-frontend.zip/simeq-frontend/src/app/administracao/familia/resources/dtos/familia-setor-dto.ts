export class FamiliaSetorDTO {

    label: string;
    id: number = null;
    idSetor: number;
    
    constructor(idSetor: number, label?: string, id?: number){
        this.idSetor = idSetor;
        this.label = label;
        this.id= null;
    }
}