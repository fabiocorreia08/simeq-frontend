import { LabelValue } from './../../../core/models/label-value';
import { Observable } from 'rxjs/Observable';
import { Http } from '@angular/http';
import { Injectable } from '@angular/core';
import { AbstractResource } from '../../../core/http/abstract.resource';
import { TecnicoDTO } from '../resources/dtos/tecnico-dto.class';
import { TecnicoVO } from '../resources/vos/tecnico-vo.class';
import { Pagina } from '../../../core/models/pagina.model';
import { AtividadeTecnicoFiltro } from '../../../manutencao/models/atividade-tecnico-filtro.model';

@Injectable()
export class TecnicoService extends AbstractResource<any>{

  private baseEndPoint: string = "/tecnico";

  constructor(http: Http) {
    super(http, '');
  }

  public filtrar(filtro: TecnicoVO,  params?: any): Observable<Pagina<TecnicoDTO>> {
    return super.filter(this.baseEndPoint + '/filtrar', filtro, params);
  }

  public buscarPor(matricula: string) : Observable<TecnicoDTO> {
    return super.getOne(this.baseEndPoint + '/matricula-valida', matricula);
  }

  public buscarPorMatricula(matricula: string) : Observable<TecnicoDTO> {
    return super.getOne(this.baseEndPoint + '/matricula', matricula);
  }

  public buscarPorMatriculaAlocado(filtro: AtividadeTecnicoFiltro, page: any): Observable<Pagina<TecnicoDTO>> {
    return super.getFilterAndPage(this.baseEndPoint +   '/alocado-permissao', filtro, page);
  }

  public buscarPorId(id: number): Observable<TecnicoDTO>{
    return super.getOne(this.baseEndPoint + '/id', id);
  }

  public buscarSetoresManutencaoPorTecnico(idTecnico: number): Observable<TecnicoDTO>{
    return super.getOne(this.baseEndPoint + '/tecnico', idTecnico);
  }

  public salvar(tecnicoDTO: TecnicoDTO){
    return super.post(this.baseEndPoint,tecnicoDTO);
  }

  public atualizar(tecnicoDTO: TecnicoDTO): Observable<TecnicoDTO> {
    return super.put(this.baseEndPoint, tecnicoDTO);
  }

  public buscarTodos(): Observable<LabelValue[]> {
    return super.getList(this.baseEndPoint);
  }

  public buscarTodosCargos(): Observable<LabelValue[]> {
    return super.getList(this.baseEndPoint + '/cargos');
  }

  public buscarTodasFuncoes(): Observable<LabelValue[]> {
    return super.getList(this.baseEndPoint + '/funcoes');
  }

}
