import { Injectable } from "@angular/core";
import { AbstractResource } from "../../../core/http/abstract.resource";
import { TecnicoDTO } from "../resources/dtos/tecnico-dto.class";
import { Http } from "@angular/http";
import { Observable } from "rxjs/Observable";
import { RealocacaoTecnicoDTO } from "../resources/dtos/realocacao-tecnico-dto.class";

@Injectable()
export class RealocacaoTecnicoService extends AbstractResource<RealocacaoTecnicoDTO>{

    private readonly baseEndPoint: string = "/realocacao-tecnico"

    constructor(http: Http) {
        super(http, '');
    }

    public buscarPor(id: number): Observable<RealocacaoTecnicoDTO[]> {
        return super.getList(this.baseEndPoint, id);
    }

    public buscarRealocacaoPorId(id: number): Observable<RealocacaoTecnicoDTO> {
        return super.getOne(this.baseEndPoint + "/buscar-realocacao", id);
    }

    public remover(id: number): Observable<RealocacaoTecnicoDTO> {
        return super.delete(this.baseEndPoint, id);
    }

    public salvar(realocacaoTecnicoDTO: RealocacaoTecnicoDTO): Observable<RealocacaoTecnicoDTO> {
        return super.post(this.baseEndPoint, realocacaoTecnicoDTO);
    }

    public atualizar(realocacaoTecnicoDTO: RealocacaoTecnicoDTO): Observable<RealocacaoTecnicoDTO> {
        return super.put(this.baseEndPoint, realocacaoTecnicoDTO);
    }
}