import { NgModule } from '@angular/core';
import { CadastrarTecnicoComponent } from './components/cadastrar-tecnico/cadastrar-tecnico.component';
import { DetalharEditarTecnicoComponent } from './components/detalhar-editar-tecnico/detalhar-editar-tecnico.component';
import { TecnicoService } from './services/tecnico.service';
import { TecnicoRoutingModule } from './tecnico-routing.module';
import {
    ButtonModule,
    DataTableModule,
    InputMaskModule,
    DropdownModule,
    CalendarModule,
    MultiSelectModule,
    PickListModule
  } from 'primeng/primeng';
import { ConsultarTecnicoComponent } from './components/consultar-tecnico/consultar-tecnico.component';
import { CoreModule } from '../../core/core.module';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RealocacaoTecnicoService } from './services/realocacao-tecnico.service';
import { BuscaTecnicoResolve } from './resolves/busca-tecnico.resolve';
import { BuscaRealocacoesTecnicoResolve } from './resolves/busca-realocacoes-tecnico.resolve';
import { SharedModule } from '../../shared/shared.module';

@NgModule({
    declarations: [
        ConsultarTecnicoComponent,
        CadastrarTecnicoComponent,
        DetalharEditarTecnicoComponent
    ],
    imports: [
        TecnicoRoutingModule,
        FormsModule,
        BrowserModule,
        BrowserAnimationsModule,
        CoreModule,
        ButtonModule,
        DataTableModule,
        InputMaskModule,
        CalendarModule,
        DropdownModule,
        SharedModule,
        PickListModule,
        MultiSelectModule
    ],
    providers: [
        TecnicoService,
        RealocacaoTecnicoService,
        BuscaTecnicoResolve,
        BuscaRealocacoesTecnicoResolve]
})
export class TecnicoModule {}
