import { TecnicoService } from "../services/tecnico.service";
import { ActivatedRouteSnapshot, Resolve } from "@angular/router";
import { Injectable } from "@angular/core";
import { TecnicoDTO } from "../resources/dtos/tecnico-dto.class";

@Injectable()
export class BuscaTecnicoResolve implements Resolve<TecnicoDTO> {

  constructor(private tecnicoService: TecnicoService) { }

  resolve(route: ActivatedRouteSnapshot) {
    return this.tecnicoService.buscarPorId(route.params['idTecnico']);
  }
  
}