import { TecnicoService } from "../services/tecnico.service";
import { ActivatedRouteSnapshot, Resolve } from "@angular/router";
import { Injectable } from "@angular/core";
import { TecnicoDTO } from "../resources/dtos/tecnico-dto.class";
import { RealocacaoTecnicoDTO } from "../resources/dtos/realocacao-tecnico-dto.class";
import { RealocacaoTecnicoService } from "../services/realocacao-tecnico.service";

@Injectable()
export class BuscaRealocacoesTecnicoResolve implements Resolve<RealocacaoTecnicoDTO[]> {

  constructor(private realocacaoTecnicoService: RealocacaoTecnicoService) { }

  resolve(route: ActivatedRouteSnapshot) {
    return this.realocacaoTecnicoService.buscarPor(route.params['idTecnico']);
  }
  
}