import { TecnicoCCDTO } from "./tecnico-cc-dto";
import { TecnicoSetorDTO } from "./tecnico-setor-dto";

export class TecnicoDTO {
	id: number;
	matricula: string = '';	
	nomeEmpregado: string;
	centroCusto: string;
	cargo: string;
	funcao: string;
	codigoFolha: string;
  	situacaoFolha: string;
  	hierarquiaCentroCusto: string;
  	salario: number;
	ccList: TecnicoCCDTO[] = [];   
	setorList: TecnicoSetorDTO[] = []; 
	nomeSetor: string;
	setoresManutencao: string;  		  
}
