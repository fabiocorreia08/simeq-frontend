export class RealocacaoTecnicoDTO{
    id?:number;
    tecnico?:number;
    tipoRealocacao?:string;
    centroCusto?:string;
    hierarquiaCentroCusto?:string;
    periodoInicio?:Date;
    periodoFim?:Date;
    motivo?:string;
    isUltima?: boolean = false;
}
