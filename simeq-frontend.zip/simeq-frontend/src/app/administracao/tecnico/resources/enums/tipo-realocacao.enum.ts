export class TipoRealocadoEnum {
    static readonly ADMINISTRATIVO: string = 'A';
    static readonly TECNICO: string = 'T';

    public static readonly lista: {chave: any, valor: any}[] = [  {chave: TipoRealocadoEnum.ADMINISTRATIVO, valor: 'Administrativo'},
                                                                {chave: TipoRealocadoEnum.TECNICO, valor: 'Técnico'}]

    public static getValor(chave: any): any {
        let retorno: {chave: any, valor: any}[] = TipoRealocadoEnum.lista.filter(item => item.chave === chave);
        if(retorno && retorno.length > 0) {
            return retorno[0].valor;
        } else {
            return null;
        }
    }
}