export class SetorManutencaoEnum {
    static readonly DEMOM: string = 'DEMOM';
    static readonly DEGER: string = 'DEGER';
    static readonly DEMAT: string = 'DEMAT';
    static readonly DEMAQ: string = 'DEMAQ';
    static readonly DEMAN: string = 'DEMAN';    

    public static readonly lista: {chave: any, valor: any}[] = [  {chave: SetorManutencaoEnum.DEMOM, valor: 'DEMOM'},
                                                                {chave: SetorManutencaoEnum.DEGER, valor: 'DEGER'},
                                                                {chave: SetorManutencaoEnum.DEMAT, valor: 'DEMAT'},
                                                                {chave: SetorManutencaoEnum.DEMAQ, valor: 'DEMAQ'},
                                                                {chave: SetorManutencaoEnum.DEMAN, valor: 'DEMAN'}]

    public static getValor(chave: any): any {
        let retorno: {chave: any, valor: any}[] = SetorManutencaoEnum.lista.filter(item => item.chave === chave);
        if(retorno && retorno.length > 0) {
            return retorno[0].valor;
        } else {
            return null;
        }
    }
}