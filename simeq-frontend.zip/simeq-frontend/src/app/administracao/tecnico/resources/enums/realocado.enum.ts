export class RealocadoEnum {
    static readonly NAO_REALOCADO: string = 'N';
    static readonly REALOCADO: string = 'S';

    public static readonly lista: {chave: any, valor: any}[] = [  {chave: RealocadoEnum.REALOCADO, valor: 'Sim'},
                                                                {chave: RealocadoEnum.NAO_REALOCADO, valor: 'Não'}]

    public static getValor(chave: any): any {
        let retorno: {chave: any, valor: any}[] = RealocadoEnum.lista.filter(item => item.chave === chave);
        if(retorno && retorno.length > 0) {
            return retorno[0].valor;
        } else {
            return null;
        }
    }
}