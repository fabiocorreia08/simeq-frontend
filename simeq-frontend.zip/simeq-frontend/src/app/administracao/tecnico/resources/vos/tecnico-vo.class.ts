export class TecnicoVO {    
	matricula: string = "";
	nome: string;
    cargo: string;
    funcao: string;
	hierarquiaCentroCusto: string = "null";
	realocado: string = "null";	
}