import { PerfisConstants } from './../../core/security/perfis.constants';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MainComponent } from '../../main/main.component';
import { CadastrarTecnicoComponent } from './components/cadastrar-tecnico/cadastrar-tecnico.component';
import { DetalharEditarTecnicoComponent } from './components/detalhar-editar-tecnico/detalhar-editar-tecnico.component';
import { ConsultarTecnicoComponent } from './components/consultar-tecnico/consultar-tecnico.component';
import { BuscaTecnicoResolve } from './resolves/busca-tecnico.resolve';
import { BuscaRealocacoesTecnicoResolve } from './resolves/busca-realocacoes-tecnico.resolve';
import { BuscaCentrosCustoResolve } from '../../shared/resolves/busca-centros-custo.resolve';
import { AuthGuard } from '../../core/security/auth.guard';
import { AuthenticationService } from '../../core/security/auth.service';
import { DetalharEditarAuthGuard } from '../../core/security/detalhar-editar-auth.guard';
import { BuscaSetoresManutencaoResolve } from '../../shared/resolves/busca-setores-manutencao.resolve';

const routes: Routes = [
    { path: 'app', component: MainComponent,
        children: [
            {
                path: 'administracao/consultar-tecnico',
                component: ConsultarTecnicoComponent,
                canActivate: [AuthGuard],
                data: {funcionalidade: PerfisConstants.CONSULTAR_TECNICO_PERMISSOES},
                resolve: {
                    centrosCustoResolve: BuscaCentrosCustoResolve,
                    setoresManutencaoResolve: BuscaSetoresManutencaoResolve
                }
            },
            {
                path: 'administracao/cadastrar-tecnico',
                component: CadastrarTecnicoComponent,
                canActivate: [AuthGuard],
                data: {funcionalidade: PerfisConstants.CADASTRAR_TECNICO_PERMISSOES},
                resolve: {
                    centrosCustoResolve: BuscaCentrosCustoResolve,
                    setoresManutencaoResolve: BuscaSetoresManutencaoResolve
                }
            },
            {
                path: 'administracao/detalhar-editar-tecnico/:isDetalhar/:idTecnico',
                component: DetalharEditarTecnicoComponent,
                canActivate: [DetalharEditarAuthGuard],
                data: {funcionalidadeDetalhar: PerfisConstants.DETALHAR_TECNICO_PERMISSOES, funcionalidadeEditar: PerfisConstants.EDITAR_TECNICO_PERMISSOES},
                resolve: {
                    tecnicoResolve: BuscaTecnicoResolve,
                    realocacoesTecnicoResolve: BuscaRealocacoesTecnicoResolve,
                    centrosCustoResolve: BuscaCentrosCustoResolve,
                    setoresManutencaoResolve: BuscaSetoresManutencaoResolve
                }
            }
        ]
    },
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class TecnicoRoutingModule { }
