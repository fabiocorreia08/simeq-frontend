import { Component, OnInit } from '@angular/core';
import { BreadcrumbService } from '../../../../core/breadcrumb/breadcrumb.service';
import { Pagina } from '../../../../core/models/pagina.model';
import { TecnicoDTO } from '../../resources/dtos/tecnico-dto.class';
import { TecnicoVO } from '../../resources/vos/tecnico-vo.class';
import { RealocadoEnum } from '../../resources/enums/realocado.enum';
import { OnDestroy } from '@angular/core/src/metadata/lifecycle_hooks';
import { Location } from '@angular/common';
import { LazyLoadEvent } from 'primeng/components/common/api';
import { MessagesService } from '../../../../core/messages/messages.service';
import { TecnicoService } from '../../services/tecnico.service';
import { AdministracaoGenericComponent } from '../../../administracao-generic.component';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthenticationService } from '../../../../core/security/auth.service';
import { SelectItem } from 'primeng/primeng';
import { LabelValue } from '../../../../core/models/label-value';
import { ArrayUtil } from '../../../../shared/Utils/ArrayUtil';
import { isNullOrUndefined } from 'util';
import { PerfisConstants } from '../../../../core/security/perfis.constants';

@Component({
  selector: 'simeq-consultar-tecnico',
  templateUrl: './consultar-tecnico.component.html',
  styleUrls: ['./consultar-tecnico.component.scss']
})
export class ConsultarTecnicoComponent extends AdministracaoGenericComponent implements OnInit {

  public buscaHabilitada: boolean = false;
  public filtro: TecnicoVO = new TecnicoVO;
  public pagina: Pagina<TecnicoDTO> = new Pagina<TecnicoDTO>();  
  public listaRealocado = RealocadoEnum.lista;
  public listaCentrosCusto: LabelValue[] = [];
  
  setorOpcoes: LabelValue[] = [];

  setoresManutencao: string;

  constructor(private auth: AuthenticationService,
    private breadcrumbService: BreadcrumbService,
    protected messagesService: MessagesService,
    private router: Router,
    private route: ActivatedRoute,
    private tecnicoService: TecnicoService) {
    super(messagesService);
    breadcrumbService.addRoute('/app/administracao', 'Administração', false);
    breadcrumbService.addRoute('/app/administracao/consultar-tecnico', 'Técnicos', false);
    breadcrumbService.addRoute('/app/administracao/consultar-tecnico', 'Consultar', false);
  }

  ngOnInit() {
    this.listaCentrosCusto = this.route.snapshot.data['centrosCustoResolve'];
    this.listaCentrosCusto = ArrayUtil.adicionarPrimeiroValor(this.listaCentrosCusto, "Selecione", "null");
    this.setorOpcoes = this.route.snapshot.data['setoresManutencaoResolve'];
    this.mostrarMensagemGuardada();
    this.buscarFiltro();    
  }

  public pesquisar(): void {
    this.buscaHabilitada = true;
    this.pagina = new Pagina();
    this.filtrar();
  }

  public paginar(event: LazyLoadEvent): void {
    if (this.buscaHabilitada) {
      this.pagina = new Pagina<TecnicoDTO>(event.first, event.rows);
      this.filtrar();
    }
  }

  public filtrar(): void {
    this.filtro.cargo = !isNullOrUndefined(this.filtro.cargo) ? this.filtro.cargo.toLocaleUpperCase() : undefined;
    this.filtro.funcao = !isNullOrUndefined(this.filtro.funcao) ? this.filtro.funcao.toLocaleUpperCase() : undefined;
    this.filtro.nome = !isNullOrUndefined(this.filtro.nome) ? this.filtro.nome.toLocaleUpperCase() : undefined;
    this.tecnicoService.filtrar(this.filtro, this.pagina)
      .subscribe((pagina) => {        
        this.pagina = pagina;
      },
        (error) => {
          this.messagesService.addErrorMessage(error);
        });
  }

  public buscarSetoresManutencaoPorTecnico(idTecnico: number){   
    this.tecnicoService.buscarSetoresManutencaoPorTecnico(idTecnico).subscribe(tecnicoDTO =>{        
      this.setoresManutencao = tecnicoDTO.nomeSetor;      
    },
    error=>{
      this.messagesService.addErrorMessage(error);      
    })
  }

  public limparFiltros(): void {
    this.buscaHabilitada = false;
    this.pagina = new Pagina();
    this.filtro = new TecnicoVO();
  }

  private buscarFiltro(): void {
    this.buscaHabilitada = localStorage.getItem("buscaHabilitada") ? JSON.parse(localStorage.getItem("buscaHabilitada")) : false;
    this.filtro = localStorage.getItem("filtroTecnico") ? JSON.parse(localStorage.getItem("filtroTecnico")) : new TecnicoVO();
    localStorage.removeItem("buscaHabilitada");
    localStorage.removeItem("filtroTecnico");
    if (this.buscaHabilitada) {
      this.pesquisar();
    }
  }

  public redirecionarRotaDetalharEditar(rota: number, id: number){    
    localStorage.setItem("buscaHabilitada", JSON.stringify(this.buscaHabilitada));
    localStorage.setItem("filtroTecnico", JSON.stringify(this.filtro));    
    this.router.navigate([`/app/administracao/detalhar-editar-tecnico/${rota}/${id}`]);
  }

  public isBotaoCadastrarExibido() {
    return this.auth.hasAnyPermission(PerfisConstants.CADASTRAR_TECNICO_PERMISSOES);
  }

  public isBotaoEditarExibido() {
    return this.auth.hasAnyPermission(PerfisConstants.EDITAR_TECNICO_PERMISSOES);
  }



}
