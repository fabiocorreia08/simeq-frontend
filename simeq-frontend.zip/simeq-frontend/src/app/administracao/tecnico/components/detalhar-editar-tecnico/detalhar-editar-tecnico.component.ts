import { Component, OnInit, ViewChild } from '@angular/core';
import { BreadcrumbService } from '../../../../core/breadcrumb/breadcrumb.service';
import { TecnicoDTO } from '../../resources/dtos/tecnico-dto.class';
import { TecnicoService } from '../../services/tecnico.service';
import { ActivatedRoute } from '@angular/router';
import { RealocacaoTecnicoDTO } from '../../resources/dtos/realocacao-tecnico-dto.class';
import { Location } from '@angular/common';
import { RealocacaoTecnicoService } from '../../services/realocacao-tecnico.service';
import { TipoRealocadoEnum } from '../../resources/enums/tipo-realocacao.enum';
import { MessagesService } from '../../../../core/messages/messages.service';
import { DataTable } from 'primeng/primeng';
import { isNullOrUndefined } from 'util';
import { ModalConfirmacaoComponent } from '../../../../core/modal-confirmacao/modal-confirmacao.component';
import { AdministracaoGenericComponent } from '../../../administracao-generic.component';
import { LabelValue } from '../../../../core/models/label-value';
import { StringUtils } from '../../../../core/utils/stringutils';
import { CalendarLocaleService } from '../../../../core/calendar.locale.service';
import * as moment from 'moment';
import { SetorManutencaoEnum } from '../../resources/enums/setor-manutencao.enum';
import { ArrayUtil } from '../../../../shared/Utils/ArrayUtil';
import { SetorManutencaoService } from '../../../../shared/services/setor-manutencao.service';
import { TecnicoSetorDTO } from '../../resources/dtos/tecnico-setor-dto';
import { TecnicoCCDTO } from '../../resources/dtos/tecnico-cc-dto';

declare var $: any;
@Component({
  selector: 'simeq-detalhar-editar-tecnico',
  templateUrl: './detalhar-editar-tecnico.component.html',
  styleUrls: ['./detalhar-editar-tecnico.component.scss']
})
export class DetalharEditarTecnicoComponent extends AdministracaoGenericComponent implements OnInit {

  @ViewChild('modalConfirmaExclusao') public modalConfirmaExclusao: ModalConfirmacaoComponent;
  @ViewChild('dataTable') private dataTable: DataTable;
  private divModal: any;
  public isDetalhar: boolean;
  public isDetalharRealocacao: boolean
  public tecnicoDTO: TecnicoDTO = new TecnicoDTO();
  public realocacoesTecnico: RealocacaoTecnicoDTO[] = [];
  public realocacaoTecnico = new RealocacaoTecnicoDTO();
  public listaRealocado = TipoRealocadoEnum.lista;
  public listaCentrosCusto: LabelValue[] = [];
  public titulo: string;
  public camposObrigatorios: string[];
  public isUltima: boolean;
  public sinalizarCamposObrigatoriosRealocacaoTecnico:string = "*";
  public listaSetorManutencao: LabelValue[] = [];

  labelValueList: LabelValue[] = [];

  centroCustoOpcoes: TecnicoCCDTO[] = [];
  centroCustoSelecionados: TecnicoCCDTO[] = [];

  setorOpcoes: TecnicoSetorDTO[] = [];
  setorSelecionados: TecnicoSetorDTO[] = [];

  centrosCustoOpcoes: LabelValue[] = [];

  constructor(private breadcrumbService: BreadcrumbService,
    private tecnicoService: TecnicoService,
    private activatedRoute: ActivatedRoute,
    private route: ActivatedRoute,
    private location: Location,
    private realocacaoService: RealocacaoTecnicoService,
    public calendarLocaleService: CalendarLocaleService,
    private setorManutencaoService: SetorManutencaoService,
    protected messagesService: MessagesService) {
    super(messagesService);
  }

  ngOnInit(): void {
    this.verificarRota();
    this.listaCentrosCusto = this.route.snapshot.data['centrosCustoResolve'];
    this.tecnicoDTO = this.route.snapshot.data['tecnicoResolve'];
    this.realocacoesTecnico = this.route.snapshot.data['realocacoesTecnicoResolve'];
    
    this.labelValueList = this.route.snapshot.data['centrosCustoResolve'];
    this.centroCustoOpcoes = this.labelValueList.map(setor => new TecnicoCCDTO(setor.value, setor.label));

    this.labelValueList = this.route.snapshot.data['setoresManutencaoResolve'];
    this.setorOpcoes = this.labelValueList.map(setor => new TecnicoSetorDTO(setor.value, setor.label));
    
    this.tecnicoDTO = this.route.snapshot.data['tecnicoResolve'];
    this.popularPicklistEditar();

    this.processarRealocacoes();
    if(!this.isDetalhar){
      
      this.labelValueList = this.route.snapshot.data['centrosCustoResolve'];
      this.centroCustoOpcoes = this.labelValueList.map(setor => new TecnicoCCDTO(setor.value, setor.label));

      this.labelValueList = this.route.snapshot.data['setoresManutencaoResolve'];
      this.setorOpcoes = this.labelValueList.map(setor => new TecnicoSetorDTO(setor.value, setor.label));
      
      this.tecnicoDTO = this.route.snapshot.data['tecnicoResolve'];
      this.popularPicklistEditar();
    }
  }

  public buscarSetoresManutencaoPorTecnico(idTecnico: number){   
    this.tecnicoService.buscarSetoresManutencaoPorTecnico(idTecnico).subscribe(tecnicoDTO =>{           
      this.tecnicoDTO.setoresManutencao = tecnicoDTO.nomeSetor;            
    },
    error=>{
      this.messagesService.addErrorMessage(error);      
    })
  }

  private verificarRota(): void {
    var isDetalhar = this.activatedRoute.snapshot.params['isDetalhar'];
    (isDetalhar == 0) ? this.isDetalhar = true : this.isDetalhar = false;
    this.mudarNome();
  }

  private mudarNome(): void {
    (this.isDetalhar) ? this.titulo = "Detalhar" : this.titulo = "Editar"
    this.breadcrumbService.addRoute('/app/administracao', 'Administração', false);
    this.breadcrumbService.addRoute('/app/administracao/consultar-tecnico', 'Técnicos', true); 
    this.breadcrumbService.addRoute('/app/administracao/detalhar-editar-tecnico', this.titulo , false);
  }

  public voltar(): void {
    this.location.back();
  }

  private buscarRealocacoes(id: number): void {
    this.realocacaoService.buscarPor(id)
      .subscribe(realocacoes => {
        this.realocacoesTecnico = realocacoes;
        this.processarRealocacoes();
      });
  }

  private processarRealocacoes(): void {
    this.realocacoesTecnico.forEach((item, indice) => {
      if (indice == 0) {
        item.isUltima = true;
      } else {
        item.isUltima = false;
      }
    })
  }

  public showModalRealocacaoTecnico(id: number, isUltima?: boolean): void {
    this.realocacaoService.buscarRealocacaoPorId(id)
      .subscribe(retorno => {
        this.realocacaoTecnico = retorno;
        this.ajustarDatas();
        this.realocacaoTecnico.isUltima = isUltima;
        this.divModal = $('#id-modal-realocacao-tecnico').modal('show');
      });
  }

  public abrirDetalhar(id: number): void {
    this.sinalizarCamposObrigatoriosRealocacaoTecnico = "";
    this.isDetalharRealocacao = true;
    this.isUltima = false;
    this.showModalRealocacaoTecnico(id);
  }

  public abrirModalRealocacaoTecnicoEditar(id: number, isUltima: boolean): void {
    this.sinalizarCamposObrigatoriosRealocacaoTecnico = "*"
    this.isUltima = isUltima;
    this.isDetalharRealocacao = false;
    this.showModalRealocacaoTecnico(id, isUltima);
  }

  public abrirModalRealocacaoTecnicoSalvar(): void {
    this.isUltima = true;
    this.isDetalharRealocacao = false;
    this.sinalizarCamposObrigatoriosRealocacaoTecnico = "*";
    this.realocacaoTecnico = new RealocacaoTecnicoDTO();
    this.ajustarDatas();
    this.divModal = $('#id-modal-realocacao-tecnico').modal('show');
  }

  private ajustarDatas() {
    if (!isNullOrUndefined(this.realocacaoTecnico.periodoInicio)) {
      this.realocacaoTecnico.periodoInicio = moment(this.realocacaoTecnico.periodoInicio).toDate();
    }
    if (!isNullOrUndefined(this.realocacaoTecnico.periodoFim)) {
      this.realocacaoTecnico.periodoFim = moment(this.realocacaoTecnico.periodoFim).toDate();
    }
  }

  public fecharModalRealocacaoTecnico(): void {
    this.divModal.modal('hide');
  }

  private validarCampos(): boolean {

    let camposObrigatorios: string[] = [];
    if (this.realocacaoTecnico.motivo == null ||  this.realocacaoTecnico.motivo.length == 0) {
     camposObrigatorios.push("Motivo");
    }
    if (this.realocacaoTecnico.centroCusto == null || this.realocacaoTecnico.centroCusto == "null") {
      camposObrigatorios.push("Centro de Custo Realocado");
    }
    if (StringUtils.isNullOrUndefinedOrEmpty(this.realocacaoTecnico.periodoInicio)) {
      camposObrigatorios.push("Periodo Data início");
    }
    if (this.realocacaoTecnico.tipoRealocacao == null || this.realocacaoTecnico.tipoRealocacao == "null") {
    camposObrigatorios.push("Realocação");
    }
    if (camposObrigatorios.length > 0) {
      this.mostrarMensagemCamposObrigatorios(camposObrigatorios);
      return false;
    }

    return true;
  }

  public atualizar(): void { 
         
      this.tecnicoService.atualizar(this.tecnicoDTO).subscribe(parametro => {
        this.messagesService.addSuccessMessage('Atualização realizada com sucesso.');  
        //this.location.back();      
      }, error => {
        this.messagesService.addErrorMessage(error);
      });   
  }

  public persistirRealocacaoTecnico(): void {
    this.realocacaoTecnico.motivo = this.realocacaoTecnico.motivo.toLocaleUpperCase();
    isNullOrUndefined(this.realocacaoTecnico.id) ? this.salvarRealocacaoTecnico() : this.editarRealocacaoTecnico();
  }

  public salvarRealocacaoTecnico(): void {
    this.realocacaoTecnico.tecnico = this.tecnicoDTO.id;
    if(this.validarCampos() && this.validarDatas()){
      this.realocacaoService.salvar(this.realocacaoTecnico)
        .subscribe(realocao => {
          this.realocacaoTecnico = realocao;
          this.messagesService.addSuccessMessage("Cadastro realizado com sucesso");
          this.buscarRealocacoes(this.tecnicoDTO.id);
          this.dataTable.reset();
          this.fecharModalRealocacaoTecnico();
        },
        error => {
          this.messagesService.addErrorMessage(error);
        })
    }
  }

  public editarRealocacaoTecnico(): void {
    if(this.validarCampos() && this.validarDatas()){
    this.realocacaoService.atualizar(this.realocacaoTecnico)
      .subscribe(realocacao => {
        this.realocacaoTecnico = realocacao;
        this.messagesService.addSuccessMessage("Edição realizada com sucesso");
        this.buscarRealocacoes(this.tecnicoDTO.id);
        this.dataTable.reset();
        this.fecharModalRealocacaoTecnico();
      },
      error => {
        this.messagesService.addErrorMessage(error);
      }
      )
  }
}

  private validarDatas(): boolean {
    if (this.realocacaoTecnico.periodoFim != null && this.realocacaoTecnico.periodoFim < this.realocacaoTecnico.periodoInicio) {
      this.messagesService.addErrorMessage("O periodo 'até' não pode ser menor do que o periodo 'de'");
      return false;
    }
    return true;
  }

  public removerRealocacaoTecnico(realocacaoTecnico: RealocacaoTecnicoDTO): void {
    this.modalConfirmaExclusao.showDialog().subscribe(success => {
      if(success) {
        this.realocacaoService.remover(realocacaoTecnico.id).subscribe(() => {
          this.realocacoesTecnico.splice(this.realocacoesTecnico.indexOf(realocacaoTecnico), 1);
          this.realocacoesTecnico = [...this.realocacoesTecnico];
          this.processarRealocacoes();
          this.messagesService.addSuccessMessage("Exclusão realizada com sucesso");
        },error => {
          this.messagesService.addErrorMessage(error);
        })
      }
    });
  }

  popularPicklistEditar() {
    
    this.tecnicoDTO.ccList.map(CC => {
      CC.label = (this.centroCustoOpcoes.find(item => item.codigoCC === CC.codigoCC)).label;
    });

    this.centroCustoSelecionados = this.tecnicoDTO.ccList;

    this.centroCustoSelecionados.forEach(CC => {
      this.centroCustoOpcoes
        .filter((item, index) =>
          item.codigoCC === CC.codigoCC ? this.centroCustoOpcoes.splice(index, 1) : null);
    });  
    
    this.tecnicoDTO.setorList.map(setor => {
      setor.label = (this.setorOpcoes.find(item => item.idSetor === setor.idSetor)).label;
    });

    this.setorSelecionados = this.tecnicoDTO.setorList;

    this.setorSelecionados.forEach((setor) => {
      this.setorOpcoes
        .filter((item, index) =>
          item.idSetor === setor.idSetor ? this.setorOpcoes.splice(index, 1) : null);
    });
  
  }

}

