import { Component, OnInit } from '@angular/core';
import { BreadcrumbService } from '../../../../core/breadcrumb/breadcrumb.service';
import { TecnicoDTO } from '../../resources/dtos/tecnico-dto.class';
import { TecnicoService } from '../../services/tecnico.service';
import { error } from 'util';
import { Location } from '@angular/common';
import { MessagesService } from '../../../../core/messages/messages.service';
import { AdministracaoGenericComponent } from '../../../administracao-generic.component';
import { AuthenticationService } from '../../../../core/security/auth.service';
import { SetorManutencaoEnum } from '../../resources/enums/setor-manutencao.enum';
import { ArrayUtil } from '../../../../shared/Utils/ArrayUtil';
import { LabelValue } from '../../../../core/models/label-value';
import { ActivatedRoute } from '@angular/router';
import { SetorManutencaoService } from '../../../../shared/services/setor-manutencao.service';
import { TecnicoSetorDTO } from '../../resources/dtos/tecnico-setor-dto';
import { TecnicoCCDTO } from '../../resources/dtos/tecnico-cc-dto';

@Component({
  selector: 'simeq-cadastrar-tecnico',
  templateUrl: './cadastrar-tecnico.component.html',
  styleUrls: ['./cadastrar-tecnico.component.scss']
})
export class CadastrarTecnicoComponent extends AdministracaoGenericComponent implements OnInit {
  
  isTecnicoValido: boolean;
  matricula: string = null;
    
  public listaSetorManutencao: LabelValue[] = [];

  header: string = "Cadastrar";

  labelValueList: LabelValue[] = [];

  centroCustoOpcoes: TecnicoCCDTO[] = [];
  centroCustoSelecionados: TecnicoCCDTO[] = [];

  setorOpcoes: TecnicoSetorDTO[] = [];
  setorSelecionados: TecnicoSetorDTO[] = [];

  tecnicoDTO: TecnicoDTO = new TecnicoDTO();
  isEditar = false;

  constructor(private breadcrumbService: BreadcrumbService, 
              messagesService: MessagesService,
              private route: ActivatedRoute,
              private tecnicoService: TecnicoService,
              private setorManutencaoService: SetorManutencaoService,
              private location: Location
  ) {
    super(messagesService);    
  }

  ngOnInit() {  
    
    this.breadcrumbService.addRoute('/app/administracao', 'Administração', false);
    this.breadcrumbService.addRoute('/app/administracao/consultar-tecnico', 'Técnicos', true);
    this.isEditar = this.route.snapshot.data['isEditar'];

    if (this.isEditar) {
      this.breadcrumbService.addRoute('/app/administracao/detalhar-editar-tecnico', 'Editar', false);
      this.header = "Editar";

      this.labelValueList = this.route.snapshot.data['centrosCustoResolve'];
      this.centroCustoOpcoes = this.labelValueList.map(setor => new TecnicoCCDTO(setor.value, setor.label));

      this.labelValueList = this.route.snapshot.data['setoresManutencaoResolve'];
      this.setorOpcoes = this.labelValueList.map(setor => new TecnicoSetorDTO(setor.value, setor.label));

      this.tecnicoDTO = this.route.snapshot.data['busca-tecnico'];
      this.popularPicklistEditar();

    } else {
      this.breadcrumbService.addRoute('/app/administracao/cadastrar-tecnico', 'Cadastrar', false);

      this.labelValueList = this.route.snapshot.data['centrosCustoResolve'];
      this.centroCustoOpcoes = this.labelValueList.map(setor => new TecnicoCCDTO(setor.value, setor.label));

      this.labelValueList = this.route.snapshot.data['setoresManutencaoResolve'];
      this.setorOpcoes = this.labelValueList.map(setor => new TecnicoSetorDTO(setor.value, setor.label));
    }     
  }

  public carregar(){
    if(this.validarMatricula()) {
      this.tecnicoService.buscarPor(this.matricula).subscribe(tecnicoDTO =>{
                          this.tecnicoDTO = tecnicoDTO;
                          this.isTecnicoValido = true;
                        },
                        error=>{
                          this.messagesService.addErrorMessage(error);
                          this.tecnicoDTO = new TecnicoDTO();
                          this.matricula = null;
                        })
    }
  }

  private validarMatricula(): boolean {
    if(!this.matricula) {
      this.messagesService.addErrorMessage('Matrícula não informada.');
      return false;
    }
    return true;
  }

  public salvar() {
    if(this.isTecnicoValido) {
      this.tecnicoDTO.ccList = this.centroCustoSelecionados;
      this.tecnicoDTO.setorList = this.setorSelecionados;
      this.tecnicoService.salvar(this.tecnicoDTO).subscribe(
        retorno => {
          this.guardarMensagem('Cadastro realizado com sucesso.');
          this.location.back();
        }, error => {
          this.messagesService.addErrorMessage(error);
        });
    } else {
      this.messagesService.addErrorMessage(`Falta informação obrigatória. Por favor, informe o/a 'Matrícula'.`);
    }
  }

  public cancelar() {
    this.location.back();
  }

  popularPicklistEditar() {

    this.tecnicoDTO.setorList.map(setor => {
      setor.label = (this.setorOpcoes.find(item => item.idSetor === setor.idSetor)).label;
    });

    this.centroCustoSelecionados = this.tecnicoDTO.ccList;

    this.centroCustoSelecionados.forEach(CC => {
      this.centroCustoOpcoes
        .filter((item, index) =>
          item.codigoCC === CC.codigoCC ? this.centroCustoOpcoes.splice(index, 1) : null);
    });

    this.setorSelecionados = this.tecnicoDTO.setorList;

    this.setorSelecionados.forEach((setor) => {
      this.setorOpcoes
        .filter((item, index) =>
          item.idSetor === setor.idSetor ? this.setorOpcoes.splice(index, 1) : null);
    });

  }

}
