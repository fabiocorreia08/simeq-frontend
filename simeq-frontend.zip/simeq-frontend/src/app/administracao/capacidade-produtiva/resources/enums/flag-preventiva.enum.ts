export class FlagPreventivaEnum {
    static readonly NAO_SOFRE_PREVENTIVA: string = 'N';
    static readonly SOFRE_PREVENTIVA: string = 'S';

    public static readonly lista: {chave: any, valor: any}[] = [  {chave: FlagPreventivaEnum.SOFRE_PREVENTIVA, valor: 'Sim'},
                                                                {chave: FlagPreventivaEnum.NAO_SOFRE_PREVENTIVA, valor: 'Não'}]

    public static getValor(chave: any): any {
        let retorno: {chave: any, valor: any}[] = FlagPreventivaEnum.lista.filter(item => item.chave === chave);
        if(retorno && retorno.length > 0) {
            return retorno[0].valor;
        } else {
            return null;
        }
    }
}