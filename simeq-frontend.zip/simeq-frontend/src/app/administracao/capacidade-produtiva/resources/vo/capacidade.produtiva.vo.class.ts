export class CapacidadeProdutivaVO{
    idEquipamento: number;
    codigoManutencao: string;
    nomeEquipamento: string;
    numeroAno: Date;
    flagStatus: string = "null";
    codigoCentroCusto: string = "null";
    dataInstalacao:Date;
    indice: string;
    dataInicial: string;
    dataFinal: string;    
    flagPreventiva: string = "null";
    centroCustos: number[] = [];
        
}

