export class CapacidadeProdutivaDTO{    
    idEquipamento?:number;
    codigoManutencao:string;
    flagStatus:string = "null";
    nomeEquipamento:string;
    dataInstalacao?:Date;
    codigoCentroCusto: string = "null";
    numeroAno: number;
    descricaoPreRequisitoInformacao: string;
    descricaoObservacao: string;
    numeroPatrimonio: string;
    numeroPeso: number;
    numeroTensao: number;
    numeroPotencia: number;
    fabricante: string;
    modelo: string;
    sequencia: string;
    flagPreventiva:string = "null";
    nomeTipoPotencia:string;  
    indice: string;  
    diasUteis: string;
	horasFuncionamento: string;
	preventivaPrevista: string;
	preventivaExecutada: string;
	corretivaComParalisacao: string; 
    dataInicial: String;
    dataFinal: String;    
}
