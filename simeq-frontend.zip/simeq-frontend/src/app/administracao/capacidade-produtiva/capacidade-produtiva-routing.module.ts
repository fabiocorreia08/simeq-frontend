import { PerfisConstants } from '../../core/security/perfis.constants';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MainComponent } from '../../main/main.component';
import { BuscaCentrosCustoResolve } from '../../shared/resolves/busca-centros-custo.resolve';
import { AuthGuard } from '../../core/security/auth.guard';
import { AuthenticationService } from '../../core/security/auth.service';
import { DetalharEditarAuthGuard } from '../../core/security/detalhar-editar-auth.guard';
import { ConsultarCapacidadeProdutivaComponent } from './components/consultar-capacidade-produtiva/consultar-capacidade-produtiva.component';

const routes: Routes = [
    { path: 'app', component: MainComponent,
        children: [
           
            {
                path: 'administracao/consultar-capacidade-produtiva',
                component: ConsultarCapacidadeProdutivaComponent,
                canActivate: [AuthGuard],
                data: {funcionalidade: PerfisConstants.RELATORIOS_PERMISSOES},
                resolve: {
                    centrosCustoResolve: BuscaCentrosCustoResolve
                }
            }
        ]
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class CapacidadeProdutivaRoutingModule { }
