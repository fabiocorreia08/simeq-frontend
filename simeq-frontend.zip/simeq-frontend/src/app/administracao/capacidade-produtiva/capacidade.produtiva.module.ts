import { SharedModule } from '../../shared/shared.module';
import { NgModule } from '@angular/core';
import { CapacidadeProdutivaRoutingModule } from './capacidade-produtiva-routing.module';
import { InputMaskModule, DataTableModule, DropdownModule, InputTextareaModule, CheckboxModule, CalendarModule } from 'primeng/primeng';
import { FormsModule } from '@angular/forms';
import { CoreModule } from '../../core/core.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ButtonModule } from 'primeng/components/button/button';
import { CentroCustoService } from '../../shared/services/centro-custo.service';
import { TextMaskModule } from "angular2-text-mask";
import { ConsultarCapacidadeProdutivaComponent } from './components/consultar-capacidade-produtiva/consultar-capacidade-produtiva.component';
import { MultiSelectModule } from 'primeng/primeng';
import { CapacidadeProdutivaService } from './services/capacidade-produtiva.service';


@NgModule({
    declarations: [
        ConsultarCapacidadeProdutivaComponent,
    ],
    imports: [
        CapacidadeProdutivaRoutingModule,
        FormsModule,
        BrowserAnimationsModule,
        ButtonModule,
        CoreModule,
        InputMaskModule,
        InputTextareaModule,
        DataTableModule,
        DropdownModule,
        CalendarModule,
        CheckboxModule,
        TextMaskModule,
        SharedModule,
        MultiSelectModule
    ],

    providers: [
        CapacidadeProdutivaService,      
        CentroCustoService        
    ]
})
export class CapacidadeProdutivaModule {}
