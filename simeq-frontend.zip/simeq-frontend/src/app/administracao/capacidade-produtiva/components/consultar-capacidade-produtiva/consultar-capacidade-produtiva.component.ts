import { Component, OnInit } from '@angular/core';
import { AdministracaoGenericComponent } from '../../../administracao-generic.component';
import { OnDestroy } from '@angular/core/src/metadata/lifecycle_hooks';
import { AuthenticationService } from '../../../../core/security/auth.service';
import { BreadcrumbService } from '../../../../core/breadcrumb/breadcrumb.service';
import { CentroCustoService } from '../../../../shared/services/centro-custo.service';
import { ActivatedRoute } from "@angular/router";
import { MessagesService } from '../../../../core/messages/messages.service';
import { CapacidadeProdutivaService } from '../../services/capacidade-produtiva.service';

import { LabelValue } from '../../../../core/models/label-value';
import { Pagina } from '../../../../core/models/pagina.model';
import { CapacidadeProdutivaDTO } from '../../resources/dtos/capacidade-produtiva-dto.class';
import { ArrayUtil } from '../../../../shared/Utils/ArrayUtil';
import { LazyLoadEvent } from 'primeng/components/common/api';
import { PerfisConstants } from '../../../../core/security/perfis.constants';
import { SituacaoEquipamento } from '../../../../manutencao/enums/situacao-equipamento.enum';
import { CapacidadeProdutivaVO } from '../../resources/vo/capacidade.produtiva.vo.class';
import { CalendarLocaleService } from '../../../../core/calendar.locale.service';
import { DatePipe } from '@angular/common';
import { isNullOrUndefined } from 'util';
import { AtivoInativoEnum } from '../../../equipamento/resources/enums/AtivoInativo.enum';
import { FlagPreventivaEnum } from '../../resources/enums/flag-preventiva.enum';
import { RelatorioService } from '../../../../relatorios/services/relatorio.service';
import { RelatorioCapacidadeProdutivaFiltro } from '../../../../relatorios/models/relatorio-capacidade-produtiva-filtro';

@Component({
  selector: 'simeq-consultar-capacidade-produtiva',
  templateUrl: './consultar-capacidade-produtiva.component.html',
  styleUrls: ['./consultar-capacidade-produtiva.component.scss']
})
export class ConsultarCapacidadeProdutivaComponent extends AdministracaoGenericComponent implements OnInit, OnDestroy {

  public buscaHabilitada = false;   
  public filtro: CapacidadeProdutivaVO = new CapacidadeProdutivaVO();  
  public filtroRelatorio: RelatorioCapacidadeProdutivaFiltro = new RelatorioCapacidadeProdutivaFiltro(); 
  public listaStatus = AtivoInativoEnum.lista;
  public listaFlagPreventiva = FlagPreventivaEnum.lista;
  public listaCentroCusto: LabelValue[] = [];
  public pagina: Pagina<CapacidadeProdutivaDTO> = new Pagina<CapacidadeProdutivaDTO>();
  public codigoMask = [/[aA-zZ]/, /[aA-zZ]/, '-', /[aA-zZ]/, '-', /\d/, /\d/, /\d/,];
  public pt = this.calendarLocalService.pt_BR;

  dataInicial: Date;
  dataFinal: Date;
  indice: number;

  public dataText: string;
  public isDataFuncionamentoValida: boolean = true;
  filtrarCentrosCustos = false;
  public centrosCustoOpcoes: LabelValue[] = [];

  constructor(private auth: AuthenticationService,
    private breadcrumbService: BreadcrumbService,
    private centroCustoService: CentroCustoService,
    private relatorioService: RelatorioService,
    private route: ActivatedRoute,
    protected messagesService: MessagesService,
    private capacidadeProdutivaService: CapacidadeProdutivaService,
    private calendarLocalService: CalendarLocaleService,
    private dataPipe: DatePipe,) {
      super(messagesService);
    breadcrumbService.addRoute('/app/administracao', 'Relatórios',false);
    breadcrumbService.addRoute('/app/relatorios/consultar-capacidade-produtiva', 'Capacidade Produtiva de Equipamento ', false);
    breadcrumbService.addRoute('/app/relatorios/consultar-capacidade-produtiva','Consultar', false);
  
     }

  ngOnInit() {
    this.limparFiltros();
    this.listaCentroCusto = ArrayUtil.adicionarPrimeiroValor(this.listaCentroCusto, "Selecione", "null");
    this.listaCentroCusto = this.route.snapshot.data['centrosCustoResolve'];
    //this.popularFiltros();
    //this.mostrarMensagemGuardada();
  }

  ngOnDestroy(): void {
    localStorage.setItem("buscaHabilitada", JSON.stringify(this.buscaHabilitada));
    localStorage.setItem("filtroCapacidadeProdutiva", JSON.stringify(this.filtro))
  }

  public carregarCentroCusto(): void {
    this.centroCustoService.buscarTodos()
    .subscribe(c => {
      this.listaCentroCusto = c;
    });     
  }

  public pesquisar(): void {    
    this.buscaHabilitada = true;
    this.pagina = new Pagina();
    this.filtro.codigoManutencao = this.limparRegex(this.filtro.codigoManutencao);   
    this.filtrar();
  } 

  public filtrar(): void {    
    this.capacidadeProdutivaService.filtrar(this.filtro, this.pagina)
      .subscribe((pagina) => {
        this.pagina = pagina;
      },
      (error) => {
        this.messagesService.addErrorMessage(error);
      });
  } 

  public paginar(event: LazyLoadEvent): void {
    if(this.buscaHabilitada) {
      this.pagina = new Pagina<CapacidadeProdutivaDTO>(event.first, event.rows);
      this.filtrar();
    }
  }

  public limparFiltros(): void {
    this.buscaHabilitada = false;
    this.pagina = new Pagina();
    this.filtro = new CapacidadeProdutivaVO();
  }

  private popularFiltros(): void {
    this.buscaHabilitada = localStorage.getItem("buscaHabilitada") ? JSON.parse(localStorage.getItem("buscaHabilitada")) : false;
    this.filtro = localStorage.getItem("filtroCapacidadeProdutiva") ? JSON.parse(localStorage.getItem("filtroCapacidadeProdutiva")) : new CapacidadeProdutivaVO();
    localStorage.removeItem("buscaHabilitada");
    localStorage.removeItem("filtroCapacidadeProdutiva");
    if(this.buscaHabilitada) {
      this.pesquisar();
    }
  }

  private limparRegex(input: string) {
    if (input) {
      input = input.replace(/_/g, "");
      input = input.replace("-", "");
      input = input.replace("-", "");
    }
    return input;
  }

  public isBotaoCadastrarExibido() {
    return this.auth.hasAnyPermission(PerfisConstants.CADASTRAR_EQUIPAMENTO_PERMISSOES);
  }

  public isBotaoEditarExibido() {
    return this.auth.hasAnyPermission(PerfisConstants.EDITAR_EQUIPAMENTO_PERMISSOES);
  }

  public validaSituacaoEquipamento(capacidadeProdutiva: CapacidadeProdutivaVO): number {
    this.indice = parseInt(capacidadeProdutiva.indice);
    if (this.indice <= 95){
      return SituacaoEquipamento.VERMELHO;
    }else{
      return SituacaoEquipamento.VERDE; 
    }         
  }

  public gerarRelatorio(): void { 
    
    this.filtroRelatorio.codigoManutencao = this.filtro.codigoManutencao;
    this.filtroRelatorio.nomeEquipamento = this.filtro.nomeEquipamento;
    this.filtroRelatorio.flagPreventiva = this.filtro.flagPreventiva;
    
    this.filtroRelatorio.dataInicial = this.dataPipe.transform(this.filtro.dataInicial, 'dd/MM/yyyy');
    this.filtroRelatorio.dataFinal = this.dataPipe.transform(this.filtro.dataFinal, 'dd/MM/yyyy');
        
    this.filtroRelatorio.centroCustos = this.filtro.centroCustos;
         
      this.relatorioService
      .gerarRelatorioCapacidadeProdutiva(this.filtroRelatorio)
      .subscribe((blobResponse: Blob) => {});    
  }   
   

  public desabilitarBotaoPesquisar() {
    if (isNullOrUndefined(this.filtro.dataInicial) || isNullOrUndefined(this.filtro.dataFinal) || (this.filtro.dataFinal < this.filtro.dataInicial) 
         || isNullOrUndefined(this.filtro.centroCustos) || this.filtro.centroCustos.length==0) {
      return true;        
    }
    return false;
  }
  
  public desabilitarBotaoRelatorio() {
    if (isNullOrUndefined(this.filtro.dataInicial) || isNullOrUndefined(this.filtro.dataFinal) || (this.filtro.dataFinal < this.filtro.dataInicial) 
         || isNullOrUndefined(this.filtro.centroCustos) || this.filtro.centroCustos.length==0) {
      return true;        
    }
    return false;
  }

}
