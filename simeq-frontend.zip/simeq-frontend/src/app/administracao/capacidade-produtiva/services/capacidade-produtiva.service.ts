import { LabelValue } from '../../../core/models/label-value';
import { Observable } from 'rxjs/Observable';
import { Http } from '@angular/http';
import { Injectable } from '@angular/core';
import { AbstractResource } from '../../../core/http/abstract.resource';
import { Pagina } from '../../../core/models/pagina.model';
import { CapacidadeProdutivaVO } from '../resources/vo/capacidade.produtiva.vo.class';
import { CapacidadeProdutivaDTO } from '../resources/dtos/capacidade-produtiva-dto.class';

@Injectable()
export class CapacidadeProdutivaService extends AbstractResource<any>{

  private baseEndPoint: string = "/capacidade-produtiva";

  constructor(http: Http) {
    super(http, '');
  }

  public filtrar(filtro: CapacidadeProdutivaVO, params?: any): Observable<Pagina<CapacidadeProdutivaDTO>> {
    return super.filter(this.baseEndPoint + '/filtrar', filtro, params);
  }  

}
