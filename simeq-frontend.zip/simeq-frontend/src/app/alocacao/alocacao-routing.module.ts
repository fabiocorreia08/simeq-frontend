import { ConsultarManutencaoCorretivaTecnicoComponent } from './components/consultar-alocacao-tecnico/consultar-manutencao-corretiva-tecnico.component';
import { ParaAlocarComponent } from './components/para-alocar/para-alocar.component';
import { PerfisConstants } from './../core/security/perfis.constants';
import { AuthenticationService } from './../core/security/auth.service';
import { AuthGuard } from './../core/security/auth.guard';
import { MainComponent } from './../main/main.component';
import { Routes, RouterModule } from '@angular/router';
import { NgModule } from '@angular/core';
import { CadastrarAlocacaoTecnicoComponent } from './components/cadastrar-alocacao-tecnico/cadastrar-alocacao-tecnico.component';

const routes: Routes = [
  { path: 'app', component: MainComponent,
    children: [
      {
        path: 'alocacao/para-alocar',
        component: ParaAlocarComponent,
        canActivate: [AuthGuard],
        data: {funcionalidade: PerfisConstants.PARA_ALOCAR_PERMISSOES},
      }, {
        path: 'alocacao/consultar',
        component: ConsultarManutencaoCorretivaTecnicoComponent,
        canActivate: [AuthGuard],
        data: {funcionalidade: PerfisConstants.CONSULTAR_ALOCACOES_PERMISSOES},
      }, {
        path: 'alocacao/consultar-preventiva',
        component: ConsultarManutencaoCorretivaTecnicoComponent,
        canActivate: [AuthGuard],
        data: {funcionalidade: PerfisConstants.CONSULTAR_ALOCACOES_PERMISSOES},
      },{
        path: 'alocacao/cadastrar',
        component: CadastrarAlocacaoTecnicoComponent,
        canActivate: [AuthGuard],
        data: {funcionalidade: PerfisConstants.CADASTRAR_ALOCACOES_PERMISSOES},
      }, 
      {
        path: 'alocacao/cadastrar/:numeroSolicitacao',
        component: CadastrarAlocacaoTecnicoComponent,
        canActivate: [AuthGuard],
        data: {funcionalidade: PerfisConstants.CADASTRAR_ALOCACOES_PERMISSOES,
          isNumeroSolicitacaoPreenchido: true},
      },
      {
        path: 'alocacao/corretiva/cadastrar/:numeroSolicitacao',
        component: CadastrarAlocacaoTecnicoComponent,
        canActivate: [AuthGuard],
        data: {funcionalidade: PerfisConstants.CADASTRAR_ALOCACOES_PERMISSOES,
          isNumeroSolicitacaoPreenchido: true,
          isCorretiva: true},
      },
      {
        path: 'alocacao/preventiva/cadastrar/:numeroSolicitacao',
        component: CadastrarAlocacaoTecnicoComponent,
        canActivate: [AuthGuard],
        data: {funcionalidade: PerfisConstants.CADASTRAR_ALOCACOES_PERMISSOES,
          isNumeroSolicitacaoPreenchido: true,
          isCorretiva: false},
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AlocacaoRoutingModule {}
