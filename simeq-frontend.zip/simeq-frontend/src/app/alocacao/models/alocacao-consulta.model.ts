
export class AlocacaoConsulta {
  public matricula: string;
  public nomeTecnico: string;
  public cargo: string;
  public centroCusto: string;
  public turno: string;
  public numeroSolicitacao: string;
  public classeManutencao: string;
  public dataHoraAlocacao: Date;
  public dataHoraAlocacaoFormatada: string;
  public alocadoPor: string;
}