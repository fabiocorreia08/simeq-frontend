import { AlocacaoCadastroTabela } from "./alocacao-cadastro-tabela";

export class CadastroAlocacao {
  public listaAlocacaoCadastroTabela: AlocacaoCadastroTabela[] = null;
  public numeroSolicitacao: string;
  public listaAlocacaoRemovidasDaBase: AlocacaoCadastroTabela[] = null;
  public matriculaUsuarioLogado: string;
  public nomeUsuarioLogado: string;
}
