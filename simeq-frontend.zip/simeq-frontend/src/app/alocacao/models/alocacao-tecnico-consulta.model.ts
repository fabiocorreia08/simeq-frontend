
export class AlocacaoTecnicoConsulta {
  public matricula: string;
  public nomeTecnico: string;
  public cargo: string;
  public funcao: string;
  public nomeTurmo: string;
    
}


