
export class AlocacaoFiltro {
  public numeroSolicitacao: string;
  public centroCusto: number;
  public nomeCargo: string;
  public idTecnico: number; 
  public perfil: number;
  public matricula: string;
  public codigoTurno: string;
  public idsStatus: number[] = null;
  public centroCustos: number[] = null;
}
