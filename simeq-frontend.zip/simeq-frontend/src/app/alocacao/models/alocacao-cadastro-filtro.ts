
export class AlocacaoCadastroFiltro {
  public nomeTecnico: string;
  public numeroSolicitacao: string;
  public nomeFuncao: string;
  public nomeCargo: string;
  public idTecnico: number;
  //public tecnicos: number[] = null;
  public matricula: string;
  public perfil: number;
  public codigoTurno: string;
}
