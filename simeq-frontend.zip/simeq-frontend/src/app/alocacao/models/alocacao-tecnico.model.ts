
export class AlocacaoTecnico {
  public idManutencao: number;
  public numeroSolicitacao: string;
  public matriculaTecnico: string;
  public idTecnico?: number;

  public constructor(idManutencao: number, numeroSolicitacao: string, matriculaTecnico: string) {
    this.idManutencao = idManutencao;
    this.numeroSolicitacao = numeroSolicitacao;
    this.matriculaTecnico = matriculaTecnico;
  }

}
