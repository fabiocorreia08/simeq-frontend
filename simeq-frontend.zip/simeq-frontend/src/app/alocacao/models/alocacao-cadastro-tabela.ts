
export class AlocacaoCadastroTabela {
  public matricula: string;
  public nomeTecnico: string;
  public cargo: string;
  public funcao: string;
  public dataHoraAlocacao: Date;
  public dataHoraAlocacaoFormatada: string;
  public alocadoPor: string;
  public idManutencao: number;
  public codigoSituacaoFolha: string;
  public nomeTurmo: string;
}
