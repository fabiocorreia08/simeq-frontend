import { ModalConfirmacaoComponent } from './../../../core/modal-confirmacao/modal-confirmacao.component';
import { PerfisConstants } from './../../../core/security/perfis.constants';
import { AuthenticationService } from './../../../core/security/auth.service';
import { AlocacaoCadastroTabela } from './../../models/alocacao-cadastro-tabela';
import { Component, OnInit, ViewChild } from '@angular/core';
import { BreadcrumbService } from '../../../core/breadcrumb/breadcrumb.service';
import { MessagesService } from '../../../core/messages/messages.service';
import { AdministracaoGenericComponent } from '../../../administracao/administracao-generic.component';
import { LabelValue } from '../../../core/models/label-value';
import { TecnicoService } from '../../../administracao/tecnico/services/tecnico.service';
import { ArrayUtil } from '../../../shared/Utils/ArrayUtil';
import { AlocacaoCadastroFiltro } from '../../models/alocacao-cadastro-filtro';
import { Pagina } from '../../../core/models/pagina.model';
import { LazyLoadEvent } from 'primeng/components/common/api';
import { Router, ActivatedRoute } from '@angular/router';
import { CadastroAlocacao } from '../../models/cadastro-alocacao.model.';
import { AlocacaoService } from '../../services/alocacao.service';
import { ManutencaoCorretivaService } from '../../../manutencao/services/manutencao-corretiva.service';
import { isNullOrUndefined, error } from 'util';
import { TurnoService } from '../../../shared/services/turno.service';
import { PreventivaConsultaFiltro } from '../../../manutencao/models/preventiva-consulta-filtro.model';
import { HistoricoManutencaoEquipamento } from '../../../manutencao/models/hist-manutencao-equip';
import { HistoricoStatusManutencaoFiltro } from '../../../manutencao/models/historico-status-filtro.model';
import { Location } from '@angular/common';
import { ShowTypes } from '@swimlane/ngx-charts';

declare var $: any;
@Component({
  selector: 'simeq-cadastrar-alocacao-tecnico',
  templateUrl: './cadastrar-alocacao-tecnico.component.html',
  styleUrls: ['./cadastrar-alocacao-tecnico.component.scss']
})
export class CadastrarAlocacaoTecnicoComponent extends AdministracaoGenericComponent implements OnInit {

  @ViewChild('modalConfirmaCancelamentoAlocacao') public modalConfirmaCancelamentoAlocacao: ModalConfirmacaoComponent;
  public listaCargo: LabelValue[] = [];
  public listaTecnico: LabelValue[] = [];
  public listaFuncao: LabelValue[] = [];
  public listaTurno: LabelValue[] = [];

  public tecnicosSelecionados: AlocacaoCadastroTabela[] = [];

  public alocacaoCadastroFiltro: AlocacaoCadastroFiltro = new AlocacaoCadastroFiltro();
  public historicoFiltro: HistoricoStatusManutencaoFiltro = new HistoricoStatusManutencaoFiltro();
  public paginaTecnicosDisponiveis: Pagina<AlocacaoCadastroTabela> = new Pagina<AlocacaoCadastroTabela>();

  public tecnicosSelecionadosParaAlocacao: AlocacaoCadastroTabela[] = [];
  public alocacoesRemovidasDaBase: AlocacaoCadastroTabela[] = [];
  public cadastroAlocacao: CadastroAlocacao = new CadastroAlocacao();
  public numeroSolicitacao: string;
  public erroEmail: string;
  public isFiltrar = false;
  public isPerfilTecnico = false;
  public isPerfilGestor = false;
  public isDesabilitarBotaoSalvar = true;
  public isNumeroSolicitacaoPreenchido = false;
  public isCorretiva = false;
  public isAlocacaoAlterada = false;  
  public filtro: PreventivaConsultaFiltro = new PreventivaConsultaFiltro();
  public pagina: Pagina<HistoricoManutencaoEquipamento> = new Pagina<HistoricoManutencaoEquipamento>();
  public divModal: any;

  public isShowMessage = false;

  constructor(
    private breadcrumbService: BreadcrumbService,
    messagesService: MessagesService,
    public tecnicoService: TecnicoService,
    private router: Router,
    private route: ActivatedRoute,
    private alocacaoService: AlocacaoService,
    public auth: AuthenticationService,
    public manutencaoCorretivaService: ManutencaoCorretivaService,
    public turnoService: TurnoService,
    private location: Location) {
    super(messagesService);
    let verificaCaminho;
    this.route.queryParams.subscribe(params => {      
      verificaCaminho = (params['isCorretiva'] === "true");
      this.isCorretiva = (this.route.snapshot.data['isCorretiva']) ?
      this.route.snapshot.data['isCorretiva'] : verificaCaminho;
    })
    
    if (this.isCorretiva) {      
      this.breadcrumbService.addRoute('/app/manutencao/consultar-manutencao-corretiva', 'Corretivas', true);
      this.breadcrumbService.addRoute('/app/alocacao/consultar', 'Alocar Técnico', false);

    } else {      
      this.breadcrumbService.addRoute('/app/manutencao/preventiva/consultar', 'Preventivas', true);
      this.breadcrumbService.addRoute('/app/alocacao/consultar', 'Alocar Técnico', false);
    }
  }

  ngOnInit(): void {
    this.paginaTecnicosDisponiveis.registros = [];
    this.isPerfilTecnico = this.auth.getPerfil(PerfisConstants.TECNICO);
    this.isPerfilGestor = this.auth.getPerfil(PerfisConstants.GESTOR);
    this.isNumeroSolicitacaoPreenchido = this.route.snapshot.data['isNumeroSolicitacaoPreenchido'];
    this.alocacaoCadastroFiltro.numeroSolicitacao = this.route.snapshot.params['numeroSolicitacao'];
    
    if (this.isNumeroSolicitacaoPreenchido) {      
        this.pesquisarTecnicosDisponiveis();      
    }
    if (this.isPerfilTecnico && !this.isNumeroSolicitacaoPreenchido) {
      this.pesquisarTecnicosDisponiveis();
    }
    
    this.carregarTecnicos();
    this.carregarCargos();
    this.carregarFuncoes();
    this.carregarTurnos();    
  }

  private carregarTecnicos(): void {
    this.tecnicoService.buscarTodos().subscribe(t => {
      this.listaTecnico = t;
      this.listaTecnico = ArrayUtil.adicionarPrimeiroValor(this.listaTecnico, 'Selecione', null);
    });
  }

  private carregarCargos(): void {
    this.tecnicoService.buscarTodosCargos().subscribe(c => {
      this.listaCargo = c;
      this.listaCargo = ArrayUtil.adicionarPrimeiroValor(this.listaCargo, 'Selecione', null);
    });
  }

  private carregarFuncoes(): void {
    this.tecnicoService.buscarTodasFuncoes().subscribe(c => {
      this.listaFuncao = c;
      this.listaFuncao = ArrayUtil.adicionarPrimeiroValor(this.listaFuncao, 'Selecione', null);
    });
  }

  public carregarTurnos(): void {
    this.turnoService.buscarTodos().subscribe(t => {
      this.listaTurno = t;
      this.listaTurno = ArrayUtil.adicionarPrimeiroValor(this.listaTurno, 'Selecione', null);
    });
  }

  public paginarTecnicosDisponiveis(event: LazyLoadEvent): void {
    if (this.isFiltrar) {
      this.paginaTecnicosDisponiveis = new Pagina<AlocacaoCadastroTabela>(event.first, event.rows);
      this.pesquisarTecnicosDisponiveis();
    }
  }   

  public limparFiltros(): void {
    if (this.isNumeroSolicitacaoPreenchido) {
      let numeroSolicitacao = this.alocacaoCadastroFiltro.numeroSolicitacao;
      this.alocacaoCadastroFiltro = new AlocacaoCadastroFiltro();
      this.alocacaoCadastroFiltro.numeroSolicitacao = numeroSolicitacao;
    } else {
      this.alocacaoCadastroFiltro = new AlocacaoCadastroFiltro();
    }
  }

  public cancelar(): void {
    if(this.isCorretiva){
      this.router.navigate(['app/manutencao/consultar-manutencao-corretiva']);
    }else{
      this.router.navigate(['app/manutencao/preventiva/consultar']);
    }
    //this.location.back();    
  }
 /*
  public cancelar(): void {
    if (this.isAlocacaoAlterada) {
      this.modalConfirmaCancelamentoAlocacao.showDialog().subscribe(success => {
        if (success) {
          this.location.back();
        }
      }, error => {
        this.messagesService.addErrorMessage(error);
      });
    } else {
      this.location.back();
    }
  }
  */
  public pesquisarTecnicosDisponiveis(): void {
    if (this.isPerfilTecnico || this.isCamposValidos()) {
      this.paginaTecnicosDisponiveis = new Pagina();
      this.isFiltrar = true;
      this.alocacaoCadastroFiltro.matricula = this.auth.authInfo.username;
      this.alocacaoCadastroFiltro.perfil = this.auth.getIdPerfil(this.auth.authInfo.details.perfis);
      this.alocacaoCadastroFiltro.numeroSolicitacao = this.alocacaoCadastroFiltro.numeroSolicitacao.toLocaleUpperCase();
      this.filtrar();
            
    }
  }

  public filtrar(): void{
    this.alocacaoService.filtrarTecnicosParaAlocacao(this.alocacaoCadastroFiltro, this.paginaTecnicosDisponiveis)
    .subscribe((pagina) => {
      this.paginaTecnicosDisponiveis = pagina;
      //if (!this.isPerfilTecnico) {
        this.buscarTecnicosAlocados();
      //}                    
    },
      (error) => {
        this.messagesService.addErrorMessage(error);
      }); 
  }

  private buscarTecnicosAlocados(): void {
    this.tecnicosSelecionadosParaAlocacao = [];
    this.alocacaoService.buscarTecnicosCorretivaAlocados(this.alocacaoCadastroFiltro.numeroSolicitacao,
      this.auth.getIdPerfil(this.auth.authInfo.details.perfis), this.auth.authInfo.username)
      .subscribe(t => {
        this.tecnicosSelecionadosParaAlocacao = t;
      }, error => {
        this.messagesService.addErrorMessage(error);
      });
  }

  public adicionarTecnicosDisponiveisAListaDeTecnicosASeremAlocados() {
    if (this.tecnicosSelecionados.length === 0) {
      this.messagesService.addErrorMessage('Nenhum técnico foi adicionado para alocação. Informe o técnico.');
      return;
    }
    this.tecnicosSelecionados.forEach(t => {
      if (t.codigoSituacaoFolha.trim().length === 0) {
        t.alocadoPor = this.auth.authInfo.username;
        t.dataHoraAlocacao = new Date();
        this.tecnicosSelecionadosParaAlocacao.push(t);
        this.isAlocacaoAlterada = true;
        this.paginaTecnicosDisponiveis.registros.splice(this.paginaTecnicosDisponiveis.registros.indexOf(t), 1);
        if (!isNullOrUndefined(t.idManutencao)) {
          this.alocacoesRemovidasDaBase.splice(this.alocacoesRemovidasDaBase.indexOf(t), 1);
        }
        this.tecnicosSelecionados = [];
      } else {
        this.messagesService.addErrorMessage('Não é possível realizar a alocação. Técnico inativo.');
      }
    });
    this.isDesabilitarBotaoSalvar = false;
  }

  public excluirTecnicoDaListaDeTecnicosAlocados(tecnicoExcluido: AlocacaoCadastroTabela) {
    this.alocacaoService.isPermitdoexcluirAlocacao(tecnicoExcluido.matricula, this.alocacaoCadastroFiltro.numeroSolicitacao)
      .subscribe(permitido => {
        this.isAlocacaoAlterada = true;
        this.paginaTecnicosDisponiveis.registros.push(tecnicoExcluido);
        this.tecnicosSelecionadosParaAlocacao.splice(this.tecnicosSelecionadosParaAlocacao.indexOf(tecnicoExcluido), 1);
        if (!isNullOrUndefined(tecnicoExcluido.idManutencao)) {
          this.alocacoesRemovidasDaBase.push(tecnicoExcluido);
        }
        this.isDesabilitarBotaoSalvar = this.verificaDesabilitarBotaoSalvar();
      }, error => {
        this.messagesService.addErrorMessage('O técnico possui atividade cadastrada na solicitação e não poderá ser excluído.');
      });
  }

  public salvar() {    
    if (this.isCamposValidos()) {
      this.cadastroAlocacao.numeroSolicitacao = this.alocacaoCadastroFiltro.numeroSolicitacao;
      this.cadastroAlocacao.listaAlocacaoCadastroTabela = this.tecnicosSelecionadosParaAlocacao;
      this.cadastroAlocacao.listaAlocacaoRemovidasDaBase = this.alocacoesRemovidasDaBase;
      this.cadastroAlocacao.matriculaUsuarioLogado = this.auth.authInfo.username;
      this.cadastroAlocacao.nomeUsuarioLogado = this.auth.authInfo.details.nome;

      this.alocacaoService.salvarAlocacao(this.cadastroAlocacao)
        .subscribe(a => {          
          this.buscarHistoricosEquipamento(false);                      
        },
          (error) => {
            this.erroEmail = error;
            if (this.erroEmail.toString().includes('mail')) {
              this.messagesService.addErrorMessage(error);
              this.buscarHistoricosEquipamento(true);
            } else {
              this.messagesService.addErrorMessage(error);
            }
          });
      }    
  }

  private isCamposPreenchido(): string[] {
    let camposNaoPreenchidos: string[] = [];
    if (isNullOrUndefined(this.alocacaoCadastroFiltro.numeroSolicitacao) ||
      this.alocacaoCadastroFiltro.numeroSolicitacao.trim().length === 0) {
      camposNaoPreenchidos.push('Número Solicitação');
    }
    return camposNaoPreenchidos;
  }

  private isCamposValidos(): boolean {
    const camposNaoPreenchidos: string[] = this.isCamposPreenchido();
    if (camposNaoPreenchidos.length > 0) {
      this.mostrarMensagemCamposObrigatorios(camposNaoPreenchidos);
      return false;
    }
    return true;
  }

  private verificaDesabilitarBotaoSalvar(): boolean {
    if (this.tecnicosSelecionadosParaAlocacao.length > 0 || this.alocacoesRemovidasDaBase.length > 0) {
      return false;
    }
    return true;
  }

  public blurNumeroSolicitacao(): void {
    if (isNullOrUndefined(this.alocacaoCadastroFiltro.numeroSolicitacao) ||
      this.alocacaoCadastroFiltro.numeroSolicitacao.trim().length === 0) {
      this.alocacaoCadastroFiltro.numeroSolicitacao = null;
      if (!this.isPerfilTecnico) {
        this.tecnicosSelecionadosParaAlocacao = [];
        this.paginaTecnicosDisponiveis = new Pagina();
      }
      return;
    }
    if (this.isPerfilTecnico) {
      this.alocacaoService.buscarManutencaoComPermissaoTecnico(this.auth.authInfo.username, this.alocacaoCadastroFiltro.numeroSolicitacao)
        .subscribe(m => {

        }, (error) => {
          this.alocacaoCadastroFiltro.numeroSolicitacao = null;
          this.messagesService.addErrorMessage(error);
        });
    }
  }

  public abrirModalHistoricoEquipamento(): void {
    this.buscarHistoricosEquipamento(false);
  }

  public fecharModalSituacaoEquipamento(): void {
    this.pagina = new Pagina<HistoricoManutencaoEquipamento>();
    this.divModal = $('#id-modal-hist-equipamento').modal('hide');
    this.router.navigate(['/app/alocacao/consultar']);
  }

  public buscarHistoricosEquipamento(contemErro: boolean): void {    
    this.historicoFiltro.numeroSolicitacao = this.alocacaoCadastroFiltro.numeroSolicitacao;    
    this.manutencaoCorretivaService.filtrarHistoricoPorEquipamento(this.historicoFiltro, this.pagina)
      .subscribe((pagina) => {                     
        if(this.isCorretiva){  
          
          this.router.navigateByUrl('/app/alocacao/corretiva/cadastrar')
          .then(() => {            
            this.router.navigate(['/app/alocacao/corretiva/cadastrar/' + this.alocacaoCadastroFiltro.numeroSolicitacao]);  
            this.messagesService.addSuccessMessage('Operação realizada com sucesso.');          
          });            
          
          //this.router.navigate(['/app/alocacao/corretiva/cadastrar/' + this.alocacaoCadastroFiltro.numeroSolicitacao]);
          //this.messagesService.addSuccessMessage('Operação realizada com sucesso.');          
             
        }else{                     
          
          this.router.navigateByUrl('/app/alocacao/preventiva/cadastrar')
          .then(() => {            
            this.router.navigate(['/app/alocacao/preventiva/cadastrar/' + this.alocacaoCadastroFiltro.numeroSolicitacao]);   
            this.messagesService.addSuccessMessage('Operação realizada com sucesso.');         
          }); 
                    
          //this.router.navigate(['/app/alocacao/preventiva/cadastrar/' + this.alocacaoCadastroFiltro.numeroSolicitacao]);     
          //this.messagesService.addSuccessMessage('Operação realizada com sucesso.'); 
        }                      
      },
        (error) => {
          this.messagesService.addErrorMessage(error);
      });
  }

  public detalharManutencaoCorretiva(id: string) {
    this.divModal = $('#id-modal-hist-equipamento').modal('hide');
    this.router.navigate(['/app/manutencao/detalhar-manutencao-corretiva/' + id]);
  }

}