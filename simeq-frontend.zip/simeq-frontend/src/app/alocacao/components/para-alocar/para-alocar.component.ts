import { ManutencaoCorretivaConsulta } from './../../../manutencao/models/manutencao-consulta.model';
import { AlocacaoService } from './../../services/alocacao.service';
import { AlocacaoTecnico } from './../../models/alocacao-tecnico.model';
import { BreadcrumbService } from './../../../core/breadcrumb/breadcrumb.service';
import { ManutencaoCorretivaService } from './../../../manutencao/services/manutencao-corretiva.service';
import { LazyLoadEvent } from 'primeng/components/common/api';
import { Pagina } from './../../../core/models/pagina.model';
import { Component, OnInit } from '@angular/core';
import { MessagesService } from '../../../core/messages/messages.service';
import { AuthenticationService } from '../../../core/security/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'simeq-para-alocar',
  templateUrl: './para-alocar.component.html',
  styleUrls: ['./para-alocar.component.scss']
})
export class ParaAlocarComponent implements OnInit {

  public pagina: Pagina<ManutencaoCorretivaConsulta> = new Pagina<ManutencaoCorretivaConsulta>();
  public confirmarSelecaoManutencaoDesabilitada = true;
  public manutencaoSelecionada: ManutencaoCorretivaConsulta = null;
  public alocacaoTecnico: AlocacaoTecnico = null;

  constructor(public manutencaoCorretivaService: ManutencaoCorretivaService,
    public router: Router,
    public alocacaoService: AlocacaoService,
    public messagesService: MessagesService,
    private breadcrumbService: BreadcrumbService,
    private auth: AuthenticationService) {
      breadcrumbService.addRoute('/app/alocacao/para-alocar', 'Para Alocar', false);
  }

  ngOnInit() {
    this.pesquisar();
  }

  public pesquisar(): void {
    this.pagina = new Pagina();
    this.filtrar();
  }

  public paginar(event: LazyLoadEvent): void {
    this.pagina = new Pagina<ManutencaoCorretivaConsulta>(event.first, event.rows);
    this.filtrar();
  }

  public filtrar(): void {
    this.manutencaoCorretivaService.buscarPaginadaAbertaReaberta(this.auth.authInfo.username, this.pagina)
      .subscribe((pagina) => {        
        this.pagina = pagina;
      },
      (error) => {
        this.messagesService.addErrorMessage(error);
      });
  }

  public habilitarBotaoSelecaoManutencao() {
    this.confirmarSelecaoManutencaoDesabilitada = false;
  }

  public confirmarAlocacao(): void {
    this.alocacaoTecnico = new AlocacaoTecnico(this.manutencaoSelecionada.idManutencao, this.manutencaoSelecionada.numeroSolicitacao, this.auth.authInfo.username);
    this.alocacaoService.salvarParaAlocar(this.alocacaoTecnico)
      .subscribe(a => {
        this.messagesService.addSuccessMessage('Operação realizada com Sucesso.');
        this.pesquisar();
      },
    (error) => {
      this.messagesService
        .addErrorMessage('Ocorreu um erro. Tente novamente mais tarde ou entre em contato com a equipe técnica da Casa da Moeda.');
    });
  }

  public detalharManutencao(manutencao: ManutencaoCorretivaConsulta){
    if(manutencao.tipo === 'P'){
      this.router.navigate(['/app/manutencao/preventiva/detalhar/' + manutencao.numeroSolicitacao]);
    } else {
      this.router.navigate(['/app/manutencao/detalhar-manutencao-corretiva/' + manutencao.idManutencao]);
    }
  }
}
