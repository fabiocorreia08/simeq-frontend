import { ModalConfirmacaoComponent } from './../../../core/modal-confirmacao/modal-confirmacao.component';
import { ArrayUtil } from './../../../shared/Utils/ArrayUtil';
import { isNullOrUndefined } from 'util';
import { AlocacaoService } from './../../services/alocacao.service';
import { AlocacaoConsulta } from '../../models/alocacao-consulta.model';
import { AuthenticationService } from '../../../core/security/auth.service';
import { Router, ActivatedRoute } from '@angular/router';
import { MessagesService } from '../../../core/messages/messages.service';
import { PessoaService } from '../../../shared/services/pessoa.service';
import { LazyLoadEvent } from 'primeng/components/common/api';
import { LabelValue } from '../../../core/models/label-value';
import { Pagina } from '../../../core/models/pagina.model';
import { BreadcrumbService } from '../../../core/breadcrumb/breadcrumb.service';
import { CalendarLocaleService } from '../../../core/calendar.locale.service';
import { Component, OnInit, ViewChild } from '@angular/core';
import { CentroCustoService } from '../../../shared/services/centro-custo.service';
import { AlocacaoFiltro } from '../../models/alocacao-filtro.model';
import { TecnicoService } from '../../../administracao/tecnico/services/tecnico.service';
import { TurnoService } from '../../../shared/services/turno.service';
import { StatusManutencaoCorretivaService } from '../../../manutencao/services/status-manutencao.service';

@Component({
  selector: 'simeq-consultar-manutencao-corretiva-tecnico',
  templateUrl: './consultar-manutencao-corretiva-tecnico.component.html',
  styleUrls: ['./consultar-manutencao-corretiva-tecnico.component.scss']
})
export class ConsultarManutencaoCorretivaTecnicoComponent implements OnInit {

  public pagina: Pagina<AlocacaoConsulta> = new Pagina<AlocacaoConsulta>();
  public filtro: AlocacaoFiltro = new AlocacaoFiltro();
  public listaCargo: LabelValue[] = [];
  public listaTecnico: LabelValue[] = [];
  public listaSolicitante: LabelValue[] = [];
  public listaCentroCusto: LabelValue[] = [];
  public listaTurno: LabelValue[] = [];
  public listaStatus: LabelValue[] = [];
  public isCorretiva = true;
  public readonly TECNICO: number = 2;
  public readonly SOLICITANTE: number = 3;
  public readonly VISITANTE: number = 6;

  public desabilitarBotoesVisitante = false;
  @ViewChild('modalConfirmacaoExcluir') public modalConfirmacaoExcluir: ModalConfirmacaoComponent;

  constructor(private calendarLocaleService: CalendarLocaleService,
    private breadcrumbService: BreadcrumbService,
    private pessoaService: PessoaService,
    private alocacaoService: AlocacaoService,
    private centroCustoService: CentroCustoService,
    private messagesService: MessagesService,
    private router: Router,
    public auth: AuthenticationService,
    public tecnicoService: TecnicoService,
    private statusManutencaoService: StatusManutencaoCorretivaService,
    private route: ActivatedRoute,
    public turnoService: TurnoService) {
      let verificaCaminho;

    this.route.queryParams.subscribe(params => {
      verificaCaminho = (params['isCorretiva'] === "true");      
      this.isCorretiva = (this.route.snapshot.data['isCorretiva']) ? this.route.snapshot.data['isCorretiva'] : verificaCaminho;      
    })
    
    if (this.breadcrumbService.routes.length === 0) {
      if (this.isCorretiva) {        
        this.breadcrumbService.addRoute('/app/manutencao/consultar-manutencao-corretiva', 'Corretivas', true);        
        this.breadcrumbService.addRoute('/app/alocacao/consultar', 'Alocações', false);        
        this.breadcrumbService.addRoute('/app/alocacao/consultar', 'Consultar', false);
      } else{        
        this.breadcrumbService.addRoute('/app/manutencao/preventiva/consultar', 'Preventivas', true);        
        this.breadcrumbService.addRoute('/app/alocacao/consultar', 'Alocações', false);        
        this.breadcrumbService.addRoute('/app/alocacao/consultar', 'Consultar', false);        
      }
    }
  }

  ngOnInit() {   
    this.carregarCentroCusto();
    this.carregarTecnicos();
    this.carregarCargos();
    this.carregarTurnos();
    this.carregarStatus();
    this.desabilitarBotoesVisitante = this.getPerfil(this.VISITANTE);
  }

  public getPerfil(perfil: number): boolean {
    let isPerfil = false;
    this.auth.authInfo.details.perfis.forEach(p => {
      if (p.id_perfil === perfil) {
        isPerfil = true;
      }
    });
    return isPerfil;
  }

  public carregarTurnos(): void {
    this.turnoService.buscarTodos().subscribe(t => {
      this.listaTurno = t;
      this.listaTurno = ArrayUtil.adicionarPrimeiroValor(this.listaTurno, 'Selecione', null);
    });
  }

  public carregarCentroCusto(): void {
    /* let idPerfil = this.auth.getIdPerfil(this.auth.authInfo.details.perfis);
    if (isNullOrUndefined(idPerfil)) {
      idPerfil = 0;
    }
    this.centroCustoService.buscarCentroCustoHierarquiaUsuarioLogadoPerfil(idPerfil, this.auth.authInfo.username)
      .subscribe(c => {
        this.listaCentroCusto = c;
        this.listaCentroCusto = ArrayUtil.adicionarPrimeiroValor(this.listaCentroCusto, 'Selecione', null);
      }); */

    this.centroCustoService.buscarTodos()
    .subscribe(c => {
      this.listaCentroCusto = c;      
    }); 
  }

  private carregarTecnicos(): void {
    this.tecnicoService.buscarTodos().subscribe(t => {
      this.listaTecnico = t;
      this.listaTecnico = ArrayUtil.adicionarPrimeiroValor(this.listaTecnico, 'Selecione', null);
    });
  }

  private carregarCargos(): void {
    this.tecnicoService.buscarTodosCargos().subscribe(c => {
      this.listaCargo = c;
      this.listaCargo = ArrayUtil.adicionarPrimeiroValor(this.listaCargo, 'Selecione', null);
    });
  }

  private carregarStatus(): void {
    this.statusManutencaoService.buscarTodosLabelValue().subscribe(s => {
      this.listaStatus = s;
      this.listaStatus = ArrayUtil.adicionarPrimeiroValor(this.listaStatus, 'Selecione', null);
    });
  }

  public limparFiltros(): void {
    this.pagina = new Pagina();
    this.filtro = new AlocacaoFiltro();
  }

  public pesquisar(): void {
    this.pagina = new Pagina();  
    this.filtrar();
  }

  public paginar(event: LazyLoadEvent): void {
    this.pagina = new Pagina<AlocacaoConsulta>(event.first, event.rows);
    this.filtrar();
  }

  public filtrar(): void {    
    
    this.filtro.matricula = this.auth.authInfo.username;
    this.filtro.numeroSolicitacao = !isNullOrUndefined(this.filtro.numeroSolicitacao) ? this.filtro.numeroSolicitacao.toLocaleUpperCase() : undefined;
    this.filtro.perfil = this.auth.getIdPerfil(this.auth.authInfo.details.perfis);

    if(this.isCorretiva){    
            
      this.alocacaoService.filtrar(this.filtro, this.pagina)    
      .subscribe((pagina) => {
        this.pagina = pagina;
      },
        (error) => {
          this.messagesService.addErrorMessage(error);
        });
    }else{      
      this.alocacaoService.filtrarPreventiva(this.filtro, this.pagina)    
      .subscribe((pagina) => {
        this.pagina = pagina;
      },
        (error) => {
          this.messagesService.addErrorMessage(error);
        });
    }    
  }

  public excluirAlocacao(matriculaTecnico: string, numeroSolicitacao: string): void {
    this.modalConfirmacaoExcluir.showDialog().subscribe(success => {
      if (success) {
        this.alocacaoService.excluirAlocacao(matriculaTecnico, numeroSolicitacao).subscribe((e) => {
          this.messagesService.addSuccessMessage('Operação realizada com sucesso.');
          this.pesquisar();
        },
          (error) => {
            this.messagesService.addErrorMessage(error);
          });
      }
    }, error => {
      this.messagesService.addErrorMessage(error);
    });
  }

public editar(numeroSolicitacao: string){
  if (this.isCorretiva){
    this.router.navigate(['/app/alocacao/cadastrar/'+ numeroSolicitacao], {queryParams:{"isCorretiva": true}});
  }    
  else{
    this.router.navigate(['/app/alocacao/cadastrar/'+ numeroSolicitacao], {queryParams:{"isCorretiva": false}});
  }

}

}
