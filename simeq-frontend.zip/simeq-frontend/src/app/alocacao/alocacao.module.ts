import { AlocacaoService } from './services/alocacao.service';
import { TextMaskModule } from 'angular2-text-mask';
import { ButtonModule, InputMaskModule, InputTextareaModule, DataTableModule, DropdownModule, CalendarModule } from 'primeng/primeng';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule } from '@angular/forms';
import { TecnicoModule } from '../administracao/tecnico/tecnico.module';
import { GrupoSubgrupoModule } from '../administracao/grupo-subgrupo/grupo-subgrupo.module';
import { EquipamentoModule } from '../administracao/equipamento/equipamento.module';
import { NgModule } from '@angular/core';
import { CoreModule } from '../core/core.module';
import { SharedModule } from '../shared/shared.module';
import { MultiSelectModule } from 'primeng/components/multiselect/multiselect';
import { AlocacaoRoutingModule } from './alocacao-routing.module';
import { ConsultarManutencaoCorretivaTecnicoComponent } from './components/consultar-alocacao-tecnico/consultar-manutencao-corretiva-tecnico.component';
import { ParaAlocarComponent } from './components/para-alocar/para-alocar.component';
import { CadastrarAlocacaoTecnicoComponent } from './components/cadastrar-alocacao-tecnico/cadastrar-alocacao-tecnico.component';
import { TurnoService } from '../shared/services/turno.service';
import {AccordionModule} from 'primeng/accordion';

@NgModule({
    imports: [
        SharedModule,
        EquipamentoModule,
        GrupoSubgrupoModule,
        TecnicoModule,
        AlocacaoRoutingModule,
        FormsModule,
        BrowserAnimationsModule,
        ButtonModule,
        CoreModule,
        InputMaskModule,
        InputTextareaModule,
        MultiSelectModule,
        DataTableModule,
        DropdownModule,
        CalendarModule,
        TextMaskModule,
        AccordionModule
    ],
    providers: [
      AlocacaoService, TurnoService
    ],
    declarations: [ConsultarManutencaoCorretivaTecnicoComponent, ParaAlocarComponent, CadastrarAlocacaoTecnicoComponent]
})
export class AlocacaoModule {}
