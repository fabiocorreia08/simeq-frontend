import { ManutencaoCorretiva } from './../../manutencao/models/manutencao-corretiva.model';
import { AlocacaoCadastroFiltro } from './../models/alocacao-cadastro-filtro';
import { AlocacaoDetalharFiltro } from './../../manutencao/models/alocacao-detalhar-filtro.model';
import { Pagina } from './../../core/models/pagina.model';
import { AlocacaoDetalhar } from './../../manutencao/models/alocacao-detalhar.model';
import { Observable } from 'rxjs/Observable';
import { Injectable } from '@angular/core';
import { AbstractResource } from '../../core/http/abstract.resource';
import { Http } from '@angular/http';
import { AlocacaoFiltro } from '../models/alocacao-filtro.model';
import { AlocacaoTecnico } from '../models/alocacao-tecnico.model';
import { AlocacaoConsulta } from '../models/alocacao-consulta.model';
import { AlocacaoCadastroTabela } from '../models/alocacao-cadastro-tabela';
import { CadastroAlocacao } from '../models/cadastro-alocacao.model.';

@Injectable()
export class AlocacaoService extends AbstractResource<any> {

  private baseEndPoint: string = '/manutencoes-corretivas-tecnicos';

  private baseEndPointPreventiva: string = '/manutencoes-preventivas-tecnicos';

  constructor(http: Http) {
    super(http, '');
  }

  public buscarAlocacaoManutencaoCorretiva(filtro: AlocacaoDetalharFiltro, params?: any): Observable<Pagina<AlocacaoDetalhar>> {
    return super.filter(this.baseEndPoint + '/pagina-listagem', filtro, params);
  }

  public buscarAlocacaoManutencaoPreventiva(filtro: AlocacaoDetalharFiltro, params?: any): Observable<Pagina<AlocacaoDetalhar>> {
    return super.filter(this.baseEndPointPreventiva + '/pagina-listagem', filtro, params);
  }

  public salvarParaAlocar(alocacao: AlocacaoTecnico): Observable<AlocacaoTecnico> {
    return super.post(this.baseEndPoint + '/tecnico', alocacao);
  }

  public filtrar(filtro: AlocacaoFiltro, params?: any): Observable<Pagina<AlocacaoConsulta>> {
    return super.filter(this.baseEndPoint + '/pagina', filtro, params);
  }

  public filtrarPreventiva(filtro: AlocacaoFiltro, params?: any): Observable<Pagina<AlocacaoConsulta>> {
    return super.filter(this.baseEndPointPreventiva + '/pagina-preventiva', filtro, params);
  }

  public filtrarTecnicosParaAlocacao(filtro: AlocacaoCadastroFiltro, params?: any): Observable<Pagina<AlocacaoCadastroTabela>> {
    return super.filter(this.baseEndPoint + '/pagina-tecnicos-cadastro-alocacao', filtro, params);
  }

  public salvarAlocacao(alocacao: CadastroAlocacao): Observable<CadastroAlocacao> {
    return super.post(this.baseEndPoint + '/alocacao', alocacao);
  }  

  public buscarTecnicosCorretivaAlocados(numeroSolicitacao: string, idPerfil: number, matricula: string): Observable<AlocacaoCadastroTabela[]> {
    return super.getList(this.baseEndPoint + '/tecnicos-alocado/' +  numeroSolicitacao + '/' + idPerfil, matricula);
  }

  public buscarTecnicosPreventivaAlocados(numeroSolicitacao: string, idPerfil: number, matricula: string): Observable<AlocacaoCadastroTabela[]> {
    return super.getList(this.baseEndPointPreventiva + '/tecnicos-alocado/' +  numeroSolicitacao + '/' + idPerfil, matricula);
  }

  public buscarManutencaoComPermissaoTecnico(matriculaTecnico: string, numeroSolicitacao: string): Observable<boolean> {
    return super.getOne(this.baseEndPoint + '/tecnico-disponivel-solicitacao/' + matriculaTecnico, numeroSolicitacao);
  }

  public excluirAlocacao(matriculaTecnico: string, numeroSolicitacao: string): Observable<boolean> {
    return super.getOne(this.baseEndPoint + '/exclusao-manutencao/' + matriculaTecnico, numeroSolicitacao);
  }

  public isPermitdoexcluirAlocacao(matriculaTecnico: string, numeroSolicitacao: string): Observable<boolean> {
    return super.getOne(this.baseEndPoint + '/pemitido-exclusao-alocacao/' + matriculaTecnico, numeroSolicitacao);
  }
}
